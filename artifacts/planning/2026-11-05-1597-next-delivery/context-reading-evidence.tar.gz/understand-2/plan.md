# Read-only execution plan: workflow-server PR #1641

Status: planning complete; Understand execution and its published architecture outcome are not performed.

## Captured identity

- PR: https://github.com/m2ux/workflow-server/pull/1641
- Repository: m2ux/workflow-server.
- Title: [I17:E01] Skill Style: The Groundwork for Prosiform Compliance.
- Captured head branch: i17/e01/workspace; head commit: dc1b274f9176a8d562ada4748c7bb89028532d1b.
- Captured base branch: workspace; base commit: 03d353300ca4804194fd50d316d73e3bf1270d1d.
- Capture reports open, draft=false, merged=false, mergeable=true, mergeable_state=blocked; updated_at=2026-11-05T15:44:46Z.
- Counts are metadata only: 23 commits, 67 changed files, 8,200 additions and 3,168 deletions. They supply no changed-path list, symbol graph or flow order.
- The body describes shared validation, instruction corpus and consuming readers. These are the author's claims, not independently measured component boundaries.
- Existing References R9 names an Architecture Overview at engineering/artifacts/planning/2026-11-05-1641-skill-style-groundwork/overview.md. R10 names integration-agent-review.json and R11 integration-validation.md in another planning record. Their content, accessibility, tested revision and evidence claims are unverified here.

## Route and scope

[SKILL](../project17-context-disclosure-final/source/skills/work-planner/SKILL.md) routes this request to [Understand](../project17-context-disclosure-final/source/skills/work-planner/modes/understand-mode.md), then [Change Overview](../project17-context-disclosure-final/source/skills/work-planner/protocols/change-overview.md).

Read-only work here consumes the frozen documents and supplied metadata and saves this plan and its receipts under /tmp/context-understand-2/. It does not call GitHub, fetch git refs, create worktrees, index or query a repository graph, populate a repository planning record, publish a record, or patch the PR. The full skill procedure includes those actions; listing them below does not execute or authorize them in this trial.

[Rules](../project17-context-disclosure-final/source/skills/work-planner/rules.md) distinguish input values, output results and callable operations by link title. Reading an operation or prerequisite is not running it. Calls must finish and return their result before their caller continues. Reuse complete prerequisites from the same revision; recover truncated reads. See read-account.md for the incomplete transitive prerequisite walk.

## Ordered evidence gates for a future full run

1. **Select the named PR.** Understand requires a supplied URL or number and would ask and stop if absent. This request supplies exactly #1641; no branch-based inference or initiative-wide account is needed.

2. **Read current PR metadata.** [Read Pull Request State](../project17-context-disclosure-final/source/skills/work-planner/artifacts/pull-request.md#read-pull-request-state) consumes repository-qualified Identity, Record Selection and Output Files. It calls Save Pull Request Snapshot, and Fetch Pull Request Files/Reviews only when selected, returning complete Pull Request Record and selected Changed Paths/Reviews or Failure. The supplied JSON is a captured record, not a live freshness check. A future authorized run must obtain current identity, title, body, literal head and base in the workflow-server project checkout. Before its first gh call, apply the session credential convention; gh resolves the repository from that checkout's remote.

3. **Establish an exact review checkout.** [Create Pull Request Worktree](../project17-context-disclosure-final/source/skills/work-planner/artifacts/delivery-branches.md#create-pull-request-worktree) consumes Project Checkout, Pull Request Number=1641 and the current Verified Head. In the project checkout it fetches the PR head, resolves FETCH_HEAD and compares that commit with the supplied head before creating anything. A changed head returns a finding; reread PR state and repeat with the new head. Review Worktrees names the default path .worktrees/pr/1641 under the repository's main working tree. An existing worktree is reusable only at that head, detached, with no tracked or untracked changes. Preserve a mismatching or dirty worktree and choose an unused path suffixed with the verified commit. Confirm HEAD again. Return Worktree Result with detached review path/head or Failure before measuring. No such checkout evidence is supplied here.

4. **Read changed paths after the checkout matches.** Call Read Pull Request State selecting changed paths, retaining every page from Fetch Pull Request Files. The capture's changed_files count cannot substitute. Preserve the actual diff and head-pinned source content necessary to explain changed behavior and line-anchored references; neither is supplied here.

5. **Measure that change in the review checkout.** [Measure Repository Change](../project17-context-disclosure-final/source/skills/work-planner/artifacts/repository-graph.md#measure-repository-change) consumes Review Checkout, Requested Revision=the verified head, and Base Branch=workspace, whose resolved comparison commit must remain identified.
   - Index Status reports the indexed revision. Index Repository is required if absent or behind; confirm freshness.
   - Change Surface uses detect-changes --scope compare --base-ref workspace. Its output supplies Changed Symbols and containing flow identities.
   - For every changed symbol, Symbol Context supplies callers, callees, containing flows and file locations.
   - For every reported flow, Flow Trace supplies ordered process_symbols with step_index, files and lines.
   - Inspect the staleness block of every response. Discard measurements from a behind index; index the verified head, confirm freshness and repeat the affected surface, symbol contexts and flow traces using the same base.
   - Changed revision requires fresh PR state and rebuilt worktree evidence. An unresolved freshness blocker must be returned before writing the overview.
   - Return Graph Measurements only when the measured revision, freshness, changed symbols, relationships and ordered traces meet the Repository Graph fields.

6. **Stop at the missing-evidence gate in this run.** No matching checkout, changed-path list, diff, index state, component relationships, symbol contexts or ordered flow traces were supplied or acquired. Do not draw a component diagram from directory names or infer sequence order by hand. The existing R9 link does not establish those measurements. No architecture overview, diagrams or code reading order can honestly be produced from this evidence.

7. **Conditional downstream authoring, outside this read-only trial.** Only after all previous gates pass:
   - Locate the existing overview record for PR #1641 before creating anything. R9 supplies a candidate identity, not a verified local record. Reuse its folder identity when found; otherwise choose a date/1641/title-slug folder.
   - [Populate Planning Record](../project17-context-disclosure-final/source/skills/work-planner/artifacts/planning-record.md#populate-planning-record) consumes Record Selection with record identity/folder, artifacts and external links, returning Planning Folder. Preserve existing creation date, other artifacts and links; create README from its template only for a new record. [Planning Records Configuration](../project17-context-disclosure-final/source/skills/work-planner/configuration.md#planning-records) places records under artifacts/planning/ on the engineering branch's one long-lived worktree.
   - [Populate Architecture Overview](../project17-context-disclosure-final/source/skills/work-planner/artifacts/architecture-overview.md#populate-architecture-overview) consumes Measurements, Pull Request Head with full-SHA code permalinks, and Overview File path. Check diagrams, populate the template, pin each code reference to the reviewed head and line anchors, and return Overview File. A repeat replaces only this overview and preserves the record's other content.
   - Required sections are Summary (at most three sentences), Structure, Behaviour, What Changed and Reading Order. Include a measured component diagram (or class diagram for a change confined to one area's types) and a sequence diagram for every reported flow. Add state diagrams for altered lifecycles and before/after pairs for structural or ordering changes. Use five to ten elements per concept, labeled directional edges, stable naming/colors, distinct changed elements and grey context. Keep the overview near 200 lines, diagrams included. The reading order starts at entry points and follows measured calls, links files at the exact head, and omits incidental files. Optional Risks/References disappear if empty.
   - Call Populate Planning Record again to register the overview as its Artifacts row and PR under Links. README inventories rather than duplicates artifact content. Preserve any other rows already present.

8. **Conditional publication, outside this read-only trial.**
   - [Publish Planning Record](../project17-context-disclosure-final/source/skills/work-planner/artifacts/planning-record.md#publish-planning-record) locates the engineering worktree, consumes Planning Folder and Commit Message File, commits/publishes via its nested operation, and returns Publication Result or a conflict/blocker. Its command stages the shared worktree, so a future run must understand that contract and confirm its own files reached origin/engineering. This run does not perform it.
   - After that URL resolves, [Link Architecture Overview](../project17-context-disclosure-final/source/skills/work-planner/artifacts/pull-request-body.md#link-architecture-overview) consumes Current Body, published Overview URL and Output Body destination, returning the complete Output Body file. Preserve the existing overview row when it already names this overview; #1641 already has R9, so avoid a duplicate. Keep other body content/references.
   - [Publish Pull Request](../project17-context-disclosure-final/source/skills/work-planner/artifacts/pull-request.md#publish-pull-request) consumes existing Identity, Repository and Selected Changes containing Body File, uses Patch Pull Request Body for this update, then Read Pull Request State again. Return the saved Pull Request Record or Failure and preserve fields not selected. Full-body writes pass through a file outside the repository. No retitle, retarget, merge, ready/draft transition or Development-link edit is implied by Understand.
   - Change Overview then returns PR identity, record folder, published overview, diagrams and References row to Understand; Understand reports them to the requester. Those outputs remain unavailable in this trial.

## Missing evidence and completion boundary

| Required result | Supplied here | Consequence |
| --- | --- | --- |
| Complete PR capture | Yes, one JSON snapshot | Identify the captured change only; live head stability unverified |
| Existing overview/review/verification contents | Links only (R9–R11) | Do not treat linked claims as inspected evidence |
| Current head and base in an exact clean detached checkout | No | Worktree freshness gate unresolved |
| Changed paths, diff and head-pinned source lines | No | No supported concrete code reading order or behavioral account |
| Index revision and every response's staleness | No | No current repository graph evidence |
| Changed symbols, relationships and ordered traces | No | No measured architecture or sequence diagrams |
| Existing record README and engineering publication state | No | No record reuse/publish result |
| Updated body file, publish and readback | No | No linked overview outcome |

The requested read-only plan is complete. The full Understand outcomes (a current measured account published and linked for the reviewer) are intentionally unfulfilled under the trial's evidence and execution restrictions.

