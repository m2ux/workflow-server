# Validation Plan

Status: proposed operations only. No checks below ran.

## Operations, Inputs and Outputs

| Operation or step | Inputs | Expected output |
| --- | --- | --- |
| Revise: Understand Request | Bounded clarification, proposed paragraph, source contract, user confirmation in a real implementation | Confirmed scope and file inventory |
| Revise: Work in Worktree | Actual project checkout, change branch, dedicated linked-worktree path | Isolated editable checkout; preserve existing work |
| Revise: Revise | Confirmed scope; shared and Work Planner guidelines read whole; Component's current conditions | One-home paragraph edit |
| Revise: Check Against Guidelines | Actual changed files, both guidelines, consumer inventory | Review findings resolved; links and anchors retained |
| Check Skill Files | Workspace = checkout containing installed scripts and sandbox; Skill Directory = `skills/work-planner` | Skill Check Result: checker output, finding count, exit status |
| Run Tests, conditionally | Workspace; executable-script, consumed-template or test changes | Test Result: output, exit status, skipped checks |
| Compare Section Bodies, conditionally | Workspace, affected Skill Directory, Base and Head revisions; moved sections | Section Comparison: counts, classifications, diffs; exit 1 means added/removed/differing |
| Disclosure verification | Representative bounded edit, affected consumers, actual required reads and receipt transcript | Structural read-path account; separate live evidence if applicable |
| Revise: Deliver, outside this exercise | Reviewed edit and completed required checks | Commits, plain push, changed-file report |

No actual Workspace, branch, worktree, Base or Head revision was established in this exercise. The frozen source is reference material, not an editable checkout.

## Proposed Sequence

1. Confirm the wording assumption and create a dedicated worktree in the real repository. Reuse complete guidelines only at the same verified revision.
2. Read the affected consumer guidance and complete the prerequisite requirements before claiming procedural compliance. Resolve the prerequisite fan-out/cycle described in the read account rather than assuming missing documents were read.
3. Change the phrase in Component's owning paragraph. Read the whole changed file against both guidelines; search for conflicting definitions and preserve all current conditions.
4. Check the declaration example and existing field links manually. Review a hypothetical `**Component:** workspace:skills/work-planner/artifacts/work-item.md` for one file and the named branch. A creation task still names its future file; a directory still fails the contract.
5. Run Check Skill Files in the actual workspace and preserve its result:

   `cd "<workspace>" && "<workspace>/scripts/sbx" python3 skills/scripts/check_skill_files.py skills/work-planner`

6. This pure paragraph edit changes no executable script, consumed template or test, so Revise's Run Tests trigger does not apply. Shared Changes/Verified nevertheless requires applicable skill and integration suites before a real delivery; conservatively include the existing skill suite if this wording ships:

   `cd "<workspace>/skills/work-planner" && "<workspace>/scripts/sbx" python3 -m unittest discover -s test`

   Record output, exit status and skips. Do not create tests that merely assert the new wording.
7. Compare Section Bodies is not selected: no section moves. SKILL.md frontmatter verification is not selected: SKILL.md is untouched. If scope changes, reconsider these conditions before retrieving or running their operations.
8. Trace the bounded Revise scenario through entry point, Rules, Conventions, Revise, both whole guidelines and necessary consumer context. Reuse common prerequisites at the same revision and record unrelated content, repeated reads and truncation. Fresh-context sub-agent live checks become required if reading paths change; this proposed wording does not change them. No token-saving claim is supported.
9. Resolve actual findings and report unavailable evidence. Only an authorized implementation may commit and push; this test saves the proposal and evidence only.

## Artifact Operation Distinction

Populate Work Item is a consumer operation, not an operation required to edit the Component definition. If later exercising it, its inputs are Task Context (task id, scope, epic context, design, component, criteria and test requirements) and Work Item File (local destination path). It returns the populated Work Item File and path for planning-record registration. This exercise only read its definition; it neither populated nor registered a work item.

