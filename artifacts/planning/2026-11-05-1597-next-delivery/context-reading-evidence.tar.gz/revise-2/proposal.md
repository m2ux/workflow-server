# Component Wording Proposal

Status: test proposal only; no source edit or procedure execution.

## Request and Scope

Clarify Work Item's Component wording in `skills/work-planner/artifacts/work-item.md#component`. The requested exact wording was not supplied; this proposal assumes the clarification concerns what the path identifies. A real edit should confirm that assumption in Revise's interview.

Revise is the relevant mode because the subject is the skill's own artifact contract. The word “proposal” does not require Propose mode or a GitHub proposal issue for this read-only exercise.

## Proposed Text

Keep the existing paragraph's declaration placement, syntax, branch link and example. Replace only “the path to it there” with “the repository-relative path to that file on that branch”.

The resulting paragraph would read:

> One declaration line ahead of the first heading, naming the single component the Implementation part extends as `<long-lived branch>:<path>`: the [long-lived branch](delivery-branches.md#branches) that holds it and the repository-relative path to that file on that branch, such as `workspace:skills/work-planner/scripts/deliver.py`.

This wording is a proposal, not applied source. The source already establishes one file per component, creation paths for new files, splitting implementations across components, and branch-driven base selection. Retain every one of those conditions.

## Ownership and Consumers

- Rule home: Work Item → Fields → Component. Preserve its heading and anchor.
- Work Item's Template and Sections already refer to the same component; their structure needs no change for this wording.
- Direct citation search found Delivery Branches, Delivery Plan, Dependency Graph and Sync. Their links continue to resolve; inspect their context during implementation without copying this definition into them.
- `scripts/deps.py` reads declarations and rejects directories/globs; `test/test_deps.py::DirectoryComponents` contains corresponding cases. These are consumer evidence, not changed files.
- Other search hits include delivery, dispatch and sync consumers. The broad content search was truncated; it is not a complete semantic audit.

## Proposed Acceptance

- Only the intended Component paragraph changes.
- Its path means a file on the named long-lived branch, from that repository's root.
- Declaration syntax, single-file identity, new-file treatment, splitting and branch selection remain stated.
- No new rule, executable behavior, file move, anchor or reading path is introduced.
- Review and required checks are reported with actual outputs and skipped checks.

