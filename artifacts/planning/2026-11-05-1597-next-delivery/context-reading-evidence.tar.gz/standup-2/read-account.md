# Read account

## Limits and preservation

The frozen skill was read from /tmp/project17-context-disclosure-final/source/skills/work-planner. Only /tmp/context-standup-2 was written. No GitHub, git, live checks, scripts from the skill, tracker mutation or snapshot change was executed. No memory or other repository skill was consulted.

receipts.json contains the initial 15 successful exec_command receipts: exact parameter objects and actual returned content/metadata. receipts-extra.json contains later successful reads. The first SKILL.md result was not placed in the orchestration store when returned; its metadata was transcribed from that result and its content recovered from the identical repeated cat read, explicitly marked in its receipt. This is a reconstruction, not an untouched captured object.

blocked-attempts.json records exact parameters for two read-only commands blocked before execution and the tool's rejection text. They produced no source evidence. A failed attempt to replace receipts.json using Delete and Add for the same file returned: "apply_patch verification failed: invalid patch: multiple operations target /tmp/context-standup-2/receipts.json". No update landed; later receipts are preserved separately.

## Actual reading path

1. Whole SKILL.md (4,586 characters); selected Standup. Repeated this later solely to reconstruct the initial receipt content; the repeat supplied no new task evidence.
2. One cat of rules.md, conventions.md and standup-mode.md, in that order. Full result: 2,205 original tokens. Filenames were not printed between the concatenated files; their own top-level headings identify boundaries. This is weaker boundary preservation than one result per file.
3. Seven separate cat calls for the mode's explicit whole-document prerequisites: board.md, sync-mode.md, pull-request.md, standup-report.md, issue.md, epic-issue-body.md and issue-body.md. All individual results returned successfully without inner truncation and are preserved exactly. The outer functions result was truncated: 47,655 original tokens. Thus a successful cat is not evidence that every returned byte reached the model.
4. Retrieved cached beginnings and lengths for those seven results, then replayed standup-report.md and sync-mode.md in full. This was cached recovery, not another filesystem read. Replayed exact focused operation/contract sections for board.md, issue.md and pull-request.md.
5. Read input byte lengths and SHA-256 hashes. Inspected a jq projection of items (first full item plus a mistaken top-level identity projection) and a PR metadata/key projection; read the complete links JSON. That outer response was also truncated (10,105 original tokens). Null top-level item identity values in the first projection reflect the wrong nesting, not unreadable issues.
6. Corrected the item projection to use content.* and fields[]. It showed 42 items, the one board URL, Status field 422017304, two repositories and no null content. This focused result was returned in full.
7. Attempted a configuration subsection read at heading level ### Standup. It returned no content because the actual heading is ## Standup. Used rg to locate headings, then a literal sed line range to read the section successfully. It states that the default window opens a week before today. The intermediate sed end-of-file range was blocked by a shell-policy false positive on literal $p; no content was returned from it.
8. Read hotfix-body.md and hotfix.md, first storing full results while returning only their beginnings, then replayed both cached full results. They add relevant hot-fix semantics but also expose unused creation/hold/mutation operations.
9. Read the captured body of workflow-server#1616 in full. Its Work Breakdown, links and checked criteria are source evidence, not a fresh validation result.

## Relevant recovered contracts

- Board: Select Project Board, Read Board State and fields Board State, Repositories, Board Coordinates and Selected Board.
- Pull Request: Fetch All Delivery Pull Requests, Fetch Repository Delivery Pull Requests, Append Repository Delivery Pull Requests, Fetch Linked Pull Requests, Fetch Pull Request Issue Links, Capture Pull Request Links, Read Initiative Pull Requests, and their relevant repository/list/issue/collection/link/authenticated-access contracts.
- Issue: Locate Initiative Issue, Read Tracker Issue, Fetch Tracker Issue, Issue Record.
- Full Standup Mode, Standup Report and Sync Mode documents; complete Hot-fix Body and Hot-fix documents.
- Repair Issue Format and related Issue Body material appeared in the initial broad output; its mutation boundary is recorded, not executed.
- A lookup for the misspelled heading "Issue Link Snapshot" in pull-request.md returned null. The actual "Issue-Link Snapshot" section was recovered afterward.

## Unrelated, repeated and incomplete material

- Explicit whole-document prerequisites returned large sets of unused operations: board creation/status mutation; PR merge/publication/review; issue writes; epic construction/delivery; body repair; hot-fix creation/holds. These were exposed by required whole documents and were not invoked.
- Sync Mode was read as a document. Its own prerequisites were not recursively loaded because the read-only task does not run Sync. In particular, no merge/closure/integration protocol was followed.
- The initial outer truncation was not fully recovered. Whole board.md, pull-request.md, issue.md and epic-issue-body.md were not fully replayed to the model; the account claims only recovered sections. Although full returned payloads are saved, whole-document model inspection remains incomplete.
- Artifact prerequisites not read include Delivery Branches, Agent Review and Hot-fix's further dependencies for pull-request operations; Requirement Characteristics for Issue Body; Lane, Epic, Dependency Graph and Delivery Plan for Epic Issue Body; Standalone Body and Board Queue for Hot-fix Body; Board Delivery, Placement and Repository Labels for Hot-fix. The source declarations remain recorded in the parent document payloads. Their recursive closure was not traversed.
- This means the plan is reviewable but not a claim of completed prerequisite loading for live execution. Before running a selected procedure, complete the applicable prerequisite reads and preserve heading boundaries. Do not turn optional conditional paths into executed work.
- Captured bodies beyond the specifically selected E01 table were not fully reviewed. No off-board initiative resolution, complete all-repository PR fetch, successful Development capture or freshness checkpoint is inferred.
- No report was rendered and no current standup or executed check is claimed.

## Captured input metadata

- /tmp/project17-handoff-items-raw.json: 722051 bytes; SHA-256 393d839d9e1ef4456e2b7f9f31b806929d8943afb08015fce0202095d88ad99d.
- /tmp/project17-integration-prs-ready.jsonl: 184728 bytes; SHA-256 ce12d217c0c4fd22f74ff6573165efcc92da2d7e301d06d9bc01cd35f996f6cb.
- /tmp/project17-integration-links.json: 978 bytes; SHA-256 b06a48b99ae118ebbeb0e806f48224e555e5c6e013af31492ab0df808b0990b1.

The timestamps and byte hashes identify the supplied local captures; they do not prove GitHub's present state or the capture procedure's completeness.

