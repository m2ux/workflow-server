# Read-only Project 17 standup execution plan

This is a plan from frozen files and supplied captures. No GitHub call, live check, delivery sync, report renderer, format repair, source edit or message publication was performed.

## Scope and available evidence

- Board: users/m2ux/projectsV2/17, established by all captured item project_url values; captured Status field 422017304.
- Requested scope is the whole board. No initiative filter was supplied. I17 is an initiative on Project 17, not the board's whole scope.
- 42 captured items, with complete-looking nested issue objects and Status fields; repositories m2ux/workflow-server and m2ux/prosiform-skills. The local projection found no null content. This does not establish complete pagination, freshness or every field's validity.
- The capture contains I11, I16, I17 and hot-fixes. I17 issue 1597 is In Progress; E01 issue 1616 is In Progress; E02 issue 1615 is Backlog; E03 issue 1625 is Done and closed 2026-11-05T07:23:48Z.
- The PR capture is nine REST-shaped records, all for workflow-server I17 E01: eight task PRs are merged into i17/e01/workspace, and integration PR 1641 is open into workspace. Its head is dc1b274f9176a8d562ada4748c7bb89028532d1b. This says nothing about present-day review readiness.
- The captured E01 Work Breakdown is readable, links all eight task PRs and ticks all rows. All captured acceptance criteria are ticked. This does not close the open integration PR or establish independently verified delivery.
- The link array supplies one entry for each of those nine PRs. Eight arrays are empty; PR 1641 links issue workflow-server#1616. Empty arrays are captured values, not proof that relations were successfully read.
- Input hashes, exact returned local projections and their metadata are in receipts.json and receipts-extra.json.

## Prerequisites and decision points

- No saved delivery results/current-board checkpoint was passed. Standup step 2 therefore regards selected initiatives as needing refresh and calls Sync Mode.
- Sync writes issues, board state and potentially PR metadata, merges and closure records. The current task expressly forbids executing it. Preserve this as a freshness blocker; do not silently skip it and call a report current.
- A full-board PR collection is unavailable: the nine supplied records cover one epic only, with no prosiform-skills collection and no evidence of all title-matched and plan/Development-linked PRs. Repository collection order also needs the board's own repository, which these projected captures do not establish.
- The nine-entry links array is structurally sufficient for the nine supplied PR identities. There is no successful capture receipt establishing full relation pagination and no links for the missing full-board PR collection. A failed or unreadable relation must block composition, not become an empty array.
- No window start or initiative filter was supplied. Configuration says the default starts one week before today. For a reproducible report anchored to the supplied session date 2026-11-05, propose --since 2026-10-29, all initiatives. A later execution must preserve the selected date explicitly rather than drift with its run date.
- Live execution requires authenticated tracker access, actual project checkout identity, board identity/title and primary repository, scripts plus sandbox availability, complete paginated fetches and provenance, saved sync results, and any off-board initiative JSON the renderer identifies. None was obtained live here.
- Finish the outstanding source prerequisites described in read-account.md before executing affected operations. This plan does not claim a complete prerequisite closure.

## Planned operations and contracts

| Order | Operation | Named inputs supplied or required | Provided output / stop condition |
| --- | --- | --- | --- |
| 1 | Select Project Board -> Find Theme Board | Board owner m2ux; requested Project 17; matching theme name/title if the selection path requires it | Selected board number, or missing/absent selection. Captured board URL establishes number 17; live selection is unperformed. No creation is authorized. |
| 2 | Read Board State -> Find Status Field, Fetch Board Items with Status | Board Coordinates owner m2ux, number 17; destination items path; fetched Status field id | Board State: items with complete issues and Status, field/item ids, repositories and unreadable-issue findings. Capture is a historical candidate, not a fresh result. |
| 3 | Follow Sync Mode for initiatives of unknown freshness | Selected initiative/epic scope, project checkout, current issues, delivery PRs, complete links, revision-bound criterion evidence and authenticated access | Saved delivery results and unresolved findings. This call is required by the missing checkpoint and is held because it exceeds this read-only task. Its own prerequisites load only if that call actually runs. |
| 4 | Read Board State again after saved delivery results | Same selected board, fresh destinations | Current board snapshot and repository list for the reporting fetch; retain freshness blockers if unavailable. |
| 5 | Fetch All Delivery Pull Requests | Ordered Repository List, Collection Path, Issue Records (board entries containing complete issues), Workspace, authenticated access | Fresh first repository collection; append remaining repository collections; include every Work Breakdown/Development-linked PR regardless of title. Complete JSONL REST records with repository identity and html_url, or incomplete-evidence Failure. Stop on first initial fetch failure. |
| 6 | Fetch Pull Request Issue Links -> Capture Pull Request Links | Current complete PR records, authenticated access, Link-Snapshot Path, Workspace | Complete Issue-Link Snapshot, one entry per PR with all linked issues' repository/number; empty list only when successfully observed. Any unreadable relation yields Failure and no usable snapshot. Refresh after changes. |
| 7 | Compose Standup Report -> Summarise Progress, preliminary pass | Board Items paginated snapshot path; complete PR JSONL path; complete link JSON path; Report Selection date/filter; resolved off-board Initiative Records; report/paragraph Output Paths; Workspace | Preliminary report and unresolved findings. Complete link evidence is required before composing. No rendering was performed here. |
| 8 | Locate Initiative Issue -> Find Initiative Issue; Read Tracker Issue -> Fetch Tracker Issue | Each unresolved repository-qualified initiative prefix; Identity and Repository; output issue JSON path; discussion selection only if needed | Tracker number or unresolved identity, then complete current issue JSON. Unavailable records remain reported gaps. Repeat compose with every resolved record and the same other inputs. |
| 9 | Write management paragraph; final Summarise Progress | Preliminary Initiatives + Completed sections; paragraph file; same inputs/date/filter and all resolved records | One paragraph of completed outcomes only, without references, links, ids or tools. If nothing completed, one sentence says so. Final report plus separate unresolved findings. |
| 10 | Report | Final Report Result | Present report verbatim in a fenced block for pasting, with unresolved evidence outside. No Slack send is authorized or planned. |
| conditional | Repair Issue Format | Epic identity/current JSON; epic template and field conditions; related evidence; output body path | Saved correction flag, saved Body Evidence and Format Findings, or blocker/no correction. This can publish and is outside scope here. If a future authorized correction is saved, repeat fetch/compose/report; otherwise retain the finding without repeated repair. |

## Future command shapes, not executed

Run tracker calls in the actual project checkout after applying the session token convention. Use the captured field id only as a historical hint; resolve it live before a current fetch.

- Board field: gh api --paginate "users/m2ux/projectsV2/17/fields?per_page=100" --jq '.[] | select(.name == "Status") | .id'
- Board items: gh api --paginate "users/m2ux/projectsV2/17/items?per_page=100&fields=<resolved-status-id>" > <new-items-path>
- Initial repository collection: gh api --paginate "repos/<first-owner>/<first-repo>/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I") or startswith("[F"))' > <new-prs-jsonl>
- Remaining repositories use the same query and append to that collection.
- From the Workspace checkout, outside sbx because it calls gh: python3 skills/work-planner/scripts/linked-pull-requests.py --prs <new-prs-jsonl> --issues <complete-board-issue-records-or-board-items>
- From the Workspace checkout, outside sbx: python3 skills/work-planner/scripts/links-by-pull-request.py --prs <new-prs-jsonl> --out <new-links-json>
- From Workspace, for preliminary and final report respectively:
  - <workspace>/scripts/sbx python3 skills/work-planner/scripts/progress.py --items <new-items-path> --prs <new-prs-jsonl> --links <new-links-json> --since 2026-10-29
  - Same command plus --initiatives <resolved-initiative-files> when needed, then --summary <management-paragraph-path> for the final pass.
- Read an unresolved issue from its own repository: gh api repos/<owner>/<repo>/issues/<issue-number> > <issue-json-path>.

The placeholders are required inputs, not prepared runnable commands. Store report and paragraph outputs outside the frozen snapshot; do not overwrite the captures.

## Report semantics to preserve

- Board Status determines grouping. Completed includes Done issues closed in the window and task PRs merged in it. A merged task PR is distinct from completed epic integration.
- In progress shows In Progress/In Review epics and In Progress task issues with open PRs or next tasks. E01's captured state is In Progress.
- Next contains the first five Ready items plus a remainder count; ready hot-fixes lead and supplier dependencies precede consumers. No queue advancement occurs.
- Hot-fixes appear in the relevant sections without an initiative filter. Their delivering PR must have the matching prefix/repository, current target base and Development issue link.
- Missing off-board initiatives, blocked dependencies and unreadable Work Breakdown tables remain findings. Only E01's captured table was specifically inspected here; no claim is made about every other table.
- The requested artifact is this execution plan, not a completed or current standup. Execution remains unperformed by design.

