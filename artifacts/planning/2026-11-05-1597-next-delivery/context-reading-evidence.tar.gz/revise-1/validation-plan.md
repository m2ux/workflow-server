# Component Validation Plan

## Authority

Everything below is prospective. This run only reads the frozen snapshot and writes its report files. Source edits, worktree creation, GitHub operations, checks, commits and pushes require a later implementation task.

## Inputs and Outputs

| Operation or review | Inputs | Provided result |
| --- | --- | --- |
| Revise / Understand the Request | The proposed wording, scope, rule home, complete applicable guidelines, consumer discovery | Confirmed scope and the files an implementation will touch |
| Revise / Work in a Worktree | Actual project checkout, approved change branch and dedicated linked-worktree path | Isolated working checkout; preserve unrelated project-root edits |
| Revise / Revise | Confirmed paragraph, owning Component definition, its consumers | One edited definition; other files link to its home if needed |
| Revise / Check Against the Guidelines | Every changed file; whole shared and skill guidelines | Reviewed diff and corrected departures |
| Check Skill Files | Workspace: checkout containing installed skill/scripts/tests; Skill Directory: `skills/work-planner` | Skill Check Result: checker output, finding count and exit status |
| Run Tests, when selected | Workspace with the skill's existing tests and sandbox helper | Test Result: output, exit status and any skipped checks |
| Compare Section Bodies, only if sections move | Workspace, all affected Skill Directory values, actual Base and Head revisions | Section Comparison: counts, classifications, differences and exit status; exit 1 means added/removed/differing sections |
| Disclosure verification | Representative request, affected required-read paths, prerequisites and consumers, captured receipts | Structural findings; independent live behavior findings only if actually exercised |
| Populate Work Item, only as a future specimen operation if needed | Task Context: id, scope, epic context, design, component, criteria and test requirements; supplied Work Item File path | Populated Work Item File and its path for registration |
| Revise / Deliver | Validated change and evidence | Committed and pushed change, per-file change report |

Populate Work Item is a consumer operation, not the operation that edits this skill definition. No work item needs to be created to clarify its field prose.

## Sequence

1. Confirm the bounded wording and actual implementation checkout. Read the shared and skill guidelines whole at that revision and inspect prerequisites before supporting sections. Reuse complete same-revision context.
2. Refresh consumer discovery for the exact field link and declaration string. Review necessary definitions, consumers, docstrings and tests; record the actual affected set. Resolve any required prerequisites. Do not execute referenced delivery or tracker procedures merely because they are read.
3. Establish the dedicated worktree on the correct change branch under the implementation workspace's conventions. The frozen snapshot is evidence and is never the implementation checkout.
4. Edit the one paragraph. Review the diff against the acceptance list in the proposal and the applicable layout, prose, ownership, link and command rules. Search for contradictory or stale descriptions if the final scope changes behavior.
5. Resolve the existing links `delivery-branches.md#branches`, `delivery-branches.md#task-branches`, `work-item.md#component`, and the Populate Work Item input/output contracts. This report inspected definitions and links but ran no comprehensive link checker.
6. Run Check Skill Files for the affected skill. The documented invocation, after replacing the placeholder with the actual absolute checkout, is:

   `cd "<workspace>" && "<workspace>/scripts/sbx" python3 skills/scripts/check_skill_files.py skills/work-planner`

   Preserve output, finding count, exit status, exact invocation and tested revision. The documented helper and checker paths were not verified for existence or executability in this run.
7. Select tests before retrieving or executing further specs. The proposed edit is outside the template fence and changes neither an executable script nor a consumed template nor a test, so Revise step 6's conditional Run Tests call is not triggered by that category. The shared guidelines' Verified rule nevertheless requires skill tests and affected checker/integration suites to pass before committing. To meet that broader gate, plan the documented skill suite and determine which additional suites are actually affected:

   `cd "<workspace>/skills/work-planner" && "<workspace>/scripts/sbx" python3 -m unittest discover -s test`

   Preserve the Test Result, revision and skips. Existing DirectoryComponents and ComponentContention tests are relevant regression evidence if the implementation reaches them; their source presence is not a pass result.
8. Select conditional checks explicitly. SKILL.md frontmatter verification is inapplicable if SKILL.md is untouched. Compare Section Bodies is inapplicable if no section moves. If either condition changes, follow the corresponding complete operation with its named inputs and retain the result. The comparison operation's Base and Head are actual revisions, not arbitrary frozen-directory names.
9. Trace the representative bounded revision request through entry point, Rules, Conventions, Revise, whole guideline files, the changed artifact and affected consumer guidance. Resolve prerequisite cycles by reusing complete content at the same revision; do not treat an unread prerequisite as supplied. Inspect supported entry paths and keep unrelated guidance out of conditional reads where the structure permits.
10. The current proposal changes no reading path, so fresh-agent live checks are not triggered by that condition. If implementation changes links, prerequisites or reading boundaries, give independent fresh readers realistic tasks and authority limits, repeat affected scenarios, and retain actual tool calls, returned content, truncation, unnecessary/repeated reads and task outcomes. Do not infer consistent behavior or context-token savings from this single read account.
11. Record check findings and evidence gaps. Resolve departures before delivery. Commit distinct changes and push with plain `git push` from the owning worktree only in the authorized implementation run. Report changed files and actual verification, separating local checks from external workflow execution.

## Current Evidence Limits

No check in this plan has run. No actual edited revision, Base/Head pair, worktree, branch configuration, tracker state, publication link, complete consumer-mode trace or complete prerequisite closure was supplied or validated. The main entry point has an observed hash in receipt 03; that is not a whole-tree immutability proof.

