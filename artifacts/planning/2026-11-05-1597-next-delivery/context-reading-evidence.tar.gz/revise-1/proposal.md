# Component Wording Proposal

## Status

Read-only test proposal. No source edit, tracker access, procedure execution, test execution, commit or push occurs in this run.

## Request and Assumption

Clarify how a reader interprets Work Item's Component declaration while preserving its present contract. The task supplies no exact replacement wording; the paragraph below is a recommendation for review, not an approved edit.

## Procedure and Rule Home

Select Revise from the frozen skill's entry point, not Propose: the subject is the skill's own files. The owning definition is `skills/work-planner/artifacts/work-item.md#component`. Revise requires Rules, Conventions, the whole shared guidelines and the whole skill guidelines before editing, then scope discovery, a dedicated worktree, one rule home, guideline review, verification and delivery.

## Proposed Text

Replace only the opening paragraph under `### Component` with:

> One declaration line ahead of the first heading names the single component the Implementation part extends, in the form `<long-lived branch>:<path>`. The prefix names the [long-lived branch](delivery-branches.md#branches) that holds the component; the path locates the component on that branch, such as `workspace:skills/work-planner/scripts/deliver.py`.

Keep the four existing bullets in that section. They govern component creation, selection of epic bases, splitting a task that extends several components, and the one-file restriction.

## Bounded Scope

One prose paragraph changes. The Component heading, declaration syntax, template fence, operation contracts, example value, branch-selection rule, task-splitting rule, and dependency-check semantics retain their meanings. No parser, template or test modification is proposed. The target wording adds no requirement that a branch exists locally or that a file already exists; a task creating a component still names its future path.

The proposal does not establish that the source has a defect. Its purpose is to make the prefix/path distinction explicit for a reader.

## Consumers to Review

- Populate Work Item in the same artifact consumes Task Context and a Work Item File destination, writes the template under Identity, Sections, Component and Test Coverage, and provides the populated path for registration.
- Plan passes task scope, design, implementation component, criteria, test requirements and the record-folder output path.
- Deliver passes the reserved file path and the confirmed delivery brief's scope, design, component, criteria and test requirements.
- Delivery Branches / Task Branches uses the declared long-lived branch to select a unit's epic base.
- Delivery Plan / Work Units uses declarations from linked work items in the engineering worktree to select bases in an epic with several bases.
- Dependency Graph uses component identity for cross-epic contention and same-epic candidate units.
- Sync confirms a finding's base against the long-lived branch in Component.
- `scripts/deps.py` reads and normalizes the declaration; `test/test_deps.py` contains directory rejection and contention cases. These are inspected source, not executed results.

Receipts 05 and 17 identify these consumers. Full consumer-mode procedures and their prerequisite closures were not read; this is discovery evidence, not a complete cross-mode validation.

## Acceptance for a Future Edit

- Only the proposed paragraph differs.
- A reader can identify which text names the branch and which names the component's path.
- Every current Component condition remains stated at its existing home.
- Existing consumer links still resolve to the Component heading.
- Guideline review, required local checks and disclosure evidence are recorded against the edited revision before delivery.

