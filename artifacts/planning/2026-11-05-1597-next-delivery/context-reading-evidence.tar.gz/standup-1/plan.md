# Project 17 standup: read-only execution plan

This is an offline plan, not an executed Standup run or a current standup. No GitHub access, live checks, delivery sync, rendering, issue repair, or source modification occurred.

## Scope and captured evidence

- Board identity is evidenced by every captured item: user m2ux, Project 17, https://github.com/users/m2ux/projects/17. The captured Status field id is 422017304.
- No initiative filter was requested. Plan for the complete board, including hot-fixes. Project 17 is not initiative I17.
- No window was requested. Configuration's Standup section says the default starts one week before today. With the supplied environment date 2026-11-05, use 2026-10-29 explicitly for reproducibility; this is a planned choice, not a renderer result.
- Board snapshot: 42 items, 30 Done, 2 In Progress, 10 Backlog. All have an issue, body, and Status in the captured data. Repositories are m2ux/workflow-server and m2ux/prosiform-skills.
- The captures do not identify the board's own linked repository or title. Repository collection ordering must put that repository first; do not infer it from the first item, which belongs to prosiform-skills.
- PR capture: nine complete-looking REST objects, all workflow-server I17 E01. Eight task PRs are merged; integration PR #1641 is open and ready, from i17/e01/workspace to workspace. Captured state does not establish required approvals, check results, or live readiness.
- Links capture: nine entries matching those PR identities, eight complete-looking empty closingIssuesReferences arrays and #1641 linking workflow-server#1616. Empty captured arrays are data; provenance proving that every relation page arrived is absent.
- Board items include I11, I16, I17, and F00–F07. Thus these nine PRs do not satisfy Fetch All Delivery Pull Requests for this board. For a concrete missing set, the captured Delivery Lanes epic #1625 links #1626, #1628, #1629, #1632, #1633, #1634, #1635, #1637, and #1638, none in the PR file. This also prevents claiming complete I17-only delivery coverage.
- Snapshot #1616 remains In Progress even though its rows and criteria are ticked and its integration PR is ready. Standup follows Status; it cannot promote that item to In Review by inference.
- Original inputs are copied byte-for-byte under evidence/. The source tree is untouched.

## Operation sequence and contracts

| Step / operation | Named inputs to provide | Expected result / gate |
| --- | --- | --- |
| Select Project Board | Board Owner m2ux, requested board 17; if the selector insists on Board Selection theme, obtain board title/theme metadata first | Selected Board 17, or missing-selection/absent-board result. Existing project_url establishes coordinates but is not a captured selector response. Do not create a board. |
| Read Board State (missing-checkpoint path) | Board Coordinates m2ux/17, output paths; Find Status Field then Fetch Board Items with Status | Board State: complete issue-bearing items, Status field and item ids, ordered Repositories, unreadable findings. Captured items are an offline candidate, not a successful fresh call. |
| Refresh Selected Initiatives / Sync Mode | Selected initiative identities and current issue JSON, complete delivery/link evidence, project checkouts and fetched epic bases, criterion instruments/evidence, authenticated access, board identity, output files and session auto-close prerequisite where writes apply | Saved delivery results plus current board state and unresolved findings. No delivery checkpoint was passed into this task; freshness is unknown for the selected initiatives. Sync can save bodies, links, merges, closures, board statuses and overviews, so it is outside this read-only task. Report this as the blocker to a current summary, retain it as a partial-report gap. |
| Read Board State after refresh | Same selected board identity | Post-sync Board State passed into all following operations. Do not compose from pre-sync items after a successful sync. |
| Fetch All Delivery Pull Requests | Repository List from Board State, Issue Records containing all board issues, Collection Path | Fresh title-matched initiative/hot-fix collection from the first repository; append other repositories; Fetch Linked Pull Requests adds all row- or Development-linked PRs whatever their title/repository. Any failed fetch returns incomplete evidence, never a complete collection. Requires capture of issue Development relations, not merely PR closing references. |
| Fetch Pull Request Issue Links | Complete Pull Request Records, Link-Snapshot Path, Workspace, Authenticated Access | Capture Pull Request Links provides one entry per PR and all closing issue references/pages. Unreadable or missing pages are blockers; no partial successful snapshot. Re-capture after link changes. |
| Compose Standup Report, first pass | Board Items, complete Pull Request Records (JSONL), complete Issue Link Snapshot, Report Selection (since 2026-10-29, no initiative filter), Initiative Records if supplied, Output Paths | Require complete links; Summarise Progress renders initial sections; return unresolved initiative references with repository/number. No management paragraph on the first renderer invocation. |
| Resolve Evidence | For each unresolved initiative: Repository and Tracker Prefix to Locate Initiative Issue; then Identity and Output Files to Read Tracker Issue for complete current JSON | Located Tracker Number / unresolved identity and Issue Record. Accumulate each resolved off-board record as a separate file. Re-run Compose with the same board/PR/link snapshots, selection, output paths and all resolved records. Unavailable records remain separate gaps. |
| Compose management paragraph and final pass | First rendered Initiatives and Completed sections; local Management File; unchanged report inputs, including all resolved initiative records | One plain-language outcome paragraph grounded only in completed work, with no links, ids, tool names, in-progress or next work. If none completed, say so in one sentence. Final Summarise Progress adds --summary and provides Report Result: copyable report plus separate unresolved findings. |
| Report | Provided Report Result | Present report verbatim in a fenced block and unresolved findings below it. No Slack send is authorized. |
| Conditional Repair Issue Format | Only when Compose returns an unreadable epic Work Breakdown: epic Identity, complete Body Record, Kind Conditions from Epic Issue Body template/fields, related evidence, Output Files | May validate, save mechanical corrections, obtain content decisions and re-read/validate saved issue. This task forbids mutations, so return a repair-needed gap. If separately executed and it confirms a saved correction, refetch and repeat Standup steps 3–6; blocker/no correction does not loop. |

## Offline composition invocation, only after evidence gates

The frozen source provides progress.py's contract but the snapshot has no scripts/sbx. The installed workspace and sandbox prerequisite must be supplied and verified before using this command. No renderer has been run here.

Initial invocation template, from the supplied installed workspace checkout:

    <workspace>/scripts/sbx python3 skills/work-planner/scripts/progress.py --items /tmp/project17-handoff-items-raw.json --prs <complete-board-prs.jsonl> --links <complete-board-links.json> --since 2026-10-29

Save stdout at the caller's report path and retain findings separately. Supply resolved off-board files via --initiatives <file1> <file2>. Final invocation retains the same inputs and adds --summary <management-paragraph.txt>. Do not add an empty --initiative or --initiatives argument. Do not substitute the narrow nine-PR file for a complete board collection.

## Report behavior to preserve

- Management paragraph followed by Initiatives, Completed, In progress, Next, Hot-fixes in the appropriate status sections, and Key; board link beneath heading.
- Completed uses Done items closed within the window and tasks whose delivering PRs merged within it. Later board catch-up does not shift an issue's completion date.
- In progress uses epic In Progress/In Review and task In Progress; show open PRs or the next task.
- Next offers five Ready items and remaining count, hot-fixes first, initiative then epic priority labels, supplier epic before a dependent epic. The captured board has no Ready item; that describes this snapshot only.
- Off-board initiatives use their resolved JSON; cross-repository relationships follow Work Breakdown/Development evidence, not prefix uniqueness.
- Unresolved off-board dependencies are blocked. Unreadable epic Work Breakdown yields an epic summary without tasks plus a separate finding.

## Missing prerequisites and deliverables

A fully current standup is blocked by the absent saved delivery checkpoint, unproven board/collection capture completeness and freshness, incomplete board-wide PR coverage, missing issue-Development capture, and missing authentication/current project-checkout evidence. No live permissions, auto-close setting, branch requirements, tests, or fetched revisions were inspected. Those are needed only on their corresponding future operation paths, not to prepare this plan.

The frozen snapshot's sandbox helper is absent. Recursive artifact prerequisites were identified but not fully read; see read-account.md. Sync's own prerequisite expansion is deferred because Sync is not executed, as Rules explicitly permits for a mode read as a prerequisite. A future execution must satisfy its selected branches' prerequisites before running them.

Provided now: this plan, read-account.md, raw tool receipts, copied captured inputs, and source-hash manifests. Not provided: a rendered report, successful sync checkpoint, live board state, criterion verification, repaired issue, or GitHub mutation.
