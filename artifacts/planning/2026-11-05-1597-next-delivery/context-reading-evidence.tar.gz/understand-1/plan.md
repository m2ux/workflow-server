# Read-only execution plan: workflow-server PR #1641

Status: plan complete; architecture overview unavailable because repository measurements were not supplied. No protocol operation was executed.

## Captured identity

- Pull request: https://github.com/m2ux/workflow-server/pull/1641
- Title: [I17:E01] Skill Style: The Groundwork for Prosiform Compliance
- Repository: m2ux/workflow-server
- Captured head: i17/e01/workspace at dc1b274f9176a8d562ada4748c7bb89028532d1b
- Captured base: workspace at 03d353300ca4804194fd50d316d73e3bf1270d1d
- Captured updated_at: 2026-11-05T15:44:46Z; open, draft=false, merged=false, mergeable_state=blocked.
- These are snapshot facts, not live verified state. The merge_commit_sha field is not delivery proof while merged=false.
- The body claims shared validation, instruction-corpus and consuming-reader changes. These claims are leads for examination, not measured architecture.

## Entry and reading rules

Use [Understand Mode](/tmp/project17-context-disclosure/source/skills/work-planner/modes/understand-mode.md), selected after Rules and Conventions. A PR URL is supplied, so no identity interview is needed. Understand calls [Change Overview](/tmp/project17-context-disclosure/source/skills/work-planner/protocols/change-overview.md); it does not call Deliver, Sync, agent review or merge.

A link title identifies input, output or operation. Read a heading-linked section plus its subsections until the next heading of equal or higher level. Load the owning file's Prerequisites before using a linked section; reading an operation never invokes it. Calls pass named inputs and finish before their callers continue. Reuse complete reads at the same revision and recover display truncation.

The protocol's six whole-document prerequisites are Pull Request, Delivery Branches, Repository Graph, Planning Record, Architecture Overview and Pull Request Body. Their prerequisite declarations add Issue, Agent Review, Hot-fix, Work Item, Issue Body and Planning Records Configuration; Issue Body adds Requirement Characteristics. Some of these documents contain broad unrelated operations. The read account identifies the uncompleted transitive Hot-fix prerequisite expansion.

## Required execution order for a future authorized Understand run

1. **Acquire current PR evidence.** Read Pull Request State for identity m2ux/workflow-server#1641, selecting complete metadata and explicit output destinations. It delegates to Save Pull Request Snapshot; output is the complete REST record or an explicit Failure. Preserve literal head and base identity. Session credentials and repository checkout must meet Conventions before any future gh call.
2. **Obtain matching review checkout.** Create Pull Request Worktree with the workflow-server project checkout, number 1641 and verified head. Fetch Review Head, resolve FETCH_HEAD, and compare it with the supplied head before worktree creation. On changed head, return to Read Pull Request State and repeat with the new SHA. The normal location is the main working tree's .worktrees/pr/1641. Reuse only an exact-head, detached, clean checkout including no untracked changes; retain a mismatching/dirty checkout and select an unused path suffixed with the verified commit. Confirm selected HEAD. This step creates/fetches local state and is excluded from this exercise.
3. **Read changed paths.** Once the review checkout matches, call Read Pull Request State again with changed-path record selection. Fetch Pull Request Files obtains every page. The snapshot's changed_files=67 is only a count and cannot provide this output.
4. **Measure the change.** Measure Repository Change with the returned review checkout, verified head and supplied base workspace. All graph commands act in that review checkout. In order: Index Status; Index Repository if absent/stale, then freshness confirmation; Change Surface against workspace with --base-ref; Symbol Context for each changed symbol; Flow Trace for every reported flow. Preserve each response's checkout/indexed revision and staleness block, symbol locations, callers/callees, containing flows and process_symbols step_index/file/lines.
5. **Resolve revision and freshness failures.** Discard measurements from a behind index, update it at the verified head, and repeat every discarded surface, affected symbol and flow call. The protocol also explicitly repeats Measure Repository Change after stale-index evidence. A changed revision requires a fresh Read Pull Request State and rebuilt worktree evidence. Return any unresolved freshness blocker before writing. A captured head alone does not establish current graph freshness.
6. **Locate the existing record before choosing a folder.** The captured body already has R9 Architecture Overview pointing to artifacts/planning/2026-11-05-1641-skill-style-groundwork/overview.md on engineering. Read/confirm that record's identity and README before any future population. Reuse its folder identity and existing overview file when confirmed, preserving its creation date, unrelated artifacts and links. If absent, compose a new date-1641-title-slug folder under the configured artifacts/planning directory.
7. **Populate only from measured evidence.** Populate Planning Record prepares the selected engineering-branch folder and README. Populate Architecture Overview consumes measured relationships/symbols/ordered flows, full verified PR head and pinned code references, plus the overview destination. It returns the completed local overview file. Repeated execution replaces that overview and preserves the record's other content.
8. **Register the output.** Populate Planning Record again with record identity/folder, overview file and PR URL. The overview has one Artifacts row; the PR belongs under Links. README is mandatory, other artifacts are registered when produced.
9. **Publish and link only in an authorized mutating run.** Publish Planning Record locates the single engineering worktree, commits/pushes the record and confirms its files reached origin/engineering. A rebase conflict is reported. Link Architecture Overview consumes the current complete body and published URL, writing a complete output body. Preserve the existing R9 row when it already names that overview; use the engineering-artifacts URL. Publish Pull Request updates only the selected existing body via Patch Pull Request Body, then rereads saved PR state. Preserve other PR fields. These are recorded contracts, not actions authorized or taken here.
10. **Report the returned result.** Understand reports PR, record folder, published overview, diagrams and References row. With present evidence, report the missing measurements rather than claiming those outcomes.

## Linked operation contracts

All links below are to the frozen source.

| Operation | Required named inputs | Returned evidence/output |
| --- | --- | --- |
| [Read Pull Request State](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/pull-request.md#read-pull-request-state) | Identity, Repository, Output Files; Record Selection for changed paths or reviews | Pull Request Record, Changed Paths and Reviews as selected; Failure for missing evidence |
| [Create Pull Request Worktree](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/delivery-branches.md#create-pull-request-worktree) | Project Checkout, Pull Request Number, Verified Head; composed lasting Worktree Path | Worktree Result naming detached checkout and head, or discrepancy/Failure |
| [Measure Repository Change](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/repository-graph.md#measure-repository-change) | Review Checkout, Requested Revision (verified head), Base Branch; changed symbol and flow identities from surface | Graph Measurements: revision/freshness, changed symbols, relationships and ordered flow traces; or freshness blocker |
| [Populate Planning Record](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/planning-record.md#populate-planning-record) | Record Selection: identity, folder, supplied artifacts and external links; engineering checkout for creation | Planning Folder with README and registered artifact inventory |
| [Populate Architecture Overview](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/architecture-overview.md#populate-architecture-overview) | Measurements, Pull Request Head with pinned code links, Overview File destination | Completed Overview File |
| [Publish Planning Record](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/planning-record.md#publish-planning-record) | Planning Folder, Project Checkout for worktree discovery, Commit Message File | Publication Result confirming remote branch/files, or conflict/blocker |
| [Link Architecture Overview](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/pull-request-body.md#link-architecture-overview) | Overview URL, Current Body, Output Body destination | Complete updated Output Body for publication |
| [Publish Pull Request](/tmp/project17-context-disclosure/source/skills/work-planner/artifacts/pull-request.md#publish-pull-request) | Existing Identity, Repository, selected body file/Selected Changes; output paths for readback | Saved Pull Request Record, or discrepancy/Failure |

Read Pull Request State may request reviews, but Understand does not require merge-readiness or approval evidence as a separate step. The Verified Head field in Pull Request is defined using current checks/target requirements; the captured metadata does not satisfy that stronger definition. Preserve that verification gap rather than assuming the head is fully verified.

## Eventual overview requirements

- Summary: at most three sentences; required Structure, Behaviour, What Changed and Reading Order sections.
- Structural diagram: measured component areas/edges, or a class diagram when the change fits one area and its types.
- Functional diagrams: one sequence per measured flow; lifecycle changes warrant a state diagram; structural rearrangement or flow reordering warrants before/after diagrams.
- Five to ten elements per concept; distinct fill for changed elements, grey context, consistent names/colors, labelled directed edges.
- Measured graph relationships establish boundaries and edges; directory layout and manually traced order do not.
- Code references use full-head commit permalinks with line anchors. Reading order starts at the entry and follows calls, one reason per file, omitting incidental files.
- About two hundred lines including diagrams. Optional Risks/References remain only when useful. What Changed describes current behaviour by area and links the PR Changes section rather than copying it.

## Evidence missing in this exercise

- Current PR readback and verified-head checks/target evidence; the record is a captured response.
- Complete changed-path list and actual base-to-head diff/source at the captured revisions.
- Detached review checkout identity, cleanliness, actual HEAD and available comparison base.
- Index status, indexed commit, response staleness blocks, changed symbols, symbol relationships and every ordered flow trace.
- Existing overview/README contents and evidence behind R9; R10 Agent Review and R11 Integration Verification contents. Links in the PR body are not proof of their contents or freshness.
- Head-pinned file/line references sufficient to author diagrams and a reading order.
- Published-record readback and saved PR-body readback.

These missing items prevent an architecture overview. No architecture diagram, measured boundary, flow order, current review-readiness claim or completed Understand outcome is invented.

