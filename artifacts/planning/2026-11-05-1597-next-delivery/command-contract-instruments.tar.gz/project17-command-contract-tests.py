from pathlib import Path
import io
import tokenize
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/test/test_check_skill_files.py'
text=path.read_text()
for token in tokenize.generate_tokens(io.StringIO(text).readline):
    if token.type==tokenize.STRING and token.string.startswith('"') and not token.string.startswith('"""'):
        replacement=token.string.replace('[**limit**](#limit)','[**limit**](#limit \\"○\\")')
        text=text.replace(token.string,replacement)
text=text.replace('[**limit**](#limit)','[**limit**](#limit "○")')
text=text.replace('[**limit**](source.md#limit)','[**limit**](source.md#limit "○")')
old='''    def test_contextual_inputs_must_carry_role_titles(self):
        self.replace(self.inventory, '[Limit](#limit "○")', '[Limit](#limit)')
        self.assertIn('operation contract links', self.kinds())
'''
new='''    def test_command_annotation_supplies_input_without_repeated_prose(self):
        self.replace(self.inventory, 'Fetch the requested page using [Limit](#limit "○").', '')
        self.assertEqual(self.findings(), [])

    def test_command_arguments_require_role_titles(self):
        self.replace(self.inventory, '[**limit**](#limit "○")', '[**limit**](#limit)')
        self.assertIn('invocation argument contract', self.kinds())

    def test_command_annotation_can_supply_the_output(self):
        self.replace(self.inventory, 'Provide [Page](#page "●").', 'The page is available.')
        self.replace(self.inventory, 'inventory_fetch { [**limit**](#limit "○"), offset }',
                     'inventory_fetch { [**limit**](#limit "○"), offset } > [**page**](#page "●")')
        self.assertEqual(self.findings(), [])

    def test_command_transformation_annotation_resolves_its_callable(self):
        self.replace(self.inventory, 'inventory_fetch {', '[**inventory_fetch**](#read-inventory "ƒ") {')
        self.assertEqual(self.findings(), [])

    def test_command_transformation_cannot_select_a_field(self):
        self.replace(self.inventory, 'inventory_fetch {', '[**inventory_fetch**](#limit "ƒ") {')
        self.assertIn('operation link role', self.kinds())

    def test_repeated_command_parameter_list_is_reported(self):
        self.replace(self.inventory, '### Limit', '### Offset\\n\\nThe page offset.\\n\\n### Limit')
        self.replace(self.inventory, ', offset }', ', [**offset**](#offset "○") }')
        self.replace(self.inventory, 'Fetch the requested page using [Limit](#limit "○").',
                     'Run the command using [Limit](#limit "○") and [Offset](#offset "○").')
        self.assertIn('duplicate command parameter prose', self.kinds())

    def test_long_shell_invocation_requires_continuations(self):
        command = 'inventory_fetch --limit [**limit**](#limit "○") --label ' + "'" + 'x' * 140 + "'"
        self.replace(self.inventory, 'inventory_fetch { [**limit**](#limit "○"), offset }', command)
        self.assertIn('unwrapped shell invocation', self.kinds())
        self.replace(self.inventory, command, command.replace(' --', ' \\\\\\n  --'))
        self.assertNotIn('unwrapped shell invocation', self.kinds())
'''
assert old in text
text=text.replace(old,new)
needle="        self.replace(self.inventory, '#### 1. Fetch Inventory Page',\n"
assert text.count(needle)==1
text=text.replace(needle,"        self.replace(self.inventory, '[**limit**](#limit \"○\")', 'limit')\n"+needle)
needle="    def test_specimen_role_links_do_not_supply_operation_inputs(self):\n"
assert needle in text
text=text.replace(needle,needle+"        self.replace(self.inventory, '[**limit**](#limit \"○\")', 'limit')\n")
Path('/tmp/project17-command-fixture-candidate.py').write_text(text)
compile(text,str(path),'exec')
path.write_text(text)

# Remove surplus spacing created by deleting pure binding lists, keeping payloads and specimens literal.
import importlib.util
import sys
spec=importlib.util.spec_from_file_location('blank_contracts',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
for path in (root/'skills/work-planner').rglob('*.md'):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    lines,fenced,_=check.scan(path)
    html=check.scan_blocks(lines).html_lines
    out=[]
    blank=False
    for i,line in enumerate(lines):
        if not line.strip() and not fenced[i] and i not in html:
            if blank:continue
            blank=True
        else:blank=False
        out.append(line)
    path.write_text('\n'.join(out)+'\n')
