import json
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/skills/work-planner/artifacts')
edits=[]
def revise(file,needle,replacement):
    path=root/(file+'.md')
    lines=path.read_text().splitlines()
    indexes=[i for i,line in enumerate(lines) if line.startswith(needle)]
    assert len(indexes)==1,(file,needle,indexes)
    i=indexes[0]
    edits.append({'file':file+'.md','before':lines[i],'after':replacement})
    lines[i]=replacement
    path.write_text('\n'.join(lines)+'\n')

revise('acceptance-criteria','- `--project` is any checkout','- The instrument follows `--` and runs at the checkout’s top level.')
revise('board-delivery','- `--epics`,','- Missing published agent-review evidence holds the epic In Progress.')
for start in ('- `--board`,','- `--out` receives','- `--others` supplies'):revise('board-delivery',start,'')
for start in ('- `--items` is','- `--prs` is','- `--links` is','- `--board` is','- `--fields` is','- `--out` is','- `--assignee` is','- `--others` is'):
    revise('board-queue',start,'')
revise('board-queue','- `--unplanned` supplies','- Repeat `--unplanned` for each supplied [Unplanned Initiative](#unplanned-initiatives "○").')
revise('delivery-branches','- `--project` is any','- Select the evaluated revision according to [Branches](#branches).')
revise('delivery-plan','- `--items`,','- Read each row’s own links from the epic body to determine whether its work is under way.')
revise('delivery-plan','- `--project` is the','')
revise('delivery-plan','- `--project` is also','- Fetch the project checkout’s remote epic bases and long-lived branches before reading producer outputs against them.')
revise('delivery-plan','- `--engineering` is the','- Read each free row’s work-item file from the supplied engineering worktree.')
revise('delivery-plan','- `--others` supplies','- Use `--date` to override the [record date](#record-date "○").')
revise('delivery-plan','- `--lane <id>`','- Omit `--lane` when the run names no lane. Offered units meet [Admission](lane.md#admission).')
revise('delivery-plan',"- `--dispatch-plan '",'- Use `--dispatch-plan` when saving a [dispatch export](#dispatch-export "●").')
revise('epic-issue-body','- `--project` is a checkout','- Read long-lived branch names from `config/branches` at each supplied epic-base revision, such as `origin/i07/e00/main`; each `source` line names its path, commit and repository.')
revise('epic-issue-body','- `--link` names','- Repeat a task id in `--link` once per pull request, one per long-lived branch its unit changes. Retain its existing deliveries and add only those missing, so repeated execution is idempotent.')
revise('epic-issue-body','- `--items` is','')
revise('epic-issue-body','- `--records` is','- Supply the planning-records base URL when no epic row links a record.')
revise('epic-issue-body','- `--engineering` is','- Refuse a row when its planning folder contains no matching work-item file or its README does not link that file.')
revise('repository-graph','- `--base-ref` is','- Compare against the pull request’s base to isolate its change from the branch’s full history.')
revise('standup-report','- `--links` is','')
revise('standup-report','- `--since` supplies','- Select the reporting [window](#scope) from the supplied [Report Selection](#report-selection "○").')
revise('standup-report','- `--initiative` selects','- An initiative filter can be `I08` or `owner/repo:I08`.')
revise('standup-report','- `--initiatives` gives','- Pass each supplied off-board [initiative record](#initiative-records "○") as a separate argument after `--initiatives`.')
revise('standup-report','- `--summary` gives','')
Path('/tmp/project17-command-flag-review.json').write_text(json.dumps(edits,ensure_ascii=False,indent=2)+'\n')
print('Reviewed',len(edits),'parameter glosses; retained meaningful selection, multiplicity, refusal and result semantics.')
