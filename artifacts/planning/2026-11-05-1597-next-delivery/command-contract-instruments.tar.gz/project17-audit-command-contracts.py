import hashlib
import importlib.util
import json
import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
base='eedc9a212ae38449a16638dc190b0e2f16d1a828'
spec=importlib.util.spec_from_file_location('audit_commands',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
ledger=json.loads(Path('/tmp/project17-command-contract-ledger.json').read_text())
failures=[]
observations=[]
for row in ledger:
    path=root/row['file']
    lines,fenced,headings=check.scan(path)
    start=next(i for i,d,title in headings if d==3 and title==row['operation'])
    end=check.heading_end(headings,start,3,len(lines))
    first=next(i for i,d,title in headings if start<i<end and d==4 and check.HEADING_STEP.match(title))
    html=check.scan_blocks(lines).html_lines
    actual={role:set() for role in ('input','output')}
    for i,target,role,_ in check.role_links(lines,fenced):
        if first<i<end and (i in html or not check.HEADING.match(lines[i])) and role in actual:
            actual[role].add(target)
            if not check.field_contract(path,target,'Fields'):failures.append({'file':row['file'],'operation':row['operation'],'invalid_field':target})
    for role in actual:
        if missing:=set(row['expected'][role])-actual[role]:failures.append({'file':row['file'],'operation':row['operation'],'role':role,'missing':sorted(missing)})
    observations.append(dict(row,observed={role:sorted(values) for role,values in actual.items()}))

def payloads(text):
    lines,_,_=check.parse(text)
    return ['\n'.join(lines[a:b+1]).strip().removeprefix('<big><pre>').removesuffix('</pre></big>').strip() for a,b in check.scan_blocks(lines).invocations]
def rendered(text):
    import html
    return html.unescape(check.ARGUMENT_LINK.sub(lambda m:m[1],text))
shell_count=0
literal_count=0
invocations=0
command_details=[]
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    name=str(path.relative_to(root))
    before=subprocess.check_output(['git','show',base+':'+name],cwd=root,text=True)
    current=path.read_text()
    a,b=payloads(before),payloads(current)
    if len(a)!=len(b):failures.append({'file':name,'reason':'Invocation count drift'})
    for number,(old,new) in enumerate(zip(a,b),1):
        invocations+=1
        if old.startswith(('cd ','gh ','git ','python3 ','gitnexus ','"[**')):
            shell_count+=1
            old_argv=shlex.split(' '.join(check.logical_command_lines(rendered(old))))
            new_argv=shlex.split(' '.join(check.logical_command_lines(rendered(new))))
            if old_argv!=new_argv:failures.append({'file':name,'invocation':number,'reason':'Command argv drift'})
            stub=check.ARGUMENT_LINK.sub(lambda m:'sample',new)
            import html
            stub=html.unescape(stub)
            env=dict(os.environ)
            env.pop('BASH_ENV',None)
            env.pop('ENV',None)
            result=subprocess.run(['bash','--noprofile','--norc','-n','-c',stub],capture_output=True,text=True,env=env)
            if result.returncode:failures.append({'file':name,'invocation':number,'reason':'Shell syntax','error':result.stderr.strip()})
            command_details.append({'file':name,'invocation':number,'argv_equal':old_argv==new_argv,'shell_syntax_exit':result.returncode})
        else:
            literal_count+=1
            if rendered(old)!=rendered(new):failures.append({'file':name,'invocation':number,'reason':'Non-shell payload drift'})
    old_lines,old_fenced,old_heads=check.parse(before)
    now_lines,now_fenced,now_heads=check.parse(current)
    if [line for line,fence in zip(old_lines,old_fenced) if fence]!=[line for line,fence in zip(now_lines,now_fenced) if fence]:failures.append({'file':name,'reason':'Fenced/template drift'})
    def prerequisites(lines,heads):
        candidates=[i for i,d,t in heads if d==2 and t=='Prerequisites']
        if not candidates:return []
        start=candidates[0]
        end=check.heading_end(heads,start,2,len(lines))
        return check.LINK.findall('\n'.join(lines[start:end]))
    if prerequisites(old_lines,old_heads)!=prerequisites(now_lines,now_heads):failures.append({'file':name,'reason':'Prerequisite drift'})

result={'base':base,'operations':len(ledger),'expected_input_obligations':sum(len(r['expected']['input']) for r in ledger),'expected_output_obligations':sum(len(r['expected']['output']) for r in ledger),'invocations':invocations,'shell_argv_and_syntax_checked':shell_count,'literal_invocations_preserved':literal_count,'failures':failures,'operation_contracts':observations,'commands':command_details,'limits':'Authoring/argv/syntax verification; commands are not executed. Semantic conditions retained by the recorded sentence-level review. No performed-operation verifier is implemented.'}
Path('/tmp/project17-command-contract-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('operation_contracts','commands')},ensure_ascii=False))
if failures:
    for row in failures:print(json.dumps(row,ensure_ascii=False))
    raise SystemExit(1)
freeze=Path('/tmp/project17-command-contract-disclosure')
assert not freeze.exists(),'Preserve existing reading evidence identity.'
manifest={}
paths=subprocess.check_output(['git','ls-files','-z','skills/work-planner','skills/scripts/check_skill_files.py','skills/test/test_check_skill_files.py','skills/guidelines.md'],cwd=root).decode().split('\0')
for name in paths:
    if not name or not (root/name).is_file():continue
    data=(root/name).read_bytes()
    output=freeze/'source'/name
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_bytes(data)
    manifest[name]=hashlib.sha256(data).hexdigest()
(freeze/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Frozen',len(manifest),'files for bounded independent reading checks.')
