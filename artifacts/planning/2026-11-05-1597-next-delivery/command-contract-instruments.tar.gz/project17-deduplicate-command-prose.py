import importlib.util
import json
import re
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('prose_contracts',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
rows=json.loads(Path('/tmp/project17-command-prose-remaining.json').read_text())
changes=[]
for name in sorted({row['file'] for row in rows}):
    path=root/name
    lines=path.read_text().splitlines()
    for row in rows:
        if row['file']!=name:continue
        index=row['line']-1
        assert lines[index]==row['text']
        missing=row['not_in_command']
        links={m[1]:m[0] for m in check.LINK.finditer(lines[index])}
        statements=[]
        cwd=[target for target in missing if target in ('#project-checkout','#checkout','#unit-checkout','#engineering-worktree')]
        if cwd:statements.append('Run in the '+links[cwd[0]]+'.')
        elif 'repository checkout' in lines[index] or '[repository]' in lines[index]:statements.append('Run in the repository checkout.')
        gates=[target for target in missing if target in ('#authenticated-access','#repository-prerequisite','#prerequisite-evidence','#missing-destination','#successful-merge','#merge-authorization','#target-requirements','#readiness-evidence','#removal-decision','#delivery-evidence','#closure-findings')]
        if gates:
            statements.append('Require '+', '.join(links[target] for target in gates)+' before executing the command.')
        for target in missing:
            if target in cwd or target in gates:continue
            link=links[target]
            sentence={
                '#resolved-issues':f'Include each supplied {link} file with `--others`.',
                '#off-board-issues':f'Include each supplied {link} file with `--others`.',
                '#status-scope':f'Limit proposed writes to {link}.',
                '#dispatch-export-path':f'Save the survey export at {link}.',
                '#requested-lane':f'Honor {link} when selecting units.',
                '#output-files':f'Use {link} to select the destination.',
                '#kind-conditions':f'Validate the body against {link}.',
                '#transfer-evidence':f'Base the transfer pointer on {link}.',
                '#collection-path':f'Use {link} for the saved collection.',
                '#node-metadata':f'Build the selected GraphQL mutation from {link} before running it.',
                '#requested-revision':f'Compare the indexed commit with {link}.',
            }.get(target)
            assert sentence,(name,target)
            statements.append(sentence)
        if '; repeat the skill argument for additional affected skills.' in lines[index]:
            statements.append('Repeat the skill argument for additional affected skills.')
        prefix='- ' if lines[index].startswith('- ') else ''
        after='\n'.join(prefix+sentence for sentence in statements)
        changes.append({'file':name,'line':index+1,'before':lines[index],'after':after,'preserved_noncommand_inputs':missing})
        lines[index]=after
    path.write_text('\n'.join(lines)+'\n')
Path('/tmp/project17-command-semantic-prose.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'reviewed_intros':len(changes),'removed':sum(not row['after'] for row in changes),'preserved_meaningful_context':sum(bool(row['after']) for row in changes)}))
# Preserve the flag prose for sentence-level review; metadata is not an implementation oracle.
flag_rows=[]
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    lines,fenced,_=check.scan(path)
    html=check.scan_blocks(lines).html_lines
    for i,line in enumerate(lines):
        if fenced[i] or i in html:continue
        if re.match(r'^- `--',line):flag_rows.append({'file':str(path.relative_to(root)),'line':i+1,'text':line})
Path('/tmp/project17-command-flag-prose.json').write_text(json.dumps(flag_rows,ensure_ascii=False,indent=2)+'\n')
for row in flag_rows:print(row['file'].split('/')[-1],row['line'],row['text'])
