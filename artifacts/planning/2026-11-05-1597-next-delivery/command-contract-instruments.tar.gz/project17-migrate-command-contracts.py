import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
base='eedc9a212ae38449a16638dc190b0e2f16d1a828'
spec=importlib.util.spec_from_file_location('command_contracts',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
ledger=[]
removed=[]
remaining=[]
tagged=0
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    name=str(path.relative_to(root))
    before=subprocess.check_output(['git','show',base+':'+name],cwd=root,text=True)
    lines,fenced,headings=check.parse(before)
    blocks=check.scan_blocks(lines)
    entry=check.contract(path,{}) or {}
    for start,level,title,end in check.procedure_headings(lines,headings,entry):
        if level!=3 or check.HEADING_STEP.match(title):continue
        expected={'input':set(),'output':set()}
        for index,target,role,_ in check.role_links(lines,fenced):
            if start<index<end and role in expected:expected[role].add(target)
        for index in range(start+1,end):
            if index not in blocks.html_lines:continue
            for match in check.ARGUMENT_LINK.finditer(lines[index]):
                expected['input'].add(match[2])
        if any(expected.values()):ledger.append({'file':name,'operation':title,'expected':{key:sorted(values) for key,values in expected.items()}})
    current=path.read_text().splitlines()
    html=check.scan_blocks(current).html_lines
    for index in html:
        def annotate(match):
            global tagged
            if check.link_role(match):return match[0]
            tagged+=1
            return match[0][:-1]+' "○")'
        current[index]=check.ARGUMENT_LINK.sub(annotate,current[index])
    plain='\n'.join(current)+'\n'
    now,_,heads=check.parse(plain)
    html=check.scan_blocks(now).html_lines
    for pos,(start,level,title) in enumerate(heads):
        if not check.HEADING_STEP.match(title):continue
        end=next((i for i,depth,_ in heads[pos+1:] if depth<=level),len(now))
        arguments={match[2] for index in range(start+1,end) if index in html for match in check.ARGUMENT_LINK.finditer(now[index])}
        for index in range(start+1,end):
            if index in html or not re.match(r'^(?:- )?Run (?:the following|the|this) command',now[index]):continue
            matches=list(check.LINK.finditer(now[index]))
            targets={m[1] for m in matches}
            remainder=check.LINK.sub('',now[index])
            pure=re.fullmatch(r'(?:- )?Run (?:the following|the|this) command (?:using|in|from)(?: the)?[\s,.]*(?:and[\s,.]*)*',remainder)
            if matches and pure and targets<=arguments:
                removed.append({'file':name,'step':title,'text':now[index]})
                current[index]=''
            else:
                remaining.append({'file':name,'line':index+1,'text':now[index],'not_in_command':sorted(targets-arguments)})
    path.write_text('\n'.join(current)+'\n')
Path('/tmp/project17-command-contract-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
Path('/tmp/project17-command-prose-removals.json').write_text(json.dumps(removed,ensure_ascii=False,indent=2)+'\n')
Path('/tmp/project17-command-prose-remaining.json').write_text(json.dumps(remaining,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'operations':len(ledger),'tagged_arguments':tagged,'removed_pure_intros':len(removed),'remaining_intros':len(remaining)}))
for row in remaining:print(row['file'].split('/')[-1],row['line'],row['text'],'MISSING',row['not_in_command'])
