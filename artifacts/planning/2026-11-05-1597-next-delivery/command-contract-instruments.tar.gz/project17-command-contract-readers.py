from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/work-planner/test/test_checkouts.py'
text=path.read_text()
text=text.replace('Input names and owning Field definitions inside this operation\'s steps.','Input names and owning Field definitions in this operation’s prose and commands.')
old='''        for index in range(start + 1, end):
            if index not in self.steps or self.fenced[index] or index in self.blocks.html_lines:
                continue
            for match in checker.LINK.finditer(checker.CODE_SPAN.sub('', self.lines[index])):
                if checker.link_role(match) != 'input':
                    continue
                name, _, fragment = match[1].partition('#')
                destination = (self.path.parent / name).resolve() if name else self.path
                if not checker.field_contract(self.path, match[1], 'Fields'):
                    continue
                lines, _, headings = checker.scan(destination)
                first, depth, title = next((i, d, t) for i, d, t in headings
                                          if checker.anchor_of(t) == fragment)
                last = checker.heading_end(headings, first, depth, len(lines))
                contracts.append(title + '\\n' + '\\n'.join(lines[first + 1:last]))
'''
new='''        for index, target, role, _ in checker.role_links(self.lines, self.fenced):
            if not (start < index < end and index in self.steps) or role != 'input':
                continue
            if index not in self.blocks.html_lines and checker.HEADING.match(self.lines[index]):
                continue
            name, _, fragment = target.partition('#')
            destination = (self.path.parent / name).resolve() if name else self.path
            if not checker.field_contract(self.path, target, 'Fields'):
                continue
            lines, _, headings = checker.scan(destination)
            first, depth, title = next((i, d, t) for i, d, t in headings
                                      if checker.anchor_of(t) == fragment)
            last = checker.heading_end(headings, first, depth, len(lines))
            contracts.append(title + '\\n' + '\\n'.join(lines[first + 1:last]))
'''
assert old in text
text=text.replace(old,new)
text=text.replace('operations.setdefault(start, []).extend(payload.splitlines())','operations.setdefault(start, []).extend(checker.logical_command_lines(payload))')
text=text.replace('def test_inputs_require_contextual_step_prose(self):','def test_inputs_require_actual_step_prose_or_command_annotations(self):')
needle="            self.assertIn('review checkout', document.inputs(start).lower())\n"
assert text.count(needle)==1
text=text.replace(needle,needle+'''            path.write_text(content.replace('Inspect the supplied state.',
                                            '<big><pre>inspect --checkout [**checkout**](#review-checkout "○")</pre></big>'))
            document = Document(path, entry)
            self.assertIn('review checkout', document.inputs(start).lower())
''')
path.write_text(text)
path=root/'skills/work-planner/test/test_documents.py'
text=path.read_text().replace('def test_artifact_operations_bind_argument_inputs_in_prose_and_consecutive_steps(self):','def test_artifact_operations_bind_arguments_at_their_use_and_consecutive_steps(self):')
start=text.index('                    prose_inputs = ')
end=text.index('                    self.assertFalse(any(re.match',start)
text=text[:start]+'''                    contracts = [(target, role) for i, target, role, _ in checker.role_links(lines, fenced)
                                 if start < i < end and (i in payload or not checker.HEADING.match(lines[i]))]
                    inputs = {target for target, role in contracts if role == 'input'}
                    arguments = [(match[2], checker.link_role(match)) for i in range(start + 1, end)
                                 if i in payload for match in checker.ARGUMENT_LINK.finditer(lines[i])]
                    self.assertTrue(all(role in ('input', 'output', 'operation') for _, role in arguments),
                                    'an executable annotation has no role')
                    self.assertLessEqual({target for target, role in arguments if role == 'input'}, inputs)
                    self.assertTrue(any(role == 'output' for _, role in contracts))
'''+text[end:]
path.write_text(text)
path=root/'skills/work-planner/test/test_plan_mode.py'
text=path.read_text()
text=text.replace("    return '\\n'.join(html.unescape(checker.ARGUMENT_LINK.sub(lambda match: match[1], line))", "    result = '\\n'.join(html.unescape(checker.ARGUMENT_LINK.sub(lambda match: match[1], line))")
needle='                     if not fenced[index])\n'
assert text.count(needle)==1
text=text.replace(needle,needle+"    return '\\n'.join(checker.logical_command_lines(result))\n")
path.write_text(text)
path=root/'skills/scripts/check_skill_files.py'
text=path.read_text().replace('import difflib\n','import difflib\nimport html\n').replace('import re\n','import re\nimport shlex\n')
text=text.replace("'invocation outside execution step', 'invocation argument contract', 'operation call verb',", "'invocation outside execution step', 'invocation argument contract', 'operation call verb',\n    'unwrapped shell invocation', 'duplicate command parameter prose',")
text=text.replace("return re.sub(r'\\\\\\n[ \\t]*', ' ', payload).splitlines()", "return re.sub(r'\\\\\\n[ \\t]*', '', payload).splitlines()")
needle="            ordinary = ARGUMENT_LINK.sub('', lines[index])\n"
new='''            visible = html.unescape(ARGUMENT_LINK.sub(lambda match: match[1], lines[index])).strip()
            if entry.get('link_roles') and len(visible) > 120 and not visible.endswith('\\\\'):
                try:
                    words = shlex.split(visible)
                except ValueError:
                    words = []
                if sum(word.startswith('--') or (word.startswith('-') and len(word) == 2) for word in words) >= 2:
                    yield index, 'unwrapped shell invocation', 'split option/value groups with shell continuations'
'''
assert needle in text
text=text.replace(needle,new+needle)
needle='\n\ndef operation_calls(path, lines, fenced, entry, inside):\n'
extra='''    if entry.get('link_roles'):
        for start, _, _, end in steps:
            parameters = {match[2] for first, last in blocks if start < first <= last < end
                          for index in range(first, last + 1) for match in ARGUMENT_LINK.finditer(lines[index])}
            for index in range(start + 1, end):
                if fenced[index] or index in lexical.html_lines:
                    continue
                matches = list(LINK.finditer(lines[index]))
                bare = LINK.sub('', lines[index])
                if len(matches) >= 2 and all(match[1] in parameters for match in matches) and re.fullmatch(
                        r'(?:- )?Run (?:the following|the|this) command using[\\s,.]*(?:and[\\s,.]*)*', bare):
                    yield index, 'duplicate command parameter prose', 'command annotations already bind these parameters'
'''
assert needle in text
text=text.replace(needle,'\n'+extra+needle)
compile(text,str(path),'exec')
path.write_text(text)
path=root/'skills/work-planner/rules.json'
text=path.read_text().replace('"malformed HTML invocation", "GraphQL without a REST gap"','"malformed HTML invocation", "unwrapped shell invocation", "GraphQL without a REST gap"').replace('"prose/contextual-contracts": ["operation contract links",','"prose/contextual-contracts": ["duplicate command parameter prose", "operation contract links",')
path.write_text(text)
