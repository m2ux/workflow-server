import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

HEAD = '4882414d678268aaa282fb4c0b184f14e3e47d1b'
BASE = '03d353300ca4804194fd50d316d73e3bf1270d1d'
PREVIOUS = 'eedc9a212ae38449a16638dc190b0e2f16d1a828'
engineering = Path('/home/mike1/projects/dev/workflow-server/.engineering')
record = engineering/'artifacts/planning/2026-11-05-1597-next-delivery'
review = Path('/home/mike1/projects/dev/workflow-server/.worktrees/pr/1641-'+HEAD)
graph = Path('/tmp/i17-e01-command-contract-graph')
url = 'https://github.com/m2ux/workflow-server/blob/engineering/'+str(record.relative_to(engineering))+'/'

def dump(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')

def archive(path, sources):
    members = []
    with tarfile.open(path, 'w:gz') as tar:
        for source, name in sources:
            data = source.read_bytes()
            assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)', data), name
            tar.add(source, arcname=name, recursive=False)
            members.append({'member':name, 'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()})
    dump(path.with_name(path.name.removesuffix('.tar.gz')+'-manifest.json'), {'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'members':members})

assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=review, text=True).strip() == HEAD
assert not subprocess.check_output(['git','status','--porcelain'], cwd=review, text=True)
subprocess.run(['git','diff','--check',BASE,HEAD], cwd=review, check=True)
audit = json.loads(Path('/tmp/project17-command-contract-audit.json').read_text())
assert audit['operations']==240 and not audit['failures']
manifests = {}
for name, folder in [('initial','/tmp/project17-command-contract-disclosure'),('final','/tmp/project17-command-contract-disclosure-final')]:
    root = Path(folder)
    manifest = json.loads((root/'manifest.json').read_text())
    assert len(manifest)==115
    assert all(hashlib.sha256((root/'source'/path).read_bytes()).hexdigest()==sha for path,sha in manifest.items())
    if name=='final':
        assert all(hashlib.sha256((review/path).read_bytes()).hexdigest()==sha for path,sha in manifest.items())
    manifests[name]=manifest
    shutil.copyfile(root/'manifest.json',record/('command-contract-'+name+'-manifest.json'))
changes = [p for p in manifests['initial'] if manifests['initial'][p]!=manifests['final'][p]]
dump(record/'command-contract-source-identity.json', {'head':HEAD,'previous':PREVIOUS,'files':115,'initial_snapshot_unchanged':True,'final_snapshot_unchanged':True,'final_matches_commit':True,'post_reader_refinements':changes,'refinement_scope':'Original branch-prologue bullet prefixes restored; helper docstring clarified; role-model guard and negative regression. Active Work Planner command roles, URLs, usage semantics and continuations are unchanged.'})

for source,dest in [
    ('project17-command-contract-audit.json','command-contract-audit.json'),
    ('project17-command-contract-ledger.json','command-contract-ledger.json'),
    ('project17-command-prose-removals.json','command-prose-removals.json'),
    ('project17-command-semantic-prose.json','command-semantic-prose.json'),
    ('project17-command-flag-review.json','command-flag-review.json'),
    ('project17-command-wrap-audit.json','command-wrap-audit.json'),
    ('project17-command-branch-prefix-restoration.json','command-branch-prefix-restoration.json'),
    ('project17-command-contract-work-planner.log','integration-work-planner.log'),
    ('project17-command-contract-shared.log','integration-shared-checker.log'),
    ('project17-command-contract-installed.log','integration-installed-check.log'),
]:
    shutil.copyfile(Path('/tmp')/source,record/dest)
assert 'Ran 934 tests' in (record/'integration-work-planner.log').read_text()
assert 'OK (skipped=1)' in (record/'integration-work-planner.log').read_text()
assert 'Ran 270 tests' in (record/'integration-shared-checker.log').read_text()

reading_sources=[]
for prefix,folder in [('board',Path('/tmp/command-contract-board-reader')),('revise',Path('/tmp/command-contract-revise-reader'))]:
    reading_sources += [(p,prefix+'/'+str(p.relative_to(folder))) for p in sorted(folder.rglob('*')) if p.is_file()]
for prefix,folder in [('initial',Path('/tmp/project17-command-contract-disclosure')),('final',Path('/tmp/project17-command-contract-disclosure-final'))]:
    reading_sources += [(p,'source/'+prefix+'/'+str(p.relative_to(folder))) for p in sorted(folder.rglob('*')) if p.is_file()]
archive(record/'command-contract-reading.tar.gz',reading_sources)
(record/'command-contract-reading-review.md').write_text('''# Command Contract Reading Review

Two independent readers received the immutable initial snapshot and scoped planning requests. Their plans, exact tool parameters/results, read audits and both source snapshots are preserved in command-contract-reading.tar.gz. These are static reading exercises; neither executes checks, changes GitHub state, indexes code or inspects the live product checkout.

## Board Review Route

The reader identifies all nine command-backed inputs to Compute Dispatch Status and the narrower Record Epic Review route. Supplied captures already show an In Review item; full board/configuration/login and fresh PR/published-review evidence remain unavailable. Eighteen read attempts include seventeen executions and one hook rejection followed by safe jq/cat recovery. Whole artifact/script reads include unrelated operations; aggregate and nested truncation require bounded recovery. Prerequisite order and closure are incomplete. A possible cross-repository issue-number collision is not demonstrated as a current defect.

## Revise Verification Route

The reader identifies Run Tests, the shared suite, installed Check Skill Files, conditional comparison, their actual command-backed inputs/results and the opt-in live check. All nineteen read calls are retained. Broad searches and whole guides retrieve unrelated material; truncated envelopes have recovery reads. A frozen-tree launcher lookup fails because the bounded snapshot intentionally omits scripts/sbx. No actual diff/base/head, live launcher execution or passing test result is supplied by this plan.

## Identity and Limits

The parent inspected both complete plans, read accounts and sampled raw receipts. Both 115-file frozen trees remain unchanged; the final tree equals the committed product head. Subsequent refinements restore unrelated branch-prologue bullet prefixes, clarify a helper docstring, and fix/test the guard for models that do not select roles. Active Work Planner command bindings, usage and continuations match the reader snapshot.

These trials remain Partial for over-reading, prerequisite closure, truncation and receipt limits. They show that the plans recognize command-backed contracts, without establishing clean progressive disclosure, a complete external workflow, performed-operation verification or context-token savings. Earlier integration reading trials retain their separately documented limitations.
''')

instruments = [p for p in sorted(Path('/tmp').glob('project17-*command-contract*.py')) if p.is_file()]
instruments += [Path('/tmp')/name for name in ['project17-deduplicate-command-prose.py','project17-review-command-flag-prose.py','project17-wrap-command-lines.py','project17-restore-unrelated-branch-format.py','project17-command-role-model-guard.py']]
archive(record/'command-contract-instruments.tar.gz',[(p,p.name) for p in dict.fromkeys(instruments)])

# The issue is the user's editable specification; preserve its live task table and references.
epic = json.loads(Path('/tmp/project17-command-contract-epic-before.json').read_text())
body = epic['body']
old = 'Each command moves into the step that runs it, with where it runs, the inputs that fill it, and an example.'
assert old in body
body = body.replace(old,'Each command sits in the step that runs it, with its execution location and any meaningful usage conditions. Linked command arguments establish their contracts without a repeated parameter list in prose.')
old = 'using `[**argument**](#argument-contract)`, while literal syntax, argument order and line breaks are preserved.'
assert old in body
body = body.replace(old,'using role-tagged `[**argument**](#argument-contract "○")`. Long shell invocations use backslash-newline continuations at token boundaries, grouping options with their values while preserving literal syntax and argument order.')
old = 'Each operation links every consumed input and provided output to its owning `###` Field in natural step prose.'
assert old in body
body = body.replace(old,'Each operation links every consumed input and provided output to its owning `###` Field where it is used, in natural step prose or an executing command. Prose retains semantic conditions and caller-facing results without repeating command bindings.')
body = body.replace('links every input and output in step prose with its role title','links every input and output at its actual use in step prose or an executing command with its role title')
assert len(re.findall(r'^- \[x\] \*\*AC',body,re.M))==8
assert '| Lane | Done |' in body and body.count('| ✓ |')==8
dump(Path('/tmp/project17-command-contract-epic-patch.json'),{'body':body})
(engineering/'artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes/bodies/e01.md').write_text(body.rstrip()+'\n')

pr=json.loads(Path('/tmp/project17-command-contract-pr-current.json').read_text())
refs=pr['body'].split('## References',1)[1].strip()
pr_body='''## Overview

Work Planner uses heading steps and linked contracts at each value's actual use. Executing commands carry their parameter contracts; prose carries meaningful conditions and caller-facing results. Markdown link titles identify input, output and callable roles, and installed declarations select the shared checker used by the corpus and its readers.

## Changes

### Shared Validation

- **Declared models.** Exact-file and family declarations select headings, preambles, Field contracts, roles and Apply/Follow routing.
- **Literal boundaries.** One lexical reader isolates fenced and HTML payloads while recognizing explicit bold command annotations and execution placement.
- **Contract interpretation.** Shared role collection accepts actual-use prose and annotated command parameters, validates Field/callable targets, and rejects specimen-only contracts. Controls cover duplicate parameter lists and unwrapped long shell invocations.

### Instruction Corpus

- **Command contracts.** All 240 operations retain their input/output obligations. Command parameters carry role titles; introductory lists and flag glosses retain only meaningful usage context.
- **Command presentation.** Long shell commands use escaped multiline option/value groups. Validated shell-safe values are unquoted; variable paths, refs, text and expressions retain required quotes. All invocation arguments and literal payloads are preserved.
- **Common context.** Rules, Conventions and Configuration have focused homes. rules.md defines runtime link roles once; guidelines link that definition.
- **Contained items.** Steps with several instruction/detail items bullet every item; a sole item uses plain prose. Called operations, protocols and procedures carry ƒ; explicit results use Provide.

### Consuming Readers

- **Installed authority.** Real-corpus readers use the declared model and shared role grammar while retaining independent script-reach, prerequisite, literal-exclusion and obligation checks.
- **Checkout propagation.** Logical command lines preserve checkout, revision, registration and publication assertions across escaped continuations, including real-git placement tests.

## References

'''+refs+'\n'
dump(Path('/tmp/project17-command-contract-pr-patch.json'),{'body':pr_body})

readme=record/'README.md'
text=readme.read_text().replace('263-test shared checker run','270-test shared checker run')
text=text.replace('Structural baseline sequences for every reported affected process','Current-head sequences for every reported affected process')
text=text.replace('Structural baseline context/flow order and freshness','Current-head context/flow order and freshness')
text += '''
| [Contract audit](command-contract-audit.json) | 240 operations, 824 inputs, 361 outputs and 204 preserved invocations |
| [Independent obligations](command-contract-ledger.json) | Baseline contracts reconciled independently from annotations |
| [Removed parameter lists](command-prose-removals.json) | Pure duplicate introductory lists |
| [Retained semantic prose](command-semantic-prose.json) | Sentence-level usage preservation and remaining intro review |
| [Flag prose review](command-flag-review.json) | Removed glosses and retained argument-use semantics |
| [Continuation audit](command-wrap-audit.json) | Readable wrapping and literal command preservation |
| [Branch prefix audit](command-branch-prefix-restoration.json) | Original unrelated branch-prologue bullets retained |
| [Source identity](command-contract-source-identity.json) | Reader snapshots, final commit equality and refinements |
| [Initial manifest](command-contract-initial-manifest.json) | Exact 115-file reader snapshot |
| [Final manifest](command-contract-final-manifest.json) | Exact 115-file committed source |
| [Reading review](command-contract-reading-review.md) | Two independent plans and explicit Partial limits |
| [Reading evidence](command-contract-reading.tar.gz) | Raw receipts, plans and frozen source trees |
| [Reading manifest](command-contract-reading-manifest.json) | Reading archive identities |
| [Executed instruments](command-contract-instruments.tar.gz) | Conversion, tests, preservation and publication instruments |
| [Instrument manifest](command-contract-instruments-manifest.json) | Exact instrument archive identities |
| [Published review gate](command-contract-review-gate.log) | Fetched current-head review matches the ready PR and target |
'''
readme.write_text(text)
plan=record/'command-contracts.md'
plan.write_text(plan.read_text().replace('- [ ] In progress: revise parser, corpus, guidelines and consuming readers together.','- [x] Revise parser, corpus, guidelines and consuming readers together.').replace('- [ ] Audit retained obligations, command semantics, regressions and reading evidence.','- [x] Audit retained obligations, command semantics, regressions and reading evidence.').replace('- [ ] Commit, push and publish current review handoff.','- [ ] In progress: publish current review handoff; product commit is pushed.'))
print(json.dumps({'head':HEAD,'operations':240,'snapshots_verified':True,'post_reader_refinements':changes,'issue_criteria':8,'issue_tasks':8}))
