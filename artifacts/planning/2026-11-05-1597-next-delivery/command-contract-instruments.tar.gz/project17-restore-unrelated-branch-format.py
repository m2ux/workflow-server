import importlib.util
import json
import subprocess
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('branch_format',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
restored=[]
for path in (root/'skills/work-planner').rglob('*.md'):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    old=subprocess.check_output(['git','show','eedc9a212ae38449a16638dc190b0e2f16d1a828:'+str(path.relative_to(root))],cwd=root,text=True)
    old_lines=set(old.splitlines())
    lines,fenced,headings=check.scan(path)
    html=check.scan_blocks(lines).html_lines
    changed=False
    for pos,(start,level,title) in enumerate(headings):
        if not check.HEADING_STEP.match(title):continue
        end=check.heading_end(headings,start,level,len(lines))
        if not any(start<i<end and depth>level for i,depth,_ in headings):continue
        first_child=next(i for i,depth,_ in headings if start<i<end and depth>level)
        for index in range(start+1,first_child):
            if index in html or fenced[index] or not lines[index].strip():continue
            if not lines[index].startswith('- ') and '- '+lines[index] in old_lines:
                restored.append({'file':str(path.relative_to(root)),'line':index+1,'text':lines[index]})
                lines[index]='- '+lines[index]
                changed=True
    if changed:path.write_text('\n'.join(lines)+'\n')
path=root/'skills/scripts/check_skill_files.py'
text=path.read_text().replace('Shell continuation lines joined without interpreting payload strings.',"Unfold the invocation model’s token-boundary shell continuations.")
path.write_text(text)
Path('/tmp/project17-command-branch-prefix-restoration.json').write_text(json.dumps(restored,ensure_ascii=False,indent=2)+'\n')
print('Preserved original branch-introduction formatting:',len(restored))
