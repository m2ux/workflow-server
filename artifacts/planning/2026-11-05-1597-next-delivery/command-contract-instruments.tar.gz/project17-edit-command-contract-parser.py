from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/scripts/check_skill_files.py'
text=path.read_text()
old=next(line for line in text.splitlines() if line.startswith('LINK = '))
assert old in text
text=text.replace(old,"LINK_DESTINATION = r'([^)]+?)(?:\\s+\"(?:\\\\.|[^\"\\\\])*\")?'\nLINK = re.compile(r'\\[[^\\]]*\\]\\(' + LINK_DESTINATION + r'\\)')")
old=next(line for line in text.splitlines() if line.startswith('ARGUMENT_LINK = '))
assert old in text
text=text.replace(old,"ARGUMENT_LINK = re.compile(r'\\[\\*\\*([^*\\]\\n]+)\\*\\*\\]\\(' + LINK_DESTINATION + r'\\)')")
marker='def operation_target(path, target):\n'
helper='''def role_links(lines, fenced):
    """Explicit role links in prose and bold invocation annotations, outside specimens."""
    commands = scan_blocks(lines).html_lines
    for index, line in enumerate(lines):
        if fenced[index]:
            continue
        matches = (ARGUMENT_LINK.finditer(line) if index in commands
                   else LINK.finditer(CODE_SPAN.sub('', line)))
        for match in matches:
            target = match[2] if index in commands else match[1]
            yield index, target, link_role(match), match[0]


def logical_command_lines(payload):
    """Shell continuation lines joined without interpreting payload strings."""
    return re.sub(r'\\\\\\n[ \\t]*', ' ', payload).splitlines()


'''
assert marker in text
text=text.replace(marker,helper+marker)
start=text.index('    commands = scan_blocks(lines).html_lines\n',text.index('def link_roles('))
end=text.index('\n\ndef heading_model(',start)
text=text[:start]+'''    for index, target, role, source in role_links(lines, fenced):
        callable_target = operation_target(path, target)
        if entry.get('link_roles') and callable_target and role != 'operation':
            yield index, 'operation link role', source
        elif entry.get('link_roles') and role == 'operation' and not callable_target:
            yield index, 'operation link role', source
        if role in ('input', 'output') and not field_contract(path, target, entry.get('contracts', 'Fields')):
            yield index, 'operation contract links', source
'''+text[end:]
old='''            roles = set()
            for line in range(first_step + 1, end):
                if fenced[line] or line in commands or HEADING.match(lines[line]):
                    continue
                for match in LINK.finditer(CODE_SPAN.sub('', lines[line])):
                    role = link_role(match)
                    if role in ('input', 'output'):
                        roles.add(role)
'''
new='''            roles = {role for line, _, role, _ in role_links(lines, fenced)
                     if first_step < line < end and (line in commands or not HEADING.match(lines[line]))
                     and role in ('input', 'output')}
'''
assert old in text
text=text.replace(old,new)
old='''            for match in ARGUMENT_LINK.finditer(lines[index]):
                if not field_contract(path, match[2], entry.get('contracts', 'Fields')):
                    yield index, 'invocation argument contract', match[2]
'''
new='''            for match in ARGUMENT_LINK.finditer(lines[index]):
                role = link_role(match)
                if role == 'operation':
                    continue
                if not field_contract(path, match[2], entry.get('contracts', 'Fields')):
                    yield index, 'invocation argument contract', match[2]
                if entry.get('link_roles') and role not in ('input', 'output'):
                    yield index, 'invocation argument contract', 'argument links identify their input/output role'
'''
assert old in text
text=text.replace(old,new)
compile(text,str(path),'exec')
path.write_text(text)
path=root/'skills/work-planner/guidelines.md'
text=path.read_text()
old='Name each consumed input and provided output in the operation’s step prose, linked to its corresponding Fields contract at its owning home. Review steps, commands, calls, conditions and result handling for implied values; every one has an explicit contextual contract. Command argument links alone do not establish that prose contract.'
new='Link each consumed input and provided output to its owning Fields contract at its actual use in step prose or an executing command. A role-tagged command argument establishes that contract; omit prose that only repeats its parameter binding. Preserve preconditions, execution location, authorization, optional/repeated argument rules and result handling. Review steps, commands, calls, conditions and results for values carried only by implication.'
assert old in text
text=text.replace(old,new)
old='Contract-backed argument names are bold Markdown links, `[**<input-name>**](#input-contract)`, inside the HTML block; literal syntax remains literal.'
new='Contract-backed argument names are bold Markdown links with their [role title](rules.md#link-roles), `[**<input-name>**](#input-contract "○")`, inside the HTML block; literal syntax remains literal.'
assert old in text
text=text.replace(old,new)
old='Preconditions and refusals belong to the governing step.'
text=text.replace(old,old+' Long shell invocations use backslash-newline continuations, with a working-directory prefix and readable option/value groups on separate lines. Keep quoting, operators and argument order intact; wrap at shell token boundaries, measuring visible command text rather than link metadata.')
path.write_text(text)
