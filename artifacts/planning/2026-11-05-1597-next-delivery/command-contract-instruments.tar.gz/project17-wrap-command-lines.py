import html
import importlib.util
import json
import re
import shlex
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('wrap_model',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
changes=[]

def tokenize(value):
    tokens=[]
    start=None
    quote=None
    escaped=False
    i=0
    while i<len(value):
        char=value[i]
        if start is None:
            if char.isspace():i+=1;continue
            start=i
        if escaped:escaped=False
        elif char=='\\' and quote!="'":escaped=True
        elif quote:
            if char==quote:quote=None
        elif char in "'\"":quote=char
        elif char.isspace():
            tokens.append(value[start:i]);start=None
        elif char in '|;&' and (char!='&' or value[i:i+2]=='&&'):
            if start<i:tokens.append(value[start:i])
            operator=value[i:i+2] if value[i:i+2] in ('&&','||') else char
            tokens.append(operator)
            i+=len(operator)-1
            start=None
        i+=1
    assert quote is None and not escaped, value
    if start is not None:tokens.append(value[start:])
    return tokens

for path in sorted((root/'skills/work-planner').rglob('*.md')):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    text=path.read_text()
    lines=text.splitlines(keepends=True)
    for start,end in reversed(check.scan_blocks([line.rstrip('\n') for line in lines]).invocations):
        block=''.join(lines[start:end+1])
        payload=block.strip().removeprefix('<big><pre>').removesuffix('</pre></big>').strip()
        logical=check.logical_command_lines(payload)
        if len(logical)!=1 or not payload.startswith(('cd ','gh ','git ','python3 ','gitnexus ','"[**')):continue
        links={}
        def hide(match):
            key='ZZLINK'+str(len(links))+'ZZ'
            links[key]=match[0]
            return key
        masked=check.ARGUMENT_LINK.sub(hide,logical[0])
        def restore(value):
            return re.sub(r'ZZLINK\d+ZZ',lambda m:links[m[0]],value)
        def visible(value):
            return html.unescape(check.ARGUMENT_LINK.sub(lambda m:m[1],restore(value)))
        if len(visible(masked))<=110:continue
        tokens=tokenize(masked)
        groups=[]
        group=[]
        for token in tokens:
            if token=='&&':
                group.append(token);groups.append(group);group=[]
            elif token.startswith('-') or token in ('|','>','>>'):
                if group:groups.append(group)
                group=[token]
            else:group.append(token)
        if group:groups.append(group)
        physical=[]
        for group in groups:
            chunks=[]
            current=[]
            for token in group:
                if len(current)>=2 and len(visible(' '.join(current+[token])))>106:
                    chunks.append(current);current=[]
                current.append(token)
            if current:chunks.append(current)
            physical.extend(' '.join(chunk) for chunk in chunks)
        assert len(physical)>1,(path,payload)
        wrapped=(' \\\n  ').join(restore(line) for line in physical)
        before=visible(masked)
        after=html.unescape(check.ARGUMENT_LINK.sub(lambda m:m[1],wrapped))
        assert shlex.split(before)==shlex.split(' '.join(check.logical_command_lines(after)))
        if payload==wrapped:continue
        changes.append({'file':str(path.relative_to(root)),'before':payload,'after':wrapped,'visible_length':len(before),'lines':len(physical)})
        lines[start:end+1]=['<big><pre>\n',wrapped+'\n','</pre></big>\n']
    path.write_text(''.join(lines))
prior=Path('/tmp/project17-command-wrap-audit.json')
all_changes=(json.loads(prior.read_text()) if prior.exists() else [])+changes
prior.write_text(json.dumps(all_changes,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'wrapped_invocations':len(changes),'continuation_lines':sum(row['lines']-1 for row in changes)}))

# Reconcile the contained-item rule after removing introductory lists.
normalized=0
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    if 'test' in path.relative_to(root/'skills/work-planner').parts:continue
    lines,fenced,heads=check.scan(path)
    html_lines=check.scan_blocks(lines).html_lines
    changed=False
    for pos,(start,level,title) in enumerate(heads):
        if not check.HEADING_STEP.match(title):continue
        end=heads[pos+1][0] if pos+1<len(heads) else len(lines)
        items=[i for i in range(start+1,end) if lines[i].strip() and not fenced[i] and i not in html_lines
               and not lines[i].startswith(('**','|','>'))]
        for index in items:
            body=lines[index][2:] if lines[index].startswith('- ') else lines[index]
            wanted=('- ' if len(items)>1 else '')+body
            if wanted!=lines[index]:lines[index]=wanted;normalized+=1;changed=True
    if changed:path.write_text('\n'.join(lines)+'\n')
print('Normalized item prefixes:',normalized)
