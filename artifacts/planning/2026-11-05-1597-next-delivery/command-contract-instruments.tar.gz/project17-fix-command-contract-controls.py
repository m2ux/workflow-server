from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/test/test_check_skill_files.py'
text=path.read_text()
start=text.index('    def test_literal_brackets_before_argument_links_keep_their_contracts(self):')
end=text.index('\n    def ',start+5)
body=text[start:end]
needle='                self.inventory.write_text(self.INVENTORY.replace(\n'
assert needle in body
body=body.replace(needle,"                command = command.replace(' --', "+repr(' '+chr(92)+'\n  --')+")\n"+needle)
text=text[:start]+body+text[end:]
path.write_text(text)
