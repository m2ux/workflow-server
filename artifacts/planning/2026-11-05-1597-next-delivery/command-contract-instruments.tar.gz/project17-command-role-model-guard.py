from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/scripts/check_skill_files.py'
text=path.read_text()
old="                if role == 'operation':\n                    continue\n"
assert text.count(old)==1
path.write_text(text.replace(old,"                if entry.get('link_roles') and role == 'operation':\n                    continue\n"))
path=root/'skills/test/test_check_skill_files.py'
text=path.read_text()
needle='    def test_command_transformation_cannot_select_a_field(self):\n'
new='''    def test_unselected_role_model_keeps_argument_field_validation(self):
        model = {name: dict(entry) for name, entry in self.MODEL.items()}
        model['artifacts'].pop('link_roles')
        self.declare(model)
        self.replace(self.inventory, 'inventory_fetch {', '[**inventory_fetch**](#read-inventory "ƒ") {')
        self.assertIn('invocation argument contract', self.kinds())

'''
assert text.count(needle)==1
path.write_text(text.replace(needle,new+needle))
