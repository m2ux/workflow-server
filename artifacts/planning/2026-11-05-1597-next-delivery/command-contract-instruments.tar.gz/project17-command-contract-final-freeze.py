from pathlib import Path
script=Path('/tmp/project17-audit-command-contracts.py').read_text().replace('/tmp/project17-command-contract-disclosure\'','/tmp/project17-command-contract-disclosure-final\'')
exec(compile(script,'final-command-contract-audit','exec'))
