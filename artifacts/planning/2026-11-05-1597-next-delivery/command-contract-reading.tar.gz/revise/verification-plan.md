# Read-Only Verification Plan

## Scope and Current Evidence

- Frozen source read: `/tmp/project17-command-contract-disclosure/source/skills/work-planner`, its shared `../guidelines.md`, `../scripts/check_skill_files.py` and shared test file.
- Intended installed Workspace input: `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace`. This path is a supplied parameter, not a verified checkout.
- Proposed change: executable command-contract validator and command templates. This plan identifies the shared checker as `skills/scripts/check_skill_files.py`, whose inline invocation and contract validation the frozen source implements. No proposed diff, changed-file list, base or head was supplied; exact impact remains provisional.
- No tests, skill procedures, GitHub calls or live-checkout reads ran. No source was edited. Only this requested plan and its receipts are written under `/tmp/command-contract-revise-reader/`.
- This is a plan, not a passing verification result, completed revision workflow or successful disclosure result.

## Required Reading Path

1. Read SKILL.md; load rules.md and conventions.md before selecting Revise.
2. Read modes/revise-mode.md whole. Its Prerequisites require shared skills/guidelines.md and work-planner/guidelines.md whole; complete both before any edit. They were read in this run, with recovery noted in the receipt audit.
3. Reuse those complete common prerequisites at the same frozen revision. Shared Progressive Disclosure requires deciding applicability before retrieving conditional command specifications. Work Planner explicitly requires modes whole, so the whole Revise read also returned its conditional comparison specification.
4. Read affected consumers and their prerequisites, selected operation sections and Fields contracts. A heading link includes subsections and stops before the next equal-or-higher heading. A whole-document requirement still applies. Determine consumers from the eventual diff; the present task supplies none.
5. Review changed files against both whole guidelines: step structure, command placement, input/output roles, literal syntax, quoting, line breaks, repeated arguments, required links/anchors, prerequisite coverage and descriptions of current behavior.

These reads do not authorize or execute the procedures they describe. No delivery, commit, push, issue or PR operation is part of this read-only plan.

## Local Checks to Plan

### 1. Work Planner Script and Document Tests — Selected

The executable change selects Revise / Verify / Run Tests. The mode runs discovery from the skill directory:

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/skills/work-planner" && "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 -m unittest discover -s test
```

Actual inputs are installed test modules in `skills/work-planner/test`, installed scripts, body artifacts and Markdown/declarations that their tests load; fixtures construct temporary files, repositories and API-shaped records. This is not a supplied GitHub board snapshot. In particular, `test_documents.py` imports the shared checker and reads installed mode/artifact/protocol documents and `structure.json`; it checks prerequisites, layer direction, operation argument roles and script reach through called executable sections.

Capture complete unittest stdout/stderr, exit status, test count, failures/errors and skips as Test Result. No test count or result is known here.

Before any future local-only test run, ensure `WORK_PLANNER_LIVE_LINK` is absent: `test_development_link.Live` is selected when this variable is nonempty. Its value is two whitespace-separated issue/pull identities; it calls real GitHub and adds a development link twice. With the variable absent, unittest skips it with `names no live issue and draft pull request`. Do not enable it under this task's authority. The frozen search identified this explicit opt-in; it is not an execution-based guarantee that all other tests have no external effects.

### 2. Shared Validator Regression Suite — Selected

Shared Changes / Verified requires affected shared-checker and integration suites. Because the proposed executable validator is the shared checker, also plan its owning suite. This invocation is derived from the frozen shared `skills/test/test_check_skill_files.py` layout and standard unittest discovery, not a separate command specification in Revise:

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/skills" && "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 -m unittest discover -s test
```

Inputs are the shared tests and imported installed `skills/scripts/check_skill_files.py`. The tests seed temporary skill trees with Markdown and JSON declarations and test both functions and CLI behavior. `DeclaredHeadingModels` covers HTML wrappers, contract-backed bold arguments and role titles, contextual outputs, shell continuation checks, literal brackets/quoting, link resolution, argument reach versus callers, execution placement, GraphQL REST gaps, classic Projects rejection and malformed declaration refusal.

Capture unittest output/status/skips. Add or adjust regression cases appropriate to the actual proposed defect during implementation; no tests are written or run by this plan. If the intended validator is a different executable, resolve that identity and select its owning suite before executing.

### 3. Check Skill Files — Required for Every Affected Skill

Revise requires the selected skill and repeats the positional argument for additional affected skills:

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace" && "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 skills/scripts/check_skill_files.py skills/work-planner
```

Interface from code: one or more positional `roots`; optional `--quiet` prints counts alone; optional `--compare BASE HEAD` selects comparison rather than static checking. Keep normal output for review evidence.

Actual static-check inputs:

- Recursively selected `*.md` files, excluding any `fixtures` path component.
- Selected scripts with suffix `.py`, `.sh`, `.js`, `.mjs` or `.ts` under a scripts path.
- Nearest applicable `structure.json` at or above each directory; exact file selector precedes directory selector, then suffix selector.
- Nearest `vocabulary.json` for retired terms, guides and their adjacent `rules.json`, the shared guideline where present, linked files/anchors and referenced script text.
- Selecting only work-planner does not recursively validate every sibling skill. Repeat skill roots for other affected skills; determine that set from the actual change and consumers of a shared validator.

The command parses inline HTML command text and follows contract citations; it does not execute those commands or verify remote state. Work Planner declares heading steps, inline HTML, Fields contracts and link-role checks in `structure.json`.

Outputs: findings in `path:line: kind — detail` form and `N files checked, M findings`; exit 0 for no findings, 1 for findings. Invalid structure/declaration reports `unreadable structure — ...` or `unreadable declaration — ...` and returns 1 before a normal success claim. Parser argument errors are distinct. Skill Check Result must retain output, finding count and status, rather than equating a requested invocation with receipt.

### 4. Guideline and Template Review — Required

Read every changed file against both guidelines, including non-executable prose rules the checker registers as `review`. Confirm commands preserve syntax, shell/URL/query/payload escaping, argument order, types, quoting, required literals and explicit examples. A passing structural checker alone does not establish that a command template is semantically correct or safe to execute.

Search affected consumers for stale claims and resolve every required file, heading and command. This is a source review; executing command templates, sandboxed or otherwise, is outside this run.

## Conditions Selecting Additional Checks

| Condition | Additional check and actual inputs | Required output |
| --- | --- | --- |
| SKILL.md changes | Inspect its frontmatter delimiters and `name`/`description` fields; shared rules also constrain allowed fields/name/description | Explicit frontmatter review evidence |
| Any section moves between files | Compare base and head revisions, supplying both and all affected skill roots | Section counts, classifications and differences; read every added/removed/differing section |
| Additional skills affected | Repeat their positional roots in the static check and run associated tests/integration checks | Per-selected-scope output/status and reviewed impact |
| Reading paths change | Independent fresh-context representative requests; repeat affected scenarios before claiming consistency | Actual tool-call parameters, returned content and task results; structural and live results separately |
| Affected consumer is a board or graph operation | Work Planner representative Standup with captured board inputs or Understand with named PR, respectively; load that consumer's required guidance and prerequisites | Task-specific evidence, unresolved inputs and observed reading behavior |
| Live-link integration explicitly authorized in a future task | Supply real issue and draft PR on a non-default base via WORK_PLANNER_LIVE_LINK; this contacts and mutates GitHub | Integration output/readback; excluded from this run |

Conditional section-comparison invocation (base/head are missing required inputs, not defaults):

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace" && \
  "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 skills/scripts/check_skill_files.py \
  --compare "<base>" "<head>" skills/work-planner
```

Repeat the skill argument for every directory the move touches. This mode reads committed Markdown from git using `git ls-tree` and `git show`, not uncommitted working files. It compares every third-level section, includes its nested body, reduces relative link targets to fragments and preserves absolute URLs. It reports identical/moved/added/removed/differing plus unified differences for differing bodies and counts at each revision. Exit 1 means an added/removed/differing section or an unreadable revision; moved or identical alone yields 0. Review expected additions/removals/differences; exit 1 is not by itself proof of accidental damage.

## Disclosure Verification Plan

Every revision requires tracing representative requests through affected modes, including common context, prerequisites, subsection boundaries, explicit whole-file requirements and reuse. The bounded Revise scenario is selected here: a skill edit affecting a validator and command templates, with installed Workspace and authority limits supplied.

If the eventual change alters read paths, run independent fresh-context readers with realistic tasks and necessary inputs, without expected reading choices or prior findings. Repeat affected scenarios before claiming consistent behavior. Record missing necessary context, unrelated content, repeated reads, truncation and task correctness. Preserve observed failures and separate structural results from observed behavior. No context-token savings claim follows from this single walk; a comparable baseline under the same conditions is required.

This reader's actual observed read behavior is retained below and in receipts; it must not be described as a successful disclosure check.

## Evidence Gaps and Execution Preconditions

- No proposed diff or changed-file inventory: exact consumers, additional skills, moved sections and required integration coverage cannot yet be settled.
- No base/head revisions: conditional section comparison cannot be populated.
- No live checkout access: installed contents, revision, cleanliness, wrapper and interpreter availability remain unverified.
- `../../scripts/sbx` was absent in the frozen source (read 17, exit 2). The installed wrapper's behavior, sandbox availability and environment forwarding are unverified. Do not claim a wrapper or test worked from the command text.
- Tests, static checker, comparison and remote workflows all remain unexecuted.
- Only selected test/code ranges were read; this is not a full audit of every test or executable.
- No initial task-specific instructions from the live workflow-server checkout were read, as prohibited. An executor must resolve applicable instructions in its separately authorized environment.
- Requested artifact creation does not require source worktrees or delivery. No source change, branch, commit or push is made here.

