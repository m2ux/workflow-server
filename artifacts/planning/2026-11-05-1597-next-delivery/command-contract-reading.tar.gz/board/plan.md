# Project 17 I17 E01 review-status execution plan

This is a plan only. No command below has been run. It concerns workflow-server#1616 and PR #1641, using the supplied installed checkout parameter:

`/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace`

The frozen skill's direct operation is **Record Epic Review** in `artifacts/board-delivery.md`. Its narrow dispatch path records In Review or In Progress; it does not require starting the whole Epic Integration protocol. Reading that protocol supplied context, not authorization to execute it.

## Captured result and decision boundary

- Board item `291152098` captured at `2026-11-06T04:09:52Z` already shows In Review, field `422017304`, option `faec56b9`.
- The embedded open epic has AC1–AC8 checked and assignee `m2ux`.
- PR #1641 is captured open, ready (`draft: false`), unmerged, with head `eedc9a212ae38449a16638dc190b0e2f16d1a828` on `i17/e01/workspace` and base `03d353300ca4804194fd50d316d73e3bf1270d1d` on `workspace`.
- The captured published-review record names those exact tips, has the expected PR URL, all documented record fields and an empty findings list. The captured PR body links that record. These are structural observations; the validator was not run and the publication was not fetched.
- PR `mergeable_state` is `blocked`. Its cause is absent. No merge readiness, approval, CI, live status, complete review or disclosure success is established here.
- In Review is the candidate requested status supported by those captures. If fresh review evidence fails, the skill blocks the In Review write. Its wider integration protocol uses Hold Epic Review and an In Progress record for failed gates, but running that protocol is outside this plan's bounded execution authorization.

## Named inputs

See `inputs.json` for the complete input manifest.

| Field | Binding | Supplied evidence / gap |
| --- | --- | --- |
| Review Selection | epic #1616, users/m2ux/projectsV2/17, candidate In Review | Requested status must be selected for the actual run; do not infer a status write merely from this plan. |
| Board Identity | `users/m2ux/projectsV2/17` | Captured item URL identifies the board. |
| Board Items | future `board-items.json` | Missing complete paginated snapshot; single-item capture cannot fill it. |
| Board Fields | future `board-fields.json` | Missing complete field/options definition; selected option alone cannot fill it. |
| Pull Request Records | future `prs.jsonl` | Fresh complete REST records, one object per nonempty line; supplied PR capture supports planning only. |
| Published Reviews | future `agent-reviews.json` | JSON list fetched from the PR-linked published record; capture supports planning only. |
| Assignee Login | future `authenticated-login.txt` | Must come from authenticated access; captured issue assignee is not proof of login. |
| Output Paths / Output Directory | proposed `/tmp/command-contract-board-reader/execution-evidence` and its `calls/` child | These destinations have not been created or populated. |
| Workspace | supplied absolute installed checkout above | Existence, checkout identity, installed revision and helper availability were not inspected. |

The narrow Record Dispatch Status path takes the epic from the embedded board item's issue. It does not take a separate epic file or the general Plan Board Changes initiative/task/link-snapshot input set. Static inspection of `deliver.py` confirms `--review` selects `place()` before the survey's `--links` requirement.

## Future sequence, commands and outputs

All commands are proposals for a later authorized execution. Tracker commands run in the workflow-server checkout, outside sbx. Computations run with its absolute sbx path. Complete the skill's prerequisite document reads first; this trial did not load their whole closure.

1. **Establish execution prerequisites.** Confirm the supplied checkout holds the intended installed skill and sandbox helper, repository access, Python and gh. Apply the Conventions session rule once before the first gh call: unset GH_TOKEN and GITHUB_TOKEN, or confirm neither is set in the shell profile where shell state does not persist. Preserve the result without exposing token values.

2. **Read Board State.** Apply Find Status Field, then Fetch Board Items with Status. Validate the fetched Status id rather than silently reusing the capture's id.

```sh
gh api --paginate "users/m2ux/projectsV2/17/fields?per_page=100" \
  --jq '.[] | select(.name == "Status") | .id'
gh api --paginate "users/m2ux/projectsV2/17/items?per_page=100&fields=<fresh-status-field-id>" \
  > '/tmp/command-contract-board-reader/execution-evidence/board-items.json'
```

   Output: complete board items with complete embedded issue records and status field id. Do not replace this input with `/tmp/project17-command-quotes-board-readback.json`.

3. **Read Board Configuration and Read Board Assignee.** Fetch all fields and authenticated login. Match the current In Review and In Progress option ids from the field definition; do not construct the complete options from the captured selected value.

```sh
gh api --paginate "users/m2ux/projectsV2/17/fields?per_page=100" \
  > '/tmp/command-contract-board-reader/execution-evidence/board-fields.json'
gh api user --jq .login
```

   Output: board configuration, actual authenticated assignee login. Save the latter stdout as `authenticated-login.txt`. Find Status Field and Fetch Board Fields overlap by design in the frozen operation's separate calls; a retained complete current fields snapshot may support both interpretations without inventing missing values.

4. **Locate Epic Item.** Match repository `m2ux/workflow-server` and issue number `1616` in the current board items, and validate issue type, body, criteria, state and assignees. Retain item `291152098` only if the fresh snapshot confirms it. An absent item is a finding and stops Record Epic Review before a status write.

   Output: matched epic and item identity, or absent-item finding. The frozen script's `place()` keys selection by issue number, so a cross-repository number collision in a complete board snapshot must not be silently assumed safe; this capture does not establish board-wide uniqueness.

5. **Refresh review inputs immediately before the board action.** Apply Save Pull Request Snapshot for #1641, produce compact JSONL for the dispatch input, and obtain the JSON review list from the record linked by the fresh PR body.

```sh
gh api repos/m2ux/workflow-server/pulls/1641 \
  > '/tmp/command-contract-board-reader/execution-evidence/epic-pr.json'
jq -c . '/tmp/command-contract-board-reader/execution-evidence/epic-pr.json' \
  > '/tmp/command-contract-board-reader/execution-evidence/prs.jsonl'
```

   Output: fresh single-object REST PR record and equivalent JSONL. Published-review retrieval is required, but the Agent Review Fields prescribe a fetched list rather than a specific download command. If the fresh PR still links the captured engineering record, retrieve its current contents through authenticated repository access and retain its returned JSON list as `agent-reviews.json`, including the exact retrieval parameters and response. That retrieval command is intentionally unresolved here: its source-retrieval mechanism was not established by the bounded document reads.

6. **Check Agent Review.** Apply Validate Agent Review with the freshly fetched PR record and published list. Missing, stale, incomplete or unresolved evidence stops In Review. A changed head or base requires a current review; test counts do not substitute.

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace" && \
  "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 skills/work-planner/scripts/agent_review.py \
  --pr '/tmp/command-contract-board-reader/execution-evidence/epic-pr.json' \
  --agent-reviews '/tmp/command-contract-board-reader/execution-evidence/agent-reviews.json'
```

   Output: validator exit code/stdout/stderr, Review Eligibility, checked head/base and blockers. No such output exists from this planning run.

7. **Record Dispatch Status → Compute Dispatch Status.** With current evidence and the actual fetched assignee, propose only #1616 as a review identity. The documented `--progress` input is omitted because no progress identity is requested; static CLI inspection confirms it is optional. Never pass an empty unquoted placeholder.

```sh
cd "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace" && \
  "/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/scripts/sbx" python3 skills/work-planner/scripts/deliver.py \
  --items '/tmp/command-contract-board-reader/execution-evidence/board-items.json' \
  --board users/m2ux/projectsV2/17 \
  --fields '/tmp/command-contract-board-reader/execution-evidence/board-fields.json' \
  --out '/tmp/command-contract-board-reader/execution-evidence/calls' \
  --assignee '<fresh-authenticated-login>' \
  --review 1616 \
  --prs '/tmp/command-contract-board-reader/execution-evidence/prs.jsonl' \
  --agent-reviews '/tmp/command-contract-board-reader/execution-evidence/agent-reviews.json'
```

   Output: generated status/assignee calls, local payload files, reports and exit status. The script checks epic review before emitting the changes. Do not predict a nonempty write: a currently matching item and assignee can require no calls. The exact generated filenames and stdout were not observed.

8. **Apply emitted calls only in the later authorized run; confirm individually.** The frozen Record Dispatch Status operation runs every emitted call, including assignee calls. Before execution, check their affected repository, issue and item match the selected epic and their status is within DISPATCH jurisdiction. Preserve each actual command, payload, output and exit status. A possible status write uses Set Item Status with a payload whose ids came from current board definitions:

```sh
gh api --method PATCH users/m2ux/projectsV2/17/items/<fresh-item-id> \
  --input '<generated-status-input-file>' --jq .id
```

   This is a conditional template, not an instruction to write the captured status back unconditionally.

9. **Read Board Configuration with Optional Item.** Fetch the selected item directly after any emitted write, and also for final confirmation when there is no call. Use the fresh ids:

```sh
gh api "users/m2ux/projectsV2/17/items/<fresh-item-id>?fields=<fresh-status-field-id>"
```

   Save the exact response as `item-291152098.json` only if that identity remains current. If the item still has the preceding status, Record Epic Review calls Record Dispatch Status again with the same evidence, then Read Board Configuration again. Preserve the discrepancy and repeated outputs; a stale list cannot prove a write failed. The skill supplies no numeric retry limit here, so do not claim convergence after an arbitrary number of attempts. Refresh tips immediately before board/handoff actions; changed tips invalidate old review eligibility.

10. **Provide Confirmed Statuses.** Report only the item-specific confirmed status or the unresolved discrepancy, the exact PR tips checked, validation outcome and any missing evidence. Do not report merge readiness or broader board reconciliation as the result of this operation.

## Evidence gaps and scope limits

- Missing current complete board items, current complete Status options, authenticated assignee, refreshed PR/publication records and installed-checkout verification.
- No validator output, generated call set, write output or current item readback was produced.
- The captured review's validation and complete-diff scope are statements in a record; this reader did not inspect the integration diff, criterion evidence, test logs, source checkout or publication transport.
- Mandatory prerequisite closure was not completed. Board Delivery lists Board Queue, Board, Issue, Pull Request and Agent Review; Board Queue and Pull Request introduce additional prerequisites. Several were not read, and no mode was selected/executed. The plan is a bounded operation trace, not a complete workflow run.
- The frozen skill and captured files were the only source reads. Outputs written by this task are limited to this /tmp plan folder and read receipts. No repository source, tracker, git, installed checkout, index or delivery state was changed.

