import html
import importlib.util
import json
import re
import shlex
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
base='fbce2c7535b1518dd3ebb4dbe845b67576186d94'
spec=importlib.util.spec_from_file_location('quote_model',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
safe_values={
 'owner':'m2ux','repo':'workflow-server','repository':'workflow-server',
 'issue-owner':'m2ux','issue-repo':'workflow-server','pr-owner':'m2ux','pr-repo':'workflow-server',
 'issue-number':'1616','pull-request-number':'1641','template-number':'13','board-number':'17',
 'item-id':'291152098','issue-id':'1001','status-field-id':'422017304',
 'head-sha':'a'*40,'head-commit':'a'*40,
 'held-issue-numbers':'1615,1616','complete-epic-numbers':'1616',
 'board-identity':'users/m2ux/projectsV2/17','survey-board':'users/m2ux/projectsV2/17',
 'unit-identity':'I17:E01:W01+W02','free-slot-count':'3','lane-index':'2',
 'initiative-number':'17','epic-number':'2','task-number-map':'1:2,3:4','epic-number-map':'1:2,3:4',
 'criterion-ids':'AC1,AC2','task-ids':'W01,W02','window-start-date':'2026-11-06',
 'initiative-filter':'I17','hex-colour':'b60205',
}
quoted=re.compile(r"'[^'\n]*'|\"[^\"\n]*\"")
removed=[]
retained=[]
changed={}
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    before=path.read_text()
    lines=before.splitlines(keepends=True)
    plain=[line.rstrip('\n') for line in lines]
    for start,end in check.scan_blocks(plain).invocations:
        payload='\n'.join(plain[start:end+1]).removeprefix('<big><pre>').strip()
        is_shell=payload.startswith(('cd ','gh ','git ','python3 ','gitnexus '))
        for index in range(start,end+1):
            edits=[]
            for match in quoted.finditer(lines[index]):
                links=list(check.ARGUMENT_LINK.finditer(match[0]))
                if not links:continue
                labels=[html.unescape(m[1]).strip('<>') for m in links]
                row={'file':str(path.relative_to(root)),'line':index+1,'before':match[0],'parameters':labels}
                if not is_shell or any(name not in safe_values for name in labels):
                    retained.append(row)
                    continue
                rendered=html.unescape(check.ARGUMENT_LINK.sub(lambda m:safe_values[html.unescape(m[1]).strip('<>')],match[0][1:-1]))
                if not re.fullmatch(r'[A-Za-z0-9_./:@#%+=,-]+',rendered) or rendered[0] in '#~':
                    retained.append(row)
                    continue
                unquoted=match[0][1:-1]
                assert shlex.split(match[0][0]+rendered+match[0][-1])==shlex.split(rendered)
                row.update(after=unquoted,rendered_sample=rendered,reason='Validated shell-safe typed identifier/number/endpoint; no shell quoting is needed.')
                removed.append(row)
                edits.append((match.start(),match.end(),unquoted))
            for start_pos,end_pos,replacement in reversed(edits):
                lines[index]=lines[index][:start_pos]+replacement+lines[index][end_pos:]
    after=''.join(lines)
    if after!=before:
        path.write_text(after)
        changed[str(path.relative_to(root))]=before

path=root/'skills/work-planner/guidelines.md'
before=path.read_text()
old='Quote shell arguments containing placeholders and escape substituted values for their shell, URL, query or payload context.'
new='Quote variable paths, free text, refs, query strings and values that may contain shell metacharacters; leave validated shell-safe numeric values and identifiers unquoted. Escape substituted values for their shell, URL, query or payload context.'
assert before.count(old)==1
path.write_text(before.replace(old,new))

failures=[]
for name,original in changed.items():
    after=(root/name).read_text().splitlines(keepends=True)
    by_line={}
    for row in removed:
        if row['file']==name:by_line.setdefault(row['line']-1,[]).append(row)
    for index,rows in by_line.items():
        # Replay exact original spans rather than searching repeated unquoted tokens.
        old_line=original.splitlines(keepends=True)[index]
        expected=old_line
        for row in rows:
            expected=expected.replace(row['before'],row['after'],1)
        if after[index]!=expected:failures.append({'file':name,'line':index+1})
    for index,line in enumerate(original.splitlines(keepends=True)):
        if index not in by_line and after[index]!=line:failures.append({'file':name,'line':index+1,'reason':'Unexpected edit'})
    old_links=[(m[0],m[1]) for m in check.LINK.finditer(original)]
    new_links=[(m[0],m[1]) for m in check.LINK.finditer(''.join(after))]
    if old_links!=new_links:failures.append({'file':name,'reason':'Link content changed'})
result={'base':base,'removed_shell_quote_pairs':len(removed),'retained_quoted_linked_arguments':len(retained),'changed_command_files':len(changed),'link_title_quotes_preserved':not failures,'links_prose_flags_order_and_unselected_payload_preserved':not failures,'typed_sample_argv_equal':not failures,'failures':failures,'removals':removed,'retained':retained}
Path('/tmp/project17-command-quote-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('removals','retained')},ensure_ascii=False))
assert not failures
