import importlib.util
import json
import re
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('literal_quote_check',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
rows=[]
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    lines=path.read_text().splitlines()
    for start,end in check.scan_blocks(lines).invocations:
        payload='\n'.join(lines[start:end+1]).removeprefix('<big><pre>').strip()
        if not payload.startswith(('cd ','gh ','git ','python3 ','gitnexus ')):continue
        for index in range(start,end+1):
            for match in re.finditer(r"'[^'\n]*'|\"[^\"\n]*\"",lines[index]):
                body=match[0][1:-1]
                if re.fullmatch(r'[A-Za-z0-9_./:@#%+=,-]+',body) and body[0] not in '#~':
                    rows.append({'file':str(path.relative_to(root)),'line':index+1,'before':match[0],'after':body,'prefix':lines[index][:match.start()]})
Path('/tmp/project17-literal-quote-inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row['file'].split('/')[-1],row['line'],row['before'])
print('Total:',len(rows))
