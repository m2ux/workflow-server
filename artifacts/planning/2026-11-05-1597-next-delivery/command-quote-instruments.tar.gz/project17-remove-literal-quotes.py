import importlib.util
import json
import re
import shlex
import subprocess
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
rows=json.loads(Path('/tmp/project17-literal-quote-inventory.json').read_text())
assert len(rows)==15
for name in sorted({row['file'] for row in rows}):
    path=root/name
    lines=path.read_text().splitlines(keepends=True)
    for row in rows:
        if row['file']!=name:continue
        index=row['line']-1
        assert row['before'] in lines[index]
        assert row['prefix'].strip() and not row['prefix'].rstrip().endswith(('&&','||',';','|'))
        assert shlex.split(row['before'])==shlex.split(row['after'])
        lines[index]=lines[index].replace(row['before'],row['after'],1)
    path.write_text(''.join(lines))
audit=json.loads(Path('/tmp/project17-command-quote-audit.json').read_text())
audit['literal_quote_pairs_removed']=len(rows)
for row in rows:
    row.pop('prefix')
    row.update(parameters=[],rendered_sample=row['after'],reason='Fixed shell-safe literal argument; quoted and unquoted argv are identical.')
    audit['removals'].append(row)
audit['removed_shell_quote_pairs']=len(audit['removals'])
failures=[]
for name in sorted({row['file'] for row in audit['removals']}):
    old=subprocess.check_output(['git','show',audit['base']+':'+name],cwd=root,text=True)
    lines=old.splitlines(keepends=True)
    for row in audit['removals']:
        if row['file']==name:
            index=row['line']-1
            assert row['before'] in lines[index],row
            lines[index]=lines[index].replace(row['before'],row['after'],1)
    if ''.join(lines)!=(root/name).read_text():failures.append({'file':name,'reason':'Unaccounted command/prose drift'})
audit['failures']=failures
Path('/tmp/project17-command-quote-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
assert not failures
print('114 shell quote pairs removed: 99 typed linked arguments and 15 fixed safe literals. Exact quote-only delta verified.')
