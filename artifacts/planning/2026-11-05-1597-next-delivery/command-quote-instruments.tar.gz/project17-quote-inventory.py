import collections
import importlib.util
import json
import re
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('quote_check',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
quotes=re.compile(r"'[^'\n]*'|\"[^\"\n]*\"")
rows=[]
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    lines=path.read_text().splitlines()
    for start,end in check.scan_blocks(lines).invocations:
        for index in range(start,end+1):
            for match in quotes.finditer(lines[index]):
                links=list(check.ARGUMENT_LINK.finditer(match[0]))
                if links:
                    rows.append({'file':str(path.relative_to(root)),'line':index+1,'quoted':match[0],'fields':[m[2] for m in links]})
Path('/tmp/project17-quote-inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
counts=collections.Counter((row['quoted'],tuple(row['fields'])) for row in rows)
print('Quoted linked tokens:',len(rows),'unique:',len(counts))
for (value,fields),count in counts.items():print(count, value, '=>',','.join(fields))
