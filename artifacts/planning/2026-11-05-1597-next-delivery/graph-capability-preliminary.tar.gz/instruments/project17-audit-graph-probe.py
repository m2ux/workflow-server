from pathlib import Path
import json,hashlib
root=Path('/tmp/i17-e01-graph-probe')
complete=json.loads((root/'complete-symbols.json').read_text())
surface=json.loads((root/'changes.json').read_text())['result']
measure=root/'complete-measurements'
failures=[]
for index,symbol in enumerate(complete['symbols']):
    record=json.loads((measure/'contexts'/f'{index:04}.json').read_text())
    if record['params']['uid']!=symbol['id'] or record['native'].get('symbol',{}).get('uid')!=symbol['id'] or record['native'].get('status')!='found':
        failures.append({'context':index,'symbol':symbol['id']})
steps=json.loads((measure/'flow_steps.json').read_text())['rows']
for flow in surface['affected_processes']:
    rows=[row for row in steps if row['process_id']==flow['id']]
    if len(rows)!=flow['step_count'] or [row['step_index'] for row in rows]!=list(range(1,flow['step_count']+1)):
        failures.append({'flow':flow['id'],'rows':len(rows),'expected':flow['step_count']})
queried=[]
for path in sorted((measure/'flow-queries').glob('*.json')):
    record=json.loads(path.read_text())
    actual=record['native'].get('processes',[])
    queried.append({'requested':record['requested']['id'],'matched':any(p['id']==record['requested']['id'] for p in actual),'native_listed_symbols':len(record['native'].get('process_symbols',[]))})
statuses=[json.loads((measure/name).read_text()) for name in ['status-before.json','status-after.json']]
fresh=all(s['status']=='up-to-date' and s['current']['commit']==complete['head']==s['index']['commit'] for s in statuses)
result={'head':complete['head'],'base':complete['base'],'symbols':complete['recovered_total'],'contexts':len(complete['symbols']),'flows':len(surface['affected_processes']),'complete_ordered_steps':len(steps),'fresh_status_pair':fresh,'failures':failures,'native_flow_queries':queried,'use':'Preliminary capability proof only. Final integration head requires fresh complete measurements.','limits':'Graph-index coverage warnings remain. Native responses omit current staleness blocks. Native query search results do not establish exact full flow traces; exact process-membership rows are separate measurements.'}
(root/'parent-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='native_flow_queries'}))
raise SystemExit(bool(failures) or not fresh)
