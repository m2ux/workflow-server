import { buildDetectChangesDiffArgs } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/mcp/local/local-backend.js';
import { parseDiffHunksResult, coalesceHunksByPath, hunksOverlapRange } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/storage/git.js';
import { pathSuffixOf } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/mcp/local/path-predicate.js';
import { getStoragePaths } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/storage/repo-manager.js';
import { withLbugDb, executeQuery, closeLbug } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/core/lbug/lbug-adapter.js';
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, writeSync } from 'node:fs';

const root = process.cwd();
const original = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const status = JSON.parse(readFileSync(process.argv[3], 'utf8'));
const head = execFileSync('git', ['rev-parse', 'HEAD'], {encoding:'utf8'}).trim();
if (head !== status.current.commit || head !== status.index.commit || status.status !== 'up-to-date') throw new Error('Index and requested checkout differ');
const diff = execFileSync('git', buildDetectChangesDiffArgs('compare', original.params.base_ref), {encoding:'utf8',maxBuffer:268435456});
const parsed = parseDiffHunksResult(diff);
if (parsed.unparsedGitHeaders) throw new Error('Diff parsing is incomplete');
const hunks = coalesceHunksByPath(parsed.files);
const selected = new Map();
const queries = [];
try {
  await withLbugDb(getStoragePaths(root).lbugPath, async () => {
    for (const [path, ranges] of hunks) {
      if (!/^[A-Za-z0-9_./-]+$/.test(path)) throw new Error('Unquoted path needs explicit handling');
      const suffix = pathSuffixOf(path);
      const query = `MATCH (n) WHERE (n.filePath = '${path}' OR n.filePath ENDS WITH '${suffix}') AND NOT n.id STARTS WITH 'BasicBlock:' AND n.startLine IS NOT NULL AND n.endLine IS NOT NULL RETURN n.id AS id, n.name AS name, labels(n) AS type, n.filePath AS filePath, n.startLine AS startLine, n.endLine AS endLine ORDER BY n.id`;
      const rows = await executeQuery(query);
      queries.push({path,query,rows,ranges});
      for (const row of rows) {
        if (hunksOverlapRange(ranges, Number(row.startLine), Number(row.endLine))) selected.set(row.id, {...row,change_type:'touched'});
      }
    }
  }, {readOnly:true,skipFts:true});
} finally {
  await closeLbug();
}
const listed = original.result.changed_symbols;
const result = {head,base:original.params.base_ref,reported_total:original.result.summary.changed_count,recovered_total:selected.size,raw_listing_count:listed.length,raw_listing_is_subset:listed.every(row=>selected.has(row.id)),queries,symbols:[...selected.values()]};
writeFileSync(process.argv[4],JSON.stringify(result,(_key,value)=>typeof value==='bigint'?value.toString():value,2)+'\n');
writeSync(1,JSON.stringify({head,reported:result.reported_total,recovered:result.recovered_total,rawSubset:result.raw_listing_is_subset,files:queries.length})+'\n');
if (result.recovered_total !== result.reported_total || !result.raw_listing_is_subset) process.exitCode=1;
