import {LocalBackend} from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/mcp/local/local-backend.js';
import {withLbugDb,executeQuery,closeLbug} from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/core/lbug/lbug-adapter.js';
import {getStoragePaths} from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/storage/repo-manager.js';
import {readFileSync,writeFileSync,mkdirSync,writeSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const [surfacePath,completePath,out]=process.argv.slice(2);
const surface=JSON.parse(readFileSync(surfacePath,'utf8'));
const complete=JSON.parse(readFileSync(completePath,'utf8'));
const root=process.cwd();
const encode=x=>JSON.stringify(x,(_k,v)=>typeof v==='bigint'?v.toString():v,2)+'\n';
const save=(name,x)=>writeFileSync(out+'/'+name,encode(x));
const git=(...a)=>execFileSync('git',a,{encoding:'utf8'}).trim();
const status=()=>JSON.parse(execFileSync('gitnexus',['status','--json'],{encoding:'utf8',maxBuffer:4194304}));
const head=git('rev-parse','HEAD');
if(git('status','--porcelain'))throw new Error('Review checkout must be clean');
if(complete.head!==head||complete.recovered_total!==complete.reported_total||!complete.raw_listing_is_subset)throw new Error('Surface recovery is incomplete or wrong revision');
mkdirSync(out,{recursive:true});
const before=status();save(existsSync(out+'/status-before.json')?'status-resume-before.json':'status-before.json',before);
if(before.status!=='up-to-date'||before.current.commit!==head||before.index.commit!==head)throw new Error('Index not current');
const backend=new LocalBackend();
const failures=[];
try{
 if(!await backend.init())throw new Error('No indexed repository');
 mkdirSync(out+'/contexts',{recursive:true});
 for(let i=0;i<complete.symbols.length;i++){
  const symbol=complete.symbols[i];
  const existing=out+'/contexts/'+String(i).padStart(4,'0')+'.json';
  if(existsSync(existing)){
   const prior=JSON.parse(readFileSync(existing,'utf8'));
   if(prior.params.uid!==symbol.id||prior.native.status!=='found'||prior.native.symbol?.uid!==symbol.id)throw new Error('Saved context does not match surface');
   continue;
  }
  const result=await backend.callTool('context',{repo:'workflow-server',uid:symbol.id});
  save('contexts/'+String(i).padStart(4,'0')+'.json',{method:'context',params:{uid:symbol.id},native:result});
  if(result.error||result.partial===true||result.status!=='found'||result.symbol?.uid!==symbol.id)failures.push({i,id:symbol.id,error:result.error,status:result.status});
  if(i%100===0)writeSync(1,encode({contexts:i+1,total:complete.symbols.length,failures:failures.length}));
 }
 mkdirSync(out+'/flow-queries',{recursive:true});
 for(let i=0;i<surface.result.affected_processes.length;i++){
  const flow=surface.result.affected_processes[i];
  const result=await backend.callTool('query',{repo:'workflow-server',query:flow.name,limit:1});
  save('flow-queries/'+String(i).padStart(3,'0')+'.json',{method:'query',params:{query:flow.name,limit:1},requested:flow,native:result});
 }
}finally{await backend.dispose();}
const ids=complete.symbols.map(s=>s.id);
const flows=surface.result.affected_processes.map(p=>p.id);
const quote=x=>"'"+x.replaceAll('\\','\\\\').replaceAll("'","\\'")+"'";
const list=xs=>'['+xs.map(quote).join(',')+']';
const queries={
 relationships:`MATCH (a)-[r:CodeRelation]->(b) WHERE a.id IN ${list(ids)} OR b.id IN ${list(ids)} RETURN a.id AS source, a.name AS source_name, a.filePath AS source_file, r.type AS relation, b.id AS target, b.name AS target_name, b.filePath AS target_file ORDER BY source, relation, target`,
 flow_steps:`MATCH (n)-[r:CodeRelation {type: 'STEP_IN_PROCESS'}]->(p:Process) WHERE p.id IN ${list(flows)} RETURN p.id AS process_id, p.heuristicLabel AS process_name, p.stepCount AS step_count, r.step AS step_index, n.id AS id, n.name AS name, n.filePath AS filePath, n.startLine AS startLine, n.endLine AS endLine ORDER BY process_id, step_index, id`
};
try{
 await withLbugDb(getStoragePaths(root).lbugPath,async()=>{
  for(const [name,query] of Object.entries(queries))save(name+'.json',{query,rows:await executeQuery(query),coordinates:'Raw indexed node lines are zero based; context display lines are one based.'});
 },{readOnly:false,skipFts:true});
}finally{await closeLbug();}
const after=status();save('status-after.json',after);
const fresh=after.status==='up-to-date'&&after.current.commit===head&&after.index.commit===head&&!git('status','--porcelain');
const summary={root,head,base:complete.base,contexts:ids.length,failures,flows:flows.length,fresh,limits:'Native context windows cap ordinary relationships at30; relationships.json recovers raw indexed edges without that cap. Native flow queries rank search matches and are not complete flow traces; flow_steps.json contains exact process-membership records. Both native responses and independent status evidence are retained without inventing native staleness blocks. Process extraction coverage warnings remain index limitations.'};
save('summary.json',summary);writeSync(1,encode(summary));
if(failures.length||!fresh)process.exitCode=1;
