import json
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
audit=json.loads(Path('/tmp/project17-field-example-migration.json').read_text())
for move in audit['data_moves']:
    path=root/move['file']
    text=path.read_text()
    label='Example contents' if move['target'] in ('#development-snapshot','#issue-link-snapshot','#status-input-file') else 'Example output'
    old='**Example:**\n\n'+move['fence']
    assert old in text
    path.write_text(text.replace(old,'**'+label+':**\n\n'+move['fence'],1))
