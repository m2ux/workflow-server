import json
import re
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
audit=json.loads(Path('/tmp/project17-field-example-migration.json').read_text())
for item in audit['fields']:
    values=item['values']
    selected={name:[items[0]] for name,items in values.items()}
    file,target=item['file'],item['target']
    if file.endswith('pull-request.md') and target=='#identity':
        selected=values
    if file.endswith('board.md') and target=='#board-coordinates':
        selected={'owner':['m2ux'],'board-number':['13']}
    if file.endswith('board.md') and target=='#item-coordinates':
        selected={'board':['users/m2ux/projectsV2/13'],'item-id':['1001']}
    if file.endswith('board.md') and target=='#status-field':
        selected={'field-id':['419167630'],'option-id':['OPTION']}
    if len(selected)==1:
        data='\n'.join(next(iter(selected.values())))
    else:
        data='\n'.join(name+': '+value for name,items in selected.items() for value in items)
    revised='\n**Example:**\n\n```text\n'+data+'\n```\n'
    path=root/file
    text=path.read_text()
    assert item['fence'] in text,(file,target)
    path.write_text(text.replace(item['fence'],revised,1))
    item['values']=selected
    item['fence']=revised
    if file.endswith('delivery-branches.md') and target=='#epic-identity':
        text=path.read_text()
        text=text.replace('The initiative and epic identifier, with an epic branch prefix of `i<initiative-number>/e<epic-number>`; **Example:** `i07/e00`.','The initiative and epic identifier, with an epic branch prefix of `i<initiative-number>/e<epic-number>`.')
        path.write_text(text)
audit['remaining_invocations']=116
audit['field_format_deduplication']='One representative for repeated values of each parameter format; repository-qualified and local identities keep both supported forms.'
Path('/tmp/project17-field-example-migration.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'fields_refined':len(audit['fields']),'command_examples_removed':88,'remaining_executing_invocations':116}))
