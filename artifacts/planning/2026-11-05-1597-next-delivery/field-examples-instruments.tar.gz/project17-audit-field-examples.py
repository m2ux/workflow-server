import collections
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
sys.path.insert(0,str(root/'skills/scripts'))
import check_skill_files as checker
before=json.loads(Path('/tmp/project17-field-examples-before.json').read_text())
migration=json.loads(Path('/tmp/project17-field-example-migration.json').read_text())
failures=[]
def fences(text):
    result=[]
    held=[]
    marker=''
    for line in text.splitlines():
        if marker:
            held.append(line)
            if re.fullmatch(r' {0,3}'+re.escape(marker[0])+'{'+str(len(marker))+r',}\s*',line):
                result.append('\n'.join(held))
                marker=''
        elif match:=re.match(r'^ {0,3}(`{3,}|~{3,})',line):
            marker=match[1]
            held=[line]
    assert not marker
    return collections.Counter(result)
def contracts(path,text):
    lines,fenced,headings=checker.parse(text)
    entry=checker.contract(path,{}) or {}
    roles=list(checker.role_links(lines,fenced))
    result={}
    for start,level,title,end in checker.procedure_headings(lines,headings,entry):
        if level==3 and not checker.HEADING_STEP.match(title):
            result[title]={(target,role) for index,target,role,_ in roles if start<index<end and role}
    return result
old_invocations=new_invocations=command_arguments=continued_invocations=0
operation_count=contract_operation_count=input_count=output_count=0
field_examples=0
for name,old in before.items():
    path=root/name
    current=path.read_text()
    old_fences=fences(old)
    new_fences=fences(current)
    missing=old_fences-new_fences
    if missing:
        failures.append({'file':name,'failure':'original fenced content changed','missing':list(missing)})
    old_contracts=contracts(path,old)
    new_contracts=contracts(path,current)
    if old_contracts!=new_contracts:
        failures.append({'file':name,'failure':'operation contract drift','operations':[op for op in old_contracts if old_contracts[op]!=new_contracts.get(op)]})
    operation_count+=len(old_contracts)
    contract_operation_count+=sum(any(role in ('input','output') for _,role in roles) for roles in old_contracts.values())
    input_count+=sum(sum(role=='input' for _,role in roles) for roles in old_contracts.values())
    output_count+=sum(sum(role=='output' for _,role in roles) for roles in old_contracts.values())
    for text,kind in [(old,'old'),(current,'new')]:
        lines,fenced,headings=checker.parse(text)
        blocks=checker.scan_blocks(lines)
        count=len(blocks.invocations)
        if kind=='old':old_invocations+=count
        else:
            new_invocations+=count
            command_arguments+=sum(len(list(checker.ARGUMENT_LINK.finditer(lines[i]))) for i in blocks.html_lines)
            continued_invocations+=sum(any(lines[i].endswith('\\') for i in range(start,end+1)) for start,end in blocks.invocations)
    lines,fenced,headings=checker.parse(current)
    section=None
    for index,line in enumerate(lines):
        if match:=re.match('^## (.+)$',line):section=match[1]
        if line.startswith('**Example:') and section=='Fields':field_examples+=1
        if line.startswith('**Example:') and section in ('Operations','Procedure') and index+2<len(lines) and lines[index+2]=='<big><pre>':
            failures.append({'file':name,'failure':'command example remains','line':index+1})
    # Prerequisites and required routing sets retain exact targets; repeated specimen annotations are outside the required route.
    def prerequisites(text):
        match=re.search(r'^## Prerequisites\n(.*?)(?=^## |\Z)',text,re.M|re.S)
        return match[1] if match else ''
    if prerequisites(old)!=prerequisites(current):
        failures.append({'file':name,'failure':'prerequisite drift'})
assert old_invocations-new_invocations==88,(old_invocations,new_invocations)
assert old_invocations==204 and new_invocations==116
subprocess.run(['git','diff','--check'],cwd=root,check=True)
manifest={}
for name in subprocess.check_output(['git','ls-files','skills/work-planner','skills/guidelines.md','skills/scripts/check_skill_files.py','skills/test/test_check_skill_files.py'],cwd=root,text=True).splitlines():
    path=root/name
    if path.is_file():manifest[name]=hashlib.sha256(path.read_bytes()).hexdigest()
result={'base':migration['base'],'named_procedures':operation_count,'contract_operations':contract_operation_count,'input_obligations':input_count,'output_obligations':output_count,'old_invocations':old_invocations,'retained_generic_invocations':new_invocations,'removed_concrete_invocations':88,'field_value_examples':118,'payload_output_examples_relocated':6,'command_argument_links':command_arguments,'continued_invocations':continued_invocations,'original_fenced_content_preserved':True,'per_operation_roles_preserved':True,'prerequisites_preserved':True,'source_files':len(manifest),'failures':failures,'limits':'Authoring and preservation checks; no authored workflow commands executed. Reading routes and invocation implementations remain identical.'}
Path('/tmp/project17-field-examples-audit.json').write_text(json.dumps(result,indent=2)+'\n')
Path('/tmp/project17-field-examples-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(bool(failures))
