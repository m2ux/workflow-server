import json
import re
import sys
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
sys.path.insert(0,str(root/'skills/scripts'))
import check_skill_files as checker
before=json.loads(Path('/tmp/project17-field-examples-before.json').read_text())
audit=json.loads(Path('/tmp/project17-field-example-migration.json').read_text())
for field in audit['fields']:
    text=before[field['file']]
    lines,_,headings=checker.parse(text)
    start,level,title=next((i,level,title) for i,level,title in headings if checker.anchor_of(title)==field['target'][1:])
    end=checker.heading_end(headings,start,level,len(lines))
    body='\n'.join(lines[start+1:end])
    values=[v for items in field['values'].values() for v in items]
    if '**Example' in body or any('`'+v+'`' in body for v in values):
        print(field['file'].split('/')[-1],field['target'],json.dumps(body.strip()))
print('Unexpected option fragments in field values:')
for field in audit['fields']:
    for items in field['values'].values():
        for value in items:
            if ' --' in value and field['target']!='#instrument':print(field['file'],field['target'],value)
