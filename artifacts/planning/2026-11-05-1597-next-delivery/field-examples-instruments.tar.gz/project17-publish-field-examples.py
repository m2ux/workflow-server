import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime,timezone
from pathlib import Path

head='a9ea82c1c04eda31b1cc2b4741d795ad80504a66'
base='03d353300ca4804194fd50d316d73e3bf1270d1d'
previous='4882414d678268aaa282fb4c0b184f14e3e47d1b'
product=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
engineering=Path('/home/mike1/projects/dev/workflow-server/.engineering')
record=engineering/'artifacts/planning/2026-11-05-1597-next-delivery'
url='https://github.com/m2ux/workflow-server/blob/engineering/'+str(record.relative_to(engineering))+'/'
def dump(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
pr=json.loads(Path('/tmp/project17-field-examples-pr-current.json').read_text())
assert pr['head']['sha']==head and pr['base']['sha']==base and pr['draft'] and not pr['merged']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=product,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=product,text=True)
paths=subprocess.check_output(['git','diff','--name-only',previous,head],cwd=product,text=True).splitlines()
assert len(paths)==22 and all(p.endswith('.md') for p in paths)
manifest=json.loads(Path('/tmp/project17-field-examples-source-manifest.json').read_text())
assert len(manifest)==115 and all(hashlib.sha256((product/p).read_bytes()).hexdigest()==sha for p,sha in manifest.items())
audit=json.loads(Path('/tmp/project17-field-examples-audit.json').read_text())
assert not audit['failures'] and audit['contract_operations']==240 and audit['retained_generic_invocations']==116
for src,dest in [('project17-field-examples-audit.json','field-examples-audit.json'),('project17-field-example-migration.json','field-examples-migration.json'),('project17-field-examples-source-manifest.json','field-examples-source-manifest.json'),('project17-field-examples-verified-work-planner.log','integration-work-planner.log'),('project17-field-examples-verified-installed.log','integration-installed-check.log')]:
    shutil.copyfile(Path('/tmp')/src,record/dest)
assert 'Ran 934 tests in 39.753s' in (record/'integration-work-planner.log').read_text() and 'OK (skipped=1)' in (record/'integration-work-planner.log').read_text()
assert '58 files checked, 0 findings' in (record/'integration-installed-check.log').read_text()
members=[]
archive=record/'field-examples-instruments.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p in sorted(Path('/tmp').glob('project17-*field*examples*.py'))+sorted(Path('/tmp').glob('project17-*field*formats*.py')):
        data=p.read_bytes()
        assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)',data)
        tar.add(p,arcname=p.name,recursive=False)
        members.append({'member':p.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
dump(record/'field-examples-instruments-manifest.json',{'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members})

validation=f'''# E01 Integration Verification

## Identity and Scope

PR #1641 integrates `{head}` into workspace `{base}`. The clean linked epic worktree holds the pushed head. This review composes the [complete preceding integration review](https://github.com/m2ux/workflow-server/blob/9caf88b4f/artifacts/planning/2026-11-05-1597-next-delivery/integration-validation.md) with the 22 Markdown-file example-placement delta from `{previous}`. All eight task PRs and checked criteria remain delivered on #1616.

## Current Checks

- Work Planner: 934 tests in 39.753 seconds; 933 pass and one opt-in live Development-link check skips.
- Installed declaration: 58 files checked, zero findings. No model override or cache.
- Frozen source: all 115 manifest hashes match the clean committed source after the final tests.
- Whitespace: complete target-to-head and previous-head-to-head checks pass.
- Shared checker and tests have identical source to the preceding 270-test passing run. No executable, declaration, template or test changes accompany this correction.

## Example Ownership and Preservation

The migration removes 88 concrete command specimens and places value-format examples under 118 linked Fields. Six payload/output specimens move to their owning input/result Field; their existing fenced bytes are retained. The Status Input File Field owns its JSON integer/string types and payload example. Repeated sample numbers and paths have one representative per format; distinct task/hot-fix title and branch forms stay visible.

All 116 retained generic invocations are byte-identical and keep their order. They contain 455 role-tagged argument links and 62 continued invocations. All 240 IO-bearing operations retain exactly the same 824 input and 361 output obligations. The broader heading audit covers 242 named procedures, including two without IO contracts. Every original fenced template/specimen, heading identity and prerequisite block is preserved. No authored workflow command is executed by this audit.

Review checks optional/repeated argument use, the conditional hot-fix draft flag, execution locations, refusals and caller-facing results. Those conditions remain in operation steps. Fields own formats and examples; generic commands link their contracts. Existing contextual IO, script-reach, real-git checkout, revision and publication assertions remain active and pass. Field fences are data specimens and establish no executable reach or operation contract.

## Criteria

| Criterion | Current observation |
| --- | --- |
| AC1 | Declared checker support and its 270-test evidence are unchanged; installed checks accept the field specimens and retained command annotations. |
| AC2 | Focused entry/common context and runtime role definitions retain their validated structure. |
| AC3 | Modes retain heading/preamble/call contracts; Revise's skill-directory example sits under its linked Field. |
| AC4 | Protocols and their prerequisites are unchanged. |
| AC5 | Issue/body artifacts retain all command contracts and templates; value examples have Field owners. |
| AC6 | Board/queue/planning/review artifacts retain IO and subject ownership; Status Input File owns its payload format. |
| AC7 | Delivery/branch/PR artifacts retain executing invocations, conditional draft behavior and checkout/propagation assertions. |
| AC8 | Installed model governs the final corpus; 58 files have zero findings. |

## Reading and Measurement Limits

The parent traces Standup through Summarise Progress to Report Selection, Understand through graph operations to Base Branch/Symbol Identity/Flow Identity, and Revise through Check Skill Files to Skill Directory. Entry routes, owning files, prerequisite blocks and generic contract targets are unchanged. Examples move within the already required Fields and their owning documents. No new required file or operation route is introduced, so no new independent reading trial is selected. Earlier trials retain their explicitly Partial limits; no clean disclosure, complete external workflow or token-saving claim follows.

The architecture diagrams/native archive retain the explicit structural baseline `{previous}`. All executable/readers/declarations are byte-identical to that measured revision; no current-head native graph run is claimed for this documentation-only change. Code links and the graph audit remain pinned to their measured baseline; current example links name this head.

## Handoff

Publish and fetch the exact-head review record before ready and board writes. Workspace requires one human approving review and reviewer merge. E02 remains blocked on E01 reaching workspace. Findings outside Work Planner remain outside the requested gate.
'''
subprocess.run(['git','diff','--check',base,head],cwd=product,check=True)
(record/'integration-validation.md').write_text(validation)
dump(record/'integration-agent-review.json',[{'pull_request':pr['html_url'],'head':head,'base':base,'url':url+'integration-agent-review.json','reviewer':'codex:/root','reviewed_at':datetime.now(timezone.utc).isoformat(),'scope':'Complete E01 integration through composed prior per-unit and integration/caller reviews, plus the 22-file field-example delta: 88 concrete command removals, 118 value-format Field owners, six payload/output moves, guidelines and unchanged generic commands/consumers.','criteria':'AC1–AC8 retain verified delivery. All eight task PRs remain merged into the epic branch; example placement follows the approved request.','validation':'Final frozen-source Work Planner suite: 934 tests, 933 pass and one opt-in skip; installed model: 58 files/zero findings; 115 source hashes match commit; whitespace checks pass. All 240 operation IO sets and 116 generic invocations remain identical. Original fenced templates and prerequisites are retained. Executable/shared-checker source is unchanged from its 270-test evidence. Static reading paths remain the same; prior trials remain Partial. Native structure remains explicitly bound to 4882414d, with no new graph/runtime/disclosure claim.','findings':[]}])

overview=engineering/'artifacts/planning/2026-11-05-1641-skill-style-groundwork/overview.md'
text=overview.read_text()
insertion=f'''## Field Format Examples

Current revision `{head}` places fenced value, payload and output examples under their linked Fields. The [Status Input File](https://github.com/m2ux/workflow-server/blob/{head}/skills/work-planner/artifacts/board.md#status-input-file) shows the file-path and JSON-content forms. Each executing step carries its generic invocation and meaningful usage conditions.

The diagrams and native archive below retain structural baseline `{previous}`. Executable readers and declarations are identical at the current revision; the [current verification]({url}integration-validation.md) records the example-preservation audit separately.

'''
text=text.replace('## Structure\n',insertion+'## Structure\n',1)
text=text.replace('The current installed checker and both test suites pass.','The current Work Planner suite and installed checker pass; unchanged shared-checker source retains its preceding suite evidence.')
overview.write_text(text)

epic=json.loads(Path('/tmp/project17-field-examples-epic-current.json').read_text())
assert epic['body']==json.loads(Path('/tmp/project17-field-examples-epic-before.json').read_text())['body']
body=epic['body']
needle='Linked command arguments establish their contracts without a repeated parameter list in prose.'
assert needle in body
body=body.replace(needle,needle+' Value-format, payload and output examples are fenced data under the owning linked Field; executing steps carry the generic invocation.')
assert body.count('- [x] **AC')==8 and body.count('| ✓ |')==8
dump(Path('/tmp/project17-field-examples-epic-patch.json'),{'body':body})
(engineering/'artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes/bodies/e01.md').write_text(body.rstrip()+'\n')
body=pr['body'].replace('All invocation arguments and literal payloads are preserved.','Generic invocation arguments and literal payloads are preserved.')
needle='### Instruction Corpus\n\n'
assert needle in body
body=body.replace(needle,needle+'- **Field examples.** Linked Fields own fenced value, payload and output examples. Executing steps carry generic commands and meaningful usage conditions, including the hot-fix draft flag.\n',1)
dump(Path('/tmp/project17-field-examples-pr-patch.json'),{'body':body})
plan=record/'field-examples.md'
plan.write_text(plan.read_text().replace('- [ ] In progress: relocate examples and update the authoring rule.','- [x] Relocate examples and update the authoring rule.').replace('- [ ] Audit command/contract preservation and validate affected readers.','- [x] Audit command/contract preservation and validate affected readers.').replace('- [ ] Commit, push and publish the current review handoff.','- [ ] In progress: publish the current review handoff; product commit is pushed.'))
readme=record/'README.md'
text=readme.read_text().replace('Current-head sequences for every reported affected process','Structural baseline 4882414d sequences for every reported affected process').replace('Current-head context/flow order and freshness','Structural baseline 4882414d context/flow order and freshness')
text+='''| [Preservation audit](field-examples-audit.json) | Operation IO, generic invocation, fenced-content and prerequisite equality |
| [Migration ledger](field-examples-migration.json) | Every removed command and owning Field specimen |
| [Validated source](field-examples-source-manifest.json) | 115 final source hashes |
| [Executed instruments](field-examples-instruments.tar.gz) | Inventory, migration, refinement, audit and publication scripts |
| [Instrument identities](field-examples-instruments-manifest.json) | Safe archive members and hashes |
| [Published review gate](field-examples-review-gate.log) | Exact current head and target validated against the fetched published record |
'''
readme.write_text(text)
print(json.dumps({'head':head,'changed_markdown_files':22,'source_files':115,'command_examples_removed':88,'field_value_examples':118,'generic_invocations_preserved':116}))
