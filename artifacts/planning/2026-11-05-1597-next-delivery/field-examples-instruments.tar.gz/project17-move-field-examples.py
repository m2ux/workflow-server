import collections
import hashlib
import html
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
sys.path.insert(0,str(root/'skills/scripts'))
import check_skill_files as checker
inventory=json.loads(Path('/tmp/project17-field-example-inventory.json').read_text())
assert len(inventory)==88
before={str(p.relative_to(root)):p.read_text() for p in sorted((root/'skills/work-planner').rglob('*.md')) if '/test/' not in str(p)}
Path('/tmp/project17-field-examples-before.json').write_text(json.dumps(before,indent=2)+'\n')
samples=collections.defaultdict(lambda:collections.defaultdict(list))
def add(file,target,name,value):
    value=html.unescape(value)
    if value not in samples[(file,target)][name]:
        samples[(file,target)][name].append(value)

for item in inventory:
    if not item['matched']:
        assert item['operation']=='Compute Board Changes'
        manual={'initiative-record':('initiative-json-file','issue-936.json'),'epic-records':('epic-json-file','issue-943.json issue-937.json'),'task-records':('task-json-file','issue-637.json'),'pull-request-records':('pull-request-records-file','prs.json'),'issue-link-snapshot':('issue-link-snapshot-file','links.json'),'board-identity':('board-identity','users/m2ux/projectsV2/9'),'board-fields':('board-fields-file','fields.json'),'board-items':('board-items-file','items.json'),'output-directory':('output-directory','board/'),'assignee-login':('assignee-login','m2ux')}
        for target,(name,value) in manual.items():
            add(item['file'],'#'+target,name,value)
        continue
    for param in item['values']:
        if item['operation']=='Check Dependencies':
            continue
        value=param['value']
        if item['label'].endswith("A hot-fix's delivering pull request.") and param['target']=='#body-file':
            value='body.md'
        if item['operation']=='Sync Epic' and param['target']=='#epic-bases':
            value=value.replace(' --revision ','\n')
        if value in ('{owner}','{repo}'):
            continue
        add(item['file'],param['target'],param['placeholder'].strip('<>'),value)

dependency='skills/work-planner/artifacts/dependency-graph.md'
samples[(dependency,'#dependency-files')]=collections.defaultdict(list,{'dependency-file-arguments':['I=/drafts/live-936.md\nE00=/drafts/live-943.md\nE01=/drafts/live-937.md\nE00:W01=/drafts/e00/w01.md\nE01:W01=/drafts/e01/w01.md\nR=/records/joins.md']})
# Repository-qualified values show the whole field, rather than isolated fragments.
for (file,target),values in list(samples.items()):
    if target=='#repository':
        samples[(file,target)]=collections.defaultdict(list,{'repository':['m2ux/workflow-server']})
    if file.endswith('pull-request.md') and target=='#identity':
        samples[(file,target)]=collections.defaultdict(list,{'identity':['m2ux/workflow-server#950','950']})
    if file.endswith('pull-request.md') and target=='#issue-identity':
        samples[(file,target)]=collections.defaultdict(list,{'issue-identity':['m2ux/workflow-server#637']})
    if file.endswith('initiative-issue-body.md') and target=='#source-evidence':
        samples[(file,target)]=collections.defaultdict(list,{'repository':['m2ux/workflow-server'],'source-path':['docs/spec.md'],'revision':['4a217fe6']})

removed=[]
for filename in before:
    text=before[filename]
    relevant=[r for r in inventory if r['file']==filename]
    for item in sorted(relevant,key=lambda r:-r['start']):
        removed.append({'file':filename,'operation':item['operation'],'source':text[item['start']:item['end']]})
        text=text[:item['start']]+text[item['end']:]
    before[filename]=before[filename]
    if relevant:
        (root/filename).write_text(re.sub(r'\n{3,}','\n\n',text))

data_moves=[]
destinations={('issue.md','Sweep Closure Evidence'):'#closure-findings',('issue.md','Capture Issue Links'):'#development-snapshot',('pull-request.md','Set Development Link'):'#development-relation',('pull-request.md','Remove Development Link'):'#failure',('pull-request.md','Capture Pull Request Links'):'#issue-link-snapshot'}
for filename in before:
    path=root/filename
    text=path.read_text()
    matches=list(re.finditer(r'^\*\*Example (?:output|payload):\*\*\n\n(```[^\n]*\n.*?\n```)',text,re.M|re.S))
    for match in reversed(matches):
        operation=re.findall(r'^### (.+)$',text[:match.start()],re.M)[-1]
        target=destinations[(path.name,operation)]
        data_moves.append({'file':filename,'operation':operation,'target':target,'fence':match[1]})
        text=text[:match.start()]+text[match.end():]
    if matches:
        path.write_text(re.sub(r'\n{3,}','\n\n',text))
assert len(data_moves)==5
board=root/'skills/work-planner/artifacts/board.md'
text=board.read_text()
status_prose='The input body names the Status field id and option id from the fetched board fields: `{"fields":[{"id":<status-field-id>,"value":"<status-option-id>"}]}`. Substitute the field id as a JSON integer and the option id as a JSON string.\n\n**Example payload:** `{"fields":[{"id":419167630,"value":"OPTION"}]}`.\n\n'
assert status_prose in text
text=text.replace(status_prose,'')
text=text.replace('The local input file containing the selected Status field and option ids in the exact JSON payload shown in the executing step.','The local input file containing the selected Status field id as a JSON integer and option id as a JSON string, from the fetched board fields.')
board.write_text(text)
data_moves.append({'file':str(board.relative_to(root)),'operation':'Set Item Status','target':'#status-input-file','fence':'```json\n{"fields":[{"id":419167630,"value":"OPTION"}]}\n```'})

field_records=[]
for filename in before:
    path=root/filename
    text=path.read_text()
    lines,fenced,headings=checker.parse(text)
    fields_start=next((i for i,level,title in headings if level==2 and title=='Fields'),None)
    if fields_start is None:
        assert not any(file==filename for file,_ in samples)
        continue
    fields={checker.anchor_of(title):(i,checker.heading_end(headings,i,level,len(lines))) for i,level,title in headings if level==3 and i>fields_start}
    additions={}
    for (file,target),values in samples.items():
        if file!=filename:
            continue
        assert target.startswith('#') and target[1:] in fields,(filename,target)
        start,end=fields[target[1:]]
        if len(values)==1:
            name=next(iter(values))
            # One representative per identical value format; preserve different collection/qualified forms.
            data='\n'.join(dict.fromkeys(values[name]))
        else:
            data='\n'.join(name+': '+value for name,items in values.items() for value in items)
        addition='\n**Example:**\n\n```text\n'+data+'\n```\n'
        additions[end]=additions.get(end,'')+addition
        field_records.append({'file':filename,'target':target,'values':dict(values),'fence':addition})
    for move in data_moves:
        if move['file']!=filename:
            continue
        start,end=fields[move['target'][1:]]
        additions[end]=additions.get(end,'')+'\n**Example:**\n\n'+move['fence']+'\n'
    for end,addition in sorted(additions.items(),reverse=True):
        lines[end:end]=addition.splitlines()+['']
    path.write_text(re.sub(r'\n{3,}','\n\n','\n'.join(lines).rstrip()+'\n'))

guide=root/'skills/work-planner/guidelines.md'
text=guide.read_text()
old='The step states where it runs, its inputs, applicable example and REST gap for GraphQL'
assert old in text
text=text.replace(old,'The step states where it runs, applicable conditions and REST gap for GraphQL')
old='State list separators, mapping syntax and repeated arguments beside the command.'
assert old in text
text=text.replace(old,'State optional and repeated-argument usage beside the command.')
old='Retain hard-coded values in explicitly labelled examples beside the executing step\'s generic command or payload template so their shape remains clear. Examples illustrate input values; they do not supply defaults or identify the current target.'
assert old in text
text=text.replace(old,'Fields contracts own value formats and fenced examples of values, payloads and outputs. Each executing step carries its generic linked invocation; the linked Fields supply its format examples. Use data-language fences for field specimens and deduplicate examples of the same format. Examples illustrate shape, not defaults or the current target.')
guide.write_text(text)

# All retained invocations are byte-identical, in order; only labelled concrete specimens disappear.
block=re.compile(r'<big><pre>\n?(.*?)\n?</pre></big>',re.S)
failures=[]
for filename,old in before.items():
    current=(root/filename).read_text()
    expected=old
    for item in sorted((r for r in inventory if r['file']==filename),key=lambda r:-r['start']):
        expected=expected[:item['start']]+expected[item['end']:]
    if [m[1] for m in block.finditer(expected)]!=[m[1] for m in block.finditer(current)]:
        failures.append({'file':filename,'failure':'generic invocation drift'})
    old_lines,old_fenced,old_headings=checker.parse(old)
    new_lines,new_fenced,new_headings=checker.parse(current)
    # Operations, conditions, callers and prerequisites retain their identities.
    if [(level,title) for _,level,title in old_headings]!=[(level,title) for _,level,title in new_headings]:
        failures.append({'file':filename,'failure':'heading drift'})
    old_roles={(target,role) for _,target,role,_ in checker.role_links(old_lines,old_fenced) if role}
    new_roles={(target,role) for _,target,role,_ in checker.role_links(new_lines,new_fenced) if role}
    if old_roles!=new_roles:
        failures.append({'file':filename,'failure':'role drift','missing':sorted(old_roles-new_roles),'added':sorted(new_roles-old_roles)})
assert not failures,failures
audit={'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'command_examples_removed':len(removed),'field_value_examples':len(field_records),'payload_output_examples_moved':len(data_moves),'remaining_invocations':sum(len(list(block.finditer((root/name).read_text()))) for name in before),'generic_invocations_byte_identical':True,'headings_and_file_roles_preserved':True,'fields':field_records,'data_moves':data_moves,'removed_commands':removed,'failures':failures}
Path('/tmp/project17-field-example-migration.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({k:v for k,v in audit.items() if k not in ('fields','data_moves','removed_commands')}))
