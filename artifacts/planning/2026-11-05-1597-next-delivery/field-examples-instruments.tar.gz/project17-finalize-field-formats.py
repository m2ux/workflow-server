import json
from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
path=root/'skills/work-planner/artifacts/pull-request.md'
text=path.read_text()
text=text.replace('The opening bracket and initiative id matched against task and epic titles, such as `[I07`.','The opening bracket and initiative id matched against task and epic titles.')
audit=json.loads(Path('/tmp/project17-field-example-migration.json').read_text())
for item in audit['fields']:
    if item['file']!=str(path.relative_to(root)) or item['target'] not in ('#title','#head-branch'):
        continue
    if item['target']=='#title':
        values={'title':['[I07:E00] Purpose','[F00] Reject Bad Keys']}
        data='[I07:E00] Purpose\n[F00] Reject Bad Keys'
    else:
        values={'task-branch':['i07/e00/w01-purpose'],'hot-fix-branch':['f00-key-validation'],'epic-base':['i07/e00/main']}
        data='\n'.join(name+': '+items[0] for name,items in values.items())
    new='\n**Example:**\n\n```text\n'+data+'\n```\n'
    assert item['fence'] in text
    text=text.replace(item['fence'],new,1)
    item['values']=values
    item['fence']=new
path.write_text(text)
Path('/tmp/project17-field-example-migration.json').write_text(json.dumps(audit,indent=2)+'\n')
