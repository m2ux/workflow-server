from pathlib import Path
root=Path('/home/mike1/projects/dev/workflow-server/.engineering/artifacts/planning/2026-11-05-1597-next-delivery')
(root/'field-examples.md').write_text('''# Field Format Examples

Executing steps carry one generic linked command. Its Fields contracts own fenced value, payload and output examples, deduplicated by format. Preserve meaningful option/repetition rules, refusal behavior and conditional hot-fix draft behavior in the operation. Examples describe shape, not defaults or current targets. Update the owning guidelines before validation.

Inventory every command example and map its useful values to linked Fields. Move existing payload/output specimens to their owning result/input contract as literal fenced data. Preserve generic invocation bytes, operation identities, prerequisites, IO obligations and all templates except the deliberate specimen relocation. Field specimens supply no executing command, input contract or script reach. Review existing inline examples in affected Fields for duplicate format descriptions.

## Progress

- [ ] In progress: relocate examples and update the authoring rule.
- [ ] Audit command/contract preservation and validate affected readers.
- [ ] Commit, push and publish the current review handoff.
''')
readme=root/'README.md'
readme.write_text(readme.read_text()+'''\n## Field Format Examples\n\n| Artifact | What it holds |\n| --- | --- |\n| [Field format examples](field-examples.md) | Field-owned fenced examples, command specimen relocation and preservation checks |\n''')
