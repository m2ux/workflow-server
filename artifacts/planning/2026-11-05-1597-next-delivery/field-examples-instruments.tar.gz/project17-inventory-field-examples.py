import html
import json
import re
import shlex
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
link=re.compile(r'\[\*\*([^\n]*?)\*\*\]\(([^\s)]+)(?:\s+"[^"]*")?\)')
block=re.compile(r'<big><pre>\n?(.*?)\n?</pre></big>',re.S)
def flatten(value):
    return re.sub(r'\s+',' ',html.unescape(value).replace('\\\n','')).strip()
records=[]
for path in sorted((root/'skills/work-planner').rglob('*.md')):
    text=path.read_text()
    if '/test/' in str(path):
        continue
    for match in re.finditer(r'^\*\*Example:\*\*[^\n]*\n\n(?=<big><pre>)',text,re.M):
        example=block.match(text,match.end())
        assert example
        previous=list(block.finditer(text,0,match.start()))[-1]
        # A second example in the same step uses that step's generic invocation.
        generic_block=previous
        previous_label=text[max(0,previous.start()-120):previous.start()]
        if re.search(r'\*\*Example:\*\*[^\n]*\n\n$',previous_label):
            candidates=list(block.finditer(text,0,previous.start()))
            if candidates:
                generic_block=candidates[-1]
        generic=flatten(generic_block[1])
        concrete=flatten(example[1])
        # Non-placeholder annotations in the specimen stay unresolved.
        concrete=link.sub(lambda m:html.unescape(m[1]),concrete)
        parameters=[]
        masked=generic
        for index,item in enumerate(link.finditer(generic)):
            parameters.append({'placeholder':html.unescape(item[1]),'target':item[2]})
        count=iter(range(len(parameters)))
        masked=link.sub(lambda m:f'ZZZP{next(count)}ZZZ',generic)
        try:
            normalized_generic=' '.join(shlex.split(masked)).removesuffix(' ...')
            normalized_example=' '.join(shlex.split(concrete))
        except ValueError:
            normalized_generic=masked
            normalized_example=concrete
        pattern=re.escape(normalized_generic)
        for index in range(len(parameters)):
            pattern=pattern.replace(f'ZZZP{index}ZZZ',f'(?P<p{index}>.*?)')
        parsed=re.fullmatch(pattern,normalized_example)
        values=[]
        if parsed:
            for index,param in enumerate(parameters):
                value=parsed[f'p{index}']
                if value!=param['placeholder']:
                    values.append({**param,'value':value})
        operation=re.findall(r'^### (.+)$',text[:match.start()],re.M)[-1]
        records.append({'file':str(path.relative_to(root)),'operation':operation,'start':match.start(),'end':example.end(),'generic':generic,'example':concrete,'matched':bool(parsed),'values':values,'generic_raw':generic_block[1],'example_raw':example[1],'label':match[0].strip()})
Path('/tmp/project17-field-example-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
for item in records:
    print(item['file'].split('/')[-1]+' :: '+item['operation']+' :: '+str(item['matched'])+' :: '+json.dumps(item['values'],ensure_ascii=False))
    if not item['matched']:
        print('  GENERIC '+item['generic'])
        print('  EXAMPLE '+item['example'])
print('TOTAL',len(records),'MATCHED',sum(r['matched'] for r in records))
