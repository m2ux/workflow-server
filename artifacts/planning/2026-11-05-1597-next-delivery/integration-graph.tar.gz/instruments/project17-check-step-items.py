import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
skill=root/'skills/work-planner'
audit=json.loads(Path('/tmp/project17-step-item-audit.json').read_text())
spec=importlib.util.spec_from_file_location('step_check',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
failures=[]
bindings=[]
for name in sorted(set(row['file'] for row in audit['step_inventory'])):
    path=skill/name
    original=subprocess.check_output(['git','show',audit['base']+':'+str(path.relative_to(root))],cwd=root,text=True)
    current=path.read_text()
    restored=current.splitlines()
    for change in audit['changes']:
        if change['file']==name:
            index=change['line']-1
            if restored[index]!=change['after']:
                failures.append({'file':name,'line':index+1,'reason':'Unexpected current bytes'})
            restored[index]=change['before']
    if '\n'.join(restored)+'\n'!=original:
        failures.append({'file':name,'reason':'Text outside recorded bullet prefixes changes'})
    old_lines,_,old_headings=check.parse(original)
    new_lines,_,new_headings=check.parse(current)
    if old_headings!=new_headings:
        failures.append({'file':name,'reason':'Heading identity or position changes'})
    for text,lines in ((original,old_lines),(current,new_lines)):
        spans=check.scan_blocks(lines)
        payloads=[lines[a:b+1] for a,b in spans.invocations]
        fences=[line for i,line in enumerate(lines) if spans.fenced[i]]
        if text==original:
            old_payloads,old_fences=payloads,fences
        elif payloads!=old_payloads or fences!=old_fences:
            failures.append({'file':name,'reason':'Command or template payload changes'})
    bindings.append({'file':name,'before_sha256':hashlib.sha256(original.encode()).hexdigest(),'after_sha256':hashlib.sha256(current.encode()).hexdigest()})
result={'base':audit['base'],'files':len(bindings),'instruction_prefix_edits':len(audit['changes']),'headings_commands_templates_and_prose_preserved':not failures,'failures':failures,'bindings':bindings,'disclosure_trace':'SKILL, common context, prerequisite targets, every mode/protocol/operation heading and link bytes are preserved. Required reading paths, transitive prerequisite closure, command ownership and caller routing are identical; this formatting correction changes no reading path, so no new live reading-path trial is claimed.'}
Path('/tmp/project17-step-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='bindings'}))
print('Scopes without instruction prose:')
for row in audit['step_inventory']:
    if not row['items']:
        print(row['file'],row['line'],row['heading'])
raise SystemExit(bool(failures))
