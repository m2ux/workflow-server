import hashlib
import json
from pathlib import Path

root = Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
results = []
for name in ('project17-context-disclosure', 'project17-context-disclosure-final'):
    folder = Path('/tmp') / name
    manifest = json.loads((folder / 'manifest.json').read_text())
    frozen_errors = [path for path, sha in manifest.items() if hashlib.sha256((folder / 'source' / path).read_bytes()).hexdigest() != sha]
    current_changes = [path for path, sha in manifest.items() if hashlib.sha256((root / path).read_bytes()).hexdigest() != sha]
    results.append({'freeze': name, 'files': len(manifest), 'frozen_errors': frozen_errors, 'current_changes': current_changes})
print(json.dumps(results, indent=2))
Path('/tmp/project17-context-postread-audit.json').write_text(json.dumps(results, indent=2) + '\n')
assert not any(row['frozen_errors'] for row in results)
assert not results[-1]['current_changes']
