import json
import sys
from pathlib import Path
root=Path(sys.argv[1])
complete=json.loads((root/'complete-symbols.json').read_text())
surface=json.loads((root/'changes.json').read_text())['result']
measure=root/'complete-measurements'
failures=[]
for index,symbol in enumerate(complete['symbols']):
    record=json.loads((measure/'contexts'/f'{index:04}.json').read_text())
    if record['params']['uid']!=symbol['id'] or record['native'].get('symbol',{}).get('uid')!=symbol['id'] or record['native'].get('status')!='found':
        failures.append({'context':index,'symbol':symbol['id']})
steps=json.loads((measure/'flow_steps.json').read_text())['rows']
for flow in surface['affected_processes']:
    rows=[r for r in steps if r['process_id']==flow['id']]
    if len(rows)!=flow['step_count'] or [r['step_index'] for r in rows]!=list(range(1,flow['step_count']+1)):
        failures.append({'flow':flow['id'],'rows':len(rows),'expected':flow['step_count']})
statuses=[json.loads((measure/name).read_text()) for name in ['status-before.json','status-after.json']]
fresh=all(s['status']=='up-to-date' and s['current']['commit']==complete['head']==s['index']['commit'] for s in statuses)
result={'head':complete['head'],'base':complete['base'],'symbols':complete['recovered_total'],'contexts':len(complete['symbols']),'flows':len(surface['affected_processes']),'ordered_steps':len(steps),'fresh_status_pair':fresh,'failures':failures,'limits':'Indexed static paths, not observed runtime traces. Native responses omit staleness blocks; paired status evidence binds index freshness. Exact process-membership rows supplement ranked flow queries and uncapped raw edges supplement bounded context windows. Analyzer coverage warnings remain.'}
(root/'parent-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
edges=json.loads((measure/'relationships.json').read_text())['rows']
print('Measured checker calls:')
for r in edges:
    if r['relation']=='CALLS' and r['source_name'] in ('check','heading_model','procedure_spans','parse','__init__','executable_scripts') and 'check_skill_files.py' in r['source_file']:
        print(r['source_name'],'->',r['target_name'],r['target_file'])
print('Measured processes:')
for flow in surface['affected_processes']:
    print(flow['id'],flow['name'],flow['step_count'])
raise SystemExit(bool(failures) or not fresh)
