import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

head='00ec0b9dd516cf6031d44c1ac2184ca95d1e0a01'
base='03d353300ca4804194fd50d316d73e3bf1270d1d'
engineering=Path('/home/mike1/projects/dev/workflow-server/.engineering')
record=engineering/'artifacts/planning/2026-11-05-1597-next-delivery'
shutil.copyfile('/tmp/project17-context-revise-contract-audit.json',record/'context-revise-contract-audit.json')
review=Path('/home/mike1/projects/dev/workflow-server/.worktrees/pr/1641-'+head)
graph=Path('/tmp/i17-e01-context-graph')
audit=json.loads((graph/'parent-audit.json').read_text())
assert audit['head']==head and audit['base']==base and audit['fresh_status_pair'] and not audit['failures']

# Reuse the measured renderer; every changed identity, source anchor and coverage warning is bound below.
renderer=Path('/tmp/project17-publish-integration-evidence.py').read_text().split('for source,destination in [')[0]
renderer=renderer.replace('dc1b274f9176a8d562ada4748c7bb89028532d1b',head).replace('/tmp/i17-e01-current-graph','/tmp/i17-e01-context-graph').replace("f['id']=='proc_17_main'", "f['id']=='proc_18_main'")
renderer=renderer.replace('Work Planner expresses procedures as heading steps, artifact calls as Apply, and protocol or mode calls as Follow. Commands execute in their owning steps with linked argument contracts, while each skill\'s declaration selects the shared checker\'s validation model. Work Planner\'s document readers use that installed model to verify the converted corpus.', 'Work Planner expresses procedures as heading steps and links each consumed input and provided output to its Field in step prose. Markdown link titles identify input, output and callable operation roles; commands execute in their owning steps. Each skill\'s declarations select the shared checker model used by the converted corpus and its document readers.')
renderer=renderer.replace('validates numbered headings, preambles, contract links and Apply/Follow routing', 'validates numbered headings, preambles, contextual IO links and Apply/Follow routing')
renderer=renderer.replace('The final index reports 304 total processes', 'The final index reports 308 total processes').replace('157 unranked candidate entries, 585 skipped callees', '159 unranked candidate entries, 590 skipped callees')
renderer=renderer.replace('Earlier independent reading exercises remain Partial for exclusion, over-reading, truncation and receipt limits', 'Six contextual-contract reading plans remain Partial for over-reading, prerequisite closure, truncation and receipt limits')
renderer=renderer.replace('Heading steps, linked Fields contracts and subject-owned operations give callers a stable place to execute each operation.', 'Heading steps and subject-owned operations give callers a stable execution home. Every callable link has the operation title; input and output links attach their role titles at natural prose uses, with Provide steps for results.')
namespace={}
exec(compile(renderer,'measured-integration-renderer','exec'),namespace)
overview=engineering/'artifacts/planning/2026-11-05-1641-skill-style-groundwork/overview.md'
text=overview.read_text()
for name,filename in [('scan_blocks','skills/scripts/check_skill_files.py'),('contract','skills/scripts/check_skill_files.py'),('heading_model','skills/scripts/check_skill_files.py'),('Document','skills/work-planner/test/test_checkouts.py'),('executable_scripts','skills/work-planner/test/test_documents.py')]:
    pattern=r'^'+('class ' if name=='Document' else 'def ')+re.escape(name)+r'\b'
    lines=(review/filename).read_text().splitlines()
    lineno=next(i+1 for i,line in enumerate(lines) if re.match(pattern,line))
    text=re.sub(r'(\[\*?\*?'+re.escape(name)+r'\*?\*?\]\([^\n]+#L)\d+',lambda m:m[1]+str(lineno),text)
# A distinct ownership paragraph references the shared role resolver without duplicating its definition.
needle='### Consuming Readers\n'
text=text.replace(needle,'### Contextual Roles\n\nThe checker\'s link_roles validates role targets and operation_target recognizes callable procedures from declarations. The contextual-input readers reuse the same link parser while retaining independent command and checkout assertions. [Link Roles](https://github.com/m2ux/workflow-server/blob/'+head+'/skills/work-planner/rules.md#link-roles) owns runtime meanings.\n\n'+needle)
overview.write_text(text)

stats=subprocess.check_output(['git','diff','--numstat',base,head],cwd=review,text=True).splitlines()
insertions=sum(int(line.split('\t')[0]) for line in stats)
deletions=sum(int(line.split('\t')[1]) for line in stats)
subprocess.run(['git','diff','--check',base,head],cwd=review,check=True)
manifest=json.loads((record/'context-final-manifest.json').read_text())
assert all(hashlib.sha256((review/path).read_bytes()).hexdigest()==sha for path,sha in manifest.items())

validation=f'''# E01 Integration Verification

## Identity

PR #1641 integrates `{head}` into workspace `{base}`. The clean detached review checkout holds that exact pushed head. All eight task PRs are merged into the epic base; all eight rows and criteria remain checked on issue #1616. Its specification now describes the approved contextual role links. The sole unmerged epic base remains the expected integration boundary.

## Current-Head Checks

- **Work Planner:** integration-work-planner.log records 934 tests in 121.223 seconds: 933 pass and one opt-in live Development-link check skips.
- **Shared checker:** integration-shared-checker.log records 262 passing tests.
- **Installed declaration:** integration-installed-check.log records 58 files checked and zero findings with no model override or cache.
- **Source identity:** all 115 final-manifest files match the clean committed review checkout. The definitive tests ran against those frozen bytes after all edits.
- **Whitespace:** the full target-to-head diff passes git diff --check: {len(stats)} paths, {insertions} insertions and {deletions} deletions.

## Criteria

| Criterion | Current observation |
| --- | --- |
| AC1 | Shared fixtures accept declared heading/HTML models and contextual role links; reject malformed models, wrong role targets, untagged callable links and specimen-only or heading-only IO. 262 tests pass. |
| AC2 | Installed entry, common Rules/Conventions/Configuration and the single Link Roles definition pass ordinary model and reader checks. |
| AC3 | Modes pass numbered heading, preamble, Apply/Follow, callable-title and executing-command checks. |
| AC4 | Protocols pass the same checks; retained prerequisite identities/order and payloads are audited. |
| AC5 | Issue/body artifact inputs and outputs are naturally linked in actual steps. Populate Hot-fix Body explicitly consumes identity, target, evidence and destination, and provides the populated body. |
| AC6 | Board, queue, planning and review operations have contextual IO; lane/report ownership and meaningful reader assertions pass. |
| AC7 | Delivery, branch and PR operations have contextual IO; real-git checkout/propagation assertions and revision argument semantics pass. |
| AC8 | Installed Work Planner declarations govern the live corpus and real-corpus readers; ordinary check reports zero findings. |

## Contract Completeness and Preservation

context-contract-audit.json reconciles all 237 original operations in 35 artifact files against an independent expected ledger: 817 input obligations and 357 output obligations resolve in step prose to their owning Fields. The starting declarations contribute 757 inputs and 357 outputs; actual command argument contracts identify 60 additional input obligations, and operation-by-operation prose review integrates the values into their consuming steps. context-revise-contract-audit.json independently checks the three additional Revise command operations: seven original input obligations and three actual command results are linked in step prose. Command placeholders alone are insufficient. The corpus audit also verifies 651 callable link titles and 204 HTML invocation payloads, exact fenced/template bytes and prerequisite target/order preservation against `dc1b274f9176a8d562ada4748c7bb89028532d1b`. No separate Inputs/Outputs declarations remain.

The earlier step-item correction records 650 steps and exact prefix changes in step-item-audit.json and step-preservation.json. The final contextual migration reapplies the same rule: a sole contained item is plain prose; several items are all flush-bulleted. The complete installed checker and document readers pass after the prose integration.

## Review and Design

The integration review composes the complete per-unit target-to-head/caller reviews with the subsequent shared-checker, corpus, guideline, declaration and consuming-reader changes on this branch. Lexical scanning owns payload boundaries; declarations select the model; operation_target recognizes callable destinations; link_roles validates role targets; heading_model requires contextual IO in actual steps. Artifact Fields own values, operation steps use them, and rules.md alone defines runtime role meanings. Guidelines link that definition. No duplicate declaration path, compatibility branch, new dependency or performed-operation verifier is introduced.

The checkout and source readers consume the title-aware link parser while retaining meaningful independent command reach, command-argument prose coverage, prerequisite, registration, revision, checkout and publication assertions. Initial regression failures exposed two stale planning-reader expectations; their corrected assertions preserve the original behavioral checks. Wrong Field/operation roles and links confined to fences, HTML, headings or lead prose have rejection controls. No unresolved defect in the reviewed contextual migration remains.

## Independent Reading Limits

context-reading-review.md and its 94-member receipt archive preserve two fresh independent plans for each of Standup, Revise and Understand. All identify relevant operations and contracts; none executes a live workflow. The readers explicitly report broad/irrelevant prerequisites, truncated displays, recovery reads, incomplete prerequisite order/closure and reconstructed receipt limits. These trials remain Partial. They establish no clean progressive-disclosure pass, complete external-workflow pass, performed-operation verification or context-token savings. The migration preserves the prerequisite graph and does not claim to resolve that separate limitation. Both frozen trees are unchanged; the second-round 115-file snapshot matches the final commit.

## Measurements

The final index is current before and after collection. All {audit['symbols']} changed symbols have matching native contexts. All {audit['flows']} reported affected processes have consecutive exact membership rows, totalling {audit['ordered_steps']} ordered steps. The first 1000 native symbols are a verified subset of complete recovery. An initial collection reached the analyzer connection-pool timeout; the successful resumed collection verifies every saved context's exact UID before reuse. Both logs are preserved. Uncapped raw relationships supplement bounded native contexts; exact process memberships supplement ranked flow searches. Native responses omit staleness blocks, so paired status records establish freshness without inventing response fields. Index coverage warnings (159 unranked candidate entries, 590 skipped callees, 21 budget-cut walks) remain limits. The before-state graph is separately bound to `{base}`.

## Delivery Boundary

Workspace requires one human approving review and reviewer merge. This evidence permits handoff; it does not approve or merge the PR, close E01 or release E02. A changed head or target requires current evidence. Existing findings outside Work Planner remain outside the requested gate.
'''
(record/'integration-validation.md').write_text(validation)
url='https://github.com/m2ux/workflow-server/blob/engineering/'+str(record.relative_to(engineering))+'/'
reviews=[{'pull_request':'https://github.com/m2ux/workflow-server/pull/1641','head':head,'base':base,'url':url+'integration-agent-review.json','reviewer':'codex:/root','reviewed_at':datetime.now(timezone.utc).isoformat(),'scope':f'Complete {len(stats)}-path E01 target-to-head integration, composed per-unit diff/caller reviews, final shared lexical/model and contextual role validation, 237 operation prose contracts, guidelines/declarations, source and checkout readers. Final frozen-source identity and payload/prerequisite preservation audited.','criteria':'AC1–AC8 verified on issue #1616, all eight task PRs merged into the epic base. Contextual role requirements checked against actual operation uses and independent retained obligations.','validation':'Frozen source matches final commit: Work Planner 934 tests (933 pass, one opt-in live check skipped), shared checker 262 pass, installed model 58 files/zero findings, target-to-head whitespace pass. Complete current graph audit passes. Six independent reading plans remain Partial for over-reading, closure, truncation and receipt limits; no full disclosure, runtime verification or token-saving claim. See integration-validation.md and context-reading-review.md.','findings':[]}]
(record/'integration-agent-review.json').write_text(json.dumps(reviews,indent=2)+'\n')
shutil.copyfile(graph/'parent-audit.json',record/'integration-graph-audit.json')

members=[]
sources=[]
for prefix,folder in [('after',graph),('before',Path('/tmp/i17-e01-before-graph/measurements'))]:
    sources.extend((path,prefix+'/'+str(path.relative_to(folder))) for path in sorted(folder.rglob('*')) if path.is_file() and not {'index','home'}.intersection(path.relative_to(folder).parts))
for name in ['project17-gitnexus-structured.mjs','project17-recover-symbols.mjs','project17-graph-measure-all.mjs','project17-final-graph-audit.py','project17-audit-freeze-context.py','project17-context-postread-audit.py','project17-context-final-review.py','project17-context-refresh-integration.py','project17-context-revise-coverage.py']:
    sources.append((Path('/tmp')/name,'instruments/'+name))
sources.extend([(Path('/tmp/i17-e01-context-analyze.log'),'after/analyze.log'),(Path('/tmp/i17-e01-before-analyze.log'),'before/analyze.log')])
sources.extend([(Path('/tmp/project17-context-graph-measure.log'),'after/initial-collection.log'),(Path('/tmp/project17-context-graph-resume.log'),'after/resumed-collection.log')])
archive=record/'integration-graph.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for path,name in sources:
        data=path.read_bytes()
        assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)',data),name
        tar.add(path,arcname=name,recursive=False)
        members.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(record/'integration-graph-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+'\n')

pr=json.loads(Path('/tmp/project17-context-pr-head.json').read_text())
refs=pr['body'].split('## References',1)[1].strip()
body='''## Overview

Work Planner uses heading steps, commands in their executing steps, and contextual input/output links to owning Fields. Markdown link titles identify input, output and callable operation roles; installed declarations select the shared checker model used by the corpus and its readers.

## Changes

### Shared Validation

- **Declared models.** Exact-file and family declarations select headings, preambles, linked Field contracts, operation roles and Apply/Follow routing.
- **Literal boundaries.** One lexical reader isolates fenced and HTML payloads while validating linked command arguments and execution placement.
- **Contextual contracts.** Role links resolve to Fields or callable procedures; actual steps carry input/output contracts. Meaningful fixtures reject invalid targets and command-only or specimen-only substitutes.

### Instruction Corpus

- **Common context.** Entry-point mode selection reaches Rules and Conventions. rules.md defines the three link roles once; guidelines link it and require complete contextual coverage.
- **Operation prose.** All 237 operations name consumed inputs and provided outputs in natural step sentences, with explicit Provide steps where needed. Every linked callable has the operation title.
- **Contained items.** Numbered steps bullet every contained instruction/detail item when several exist and use plain prose for a sole item.

### Consuming Readers

- **Installed authority.** Real-corpus readers use the declared model and title-aware links while retaining operation interfaces, script reach, prerequisite and literal-exclusion assertions.
- **Checkout propagation.** Actual commands and transitive operations preserve checkout, fetched-base revision, registration and publication checks, including real-git placement tests.

## References

'''+refs+'\n'
assert '## Test Plan' not in body and body.count('**R9.')==1 and body.count('**R10.')==1 and body.count('**R11.')==1
Path('/tmp/project17-context-pr-body.md').write_text(body)
Path('/tmp/project17-context-pr-patch.json').write_text(json.dumps({'body':body})+'\n')

path=record/'README.md'
text=path.read_text()
start=text.index('## Contextual Contract Draft\n')
end=text.index('## Contextual Contract Migration\n',start)
text=text[:start]+'''## Contextual Contract Example

| Artifact | What it holds |
| --- | --- |
| [Approved example](contextual-contract-example.md) | Natural input/output prose and tagged callable links |

Runtime meanings live in [Link Roles](https://github.com/m2ux/workflow-server/blob/'''+head+'''/skills/work-planner/rules.md#link-roles); the migration record owns the completeness check. Performed-operation verification is a future feature.

'''+text[end:]
path.write_text(text)
text=path.read_text().replace('| [Coverage audit](context-contract-audit.json) | 237 operations and expected versus observed role links |','| [Coverage audit](context-contract-audit.json) | 237 artifact operations and expected versus observed role links |\n| [Revise command audit](context-revise-contract-audit.json) | Three additional command operations and their actual results |')
path.write_text(text)
path=record/'context-contract-migration.md'
path.write_text(path.read_text().replace('- [ ] In progress: publish exact-head integration review and handoff evidence; product commit is pushed.','- [x] Commit and push the product correction; publish exact-head integration review and handoff evidence.'))
print(json.dumps({'head':head,'files':len(stats),'insertions':insertions,'deletions':deletions,'symbols':audit['symbols'],'flows':audit['flows'],'steps':audit['ordered_steps'],'overview_lines':len(overview.read_text().splitlines()),'graph_archive_members':len(members),'graph_archive_bytes':archive.stat().st_size}))
