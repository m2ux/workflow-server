import hashlib
import json
from pathlib import Path

engineering=Path('/home/mike1/projects/dev/workflow-server/.engineering')
record=engineering/'artifacts/planning/2026-11-05-1597-next-delivery'
review=Path('/home/mike1/projects/dev/workflow-server/.worktrees/pr/1641-4882414d678268aaa282fb4c0b184f14e3e47d1b')
manifest=json.loads((record/'command-contract-final-manifest.json').read_text())
assert len(manifest)==115
assert all(hashlib.sha256((review/p).read_bytes()).hexdigest()==sha for p,sha in manifest.items())
epic=json.loads(Path('/tmp/project17-command-contract-epic-resumed.json').read_text())
body=(engineering/'artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes/bodies/e01.md').read_text()
assert body.split('## Work Breakdown')[1].split('## Acceptance Criteria')[0]==epic['body'].split('## Work Breakdown')[1].split('## Acceptance Criteria')[0]
assert body.count('- [x] **AC')==8
Path('/tmp/project17-command-contract-epic-patch.json').write_text(json.dumps({'body':body.rstrip()+'\n'})+'\n')
pr=json.loads(Path('/tmp/project17-command-contract-pr-resumed.json').read_text())
assert pr['head']['sha']=='4882414d678268aaa282fb4c0b184f14e3e47d1b' and pr['base']['sha']=='03d353300ca4804194fd50d316d73e3bf1270d1d' and pr['draft'] and not pr['merged']
script=Path('/tmp/project17-evidence-recovery/project17-publish-command-contract-evidence.py').read_text()
segment=script[script.index("refs=pr['body'].split('## References'"):script.index("readme=record/'README.md'")]
def dump(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n')
exec(compile(segment,'approved-pr-description','exec'))
print(json.dumps({'source_files_verified':len(manifest),'tasks_and_criteria_preserved':True,'head':pr['head']['sha']}))
