import hashlib
import json
import re
import shutil
import subprocess
import tarfile
from datetime import datetime, timezone
from pathlib import Path

head='4882414d678268aaa282fb4c0b184f14e3e47d1b'
base='03d353300ca4804194fd50d316d73e3bf1270d1d'
engineering=Path('/home/mike1/projects/dev/workflow-server/.engineering')
record=engineering/'artifacts/planning/2026-11-05-1597-next-delivery'
review=Path('/home/mike1/projects/dev/workflow-server/.worktrees/pr/1641-'+head)
graph=Path('/tmp/i17-e01-command-contract-graph')
measure=graph/'complete-measurements'
audit=json.loads((graph/'parent-audit.json').read_text())
assert audit['head']==head and audit['base']==base and audit['fresh_status_pair'] and not audit['failures']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=review,text=True)
manifest=json.loads((record/'command-contract-final-manifest.json').read_text())
assert all(hashlib.sha256((review/p).read_bytes()).hexdigest()==sha for p,sha in manifest.items())
complete=json.loads((graph/'complete-symbols.json').read_text())
changed={row['id'] for row in complete['symbols']}
flows=json.loads((graph/'changes.json').read_text())['result']['affected_processes']
rows=json.loads((measure/'flow_steps.json').read_text())['rows']
edges=json.loads((measure/'relationships.json').read_text())['rows']
def has_call(source,target):
    return any(row['relation']=='CALLS' and row['source_name']==source and row['target_name']==target for row in edges)
for source,target in [('check','heading_model'),('heading_model','scan_blocks'),('parse','scan_blocks'),('procedure_spans','scan_blocks'),('check','link_roles'),('link_roles','role_links'),('heading_model','role_links'),('inputs','role_links'),('role_links','scan_blocks'),('role_links','link_role'),('link_roles','operation_target'),('link_roles','field_contract'),('commands','logical_command_lines')]:
    assert has_call(source,target),(source,target)
url='https://github.com/m2ux/workflow-server/blob/'+head+'/'
record_url='https://github.com/m2ux/workflow-server/blob/engineering/'+str(record.relative_to(engineering))+'/'
def sequence(flow):
    steps=[r for r in rows if r['process_id']==flow['id']]
    assert len(steps)==flow['step_count']
    participants={row['id']:row for row in steps}
    ids={uid:'P'+str(i) for i,uid in enumerate(participants)}
    text=['```mermaid','sequenceDiagram']
    for altered,label,color in [(True,'Changed','rgb(200,230,201)'),(False,'Context','rgb(245,245,245)')]:
        group=[r for uid,r in participants.items() if (uid in changed)==altered]
        if group:
            text.append('    box '+color+' '+label)
            text += ['    participant '+ids[r['id']]+' as '+r['name'] for r in group]
            text.append('    end')
    text.append('    Note over '+ids[steps[0]['id']]+': Indexed entry: '+steps[0]['name'])
    text += ['    '+ids[a['id']]+'->>'+ids[b['id']]+': Indexed step '+str(b['step_index']) for a,b in zip(steps,steps[1:])]
    return '\n'.join(text+['```'])

atlas=['# Measured Integration Flows','',f'PR #1641 at `{head}`, against `{base}`.','',f'All {len(flows)} reported affected static processes appear below. The {len(rows)} ordered membership rows establish each sequence; arrows identify the next indexed step, not observed runtime calls. Green marks changed symbols; grey marks context. Ranked searches and exact membership records are retained separately. Analyzer coverage warnings mean unreported paths can exist.','']
for i,flow in enumerate(flows,1):
    atlas += [f"## {i}. {flow['name']}",'',f"Process `{flow['id']}` has {flow['step_count']} measured steps.",'',sequence(flow),'']
    atlas += [f"- **Step {r['step_index']}: [{r['name']}]({url}{r['filePath']}#L{r['startLine']+1}).**\n  {r['filePath']}." for r in rows if r['process_id']==flow['id']]
    atlas.append('')
(record/'integration-flow-atlas.md').write_text('\n'.join(atlas)+'\n')

overview=engineering/'artifacts/planning/2026-11-05-1641-skill-style-groundwork/overview.md'
text=overview.read_text()
text=text[:text.index('## Summary')]+'''## Summary

Work Planner uses heading steps and linked contracts where values are consumed or provided in prose or executing commands. Link titles identify input, output and callable roles; command parameters carry their own contracts. Shared declaration, lexical and role readers validate the installed corpus, while checkout readers interpret escaped command continuations.

'''+text[text.index('## Structure'):]
text=text.replace('00ec0b9dd516cf6031d44c1ac2184ca95d1e0a01',head)
text=text.replace('37 reported affected processes',str(len(flows))+' reported affected processes').replace('308 total processes and 37 affected ones','311 total processes and '+str(len(flows))+' affected ones').replace('159 unranked candidate entries','160 unranked candidate entries')
text=text.replace('The current symbol-notation installed checker and both test suites pass. Six contextual-contract reading plans remain Partial','The current installed checker and both test suites pass. Two command-contract plans and earlier reading trials remain Partial')
text=text.replace('input and output links attach their role titles at natural prose uses','input and output links attach their role titles at actual prose or executing-command uses')
text=text.replace('Validates numbered headings, preambles, contract links and Apply/Follow routing','Validates numbered headings, preambles, actual-use contract links and Apply/Follow routing')
text=text.replace("The checker's link_roles validates role targets and operation_target recognizes callable procedures from declarations. The contextual-input readers reuse the same link parser while retaining independent command and checkout assertions.","role_links collects explicit prose and bold command annotations outside fenced specimens. link_roles validates Field/callable targets; heading_model and Document.inputs share the collector. Document.commands uses logical_command_lines for token-boundary continuations while retaining independent checkout and publication assertions.")
role_graph='''### Contract Readers

These native CALLS relationships connect validation and checkout inputs through the shared role collector and target checks.

```mermaid
flowchart LR
    subgraph Consumers [Validation and checkout inputs]
        C[check]
        H[heading_model]
        I[Document.inputs]
    end
    subgraph Roles [Shared contract interpretation]
        V[link_roles]
        R[role_links]
        B[scan_blocks]
        L[link_role]
        O[operation_target]
        F[field_contract]
    end
    C -->|validates roles| V
    V -->|collects links| R
    H -->|collects contracts| R
    I -->|collects inputs| R
    R -->|reads boundaries| B
    R -->|decodes role| L
    V -->|checks callable| O
    V -->|checks field| F
    classDef changed fill:#c8e6c9,stroke:#2e7d32
    class C,H,I,V,R,B,L,O,F changed
```

'''
text=text.replace('### Shared Interpretation\n',role_graph+'### Shared Interpretation\n')
for name,filename in [('scan_blocks','skills/scripts/check_skill_files.py'),('contract','skills/scripts/check_skill_files.py'),('heading_model','skills/scripts/check_skill_files.py'),('Document','skills/work-planner/test/test_checkouts.py'),('executable_scripts','skills/work-planner/test/test_documents.py')]:
    prefix='class ' if name=='Document' else 'def '
    number=next(i+1 for i,line in enumerate((review/filename).read_text().splitlines()) if line.startswith(prefix+name+'(') or line.startswith(prefix+name+':'))
    text=re.sub(r'(\[\*?\*?'+re.escape(name)+r'\*?\*?\]\([^\n]+#L)\d+',lambda m:m[1]+str(number),text)
for name in ['role_links','logical_command_lines']:
    number=next(i+1 for i,line in enumerate((review/'skills/scripts/check_skill_files.py').read_text().splitlines()) if line.startswith('def '+name+'('))
    text=text.replace(name+' ',f'[{name}]({url}skills/scripts/check_skill_files.py#L{number}) ',1)
flow=next(f for f in flows if f['name']=='Main → Heading_end')
start=text.index('```mermaid',text.index('### Checker Entry to Heading Boundary'))
end=text.index('```',start+3)+3
text=text[:start]+sequence(flow)+text[end:]
overview.write_text(text)

subprocess.run(['git','diff','--check',base,head],cwd=review,check=True)
stats=subprocess.check_output(['git','diff','--numstat',base,head],cwd=review,text=True).splitlines()
validation=f'''# E01 Integration Verification

## Identity

PR #1641 integrates `{head}` into workspace `{base}`. The clean detached review checkout holds the exact pushed head. All eight task PRs remain merged into the epic branch; all eight rows and criteria on #1616 remain checked. The review composes the full per-unit integration/caller reviews with subsequent checker/corpus corrections and the current 32-path command-contract delta from `eedc9a212ae38449a16638dc190b0e2f16d1a828`.

## Verification

- Work Planner: 934 tests in 119.734 seconds; 933 pass and one opt-in live Development-link check skips.
- Shared checker: 270 tests pass in 1.029 seconds.
- Installed declaration: 58 files checked, zero findings, without model override/cache.
- All 115 final source hashes match the committed source. Definitive suites ran against these frozen bytes after source corrections; the resumed identity check matches them again.
- The full target-to-head diff passes whitespace checks: {len(stats)} paths, {sum(int(r.split(chr(9))[0]) for r in stats)} insertions, {sum(int(r.split(chr(9))[1]) for r in stats)} deletions.

## Acceptance Evidence

| Criterion | Observation |
| --- | --- |
| AC1 | Fixtures accept declared heading/HTML models, actual-use prose/command roles and continuations. Controls reject malformed models, missing/wrong roles or targets, specimen-only contracts, duplicate parameter lists and unwrapped long commands. Unselected models retain Field-target validation. |
| AC2 | Entry layout and focused Rules, Conventions and Configuration homes pass installed checks and readers; runtime role meanings have one home. |
| AC3 | Modes pass heading, preamble, routed-call and executing-command checks, with retained contextual obligations. |
| AC4 | Protocols pass the same declared checks; prerequisite identities/order and payloads are retained. |
| AC5 | Issue/body artifacts link values at actual prose/command uses; explicit results use Provide. Hot-fix identity, target, evidence, destination and populated result stay explicit. |
| AC6 | Board, queue, planning and review artifacts retain contracts, lane/report ownership, meaningful usage conditions and reader assertions. |
| AC7 | Delivery, branch and PR artifacts retain contracts and real-git placement/propagation assertions; logical commands preserve CWD, revision, registration and publication semantics. |
| AC8 | Installed Work Planner declarations govern the live corpus and readers; ordinary checker reports zero findings. |

## Contract and Invocation Preservation

command-contract-audit.json independently reconciles 240 named operations: all 824 input and 361 output obligations remain explicit. All 204 HTML invocations survive: 196 shell invocations retain equal argv and pass Bash syntax checks with safe representative values; eight non-shell payloads retain literal content. The audit executes no authored workflow command. Fenced/template bytes, prerequisite targets/order and operation identities are retained.

All 609 explicit command argument links have role metadata. Semantic review removes 63 pure introductory parameter lists, rewrites 53 intros with meaningful context and reviews 33 flag glosses. Authorization, selection, optional/repeated arguments, refusal and result semantics stay explicit. The continuation audit records 103 wrapped invocations, preserving required quotes, operators and argument order. Original unrelated branch-prologue bullet prefixes are restored. A sole contained item is prose; several are all bulleted.

The approved command-contract plan supersedes historical prose-only requirements: actual executing command annotations establish IO contracts. Earlier contract and prefix audits remain historical evidence.

## Design and Review

Destination grammar, role collection, lexical boundaries and continuation unfolding have separate responsibilities. Declarations select validation; Fields own value definitions; steps own actual uses. Guidelines own authoring constraints and link the single runtime role definition. Consuming readers reuse interpretation helpers while independently asserting obligations, script reach, prerequisites, CWD, revision, registration, publication and real-git behavior.

Review corrected an unselected-model role guard and restored unrelated branch prefixes; the final suites pass after both corrections. No unresolved defect remains in the reviewed change. No compatibility path, dependency or performed-operation verifier is introduced.

## Reading Limits

command-contract-reading-review.md and its receipt archive preserve two fresh bounded plans for Board review status and Revise verification. They recognize command-backed inputs and execute no checks/live workflow. Broad retrieval, incomplete prerequisite order/closure, truncated envelopes, recovery reads, one rejected read and a missing bounded-snapshot launcher remain explicit limits. These and earlier integration trials remain Partial. Both frozen trees are preserved; final source equals the committed head. Subsequent refinements restore branch bullet prefixes, clarify a docstring and fix/test the unselected-model guard; active Work Planner command bindings and usage are identical. There is no clean disclosure, complete external-workflow, performed-operation verification or token-saving claim.

## Native Measurements

The regenerated index is fresh before and after collection. All {audit['symbols']} changed symbols have exact-UID native contexts; {audit['flows']} reported affected processes have complete consecutive memberships totalling {audit['ordered_steps']} steps. The capped native symbol list is a verified subset of recovery. Uncapped relationships supplement native context windows; exact memberships supply order independently of ranked flow queries. Native responses omit staleness blocks, so paired status evidence supplies freshness. The before graph is separately bound to `{base}`.

The index reports 311 total processes, with 160 unranked candidates, 590 skipped callees and 21 budget-cut walks limiting coverage. An absent path does not establish nonexistence. Every reported affected process appears in the atlas. These are static indexed paths, not runtime traces. Interrupted temporary measurements were unavailable after resume; the retained bundle contains the new complete collection.

## Handoff

Validate the published review against fresh PR metadata before ready and board writes. Workspace requires one human approving review and reviewer merge. E02 remains blocked on E01 reaching workspace. Findings outside Work Planner remain outside the requested gate.
'''
(record/'integration-validation.md').write_text(validation)
review_record=[{'pull_request':'https://github.com/m2ux/workflow-server/pull/1641','head':head,'base':base,'url':record_url+'integration-agent-review.json','reviewer':'codex:/root','reviewed_at':datetime.now(timezone.utc).isoformat(),'scope':f'Complete {len(stats)}-path E01 integration through composed per-unit diff/caller reviews and subsequent corrections; current 32-path command-contract delta, shared grammar/model guards, 240 operation contracts, guidelines, command semantics and consuming readers.','criteria':'AC1–AC8 verified on #1616; eight task PRs merged into the epic branch. Actual-use prose/command contracts match the approved request.','validation':'Frozen source matches commit: Work Planner 934 tests (933 pass, one opt-in skip); shared checker 270 pass; installed declaration 58 files/zero findings; whitespace pass. All 824 input/361 output obligations and 204 invocations retained, including 196 argv/Bash syntax checks and eight literal payloads. Complete current graph audit passes. Two reading plans and earlier trials remain Partial. See integration-validation.md and command-contract-reading-review.md.','findings':[]}]
(record/'integration-agent-review.json').write_text(json.dumps(review_record,indent=2)+'\n')
shutil.copyfile(graph/'parent-audit.json',record/'integration-graph-audit.json')

sources=[]
for prefix,folder in [('after',graph),('before',Path('/tmp/project17-evidence-recovery/before'))]:
    sources += [(p,prefix+'/'+str(p.relative_to(folder))) for p in sorted(folder.rglob('*')) if p.is_file() and not {'index','home'}.intersection(p.relative_to(folder).parts)]
for p in sorted(Path('/tmp/project17-evidence-recovery/instruments').glob('*.mjs')):
    sources.append((p,'instruments/'+p.name))
for p in [Path('/tmp/project17-evidence-recovery/instruments/project17-final-graph-audit.py'),Path(__file__),Path('/tmp/project17-resume-contract-metadata.py')]:
    sources.append((p,'instruments/'+p.name))
sources.append((Path('/tmp/i17-e01-command-contract-analyze.log'),'after/analyze.log'))
for p in sorted(Path('/tmp').glob('project17-command-contract-graph-*.log')):
    sources.append((p,'after/logs/'+p.name))
members=[]
archive=record/'integration-graph.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for p,name in sources:
        data=p.read_bytes()
        assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)',data),name
        tar.add(p,arcname=name,recursive=False)
        members.append({'member':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(record/'integration-graph-manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':members},indent=2)+'\n')
print(json.dumps({'head':head,'symbols':audit['symbols'],'flows':audit['flows'],'steps':audit['ordered_steps'],'graph_members':len(members),'overview_lines':len(text.splitlines())}))
