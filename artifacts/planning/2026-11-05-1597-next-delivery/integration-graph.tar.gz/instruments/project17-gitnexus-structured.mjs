import { LocalBackend } from '/home/mike1/.nvm/versions/node/v24.21.0/lib/node_modules/gitnexus/dist/mcp/local/local-backend.js';
import { readFileSync, writeFileSync, writeSync } from 'node:fs';

const request = JSON.parse(readFileSync(process.argv[2], 'utf8'));
const allowed = new Set(['detect_changes', 'context', 'query', 'cypher', 'trace']);
if (!allowed.has(request.method)) throw new Error('Only graph measurement methods are permitted');
const backend = new LocalBackend();
try {
  if (!(await backend.init())) throw new Error('No indexed repository is available');
  const repositories = await backend.listRepos();
  const result = await backend.callTool(request.method, request.params);
  writeFileSync(process.argv[3], JSON.stringify({ method: request.method, params: request.params, repositories, result }, null, 2) + '\n');
  writeSync(1, JSON.stringify({ method: request.method, output: process.argv[3], resultKeys: Object.keys(result), changedSymbols: result.changed_symbols?.length, reportedChanged: result.summary?.changed_symbols, partial: result.partial, error: result.error }) + '\n');
  if (result.error || result.partial === true) process.exitCode = 1;
} finally {
  await backend.dispose();
}
