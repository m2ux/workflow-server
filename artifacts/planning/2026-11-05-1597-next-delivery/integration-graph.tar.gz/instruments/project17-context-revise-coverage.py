import importlib.util
import json
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
spec=importlib.util.spec_from_file_location('check_skill_files',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
name='skills/work-planner/modes/revise-mode.md'
before=subprocess.check_output(['git','show','dc1b274f9176a8d562ada4748c7bb89028532d1b:'+name],cwd=root,text=True)
path=root/name
lines,fenced,headings=check.scan(path)
html=check.scan_blocks(lines).html_lines
rows=[]
for title in ('Run Tests','Check Skill Files','Compare Section Bodies'):
    start=before.index('### '+title+'\n')
    rest=before[start+4:]
    import re
    end=re.search(r'^#{2,3} ',rest,re.M)
    body=before[start:start+4+end.start()] if end else before[start:]
    expected={'input':check.LINK.findall(re.search(r'^\*\*Inputs:\*\* (.*)$',body,re.M)[1]),'output':[{'Run Tests':'#test-result','Check Skill Files':'#skill-check-result','Compare Section Bodies':'#section-comparison'}[title]]}
    start=next(i for i,d,t in headings if d==3 and t==title)
    end=check.heading_end(headings,start,3,len(lines))
    first=next(i for i,d,t in headings if start<i<end and d==4 and check.HEADING_STEP.match(t))
    observed={kind:set() for kind in expected}
    for i in range(first+1,end):
        if fenced[i] or i in html or lines[i].startswith('#'):continue
        for match in check.LINK.finditer(check.CODE_SPAN.sub('',lines[i])):
            role=check.link_role(match)
            if role in observed:
                assert check.field_contract(path,match[1],'Fields')
                observed[role].add(match[1])
    assert all(set(expected[kind])<=observed[kind] for kind in expected)
    rows.append({'operation':title,'expected':expected,'observed':{k:sorted(v) for k,v in observed.items()}})
result={'file':name,'operations':3,'inputs':sum(len(r['expected']['input']) for r in rows),'outputs':sum(len(r['expected']['output']) for r in rows),'failures':[],'rows':rows}
Path('/tmp/project17-context-revise-contract-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
