import json
import shutil
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace/skills/work-planner')
path=root/'guidelines.md'
text=path.read_text()
assert text.count('provide points')==2
path.write_text(text.replace('provide points','continuation points'))
path=root/'structure.json'
mapping=json.loads(path.read_text())
text='{\n'
for number,(name,entry) in enumerate(mapping.items()):
    text+='  '+json.dumps(name)+': {\n'
    text+=',\n'.join('    '+json.dumps(key)+': '+json.dumps(value) for key,value in entry.items())+'\n'
    text+='  }'+(',' if number<len(mapping)-1 else '')+'\n'
text+='}\n'
assert json.loads(text)==mapping
path.write_text(text)
shutil.copyfile('/tmp/project17-context-final-work-planner.log','/tmp/project17-context-prewording-work-planner.log')
shutil.copyfile('/tmp/project17-context-coverage-audit.json','/tmp/project17-context-coverage-prewording-audit.json')
script=Path('/tmp/project17-audit-freeze-context.py').read_text().replace('/tmp/project17-context-disclosure/','/tmp/project17-context-disclosure-final/')
exec(compile(script,'/tmp/project17-audit-freeze-context.py','exec'))
