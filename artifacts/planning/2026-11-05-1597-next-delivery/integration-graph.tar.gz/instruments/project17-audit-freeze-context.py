import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

root=Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace')
skill=root/'skills/work-planner'
base='dc1b274f9176a8d562ada4748c7bb89028532d1b'
spec=importlib.util.spec_from_file_location('context_audit',root/'skills/scripts/check_skill_files.py')
check=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=check
spec.loader.exec_module(check)
ledger=json.loads(Path('/tmp/project17-context-coverage-ledger.json').read_text())
failures=[]
bindings=[]
for row in ledger:
    path=skill/row['file']
    lines,fenced,headings=check.scan(path)
    html=check.scan_blocks(lines).html_lines
    start=next(i for i,d,t in headings if d==3 and t==row['operation'])
    end=check.heading_end(headings,start,3,len(lines))
    first=next(i for i,d,t in headings if start<i<end and d==4 and check.HEADING_STEP.match(t))
    roles={r:set() for r in ('input','output')}
    for index in range(first+1,end):
        if fenced[index] or index in html or lines[index].startswith('#'):
            continue
        for m in check.LINK.finditer(check.CODE_SPAN.sub('',lines[index])):
            role=check.link_role(m)
            if role in roles:
                roles[role].add(m[1])
                if not check.field_contract(path,m[1],'Fields'):
                    failures.append({'operation':row['operation'],'invalid_field':m[1]})
    for role in roles:
        missing=set(row['expected'][role])-roles[role]
        if missing:
            failures.append({'operation':row['operation'],'role':role,'missing':sorted(missing)})
    bindings.append({'file':row['file'],'operation':row['operation'],'expected':row['expected'],'observed':{r:sorted(v) for r,v in roles.items()}})

def protected(text):
    lines=text.splitlines(keepends=True)
    plain=[line.rstrip('\n') for line in lines]
    blocks=check.scan_blocks(plain)
    return ([lines[a:b+1] for a,b in blocks.invocations],
            [line for i,line in enumerate(lines) if blocks.fenced[i]])

def prerequisites(text):
    lines,_,headings=check.parse(text)
    starts=[i for i,d,t in headings if d==2 and t=='Prerequisites']
    if not starts: return []
    start=starts[0]
    end=check.heading_end(headings,start,2,len(lines))
    return check.LINK.findall('\n'.join(lines[start:end]))

payloads=0
tagged=0
operation_files=0
for path in sorted(skill.rglob('*.md')):
    if 'test' in path.relative_to(skill).parts: continue
    relative=str(path.relative_to(root))
    before=subprocess.check_output(['git','show',base+':'+relative],cwd=root,text=True)
    current=path.read_text()
    if protected(before)!=protected(current): failures.append({'file':relative,'reason':'Literal payload drift'})
    if prerequisites(before)!=prerequisites(current): failures.append({'file':relative,'reason':'Prerequisite targets/order drift'})
    if re.search(r'^\*\*(?:Inputs|Outputs):\*\*',current,re.M): failures.append({'file':relative,'reason':'Standalone IO declaration'})
    payloads+=len(protected(current)[0])
    lines,fenced,_=check.scan(path)
    html=check.scan_blocks(lines).html_lines
    for index,line in enumerate(lines):
        if fenced[index] or index in html: continue
        for match in check.LINK.finditer(check.CODE_SPAN.sub('',line)):
            actual=check.operation_target(path,match[1])
            role=check.link_role(match)
            if actual:
                tagged+=1
                if role!='operation': failures.append({'file':relative,'operation_link':match[1],'role':role})
            elif role=='operation': failures.append({'file':relative,'invalid_operation_link':match[1]})

freeze=Path('/tmp/project17-context-disclosure/source')
assert not freeze.exists(),'Freeze already exists; preserve its identity'
files=subprocess.check_output(['git','ls-files','-z','skills/work-planner','skills/scripts/check_skill_files.py','skills/test/test_check_skill_files.py','skills/guidelines.md'],cwd=root).decode().split('\0')
manifest={}
for name in files:
    if not name: continue
    source=root/name
    if not source.is_file(): continue
    data=source.read_bytes()
    destination=freeze/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(data)
    manifest[name]=hashlib.sha256(data).hexdigest()
Path('/tmp/project17-context-disclosure/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
result={'base':base,'operations':len(bindings),'expected_inputs':sum(len(x['expected']['input']) for x in bindings),'expected_outputs':sum(len(x['expected']['output']) for x in bindings),'tagged_callable_links':tagged,'preserved_html_invocations':payloads,'frozen_files':len(manifest),'manifest_sha256':hashlib.sha256(Path('/tmp/project17-context-disclosure/manifest.json').read_bytes()).hexdigest(),'failures':failures,'operations_audit':bindings,'limits':'Expected declarations and actual invocation arguments establish retained obligations; sentence-level review binds the remaining implicit evidence and output uses. This is authoring verification, not the future performed-operation verifier.'}
Path('/tmp/project17-context-coverage-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='operations_audit'}))
raise SystemExit(bool(failures))
