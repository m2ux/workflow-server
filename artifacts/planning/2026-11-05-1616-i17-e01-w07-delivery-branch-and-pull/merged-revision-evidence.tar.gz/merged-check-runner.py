import hashlib,json,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve();out=Path('/tmp/i17-e01-w07')
git=lambda *args:subprocess.check_output(['git',*args],cwd=root,text=True).strip()
revision='652ef07ea5b8553d3bdb73542c3a393ac20e6ea9';tree='9a517bcc9640caa2fa69b6bce0ffbed94fc16bd0'
assert git('rev-parse','HEAD')==revision and git('rev-parse','HEAD^{tree}')==tree
assert not git('status','--porcelain=v1','--untracked-files=all')
source=json.loads(Path('/home/mike1/projects/dev/workflow-server/.engineering/artifacts/planning/2026-11-05-1616-i17-e01-w07-delivery-branch-and-pull/disclosure-source-manifest.json').read_text())
for name,sha in source['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
criterion='/home/mike1/projects/dev/workflow-server/.engineering/artifacts/planning/2026-11-05-1616-i17-e01-w07-delivery-branch-and-pull/criterion-check.py'
commands=[
 ('strict',[sys.executable,criterion,'--expected-revision',revision,'--expected-tree',tree],root,0),
 ('work-planner',[sys.executable,'-m','unittest','discover','-s','test'],root/'skills/work-planner',0),
 ('shared',[sys.executable,'-m','unittest','discover','-s','skills/test'],root,0),
 ('installed',[sys.executable,'skills/scripts/check_skill_files.py','skills/work-planner'],root,1),
]
results=[]
for name,command,cwd,expected in commands:
    run=subprocess.run(command,cwd=cwd,text=True,capture_output=True)
    text=run.stdout+run.stderr;(out/('merged-'+name+'.log')).write_text(text)
    assert run.returncode==expected,(name,run.returncode,text[-4000:])
    if name=='strict':assert '"findings": []' in text and '"converted_files": 6' in text
    if name=='work-planner':assert 'Ran 925 tests' in text and 'OK (skipped=1)' in text
    if name=='shared':assert 'Ran 258 tests' in text and '\nOK\n' in text
    if name=='installed':assert '58 files checked, 1 findings' in text and 'section outside the set — Fields' in text
    results.append({'check':name,'argv':command,'cwd':str(cwd),'exit':run.returncode,'sha256':hashlib.sha256(text.encode()).hexdigest()})
assert not git('status','--porcelain=v1','--untracked-files=all')
record={'revision':revision,'tree':tree,'checkout':str(root),'checkout_after':'clean','frozen_source_file_hashes_verified':len(source['files']),'source_digest':source['source_digest'],'commands':results,'work_planner':{'total':925,'pass':924,'skip':1},'shared':{'pass':258},'strict':{'files':6,'findings':0},'installed':{'files':58,'findings':1,'expected':'Revise Fields'},'disclosure':'Partial; unchanged walked source'}
(out/'merged-checks.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
