# Reviewer Overview — Modes in the New Style

> Local bounded draft · m2ux/workflow-server#1643 · captured head c28be9980208c469e2c119e715a5b9b50b9e246e

## Summary

[PR #1643](https://github.com/m2ux/workflow-server/pull/1643) gives all ten Work Planner modes numbered heading steps, a common Rules/Conventions/Outcomes preamble, and explicit Apply/Follow calls. Two Python test readers recognize that presentation while checking planning-record publication and epic-base inputs. This account describes captured changes and local source; it is not the protocol's completed measured architecture overview.

## Structure

Work Planner modes coordinate planning and delivery. Their linked artifact operations provide data or individual changes; protocols coordinate related changes. In this PR, the changed production files are the ten mode documents, with two tests reading those documents.

| Area | Responsibility and observed change |
| --- | --- |
| Mode documents | Advance, Align, Deliver, Hoist, Plan, Propose, Revise, Standup, Sync and Understand expose ordered actions as `### N. Title` headings. Calls name Apply for artifact operations and Follow for procedures. |
| Revise verification procedures | Run Tests, Check Skill Files and Compare Section Bodies place commands inside their executing steps, with linked input contracts and examples. |
| `test_plan_mode.py` | `steps()` selects numbered heading steps, slices their bodies, and keys them by case-folded action titles. Assertions inspect draft locations, registration and publication. |
| `test_documents.py` | `RECORD_EPIC_DELIVERY` recognizes Apply calls; its callers remain subject to epic-base and caller-coverage assertions. |

The captured change is 12 modified files, +1147/-715. Local comparison of captured base and head agrees. There are no changed application-server source files in that comparison.

Graph-derived component boundaries, dependency edges, symbol context and ordered traces are unavailable. Structural and sequence diagrams are withheld because the installed Architecture Overview contract requires measured relationships and step order; directory grouping or manual ordering does not supply them.

## Behaviour

These are documented procedure orders or Python source paths, not measured GitNexus flow traces.

- **Planning record publication.** [Plan's Prepare the Planning Record step](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L43-L48) populates the selected record, uses its layout, and publishes it. The complete mode also registers draft bodies and work items and publishes at its Publish and Keep the Goal Current steps. [`steps()`](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L29-L34) makes those heading bodies available to the assertions.
- **Epic delivery recording.** [Sync Each Epic](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/sync-mode.md#L91-L209) passes task issues, project checkout and fetched epic bases to Record Epic Delivery, handles returned findings, and repeats with refreshed records and the same bases. [The caller tests](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221) recognize Apply and require epic-base inputs at detected calls.
- **Review explanation.** [Sync's review-entry step](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/sync-mode.md#L275-L281) follows Understand once per qualifying epic review PR/base. [Understand](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L1-L39) requires an explicitly named PR, follows Change Overview, then reports its record, diagrams and References row.
- **Skill verification.** [Revise's Verify step](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L62) conditionally follows Run Tests and Compare Section Bodies, always checks affected skills, and calls for disclosure verification and resolution of required dependencies.

## What Changed

- **Instruction presentation.** Mode actions and their scoped details use heading steps. Common context is presented once before the prerequisites.
- **Procedure calls.** The mode text distinguishes artifact calls from followed procedures. Reviewers should inspect call inputs and conditions, particularly project checkout and epic-base arguments.
- **Source readers.** Plan's parser uses heading syntax and case-folded keys. Epic-delivery call detection accepts Apply and includes a positive example while keeping negative examples for mere reports of an operation.

The PR body reports preservation checks, passing suites and six bounded exercises. Those are captured author claims; this run did not execute tests or inspect the linked validation/disclosure records, which are outside this request's supplied evidence. The body itself qualifies strict selection order, complete prerequisite closure and complete graph outcomes as unestablished, and leaves installed-model adoption to a later task.

## Reading Order

1. [understand-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L1-L39) — the smallest complete example of the mode layout and Follow call.
2. [plan-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L1-L169) — a longer procedure with draft, registration, publication and delivery preparation conditions.
3. [sync-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/sync-mode.md#L1-L301) — finding branches, repeated calls and review handoff make preservation risks concrete.
4. [revise-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L62) — verification dispatch and the local command procedures shown in its captured diff.
5. [test_plan_mode.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L11-L79) — parser, keyed steps and publication assertions.
6. [test_documents.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221) — Apply recognition, caller coverage and required epic-base inputs.

The remaining six modes were identified through the complete changed-path summary and their heading additions in the supplied patches; they were not read in full. This is a suggested reading order, not evidence of a complete semantic review of all ten modes.

## Head and Review Worktree Requirements

- **Captured identity.** Head `c28be9980208c469e2c119e715a5b9b50b9e246e`, branch `i17/e01/w03-modes-in-the-new`; base `i17/e01/workspace` at `238b652aaa52057f66c86c9651c379296a7ba5b2`. The local head's parent equals that captured base.
- **Captured outcome.** The supplied REST response says merged at `2026-11-05T10:25:02Z`, merge commit `fb9a834c940cbed9742709d7e03594900e31d22f`. Reviews capture is `[]`. Neither proves current remote state or present approval requirements.
- **Local source.** Existing `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new` is clean and at the captured head, but attached to its task branch. Its identity was checked before and after source inspection; selected files have no diff against the captured commit.
- **Required review placement.** The prescribed path is `/home/mike1/projects/dev/workflow-server/.worktrees/pr/1643`. It is absent. The complete local worktree listing was searched for this PR/head; only the attached task worktree matches the head.
- **Required creation evidence.** The procedure fetches `pull/1643/head`, resolves `FETCH_HEAD`, compares it with the verified head, selects the PR path, and confirms a clean detached HEAD at that commit. A dirty or mismatching existing review worktree must be retained; an unused commit-suffixed path is selected. No fetch, creation or branch change is authorized here.
- **Required graph evidence.** Measurement runs in that review checkout, checks index status and staleness at the exact head, compares against the PR base, reads changed-symbol contexts and traces each reported flow. A stale index requires rebuilding and discarding stale measurements. This run has no matching review checkout and cannot build or refresh a graph. No graph commands were executed.

## Risks and Watch Points

- **Source versus execution.** Head-matching local documents support their syntax and written flow; they do not prove those procedures execute successfully, retain every prior condition, or satisfy all required prerequisite reads.
- **Test coverage.** The two changed tests were inspected, not run. Passing tests in the PR body's linked evidence remain unverified here. The captured review list contains no reviews, and no check-run/status capture was supplied for this PR.
- **Historical evidence.** The manifest records a non-atomic capture window from `2026-11-05 11:55:37 UTC` through `11:59:27 UTC`. It is historical evidence, not a live tracker read. PR metadata, file and review capture hashes match their manifest entries.
- **Protocol completion.** Change Overview requires unresolved freshness blockers to return before authoring its measured overview. This temporary draft therefore does not satisfy Populate Architecture Overview, registration, publication or PR linking.

## Record and Publication Status

Only this scratch draft exists. A top-level folder-name search of the engineering planning directory found no `*-1643-*` directory; this was not an exhaustive content search for an existing overview. No record was allocated, registered or published. A future authorized complete run must locate any existing account first and reuse it; otherwise its reference is 1643 and its slug derives from the PR title.

Diagrams: unavailable pending valid measurements. References row: none written. The captured PR already has R1 and R2; a complete publishing run must preserve those and any existing overview reference while registering its published architecture overview.
