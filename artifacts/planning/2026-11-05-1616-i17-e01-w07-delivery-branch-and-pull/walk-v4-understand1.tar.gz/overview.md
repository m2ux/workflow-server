# Reviewer Overview — Modes in the New Style

> Local, evidence-limited draft · [m2ux/workflow-server#1643](https://github.com/m2ux/workflow-server/pull/1643) · 2026-11-05

## Summary

The change presents Work Planner's ten modes as numbered heading steps with a shared Rules/Conventions/Outcomes preamble. It also makes the two affected source-reader tests understand that presentation. This concerns the skill's instruction documents and their tests; the captured change contains no workflow-server runtime implementation files.

## Identity and Head

- **Captured title:** `[I17:E01] Modes in the New Style`.
- **Captured head:** `i17/e01/w03-modes-in-the-new` at `c28be9980208c469e2c119e715a5b9b50b9e246e`.
- **Captured base:** `i17/e01/workspace` at `238b652aaa52057f66c86c9651c379296a7ba5b2`.
- **Captured outcome:** merged at `2026-11-05T10:25:02Z`, merge commit `fb9a834c940cbed9742709d7e03594900e31d22f`.
- **Change surface:** 12 files, 1,147 additions and 715 deletions. An exact-commit local git comparison agrees with the capture.
- **Freshness:** these are historical captures from a non-atomic capture window, not a live tracker read. The package's source snapshot at `709a038e…` with local W07 conversion is distinct from this PR head.

## Structure

- **Mode documents.** `advance`, `align`, `deliver`, `hoist`, `plan`, `propose`, `revise`, `standup`, `sync` and `understand` are the ten changed mode files. They are the agent-facing orchestration instructions. The PR describes ordered heading steps, flush scoped detail and Apply/Follow calls; exact-head Plan and Revise source and captured Understand/Revise patches directly demonstrate that form.
- **Plan reader.** `test_plan_mode.py` identifies `### <number>. <title>` headings within Procedure, slices each step at the next numbered heading and case-folds its title. Its assertions still examine draft placement, artifact registration, engineering publication and the distinction between planning and delivery.
- **Delivery-call reader.** `test_documents.py` recognizes Apply in `RECORD_EPIC_DELIVERY`. Its caller scan checks that recognized calls supply epic bases, while negative examples distinguish an operation report from a call.
- **Unchanged supporting areas.** The file capture and exact-commit diff contain no protocol, artifact or executable production-script changes. Those documents remain linked dependencies; their behavior is not proven by the mode layout alone.

These are file and source-level findings. Graph-measured component boundaries and edges are unavailable, so no component diagram is asserted.

## Behaviour

The following flows are read from the source; they are not GitNexus flow traces and were not executed.

- **Plan instructions.** The procedure selects a scoped proposal or initiative, prepares a planning record, drafts initiative and epic content, reviews it, publishes it and keeps it current. Preparing delivery checks prerequisites before delivery-base preparation; recording delivered work follows Sync and returns its results or blockers. The numbered headings make these stages addressable by title.
- **Revise verification.** Verify follows Run Tests conditionally, follows Check Skill Files for affected skills, and follows Compare Section Bodies for section moves. Each callable procedure contains its numbered execution step and HTML command block; Fields defines Workspace, Skill Directory, Base and Head.
- **Plan test reader.** `steps()` reads Plan, extracts Procedure with `section()`, finds numbered headings with `STEP`, slices their bodies and returns a title-keyed dictionary. Tests consume that dictionary to inspect record paths and publication calls.
- **Epic delivery test reader.** `EpicDeliveryCallers.calls()` scans Markdown lines, matches `RECORD_EPIC_DELIVERY` and returns locations with text. Assertions verify the expected caller set and the required epic-base input; an Apply example exercises the new call spelling.

No ordered graph evidence is available for a sequence diagram. The required measured structural and functional diagrams remain outstanding for a full Architecture Overview.

## What Changed

- **Instruction presentation.** Numbered heading steps carry ordered actions, and mode entry prose links common context and outcomes.
- **Verification instructions.** Revise's callable verification procedures hold the commands where they execute and link their inputs to field definitions.
- **Source-reading tests.** The Plan reader selects the new heading form, and the epic-delivery caller reader includes Apply.

## Reading Order

1. [understand-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L17-L33) — the compact three-step example of the mode presentation, supported by the captured patch.
2. [plan-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L31-L153) — a longer procedure with conditional calls, publication and delivery boundaries.
3. [revise-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L118) — verification calls, callable procedures and command/input placement.
4. [test_plan_mode.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L10-L79) — the heading parser and the invariants it observes.
5. [test_documents.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221) — Apply recognition and delivery caller checks.

These links are pinned from local/captured evidence; their remote accessibility was not checked.

## Review Checkout and Graph Requirements

- **Existing evidence checkout.** `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new` is clean, including untracked files, and its HEAD matches the captured SHA. It is attached to its task branch, so it does not satisfy the detached review-worktree requirement.
- **Required review checkout.** The prescribed default is `/home/mike1/projects/dev/workflow-server/.worktrees/pr/1643`. It is absent, and the filtered worktree inventory contains no `pr/1643` or commit-suffixed alternative. In a fully authorized run, fetch the PR head, compare FETCH_HEAD with fresh PR metadata, and create a detached checkout at that exact head. Reuse an existing review checkout only when its head matches, it is detached and it has no tracked or untracked changes; otherwise retain it and use an unused commit-suffixed path.
- **Required graph evidence.** Run graph status in that verified review checkout, establish index freshness, compare the surface against `i17/e01/workspace`, inspect changed-symbol context and trace reported flows. Every response's staleness block must support the requested head; stale results require index refresh and repeated measurement.
- **Authority limit.** Fetch, worktree creation and graph construction/refresh are prohibited here. No proper review checkout is available, so graph measurement is blocked. GitNexus CLI is installed; no GitNexus connector tools are exposed. CLI availability supplies no measurement evidence.

## Risks and Evidence Limits

- **Presentation is not behavior proof.** The PR body reports passing strict-model, preservation and behavioral suites. This run inspected source and captures and did not rerun tests or inspect external design/disclosure evidence. It cannot independently affirm those outcomes.
- **No review approval evidence.** The supplied reviews capture is `[]`; this establishes only what that historical record contains. It does not establish current reviews, checks, protection or approval requirements.
- **Selection and prerequisite fidelity.** The PR itself calls disclosure observations partial, including selection order, prerequisite closure and graph outcomes. This walk also does not establish complete prerequisite closure; see the execution report.
- **No publication.** No engineering planning record, PR body link or remote overview was written. The expected protocol outcome of one published, graph-measured account is incomplete. This temporary draft is the authorized read-only deliverable.

## References

- **R1.** [PR #1643](https://github.com/m2ux/workflow-server/pull/1643) — captured identity, description and patch scope.
- **Local evidence.** `inputs/pr1643.json`, `inputs/pr1643-files.json`, `inputs/pr1643-reviews.json`, `capture-manifest.json`, exact-commit local git comparisons and the neutral-reader log in this walk.

## Record and References Handoff

No existing top-level engineering record folder matching `*-1643-*` was found. A later authorized run should search record contents as well before choosing or reusing an identity; that broader content search was not performed because prior design and walk evidence are outside this request's inputs.

An unpublished candidate identity is `artifacts/planning/2026-11-05-1643-modes-in-the-new-style/`. No such folder was created. The following is a proposed PR References row only; it must not be published until a measured overview exists and its engineering record is published:

`- **R3.** [Architecture Overview](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1643-modes-in-the-new-style/architecture-overview.md) — the change's structure, its flows, and the order to read the diff.`
