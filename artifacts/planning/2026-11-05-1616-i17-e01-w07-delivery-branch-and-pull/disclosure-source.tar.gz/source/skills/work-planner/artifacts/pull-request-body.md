# Pull Request Body

Populates one pull request body from its change, review scope and validation evidence.

## Prerequisites

Read these files first.

- [Issue Body](issue-body.md)
- [Hot-fix](hotfix.md)

## Operations

### Populate Pull Request Body

One pull request body from supplied change and validation evidence.

**Inputs:** [Change Evidence](#change-evidence), [Current Body](#current-body), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Unresolved Evidence](#unresolved-evidence).

#### 1. Populate Change Body

Populate the body from the [Template](#template) using the change and its evidence. For an epic review, Apply [Populate Review Body](#populate-review-body).
- All populated fields must meet [Fields](#fields).

#### 2. Verify Evidence Links

Verify each result link against [Test Plan](#test-plan) before publishing the body.

#### 3. Return Complete Body

Return the complete body file and any unresolved evidence links to the caller for publication.

### Populate Review Body

The current change carried by one epic base.

**Inputs:** [Change Evidence](#change-evidence), [Current Body](#current-body), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body).

#### 1. Populate Base Review

Populate the review body from the [Template](#template) using the actual task merges into the base.
- All populated fields must meet [Fields](#fields).

#### 2. Account for Task Merge

For a later task merge:
- Restate each standing Changes bullet the merged change makes false, so the bullet states the base as it now is.
- Add its functional change under the corresponding area.
- Cite the merged task pull request as the next reference.

#### 3. Return Updated Body

Return the complete updated body file to the caller.

### Link Architecture Overview

One pull request body referencing its published overview.

**Inputs:** [Current Body](#current-body), [Overview URL](#overview-url), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body).

#### 1. Add Published Reference

Add the Architecture Overview reference to the body's References section, creating that section in its [Template](#template) position when absent.

#### 2. Preserve Existing Reference

Preserve an existing row already naming the overview. The link uses the engineering-artifacts base URL so later files resolve from the same record.

```markdown
- **R1.** [Architecture Overview](https://github.com/{owner}/{repo}/tree/engineering/artifacts/planning/2026-10-08-950-queue-placement/architecture-overview.md) — the change's structure, its flows, and the order to read the diff.
```

#### 3. Return Linked Overview Body

Return the complete updated body file for publication.

### Repair Test Plan

One task pull request's test plan aligned to its current table.

**Inputs:** [Pull Request Record](#pull-request-record), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Unresolved Evidence](#unresolved-evidence).

#### 1. Convert Current Plan

Apply [Convert Test Plan](#convert-test-plan) with the supplied record and output path.

#### 2. Inspect Preserved Coverage

Inspect the diff. A checked list and Test/Criteria table convert only when their ids agree and every line is accounted for; descriptions and coverage are preserved.

#### 3. Verify Retained Evidence

Verify retained result links against [Test Plan](#test-plan). A checked entry without linked result evidence remains pending; restore its Pass result only from verified published evidence.

#### 4. Return Plan Findings

Return the body, the converted pull request identity and unresolved findings. The caller publishes and names each conversion. An unreadable plan remains a finding until repaired from its actual checks and coverage.

### Convert Test Plan

Convert an unambiguous checked list and Test/Criteria table to the current plan table.

**Inputs:** [Pull Request Record](#pull-request-record), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Unresolved Evidence](#unresolved-evidence).

#### 1. Convert Test Plan

Run this command from the workspace checkout with the supplied inputs.

- Input is a current REST pull request record; output is the complete body. Existing current tables are unchanged.
- A conversion prints the pull request identity. Exit 1 means an unreadable plan or missing linked result evidence; inspect the body and findings before publishing.

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py plan '[**&lt;pull-request-json-file&gt;**](#pull-request-record)' --fix '[**&lt;output-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py plan pr-950.json --fix fixed-950.md
</pre></big>

## Fields

### Template

````markdown
## Overview

{{One paragraph: what this pull request delivers and why.}}

## Changes

{{One sentence on what changed and why it was needed. Then one heading per area the changes sit in. A heading is two to five words, in title case, such as Queue Placement or Task Readiness. Under each heading, one bullet per functional change in that area. The bullet opens with a bold lead, as the scheme's Bold leads rule lays one out. The change is at most two lines, the lead included: the lead names what it does, and the behavior is the single line under it.}}

### {{Queue Placement}}

- **{{What it does.}}**
  {{The behavior as it is.}}

## Test Plan

| Test | Description | Coverage | Pass |
| --- | --- | --- | --- |
| T1 | {{Check name, per [Test Plan](#test-plan).}} | {{Observed criteria, if any.}} | [{{Result}}]({{Planning document URL#test-section}}) |

## Open Questions

- {{An undecided point. Resolve it, then delete the section.}}

## References

- **R1.** [{{Title}}]({{URL}}) — {{What the reader finds there. The issue this pull request delivers is not a reference: the Development field carries that link, as [Issue Links](pull-request.md#issue-links) state. Delete the section when there is none.}}
````

### Titles

- A pull request's title starts with the epic it works on: `[I07:E00] Purpose`.
- A hot-fix's pull request takes the title its [Delivering Pull Request](hotfix.md#delivering-pull-request) names.
- A pull request working on neither an epic nor a hot-fix takes `Name: Subtitle`, with no prefix, as a revision of the skill itself does.
- The prefix is how an epic's pull requests are found, and each one, open or merged, is matched to the tasks it works on from its changes and the tasks' Descriptions.
- The pull request that merges an epic base carries the same prefix. Its head is the epic base, which tells it from a task pull request.
- A title carrying an initiative's prefix names one of its epics. An epic sync reports one that names none as `no epic`, and one naming its epic by a task id, `[I07:E00:W01]`, as `retitle`.

### Review Body

- Overview is one paragraph on what the base carries.
- Changes holds one heading per area, with a bullet per functional change.
- A Changes bullet states what the base does and carries no count of the corpus, such as how many specifications or files it holds. A count belongs in the unit's planning record, with the revision that produced it.
- Each file a Changes bullet names in a code span stands at the base's head. A code name, such as `board.Outputs`, names no file.
- References cites each task pull request merged into that base.
- It carries no Test Plan, since it delivers no task of its own, and no statement about what the epic has yet to deliver. The epic's Work Breakdown is where delivery state is read.

### Test Plan

A task pull request carries a Test Plan.

- **Table.**
  The pull request's Test Plan section contains only one table, with columns Test, Description, Coverage and Pass, in that order.
- **Columns.**
  - Test names the id.
  - Description briefly names the check.
  - Coverage names the criteria the check observes, `AC1, AC3`, and is empty when the check observes none.
  - A row whose Test cell is empty names a criterion no check observes, and its Pass cell is empty.
  - Pass is empty while a check awaits a result. A recorded result uses ✓ when the check ran and held, or an accurate label such as Partial, Fail or Not run.
- **Evidence.**
  - Test procedures, tested revisions, observations, limitations and supporting evidence belong in the work's published planning document.
  - Each recorded result in Pass links to its relevant section in that document, using the result as link text: `[✓](URL#check)` or `[Partial](URL#check)`.
  - Each evidence link is accessible to the pull request's readers and resolves to the intended section.
- **Completion.**
  The test plan has passed when every row with a Test id carries ✓ as its result. Partial, failed and unexecuted checks remain incomplete.

### Test Coverage

- Every criterion a unit's Coverage names has an observing test in its work item and pull request. A criterion no test can observe remains in the [coverage report](issue-body.md#coverage-reports) and in a test-plan row with an empty Test cell.
- The criterion selects the test kind: a unit test for one component, an integration test for a seam between components, and an end-to-end or system test for running-system behaviour. That evidence meets [Coverage Reports](issue-body.md#coverage-reports).
- An instrument that does not exist yet is work the task carries, as the verified rule defines. Use the project's own system test where it can observe the criterion.
- One row per check, in execution order, followed by any unobserved criteria. Every criterion in the unit's Coverage appears in at least one row.

### Change Evidence

The supplied current change summary and delivery scope, with validation evidence, and task-merge evidence for an epic review body.

### Current Body

The optional existing complete pull request body.

### Pull Request Record

The supplied current REST pull request JSON.

### Overview URL

The published architecture overview URL on the engineering branch.

### Output Body

The supplied local destination for the complete body.

### Unresolved Evidence

The unresolved evidence links and test-plan findings, with the identities and missing evidence of unsupported results.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.
