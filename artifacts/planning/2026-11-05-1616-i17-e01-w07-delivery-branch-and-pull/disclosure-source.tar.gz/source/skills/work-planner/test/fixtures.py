"""Board items, issues and pull requests as the REST API returns them, reduced to the fields the
scripts read, and a runner for the scripts on them."""
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent.parent / 'scripts'
REPO = 'o/r'


def url(kind: str, number: int, repo: str = REPO) -> str:
    return f'https://github.com/{repo}/{kind}/{number}'


def issue(number: int, title: str, state: str = 'open', closed: str | None = None, body: str = '',
          labels: tuple[str, ...] = (), repo: str = REPO) -> dict:
    return {'number': number, 'title': title, 'state': state, 'closed_at': closed,
            'state_reason': 'completed' if state == 'closed' else None,
            'repository_url': f'https://api.github.com/repos/{repo}', 'html_url': url('issues', number, repo),
            'body': body, 'labels': [{'name': l} for l in labels]}


def hotfix_body(target: str | None = 'main', criteria: tuple[str, ...] = ('Holds.', 'Also holds.')) -> str:
    """A hot-fix body in the standalone template, whose Overview names target in its Target: line."""
    named = f'Target: `{target}`\n\n' if target else ''
    return (f'## Overview\n\nRejects bad keys.\n\n{named}## Problem\n\nBad keys pass.\n\n'
            '## Proposal\n\nReject them.\n\n## Acceptance Criteria\n\n'
            + ''.join(f'- [ ] **AC{n}.** {text}\n' for n, text in enumerate(criteria, 1)))


def hotfix(number: int, state: str = 'open', closed: str | None = None, target: str | None = 'main',
           labels: tuple[str, ...] = ('type:hot-fix', 'theme:canon', 'priority: 10'), repo: str = REPO) -> dict:
    """An open or closed hot-fix titled [Fnn] for its number, in the hot-fix layout."""
    return issue(number, f'[F{number:02d}] Key Validation: Reject Bad Keys', state, closed,
                 hotfix_body(target), labels, repo)


BOARD = 'https://api.github.com/orgs/o/projectsV2/7'


def item(content: dict | None, status: str | None) -> dict:
    fields = [{'id': 1, 'name': 'Status', 'value': {'name': {'raw': status, 'html': status}}}] if status else []
    return {'content_type': 'Issue', 'fields': fields, 'content': content, 'project_url': BOARD}


def epic_body(*rows: tuple[str, str, str]) -> str:
    """An epic body whose Work Breakdown holds rows of (task id, description, depends on)."""
    lines = ['## Work Breakdown', '', '| Task | Description | Coverage | Depends on | Joins | Lane | Done |',
             '| --- | --- | --- | --- | --- | --- | --- |']
    lines += [f'| {task} | {description} | AC1 | {depends} | | | |' for task, description, depends in rows]
    return '\n'.join(lines + ['', '## Acceptance Criteria', '', '- [ ] **AC1.** Holds.', ''])


def work_item(component: str) -> str:
    """A work item whose declaration line names the component its implementation extends."""
    return f'**Component:** {component}\n\n## Overview\n\nWhat the task delivers.\n'


def initiative_body(*rows: tuple[str, str]) -> str:
    """An initiative body whose Work Breakdown holds rows of (epic id, depends on)."""
    lines = ['## Work Breakdown', '', '| Epic | Description | Coverage | Depends on | Done |',
             '| --- | --- | --- | --- | --- |']
    lines += [f'| {epic} | Work | AC1 | {depends} | |' for epic, depends in rows]
    return '\n'.join(lines + ['', '## Acceptance Criteria', '', '- [ ] **AC1.** Holds.', ''])


def pr(number: int, title: str, merged: str | None = None, state: str | None = None, draft: bool = False,
       body: str = '', repo: str = REPO, base: str | None = None, head: str | None = None) -> dict:
    record = {'number': number, 'title': title, 'body': body, 'html_url': url('pull', number, repo),
              'node_id': f'PR_node{number}',
              'state': state or ('closed' if merged else 'open'), 'draft': draft, 'merged_at': merged}
    if base:
        record['base'] = {'ref': base, 'repo': {'full_name': repo}}
    if head:
        record['head'] = {'ref': head}
    return record


def links(number: int, *issues: int, repo: str = REPO, issue_repo: str | None = None) -> dict:
    """One pull request's closing issue references, as Fetch Pull Request Issue Links writes them."""
    return {'repo': repo, 'number': number,
            'closingIssuesReferences': [{'repo': issue_repo or repo, 'number': n} for n in issues]}


def run(script: str, *args: str, tz: str = 'UTC') -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(SCRIPTS / script), *args], capture_output=True, text=True,
                          env={**os.environ, 'TZ': tz, 'PYTHONDONTWRITEBYTECODE': '1'})


def progress(items: list[dict], prs: list[dict], *args: str, tz: str = 'UTC',
             held: tuple[dict, ...] = (), initiatives: tuple[dict, ...] = ()) -> subprocess.CompletedProcess:
    """progress.py on the items, as two pages, the pull requests as JSON lines, the issue links
    those pull requests hold, and each initiative off the board as its own issue file."""
    with tempfile.TemporaryDirectory() as tmp:
        items_path, prs_path = Path(tmp, 'items.json'), Path(tmp, 'prs.json')
        links_path = Path(tmp, 'links.json')
        half = len(items) // 2
        items_path.write_text(json.dumps(items[:half]) + '\n' + json.dumps(items[half:]))
        prs_path.write_text('\n'.join(json.dumps(p) for p in prs))
        links_path.write_text(json.dumps(list(held)))
        extra = []
        for n, initiative in enumerate(initiatives):
            path = Path(tmp, f'initiative-{n}.json')
            path.write_text(json.dumps(initiative))
            extra.append(str(path))
        return run('progress.py', '--items', str(items_path), '--prs', str(prs_path),
                   '--links', str(links_path), *args,
                   *(['--initiatives', *extra] if extra else []), tz=tz)


def section(output: str, name: str) -> list[str]:
    """The lines of one section of a summary, between its heading and the next blank line."""
    lines = output.splitlines()
    start = lines.index(f'*{name}*') + 1
    end = next((i for i in range(start, len(lines)) if not lines[i]), len(lines))
    return lines[start:end]


GIT = ('git', '-c', 'user.email=t@t', '-c', 'user.name=T', '-c', 'init.defaultBranch=main',
       '-c', 'commit.gpgsign=false', '-c', 'core.hooksPath=/dev/null')


def git(cwd: Path, *args: str) -> str:
    """Run git in cwd and return its output, failing the test on a git error."""
    done = subprocess.run([*GIT, *args], cwd=cwd, capture_output=True, text=True)
    assert done.returncode == 0, done.stderr
    return done.stdout.strip()


def commit_branches(checkout: Path, *names: str, message: str = 'state branches') -> str:
    """Commit config/branches stating names in checkout, returning the commit."""
    stated = checkout / 'config' / 'branches'
    stated.parent.mkdir(parents=True, exist_ok=True)
    stated.write_text(''.join(f'{name}\n' for name in names))
    git(checkout, 'add', 'config/branches')
    git(checkout, 'commit', '--allow-empty', '-m', message)
    return git(checkout, 'rev-parse', 'HEAD')


def repository(checkout: Path, *names: str) -> str:
    """A repository on main whose one commit states the long-lived branches in config/branches."""
    checkout.mkdir(parents=True, exist_ok=True)
    git(checkout, 'init')
    return commit_branches(checkout, *names)


def declared(root: Path, *names: str) -> list[str]:
    """The --project and --revision arguments of a repository whose HEAD states names."""
    checkout = root / 'checkout'
    repository(checkout, *names)
    return ['--project', str(checkout), '--revision', 'HEAD']


def lane_table(*rows: tuple[str, str, str]) -> str:
    return ('## Work Breakdown\n\n'
            '| Task | Description | Coverage | Depends on | Joins | Lane | Done |\n'
            '| --- | --- | --- | --- | --- | --- | --- |\n'
            + ''.join(f'| {task} | Work | AC1 | | {joins} | {lane} | |\n'
                      for task, joins, lane in rows))
