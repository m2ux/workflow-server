# Read and command receipt trace

Scope: Project 17, m2ux/workflow-server:I17, since 2026-11-01. All writes are under /tmp/w06-walk-final-standup2. No network, external state changes, source edits, worktrees, commits, pushes, merges or agents. The allowed project checkout was not inspected because the supplied captures suffice for the captured-state report.

## Actual returned content versus emitted/saved content

- Shell tee receipts contain the full bytes emitted by each selected cat/sed/jq command. A full tee file is not by itself evidence the tool returned all of it.
- The first batched board/sync/standup-report read emitted and saved 44,625 bytes across three distinct receipt files. The functions wrapper truncated the combined return (original 11,553 tokens); board's final fields and part of Sync Mode did not arrive completely. Recovery: the entire saved sync-mode.txt was returned in chunk 1db357 (4,203 tokens), and board's last 35 lines were returned in chunk 22d47c (209 tokens). Standup Report arrived complete.
- Pull Request emitted/saved all 47,774 bytes, but its wrapper return was truncated (original wrapper 12,278 tokens, underlying command 11,944 tokens). Recovery returned original lines 430-700 in chunk c4c542 (2,986 tokens), then 395-445 in chunk 130130 (479 tokens), covering the missing region and both boundaries. The tail fields were present in the initial return. No truncation was treated as a completed read.
- Every other document return was complete. Whole prerequisites read for Standup: Board, Sync Mode, Pull Request, Standup Report, Issue, Epic Issue Body, Issue Body. Sync was read as a referenced mode; its state-changing procedure was not run, and its execution-only prerequisite tree was not loaded. Additional relevant documentation reads are saved as hotfix, lane, epic, requirement-characteristics receipts.
- The neutral reader is only a byte receipt helper; I independently selected Hot-fix Body from Standup Report prerequisites. First sbx attempt failed before Python execution due to namespace restrictions (chunk f7d777, exit 1). The identical authorized escalated command succeeded (chunk 40826b, exit 0). Its exact emitted document bytes and metadata are in receipts/neutral/. All those 2,699 bytes were returned by the successful tool call.
- Initial and final progress commands redirect stdout/stderr to scratch. Their immediate tool results contain no report bytes: b9e914 and 97ec03 both exit 0 with empty returned output. The initial report was subsequently read in chunk 67bf34, 897 tokens, complete. Initial stderr read chunk 319f7e returned empty. Final report was subsequently read in chunk c4cfeb, 1,012 tokens, complete; exact returned tool JSON is saved as final-read-0.json.
- final-read-1.json is the actual returned wc receipt: final report 4,046 bytes, management paragraph 459 bytes, both renderer-finding files zero bytes.
- final-read-2.json is the actual returned SHA-256 receipt for all four inputs and both final output files.
- returned-i17-board.json preserves the exact jq tool result returned to the model: 8,539 tokens, complete. i17-board-selected.jsonl is its stdout projection. i17-prs-selected.jsonl contains the selected I17 PR metadata returned in chunk 3e86c8 (1,762 tokens, complete). initiative-1597-selected.json was returned in chunk de6ee4 (1,431 tokens, complete).
- The Python renderer consumed the complete supplied items/PR/link/initiative inputs. I inspected selected JSON projections; I do not claim to have read the multi-megabyte inputs verbatim. The inventory, not a new network fetch, supplies their capture-completeness guarantee. Only progress.py's last 130 lines were read, as progress-main.txt; its other code and transitively imported implementation are not claimed as model-read content.
- Prompt, entry skill and neutral reader source were initially returned whole by cat (chunks ce2653, 517583, cc8491). Later copies preserve their immutable source bytes; copying emits no document content to the model.

## Operations and outcomes

1. Read prompt; create scratch receipts; read skill, rules and conventions; select Standup; read its reporting prerequisites and relevant artifact fields.
2. Read capture inventory, supplied initiative and selected board/PR evidence. Board Status field 422017304 identifies I17 In Progress, E00 Done, E01 In Progress, E02 Backlog, E03 Done.
3. Run captured progress.py through mandatory sbx from scratch with PYTHONPYCACHEPREFIX under scratch, since 2026-11-01 and repository-qualified I17. Include the supplied initiative JSON immediately. Exit 0; no unresolved renderer findings.
4. Write management.txt grounded in returned Initiatives/Completed only.
5. Run the same progress helper with --summary management.txt. Exit 0; complete report saved, empty stderr.
6. Read final report completely and retain actual response JSON, byte counts and input/output hashes. Preserve separate freshness/authority/integration limits in unresolved.md.
7. Stop locally before posting. No complete delivery-refresh checkpoint is asserted.

Exact shell commands are listed in commands.txt. apply_patch calls created only scratch management, gap, checklist and receipt files; they executed no shell commands.
