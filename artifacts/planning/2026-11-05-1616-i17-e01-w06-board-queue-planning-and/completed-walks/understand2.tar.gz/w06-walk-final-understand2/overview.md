# PR 1643 — Modes in the New Style

> Provisional source-based architecture notes · 2026-11-05 · [m2ux/workflow-server#1643](https://github.com/m2ux/workflow-server/pull/1643)

## Summary

This PR gives Work Planner's ten operating modes a consistent, addressable procedure structure and updates two tests that read those documents. A mode is an agent's workflow; linked artifact operations define the records and actions it uses. The changed-path inventory contains ten mode documents and two test files, with no workflow-server runtime implementation changes.

**Status:** this is a local draft, not the skill's completed measured Architecture Overview. Required graph evidence and publication are unavailable. Both diagrams below are unmeasured source sketches, excluded from any claim of satisfying the skill's measured-diagram requirements.

## Evidence Identity

- **Captured head:** `c28be9980208c469e2c119e715a5b9b50b9e246e`.
- **Captured base:** `238b652aaa52057f66c86c9651c379296a7ba5b2`, branch `i17/e01/workspace`; the local merge-base agrees.
- **Captured state:** merged, merge commit `fb9a834c940cbed9742709d7e03594900e31d22f`.
- **Capture window:** 2026-11-05 13:03:23–13:04:08 UTC. This establishes observed state only.
- **Supplied checkout HEAD:** `612da8d650f524eb05c3e2436bac3cdfd7f82e4c`, different from PR head. Source reads use literal historical git object SHAs.
- **Change size:** 12 files, 1,147 additions and 715 deletions. Local three-dot diff counts match the capture.
- **Distinct sources:** the immutable installed skill governs this exercise; historical PR git objects substantiate PR claims. The installed snapshot is not treated as historical PR source.

## Structure

The changed mode files define actions and calls in prose. `test_plan_mode.py` parses Plan's procedure into named steps and checks that drafts remain in the planning record and publication reaches the engineering branch. `test_documents.py` recognizes Record Epic Delivery calls and checks that they supply epic bases: the integration branches for an epic's work. These are document-contract tests, not a new production interpreter.

**Unmeasured structural sketch:** relationships below come from inspected source, not Repository Graph.

```mermaid
flowchart LR
    Reader([Engineer or agent])
    subgraph Instructions [Work Planner instructions]
      Plan[plan-mode.md]
      Revise[revise-mode.md]
      Understand[understand-mode.md]
    end
    subgraph Checks [Source-reader tests]
      PlanTests[test_plan_mode.py]
      DocTests[test_documents.py]
    end
    Reader -->|follows planning steps| Plan
    Reader -->|follows verification steps| Revise
    Reader -->|selects a PR and follows Change Overview| Understand
    PlanTests -->|reads and divides procedure headings| Plan
    DocTests -->|scans Record Epic Delivery calls| Corpus[Work Planner Markdown corpus]
    style Plan fill:#c8e6c9,stroke:#2e7d32
    style Revise fill:#c8e6c9,stroke:#2e7d32
    style Understand fill:#c8e6c9,stroke:#2e7d32
    style PlanTests fill:#c8e6c9,stroke:#2e7d32
    style DocTests fill:#c8e6c9,stroke:#2e7d32
    style Corpus fill:#f5f5f5,stroke:#9e9e9e
```

- **Modes.** The preamble links Procedure, Rules, Conventions and Outcomes. Numbered action headings expose each action with its scoped details. [Understand demonstrates the complete shape.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L7-L30)
- **Plan's reader.** `STEP` recognizes numbered third-level headings; `steps()` indexes bodies by case-folded title. Tests inspect record paths, registration, publication and the restriction on opening plan PRs. [Parser and checks.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L10-L79)
- **Delivery-call reader.** `RECORD_EPIC_DELIVERY` accepts Apply, Run, Re-run and Repeat. Tests retain expected caller coverage and require `epic bases` on each call, distinguishing an operation report from a call. [Reader and assertions.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221)

## Behaviour

The executable flow inspected is Plan's document reader. The following order is a manual reading of its source; no graph trace or runtime execution was supplied.

**Unmeasured functional sketch:** a test invokes `steps()`, which reads Plan, bounds its Procedure, finds numbered headings and returns step bodies keyed by title.

```mermaid
sequenceDiagram
    participant Test as DraftsInTheRecord test
    participant Steps as steps()
    participant File as Path.read_text()
    participant Section as section()
    participant Regex as STEP regex
    Test->>Steps: request procedure steps
    Steps->>File: read modes/plan-mode.md
    File-->>Steps: Markdown text
    Steps->>Section: select Procedure
    Section-->>Steps: text before next peer or parent heading
    Steps->>Regex: finditer(procedure)
    Regex-->>Steps: numbered heading matches
    Steps-->>Test: case-folded titles mapped to scoped bodies
    Note over Test,Steps: test inspects writer calls and record paths
```

[Source for this order.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L21-L49)

Agent-facing workflows retain explicit branches and gates in the inspected material. Plan waits for prerequisite checks before preparing delivery bases. Understand requires a named PR and delegates to Change Overview. Follow/Apply are textual instructions, not a new Python dispatcher. [Plan's gate and calls.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L130-L156) [Understand's selection and delegation.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L17-L30)

## What Changed

- **Procedure presentation.** All ten modes appear in the diff. Selected additions show their common preamble, numbered headings and explicit Apply/Follow calls. Understand's former numbered list becomes individual heading steps.
- **Revise verification.** Its verification step follows named local procedures. Each has a numbered execution step and an HTML command block with linked inputs. The source contains test, checker and comparison invocations, plus the checker example. [Verification and commands.](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L118)
- **Source-reading tests.** Plan's parser and case-insensitive keys match heading steps; the epic-delivery reader accepts Apply while retaining its input assertions. These changes support the document structure without proving end-to-end agent behaviour.

The captured PR body reports passing strict-model/preservation checks and suites, while describing disclosure observations as partial and installed-model adoption as later work. Those are captured author claims, not checks independently executed here. The PR's Changes and Test Plan retain the reported detail.

## Reading Order

1. [understand-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L7-L30) — the smallest complete preamble, heading-step and delegation example.
2. [plan-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L31-L63) — real branch conditions and artifact calls beneath headings.
3. [test_plan_mode.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L10-L79) — the executable reader and the record/publication contract it protects.
4. [revise-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L144) — verification procedures, command placement and input definitions.
5. [test_documents.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221) — the Apply recognizer and retained delivery-input safeguards.

## Risks and Completion Needs

- **Graph blocker.** No graph inventory, indexed-head identity, changed-symbol surface, contexts or ordered flow traces are supplied. The checkout is at a different head. Creating/fetching a detached review checkout and refreshing an index exceed this walk's authority. Formal diagram population stops at this blocker, as Change Overview requires.
- **Provisional diagrams.** A completing run needs head-matching review-checkout evidence, fresh graph measurements against the captured base, context for each changed symbol and complete ordered traces for reported flows. It must determine whether the structural rearrangement requires a before/after pair.
- **Publication authority.** No planning-record lookup outside allowed evidence, engineering write, commit/push or PR References edit is authorized. There is no published overview URL or saved References row. The eventual row must name an actual published record.
- **Reading limits.** Full prerequisite closure and complete semantic preservation of all ten mode bodies are not established. All ten were inspected through a selected diff projection; Understand, Plan and Revise received deeper source reads. The trace records incomplete prerequisite retrievals.
- **Validation limits.** No PR-head tests, preservation tools, graph commands or live workflows ran. Captured result links were not fetched. No performance or reading-reduction result is established.

## References

- **R1.** [PR 1643](https://github.com/m2ux/workflow-server/pull/1643) — captured description and reported validation; remote contents were not fetched.
- **R2.** Local `diff-stat.txt`, `merge-base.txt`, `head-*.txt`, `diff-entry-tests.txt`, `diff-revise.txt` and `mode-change-selection.txt` — retained local git evidence.
- **R3.** Local `findings.md` and `reads/reads.jsonl` — command outcomes, retrieval limits and exact helper-emitted artifacts.
