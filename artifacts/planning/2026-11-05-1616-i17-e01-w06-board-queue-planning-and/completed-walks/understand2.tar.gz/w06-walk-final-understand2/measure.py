import json
from pathlib import Path

root = Path('/tmp/w06-walk-final-understand2')
receipts = [json.loads(line) for line in (root / 'reads/reads.jsonl').read_text().splitlines()]
result = {
    'helper_calls_succeeded': len(receipts),
    'helper_emitted_bytes_including_repeats': sum(row['bytes'] for row in receipts),
    'helper_emitted_lines_including_repeats': sum(row['lines'] for row in receipts),
    'interpretation': 'Emitted and saved bytes only; this is not tool-returned visibility, unique source coverage, or model token usage.',
    'graph_measurements': None,
    'graph_blocker': 'No supplied graph evidence or matching review checkout; review worktree creation and indexing are outside authority.',
    'pr_head': 'c28be9980208c469e2c119e715a5b9b50b9e246e',
    'pr_base': '238b652aaa52057f66c86c9651c379296a7ba5b2',
    'checkout_head': '612da8d650f524eb05c3e2436bac3cdfd7f82e4c',
    'changed_files': 12,
    'insertions': 1147,
    'deletions': 715,
}
(root / 'measurements.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
