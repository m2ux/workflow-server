"""Read-only Git measurements; all generated files live beside this script."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
CHECKOUT = '/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and'
BASE = '238b652aaa52057f66c86c9651c379296a7ba5b2'
HEAD = 'c28be9980208c469e2c119e715a5b9b50b9e246e'

def git(*args):
    return subprocess.check_output(['git', '-C', CHECKOUT, *args])

def section(text, heading):
    match = re.search(r'^## ' + re.escape(heading) + r'\s*$', text, re.M)
    if not match:
        return None
    rest = text[match.end():]
    end = re.search(r'^#{1,2} ', rest, re.M)
    return rest[:end.start() if end else len(rest)].strip()

paths = git('diff', '--name-only', BASE + '...' + HEAD).decode().splitlines()
measurements = {
    'base': BASE, 'head': HEAD,
    'checkout_head': git('rev-parse', 'HEAD').decode().strip(),
    'merge_base': git('merge-base', BASE, HEAD).decode().strip(),
    'changed_file_count': len(paths),
    'numstat': git('diff', '--numstat', BASE + '...' + HEAD).decode().splitlines(),
    'files': [],
    'graph_measurements': None,
    'graph_limitation': 'No captured graph evidence; supplied checkout is not the PR head; review-worktree and index writes are unauthorized.'
}
for name in paths:
    raw = {revision: git('show', revision + ':' + name) for revision in (BASE, HEAD)}
    for revision, label in ((BASE, 'base-source'), (HEAD, 'head-source')):
        target = ROOT / label / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw[revision])
    before, after = (raw[revision].decode() for revision in (BASE, HEAD))
    row = {
        'path': name,
        'base_bytes': len(raw[BASE]), 'head_bytes': len(raw[HEAD]),
        'head_sha256': hashlib.sha256(raw[HEAD]).hexdigest(),
        'head_lines': len(after.splitlines()),
        'head_anchors': [
            {'line': index, 'text': line}
            for index, line in enumerate(after.splitlines(), 1)
            if line.startswith('#') or line.startswith('class ') or line.startswith('def ') or line.startswith('STEP =') or line.startswith('RECORD_EPIC_DELIVERY =')
        ],
    }
    if '/modes/' in name:
        row.update({
            'old_numbered_list_steps': len(re.findall(r'^\d+\. \*\*', before, re.M)),
            'new_numbered_heading_steps': len(re.findall(r'^### \d+\. ', after, re.M)),
            'prerequisites_identical': section(before, 'Prerequisites') == section(after, 'Prerequisites'),
            'outcomes_identical': section(before, 'Outcomes') == section(after, 'Outcomes'),
        })
    measurements['files'].append(row)
(ROOT / 'measurements.json').write_text(json.dumps(measurements, indent=2) + '\n')
print(json.dumps({key: value for key, value in measurements.items() if key != 'files'}, indent=2))
for row in measurements['files']:
    print(json.dumps({key: value for key, value in row.items() if key not in ('head_sha256', 'head_anchors')}, sort_keys=True))
print('Exact base/head blobs saved under base-source/ and head-source/. Their content is not printed by this command; saved bytes do not establish reader retrieval.')
