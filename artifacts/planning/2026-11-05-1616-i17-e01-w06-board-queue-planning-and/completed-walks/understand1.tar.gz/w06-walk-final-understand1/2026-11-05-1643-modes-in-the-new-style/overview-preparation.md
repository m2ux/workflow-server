# Overview preparation — Modes in the New Style

> Incomplete · [m2ux/workflow-server#1643](https://github.com/m2ux/workflow-server/pull/1643) · 2026-11-05

## Summary

PR 1643 expresses Work Planner's ten mode procedures as numbered Markdown headings and maintains the tests that read those instructions. The changed surface consists of ten mode documents and two Python test files, with 1,147 inserted lines and 715 removed lines. It gives each procedure an explicit Rules/Conventions/Outcomes preamble and uses Apply or Follow at its linked execution points.

These observations describe captured head `c28be9980208c469e2c119e715a5b9b50b9e246e` against base `238b652aaa52057f66c86c9651c379296a7ba5b2` (`i17/e01/workspace`). The capture reports the PR merged at 2026-11-05T10:25:02Z; the capture window ends at 2026-11-05T13:04:08.652854+00:00. No live state was queried.

## Evidence boundary

- **Exact source, separate checkout.**
  Git can read both captured commits, and the merge base equals the captured base. The supplied worktree HEAD is `612da8d650f524eb05c3e2436bac3cdfd7f82e4c`, which is a different revision; its working files are not evidence of the PR head. All head links below refer to blobs read through Git or saved directly from Git.
- **Graph evidence missing.**
  No graph inventory, indexed revision, staleness blocks, symbol contexts or ordered traces are supplied. `gitnexus` is installed, but its presence establishes none of those facts. No graph commands ran in a substitute checkout.
- **Overview paused before population.**
  The captured Change Overview protocol requires a matching review checkout and current measurements before writing the overview. Its unresolved-freshness branch returns the blocker. This document preserves preparation findings and is not the completed architecture overview.

## Source observations

### Work Planner instructions

- **Domain vocabulary.**
  Work Planner represents work as proposals, initiatives, epics and tasks. An epic holds its task table; boards show item status; a planning record holds supporting evidence and decisions. See the [skill entry point](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/SKILL.md#L13-L25).
- **Instruction layers.**
  A mode describes a user-facing workflow, a protocol coordinates a change across artifacts, and an artifact owns an operation and its data contract. These are declared instruction relationships, not graph-measured component boundaries. See [Layers and Execution](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/rules.md#L7-L10).
- **Addressable steps.**
  A step is a numbered heading with its conditions and supporting details beneath it. Understand offers the small example: select the explicit PR, follow Change Overview, then report. See [Understand's procedure](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L15-L30).
- **Nested procedures.**
  Deliver has a four-step main procedure and separately named coordinator and worker procedures. The worker procedure declares the unit checkout and gives its own numbered fourth-level headings. See [Deliver's main procedure](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/deliver-mode.md#L37-L80) and [Run Delivery Session](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/deliver-mode.md#L155-L200).
- **Executable commands.**
  Revise's verification procedures contain HTML command blocks, links on command inputs and explicit parameter definitions. The diff exposes the unittest, checker, checker example and section-comparison commands. See [verification procedures and fields](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L144).

### Test readers

- **Plan heading reader.**
  `STEP` matches numbered third-level headings. `steps()` selects the Procedure section and keys action labels with `casefold()`. The surrounding tests inspect draft placement, record registration and publication requirements. See [test_plan_mode.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L11-L79).
- **Epic-delivery call reader.**
  `RECORD_EPIC_DELIVERY` recognizes Apply alongside Run, Re-run and Repeat. Its tests require the expected caller files, require each matching call to pass epic bases, and distinguish a report about an operation from a call to it. See [test_documents.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221).

## Local measurements

The helper compares `## Prerequisites` and `## Outcomes` section bodies, trimmed at their boundaries, for each mode. Both section bodies match at base and head in all ten modes. This is a narrow comparison, not a claim that every procedural sentence or behavior is identical.

| Mode | Numbered third-level headings at head |
| --- | ---: |
| Advance | 8 |
| Align | 13 |
| Deliver | 4 |
| Hoist | 7 |
| Plan | 9 |
| Propose | 8 |
| Revise | 7 |
| Standup | 6 |
| Sync | 14 |
| Understand | 3 |

Deliver's count excludes its fourth-level child steps. Exact paths, line anchors, source byte sizes, SHA-256 values and comparison results are in [measurements.json](../measurements.json). Counts are Git/text measurements; they are not graph measurements or evidence of token reduction.

## Reading order

This is a document-reading recommendation based on the exact source selections, not a measured execution trace. Open the entry point and rules linked above first for vocabulary, then read these changed files:

1. **[understand-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/understand-mode.md#L5-L30)** — the smallest complete example of preamble, prerequisites, numbered steps and a Follow call.
2. **[plan-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/plan-mode.md#L31-L156)** — a larger mode with artifact calls, output paths, decision points, review and publication conditions.
3. **[test_plan_mode.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_plan_mode.py#L11-L79)** — how Python reads the document structure and asserts its planning-record contracts.
4. **[deliver-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/deliver-mode.md#L37-L80)** — the nested-procedure shape and the declared coordinator/worker separation.
5. **[sync-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/sync-mode.md#L91-L124)** — an Apply call that supplies task matches, task issues, the project checkout and fetched epic bases.
6. **[test_documents.py](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/test/test_documents.py#L180-L221)** — the matching call reader and the assertions that keep those epic-base inputs visible.
7. **[revise-mode.md](https://github.com/m2ux/workflow-server/blob/c28be9980208c469e2c119e715a5b9b50b9e246e/skills/work-planner/modes/revise-mode.md#L54-L144)** — command-bearing verification procedures and their linked input definitions.

The other five changed mode files are recorded in the change surface. Their complete bodies have been saved but were not returned for substantive review in this run; the helper's reported heading and section comparisons are the claims established for them here.

## Structural and functional diagrams — pending

- **Structural diagram.**
  Requires changed-symbol contexts with measured callers, callees, file locations and containing flows at the exact reviewed head. Directory names and Markdown links alone cannot establish the component areas or edges required by the captured skill.
- **Functional diagrams.**
  Require each reported flow's ordered `process_symbols`, with step indexes, files and lines. A hand-built sequence from the procedure prose would not meet the skill's graph-trace requirement.
- **Completion gate.**
  The current preparation contains no architecture diagrams. The captured Architecture Overview rule says a directory-derived boundary or hand-traced call order is a defect; the Change Overview protocol returns unresolved freshness blockers before writing an overview. This boundary prevents a complete overview under the supplied evidence.

## Risks and completion requirements

- **Review revision.**
  Supply a clean detached review checkout at the captured head, or authorize its creation. Worktree creation, fetches, checkout changes and source/index writes were forbidden in this run. A newer checkout is not interchangeable with the PR head.
- **Fresh graph capture.**
  Supply `gitnexus status`, `detect-changes --scope compare --base-ref i17/e01/workspace`, each changed symbol's `context`, and each reported flow's `query --query <flow> --limit 1` output from the matching review checkout, including revision and every response's staleness block. An absent or stale index needs an authorized `gitnexus analyze` followed by repeated measurements. The comparison base must resolve to the captured base revision for this historical overview.
- **Incomplete prerequisite retrieval.**
  The broad prerequisite read was saved in full but truncated before reaching the model. Graph, architecture overview and planning record were subsequently returned fully; delivery branches was recovered through line 220. The remaining prerequisite closure was not completed, and no dependent write or publication operation was executed. See the exact trace.
- **Validation claims.**
  The captured PR body reports five passing test-plan rows and explicitly partial reading/graph observations. Its linked planning, preservation, review, diff and validation records were outside scope, so those reports were not independently checked. No test suite ran here; no complete workflow, preservation or token-reduction result is claimed.
- **Existing record and publication.**
  A permitted continuation must locate/reuse any existing PR-1643 overview record before choosing an official folder. It must populate the measured overview, register it, publish the record and update the PR's References. Those steps require evidence/access and external-write authority unavailable here. No published overview URL or completed References row is asserted.

## References

- **R1.** [Pull request](https://github.com/m2ux/workflow-server/pull/1643) — the captured body contains its area-by-area Changes list and reported test plan; this local explanation substantiates only the reads and measurements described above.

