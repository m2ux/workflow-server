## Overview

This epic delivers each Work Planner fix found before the skill's extraction to its own repository, merged into `workspace` so the extraction carries it. Each fix is a task row, and a fault found later joins as a further row.

## Problem

The skill carries faults its own planning and sync runs have exposed.

- **Planning takes a branch the record forbids.**
  [Plan Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L42-L43) opens a draft discussion pull request from a planning branch, while the [planning record](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/planning-record.md#L153) states the engineering branch takes no further branch.
- **Draft bodies sit outside the record.**
  The [Bodies convention](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/SKILL.md#L96) keeps body files outside the repository, so a plan's drafts are not part of its committed record.
- **A not-planned epic has no rule.**
  [Initiative rows](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/initiative-issue-body.md#L143-L153) say nothing of an epic closed as not planned; only [task rows another issue takes](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/epic-issue-body.md#L267-L268) leave a table.
- **A criterion gap asks for a decision.**
  The [format check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/format.py#L1024-L1025) asks to decide criterion labels not numbered from one without a gap. When #1427 closed as not planned, #1166 dropped its row by hand.
- **Uncited closed items stay on the board.**
  [Board sync](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board.py#L578-L582) removes an item closed other than as completed only when a plan body cites it, so #1427 and #1475 were deleted from their board by hand.
- **Sync misses untitled pull requests.**
  [Read Initiative Pull Requests](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L95-L102) keeps only [titles carrying the initiative prefix](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L523-L539), so older task pull requests that #1166's epic rows link went unread until fetched by hand.

## Proposal

- **Planning commits straight to engineering.**
  Every planning artifact, draft bodies and work items included, is committed to the engineering branch in its planning record's folder. Planning opens no branch and no pull request.
- **A not-planned epic leaves its initiative.**
  Its row and the criteria only it covers are removed, and References name where its work went. Criterion numbers other work cites are kept, and the format check accepts the gap.
- **Every item closed other than as completed leaves the board.**
  Board sync applies that status to each such item on the board, whether or not a plan body cites it.
- **Sync reads pull requests by their links.**
  The fetch selects each pull request a row or a Development link of the plan names, whatever its title.

## Work Breakdown

| Task | Description | Coverage | Depends on | Joins | Done |
| --- | --- | --- | --- | --- | --- |
| [W01](https://github.com/m2ux/workflow-server/pull/1605) | Planning commits directly to engineering | AC1, AC2, AC3 | | | ✓ |
| [W02](https://github.com/m2ux/workflow-server/pull/1602) | Not-planned epic leaves its initiative | AC4, AC5, AC6 | | | ✓ |
| [W03](https://github.com/m2ux/workflow-server/pull/1603) | Board sync removes uncited not-planned items | AC7 | | | ✓ |
| [W04](https://github.com/m2ux/workflow-server/pull/1607) | Sync reads every linked pull request | AC8 | | | ✓ |

## Acceptance Criteria

- [x] **AC1.** Plan Mode writes every draft body and work item into its planning record's folder, as the skill's fixture suite checks against the mode's procedure.
- [x] **AC2.** Plan Mode publishes its planning record by committing it to the engineering branch and pushing that branch, as the skill's fixture suite checks against the mode's procedure.
- [x] **AC3.** No skill file names a planning branch or a discussion pull request, as a search of the skill's files shows.
- [x] **AC4.** An initiative row whose epic is closed as not planned is removed with every criterion only that row covers, as the initiative body's Work Breakdown conditions state.
- [x] **AC5.** An initiative that removes such a row names where its work went in References, as the initiative body's References conditions state.
- [x] **AC6.** The format check reports no finding on criterion labels that ascend with a gap, as the format check's fixture suite shows.
- [x] **AC7.** Board sync removes every board item closed other than as completed, whether or not a plan body cites it, as the board fixture suite shows for a cited and an uncited item.
- [x] **AC8.** Sync's pull request records hold every pull request a row or a Development link of the plan names, whatever its title, as the sync fixture suite shows for a linked pull request whose title carries no initiative prefix.

## References

- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
