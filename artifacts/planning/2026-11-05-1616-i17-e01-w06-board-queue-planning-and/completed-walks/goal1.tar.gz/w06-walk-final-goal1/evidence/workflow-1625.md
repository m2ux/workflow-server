## Overview

A board can be delivered by more than one session at once, each serving its own lane of task rows. Each row carries its lane as a bare index in the epic Work Breakdown table, Plan mode assigns it, and a Deliver run naming a lane takes its lane’s rows and unlaned rows. The epic lands before the skill’s extraction, so the skill moves with lanes.

## Problem

- **The live task table has no lane column.**
  Its Task, Description, Coverage, Depends on, Joins and Done cells contain no lane assignment.
- **Work-item declarations split the row’s plan.**
  The epic base’s Work Item artifact defines a separate Lane declaration, so the task table alone cannot show or supply a row’s lane.
- **Every session sees one queue.**
  The delivery survey offers available units by priority and dependencies, so two sessions on one board can select the same unit.
- **A label cannot carry it.**
  A label marks an issue, while task rows in one epic can belong to different lanes and have no task issue.

## Proposal

- **The task table owns the lane.**
  Its columns are `Task | Description | Coverage | Depends on | Joins | Lane | Done`. Lane contains a bare decimal index such as `2`; an empty cell is unlaned.
- **A lane is an opaque board-wide index.**
  The same index names one lane across the theme board. Its cell contains the index alone.
- **The request names the run’s lane.**
  A Deliver request states its lane each time. A request naming none is offered only unlaned units.
- **A laned run also admits unlaned work.**
  A run is offered its lane’s units and unlaned units, ordered by priority. Hot-fix units are unlaned.
- **Plan mode writes the task cells.**
  It asks whether the initiative uses lanes, proposes each row’s index for confirmation and passes the confirmed values to Populate Epic Issue Body.
- **Joined rows share one lane.**
  Their Lane cells carry the same index or are all empty. The dependency check refuses a split unit, settled by changing a lane or unjoining.
- **Readers use the issue body.**
  Dependency checks, delivery and queue reporting use one task-table lane reader. Work-item files supply components and implementation plans.
- **Table operations preserve lanes.**
  Format validation checks bare indices, and normalization, reservation, release, linking and Done ticks preserve the Lane cell.
- **The queue reports unit lanes.**
  Board Queue reports each Ready unit’s lane from its existing issue snapshots, and Advance carries those report lines.

## Work Breakdown

| Task | Description | Coverage | Depends on | Joins | Lane | Done |
| --- | --- | --- | --- | --- | --- | --- |
| [W01](https://github.com/m2ux/workflow-server/pull/1626) | Work item declares an optional lane | | | | | ✓ |
| [W02](https://github.com/m2ux/workflow-server/pull/1628) | Task table carries the lane column | AC11 | | W03 | | ✓ |
| [W03](https://github.com/m2ux/workflow-server/pull/1628) | Work item holds its component declaration | AC12 | W01 | W02 | | ✓ |
| [W04](https://github.com/m2ux/workflow-server/pull/1629) | Joined rows share one lane | AC3 | W02 | W05, W06 | | ✓ |
| [W05](https://github.com/m2ux/workflow-server/pull/1629) | Dependency check reads task table lanes | AC4 | W02 | W04, W06 | | ✓ |
| [W06](https://github.com/m2ux/workflow-server/pull/1629) | Lane cells validate and survive table writes | AC13, AC14 | W02 | W04, W05 | | ✓ |
| [W07](https://github.com/m2ux/workflow-server/pull/1632) | Delivery plan admits units by lane | AC2 | W02 | W08 | | ✓ |
| [W08](https://github.com/m2ux/workflow-server/pull/1632) | Available-work survey filters units by lane | AC5 | W05 | W07 | | ✓ |
| [W09](https://github.com/m2ux/workflow-server/pull/1634) | Deliver mode passes the requested lane | AC6 | W07 | | | ✓ |
| [W10](https://github.com/m2ux/workflow-server/pull/1633) | Plan mode writes task row lanes | AC7 | W04 | | | ✓ |
| [W11](https://github.com/m2ux/workflow-server/pull/1637) | Board queue reports Ready units' lanes | AC8 | W07 | W12 | | ✓ |
| [W12](https://github.com/m2ux/workflow-server/pull/1637) | Board-queue script prints Ready unit lanes | AC9 | W05 | W11 | | ✓ |
| [W13](https://github.com/m2ux/workflow-server/pull/1638) | Advance mode reports Ready unit lanes | AC10 | W11 | | | ✓ |
| [W14](https://github.com/m2ux/workflow-server/pull/1635) | Cross-epic joins receive bounded diagnostics | AC15 | W05 | | | ✓ |

## Acceptance Criteria

- [x] **AC2.** The Delivery Plan artifact states lane admission from task-table Lane cells: a run naming an index is offered units in that lane and unlaned units, a run naming none is offered only unlaned units, priority orders admitted units, and each unit line names its lane, as a read of the artifact shows.
- [x] **AC3.** The Dependency Graph artifact states that joined rows share one Lane index or all have empty Lane cells, and a split unit is refused with moving a lane or unjoining as its resolutions, as a read of the artifact shows.
- [x] **AC4.** The dependency check reads and validates the task-table Lane cells and refuses a joined unit with different lane values, naming each row and its lane, as test_deps.py fixtures with equal, different, empty and malformed Lane cells show.
- [x] **AC5.** The available-work survey reads task-table Lane cells and offers only the units admitted by the requested lane, including laned rows with no work-item link, as test_deliver.py fixtures with two lanes and unlaned rows show.
- [x] **AC6.** Deliver mode passes the lane its request names to every Plan Available Work call, passes none when the request names none, and stores no lane per session, as a read of the mode shows.
- [x] **AC7.** Plan mode asks whether an initiative uses lanes, proposes each row’s lane for confirmation and passes each confirmed index to Populate Epic Issue Body for its Lane cell, as a read of the mode shows.
- [x] **AC8.** The Board Queue artifact states that each Ready unit’s reported lane comes from its task-table Lane cells in the supplied issue bodies, as a read of the artifact shows.
- [x] **AC9.** The board-queue script reports each Ready unit’s task-table lane while producing identical placement calls for the same delivery state, as test_board_queue.py fixtures with laned and unlaned rows show.
- [x] **AC10.** Advance mode reports each Ready unit’s lane from the returned board queue lines, as a read of the mode shows.
- [x] **AC11.** The Epic Issue Body artifact defines and populates the exact task-table columns Task, Description, Coverage, Depends on, Joins, Lane, Done, with Lane holding a bare board-wide index such as 2 or an empty unlaned cell, as an artifact read and specimen row population show.
- [x] **AC12.** The Work Item artifact’s population inputs, template, fields and section rules describe Component as its declaration and contain no Lane declaration path, as a read and search of the artifact show.
- [x] **AC13.** The issue-format check rejects populated Lane cells that are not bare indices, as test_format.py fixtures for valid, empty, marked-up and prose cells show.
- [x] **AC14.** Valid and empty Lane values stay attached to their task rows through normalization, reservation, release and delivery recording, as test_format.py, test_deliver.py and test_sync.py round-trip fixtures show.
- [x] **AC15.** Joins entries outside their row’s epic produce a row-specific nonzero dependency-check result before epic-priority calculation, as CLI regression fixtures for the pinned reciprocal-join reproducer and ordinary same-epic joins show.

## References

- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the dependency report and each task's work item.
- **R2.** [prosiform I10 Evaluation and Checks](https://github.com/m2ux/prosiform/issues/464) — the initiative whose two delivery sessions wait on the lane filter.
- **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/b2844c821ce800ed3d12735bdf339049594e5ec5/skills/work-planner) — the skill this epic changes.

- **R4.** [Cross-epic join input](https://github.com/m2ux/workflow-server/issues/1630) — the pinned unsupported-input priority recursion and its bounded-diagnostic fix.
