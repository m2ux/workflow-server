# Ranked Review Findings

The captured plan does not yet establish the complete confirmed goal. F1 and F2 most threaten it. All recommendations remain **pending**, with no plan-change allowance and no changes applied.

## Discovery Coverage

### F1 — High — Acceptance excludes findings that have not entered the plan

**Problem.** The goal covers every pre-cut discovery, but the sole initiative criterion covers only work “planned here”. A known fault or required feature omitted from the table can leave AC1 true. Proposal prose promises future admission without an independently checkable discovery set, reconciliation threshold or final owner. E02's planned audit covers SOLID breaches, not every kind of pre-cut finding.

**Evidence.** [workflow-1597.md](evidence/workflow-1597.md), line 36: “Every Work Planner fix and feature planned here is in the history”. Lines 20–21: “A fault found before the extraction becomes a further task row”. [workflow-1615.md](evidence/workflow-1615.md), line 49: “Every breach of those guidelines … is listed”. The provided confirmed goal explicitly quantifies findings, including required features, before the cut.

**Proposed solution.** Require reconciliation of an identified discovery/requirement inventory against delivered rows at the cut: every applicable item has verified delivery into the exact source commit, with none pending. Fix the initial baseline before subsequent changes and retain dated additions through the cut; a fixed initial list alone would miss late findings. Keep required-feature decisions visible.

**Decision.** Pending. Recommended: adopt the complete discovery-set obligation and assign its reconciliation owner. Alternative: explicitly narrow the confirmed goal to already planned work. No narrowing was authorized.

**Evidence gap.** The excluded planning records could contain an inventory, but it was neither supplied nor read. This finding concerns the missing acceptance obligation in the captured issue bodies; it does not assert that a particular known fix is currently omitted.

## Extraction Consumer

### F2 — High — The cutover gate names a stale subset of I17

**Problem.** The extraction task waits for three named I17 epics, omitting Delivery Lanes and any future epics admitted for pre-cut findings. The consumer initiative's prose is weaker still, naming only Pre-Cutover Fixes. The plan therefore lacks a consistent consumer gate against the complete, current prerequisite set.

**Evidence.** [skills-2.md](evidence/skills-2.md), line 23: “once I17's Pre-Cutover Fixes, Skill Separation and Skill Style epics close”; line 31 lists only I17:E00, I17:E01 and I17:E02 in W00 Depends on. [workflow-1597.md](evidence/workflow-1597.md), line 32 lists E03 Delivery Lanes. [skills-1.md](evidence/skills-1.md), line 93: “once I17's Pre-Cutover Fixes epic closes.”

**Proposed solution.** Make the extraction consumer check the complete reconciled pre-cut set at the chosen workspace SHA, and keep the initiative, epic and extraction-row gate consistent. Express any task dependencies in the row-level form the current skill requires; identify all producing outputs rather than copying a static epic list.

**Decision.** Pending. Recommended: reconcile the consumer gate with the complete I17 admission set. Alternative: keep the static gate and explicitly constrain admission, requiring a new confirmed goal. Cross-initiative changes remain outside this review's authority.

**Qualification.** E03 is already captured closed and its task/integration commits are present in local workspace history. The omission has not produced a demonstrated loss of delivery lanes. E01 and E02 still block the captured extraction task. No premature extraction is claimed.

## Completion Evidence

### F3 — Medium — Historical ancestry does not prove the fixes survive at the cut

**Problem.** AC1's ancestry instrument proves a merge commit is in history. A later revert or rewrite can preserve ancestry while removing the fix's effective content. I16's explicit tree comparison proves copying against its source, which is useful, but would also faithfully copy such a source. Neither captured criterion connects each admitted fix/feature's required end state to verification at the exact source commit used for extraction.

**Evidence.** [workflow-1597.md](evidence/workflow-1597.md), line 36: “as `git merge-base --is-ancestor` shows for each one's merge commit”. [skills-2.md](evidence/skills-2.md), line 36 requires destination content to match “at the extracted workflow-server commit”. The former observes history; the latter observes equality with that source.

**Proposed solution.** Retain ancestry as branch-delivery proof, verify each required invariant against the exact cut commit, and correlate that source SHA with the consumer's destination tree comparison. Keep extraction ownership with I16 rather than duplicating its delivery in I17.

**Decision.** Pending. Recommended: require source-revision verification plus the existing consumer tree comparison. Alternative: accept historical inclusion as the whole meaning of “carries it”; that narrows the observable goal.

**Qualification.** No revert or lost implementation was observed. This is a gap in the planned completion instrument. No source/destination cut pair, post-integration criterion checks or extraction comparison receipt was supplied.

## Retained Evidence Gaps

- Local refs are not refreshed remote evidence. The capture window bounds tracker claims.
- All permitted epic bodies were recovered from whole issue captures. Planning/work-item files were not read, so audit ownership, component contention, detailed tests and decisions there remain unverified.
- No **Source.** references exist in I17; historical and example URLs were not fetched. Their remote contents are unavailable here and were not used as binding requirements.
- The captured PR bodies describe checks and disclosure observations; this review did not rerun the skill's fixture suite or independently verify every criterion tick.
- I17 dependencies pass over supplied bodies, but component declarations were unavailable. “No component contention” is not established.
- No graph inventory/measurements, live GitHub state or authority to repair the plan is available.
