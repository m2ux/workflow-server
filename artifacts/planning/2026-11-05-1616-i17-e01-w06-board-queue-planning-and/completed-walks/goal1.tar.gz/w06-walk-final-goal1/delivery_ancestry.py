import json
from pathlib import Path
import subprocess

root=Path('/tmp/w06-walk-final-goal1')
project='/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and'
rows=[]
for line in Path('/tmp/i17-e01-w06/final-package/inputs/prs.jsonl').read_text().splitlines():
    pr=json.loads(line)
    if not pr['title'].startswith('[I17:') or not pr.get('merged_at'):
        continue
    commit=pr.get('merge_commit_sha')
    args=['git','--no-optional-locks','-C',project,'merge-base','--is-ancestor',commit,'03d353300ca4804194fd50d316d73e3bf1270d1d']
    result=subprocess.run(args,capture_output=True,text=True)
    record={'pr':pr['html_url'],'title':pr['title'],'merge_commit':commit,'consumer_commit':'03d353300ca4804194fd50d316d73e3bf1270d1d','command':args,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    rows.append(record)
    print(json.dumps({k:record[k] for k in ('pr','merge_commit','exit_code','stderr')}))
(root/'validation/all-i17-ancestry.json').write_text(json.dumps(rows,indent=2)+'\n')
