import json
import os
from pathlib import Path
import subprocess
import sys

root=Path('/tmp/w06-walk-final-goal1')
script='/tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/format.py'
project='/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and'
for number,rev in [(1598,'48f4ac592814d6c74bd67d94350909d096835c45'),(1616,'612da8d650f524eb05c3e2436bac3cdfd7f82e4c'),(1615,'03d353300ca4804194fd50d316d73e3bf1270d1d'),(1625,'03d353300ca4804194fd50d316d73e3bf1270d1d')]:
    args=[sys.executable,script,str(root/f'evidence/workflow-{number}.json'),'--initiative',str(root/'evidence/workflow-1597.json'),'--prs','/tmp/i17-e01-w06/final-package/inputs/prs.jsonl','--project',project,'--revision',rev,'--fix',str(root/f'validation/project-{number}.md')]
    result=subprocess.run(args,text=True,capture_output=True,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
    record={'command':args,'cwd':str(root),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    (root/f'validation/project-{number}.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))
