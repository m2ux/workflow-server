# I17 Goal Trace

Confirmed goal: every Work Planner fix and required feature found before extraction lands in workflow-server workspace before the extraction is cut, and the extraction carries it.

Result: **partially covered; goal achievement unconfirmed**. I17 defines a credible merge route for planned work. Its sole criterion does not establish completeness against discoveries, and the extraction consumer's gate does not track the complete initiative. Content carriage is planned in I16 but has no supplied execution evidence.

Evidence window: captures from 2026-11-05T13:03:23.661278+00:00 through 13:04:08.652854+00:00. Local git results are observations of existing objects and local refs, not a live remote refresh.

| Goal clause | Initiative criteria | Epics | Epic criteria and delivering rows | Source requirement |
| --- | --- | --- | --- | --- |
| Every fix found before extraction is delivered | AC1, partly: “planned here” narrows “found” | E00 #1598 | AC1–AC3: W01; AC4–AC6: W02; AC7: W03; AC8: W04 | Confirmed user goal; #1597 Proposal lines 20–21 admit later faults |
| Required features found before extraction are delivered | AC1, partly: planned features | E03 #1625 | AC11: W02; AC12: W03; AC3: W04; AC4: W05; AC13–AC14: W06; AC2: W07; AC5: W08; AC6: W09; AC7: W10; AC8: W11; AC9: W12; AC10: W13; AC15: W14. Delivered W01 has its criteria adopted elsewhere | Confirmed user goal; #1597 Proposal lines 22–23 |
| Planned skill-style work reaches workspace before extraction | AC1 | E01 #1616 | AC1–AC8: W01–W08 respectively | Confirmed goal's required feature/fix scope; captured initiative explicitly admits this epic |
| Planned separation work reaches workspace before extraction | AC1 | E02 #1615 | AC1–AC5: W01–W05 respectively | Confirmed goal's required feature/fix scope; captured initiative explicitly admits this epic |
| Every discovery before the cut is accounted for | No criterion proves equality between discoveries and planned work | No owning row for a final discovery-to-delivery reconciliation | E02 AC2 audits SOLID breaches only; it is not an inventory of every fix and required feature | Confirmed user goal's “every … found before extraction”; finding F1 |
| Delivery is into workflow-server workspace before the cut | AC1 ancestry at the extraction-source workspace commit | All four epic rows cite AC1 | Detailed criteria above establish each epic's own outcome; integration evidence establishes the branch boundary | Confirmed user goal; #1597 lines 16–19 and 36; consumer gap F2 |
| The extraction carries the fixes and required features | AC1 supplies historical ancestry, not direct content verification | No I17 epic criterion observes extraction content; external consumer I16 E00 #2 owns copying | I16 E00 AC1/W00 compares the extracted tree; AC2/W00 checks SKILL history. I16 AC1 names tree/log comparison | Confirmed user goal; consumer evidence is supplied in items.json; content-survival gap F3 |

All initiative criteria and all four epic rows appear above. Every supplied epic criterion has a task-row Coverage entry; format validation reports no uncovered criterion. No extra initiative criterion lacks a goal clause. Component/work-item completeness is unevaluated because the permitted inputs do not include those records.

## Requirement Sources

I17's References contain no **Source.** marker. R1 is a background consumer initiative, R2 a planning record, and R3 a historical source revision. No remote document was fetched or silently treated as a binding requirement. Captured I16 bodies were read as external-consumer evidence. Planning records were excluded by the task's authority limits.

## Observed Delivery

- E00 is captured closed, with all criteria and tasks ticked. Its integration #1604 and all four task merge commits are ancestors of exact local workspace commit `03d353300ca4804194fd50d316d73e3bf1270d1d`.
- E03 is captured closed. Its integration #1627 and all captured task merge commits are ancestors of that same workspace commit. Delivery lanes are already present in that history despite their omission from the extraction gate.
- E01 is captured open. W06 and W08 remain open. Six task PRs are merged into its epic base; none of their merge commits is an ancestor of the local workspace commit. #1647's merge is an ancestor of captured epic head `612da8d650f524eb05c3e2436bac3cdfd7f82e4c`. Integration #1641 remains draft and open.
- E02 is captured open, with all tasks and criteria unticked. Its task edge follows E01 W08.
- No extraction source/destination commit pair or tree-comparison receipt is supplied. No extraction completion is inferred from the absence of a matching PR; the extraction plan permits a direct first push.

These open deliveries are expected incomplete work, not proof of a defect in the implementation.
