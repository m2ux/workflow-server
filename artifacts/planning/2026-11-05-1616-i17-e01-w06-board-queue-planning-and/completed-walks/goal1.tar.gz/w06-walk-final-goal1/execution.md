# Execution and Retrieval Record

## Authority

Only the prompt, immutable captured source, supplied captures and read-only git evidence in the named unit checkout were used. Outputs are confined to /tmp/w06-walk-final-goal1. No external calls or source writes occurred. The task explicitly authorizes escalated execution of mandatory read-only sbx helpers after namespace setup fails.

The first sbx helper failed with bwrap namespace-permission error (exit 1). The same read-only helper succeeded with require_escalated (exit 0). Subsequent Python helpers used that same sbx route with PYTHONPYCACHEPREFIX under this scratch directory. No automatic approval rejection occurred.

## Commands and Outcomes

Exact top-level command text, responses, exit codes and output are in receipts/tool-results.json. Helper subprocess commands and full stdout/stderr are in validation/*.json.

- Initial prompt cat from the not-yet-created scratch directory: process creation failed, no content returned. Retried from /tmp successfully; then created the scratch directory.
- cat/sed reads of the captured skill, rules, conventions, Plan mode, all direct Plan prerequisites, goal/review artifacts, requirement characteristics, Initiative and Plan Change: supplied guidance only; procedures requiring writes were not executed.
- jq on issue captures: complete selected issue bodies returned. Whole selected JSON records were saved to evidence/ by the read-only helper; only selected fields and bodies were actually returned to the model, not every metadata byte.
- rg --files on inputs: capture inventory only. rg on deps.py: matched implementation lines only, not a complete script read.
- sbx neutral-read.py --heading 'Planning Records': namespace attempt failed, authorized escalated retry returned the complete section; exact emitted bytes and source range are logged under receipts/neutral/.
- sbx review_helper.py: wrapper exit 0. Initiative format and all four epic format checks exit 0. E00 gets only a diagnostic Lane-column normalization in scratch. Dependency check exit 0, with an E03 W14 numbering advisory, 15 longest chains of seven steps, and no component read for any task. Program stdout prints ten chains and explicitly suppresses five; those suppressed chains were not emitted or read.
- sbx project_validation.py: four epic checks exit 0 at explicit local git commits. Required-criterion configuration applies to workflows/corpus; captured I17 PRs target workspace routes. No missing changed-path record was treated as evidence of coverage.
- git for-each-ref: local origin/workspace = 03d353300ca4804194fd50d316d73e3bf1270d1d and origin/i17/e01/workspace = 612da8d650f524eb05c3e2436bac3cdfd7f82e4c; E00 and E02 base refs were absent from the selected local refs. No fetch occurred.
- git show config/branches succeeds at workspace, E01 head and the two integration commits; names docker, main, workflows, workspace. git show required criteria succeeds at E01's captured head.
- git merge-base --is-ancestor: E00/E03 integrations are ancestors of local workspace and E01 head. W07 merge 652ef07 is absent from local workspace ancestry (exit 1) and present in E01 head ancestry (exit 0).
- sbx delivery_ancestry.py: wrapper exit 0. Every captured E00/E03 merged PR has ancestry exit 0 against exact workspace SHA 03d3533; all six captured E01 task merges have exit 1. No git errors were returned.

## Retrieval Limits and Recovery

1. A batched cat produced complete inner tool response objects of 10,506 and 20,810 reported tokens. The functions.exec envelope truncated their combined presentation. Both complete inner objects were retained in session storage and are saved in tool-results.json. Saved bytes alone were not counted as read.
2. The first inner output was re-emitted whole with an adequate output allowance; Issue Body, Initiative Issue Body and Planning Record were fully returned.
3. The second inner output was re-emitted as lines 1–780 and 781–1404. The first replay clipped a small region in Propose mode, which was separately re-emitted from its title through the next mode title. The second replay was complete. The recovered texts cover that batch.
4. A jq inventory-shape probe inadvertently emitted the first entire board item. Its inner response and combined envelope were truncated. This retrieval is retained as incomplete; unreturned metadata was not used. Relevant I16 initiative and extraction-epic bodies were subsequently selected with jq and returned completely alongside all I17 sibling bodies. Unused first-item metadata was not recovered.
5. Further reads were bounded and their visible output contained no truncation marker. Source snapshots saved by helpers are not described as wholesale model reads.
6. Initial tool calls predate structured result collection; their commands, outcome, warnings and known token sizes are recorded in early-retrievals.md. The exact core-read response was retained separately. The live tool transcript remains the primary evidence for those early returns.
7. Prerequisite timing was not fully ordered: several dependent documents were read before all prerequisite documents, including Planning Records Configuration. Direct Plan prerequisites were eventually returned, but transitive prerequisite closure outside the goal-review branch was not exhausted. No executed merge, publish or delivery operation is claimed. This reading result is therefore not evidence of full disclosure compliance.

## Unavailable Work

No plan or consumer-gate fix is applied. Proposed changes need user decisions and later authorized writes. Live tracker refresh, extraction source/destination trees, graph measurements, full work-item/component evidence and post-integration requirement verification remain unavailable. Captured evidence cannot establish present remote readiness or a completed extraction.
