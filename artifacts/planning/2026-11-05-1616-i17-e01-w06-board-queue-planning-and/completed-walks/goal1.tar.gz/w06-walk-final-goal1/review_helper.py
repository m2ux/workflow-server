import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/w06-walk-final-goal1')
INPUTS = Path('/tmp/i17-e01-w06/final-package/inputs')
SOURCE = Path('/tmp/i17-e01-w06/final-package/source')
PROJECT = '/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and'
SCRIPTS = SOURCE / 'skills/work-planner/scripts'
for name in ('evidence', 'validation'):
    (ROOT / name).mkdir(exist_ok=True)
items = json.loads((INPUTS / 'items.json').read_text())
selected = {}
for item in items:
    issue = item.get('content', {})
    repo = issue.get('repository', {}).get('full_name', '')
    n = issue.get('number')
    if (repo == 'm2ux/workflow-server' and n in (1597,1598,1615,1616,1625)) or (repo == 'm2ux/prosiform-skills' and n in (1,2)):
        key = ('workflow-' if repo.endswith('workflow-server') else 'skills-') + str(n)
        selected[key] = issue
for name,n in [('initiative',1597),('epic',1616)]:
    selected['workflow-'+str(n)] = json.loads((INPUTS / f'{name}-{n}.json').read_text())
for key, issue in selected.items():
    (ROOT / 'evidence' / f'{key}.json').write_text(json.dumps(issue,indent=2)+'\n')
    body=issue['body']
    (ROOT / 'evidence' / f'{key}.md').write_text(body)
    numbered=''.join(f'{i:4d} {line}\n' for i,line in enumerate(body.splitlines(),1))
    (ROOT / 'evidence' / f'{key}.numbered.txt').write_text(numbered)

def run(name,args):
    result=subprocess.run(args,text=True,capture_output=True,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'))
    record={'name':name,'command':args,'cwd':str(ROOT),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    (ROOT / 'validation' / f'{name}.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))

initiative=ROOT/'evidence/workflow-1597.json'
epics=[ROOT/f'evidence/workflow-{n}.json' for n in (1598,1616,1615,1625)]
run('initiative-format',[sys.executable,str(SCRIPTS/'format.py'),str(initiative),*sum((['--epic',str(p)] for p in epics),[]),'--fix',str(ROOT/'validation/initiative-format.md')])
for p in epics:
    run(p.stem+'-format',[sys.executable,str(SCRIPTS/'format.py'),str(p),'--initiative',str(initiative),'--fix',str(ROOT/'validation'/f'{p.stem}-format.md')])
run('dependencies',[sys.executable,str(SCRIPTS/'deps.py'),'I='+str(ROOT/'evidence/workflow-1597.md'),*['E'+f'{i:02d}'+'='+str(ROOT/f'evidence/workflow-{n}.md') for i,n in enumerate((1598,1616,1615,1625))]])
for rev in ('origin/workspace','origin/i17/e01/workspace','48f4ac592814d6c74bd67d94350909d096835c45','03d353300ca4804194fd50d316d73e3bf1270d1d'):
    run('config-'+rev.replace('/','-'),['git','--no-optional-locks','-C',PROJECT,'show',rev+':config/branches'])
for label,commit in [('e00-integration','48f4ac592814d6c74bd67d94350909d096835c45'),('e03-integration','03d353300ca4804194fd50d316d73e3bf1270d1d'),('e01-w07','652ef07ea5b8553d3bdb73542c3a393ac20e6ea9')]:
    for ref in ('origin/workspace','origin/i17/e01/workspace'):
        run(label+'-at-'+ref.replace('/','-'),['git','--no-optional-locks','-C',PROJECT,'merge-base','--is-ancestor',commit,ref])
print('Extracted issue bodies and immutable snapshots: '+str(ROOT/'evidence'))
