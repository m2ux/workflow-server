# Commands actually recorded

Each receipt preserves the command and its returned exec_command result. Python commands ran from this scratch directory through the mandated sbx wrapper. Other commands used the session default directory unless their literal git -C selected the permitted checkout. Read read-trace.md for the initial unreceipted transcript actions, blocked attempt039 and outer presentation truncation.

## 003-skill

Exit: 0; receipt: [003-skill.json](receipts/003-skill.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/SKILL.md
```

Returned output:

```text
---
name: work-planner
description: >-
  Plans and maintains agent-engineering work on GitHub: proposals, initiatives, epics, tasks and theme boards. Use to propose work or scope a problem; plan or break down work; raise, restructure, align or renumber an initiative or epic; check issue format, criteria, dependencies or delivery; fold review findings into issues; sync completed work and close what is finished; advance a board, decide what moves to ready or what to pick up next; deliver board work or dispatch ready tasks; understand or explain a pull request, write its architecture overview or diagram its changes; hoist, triage or find a home for orphan issues; produce a standup or Slack status update; or revise the work-planner skill itself.
---

# Work Planner

Work Planner plans work as GitHub issues and keeps the plan current until the work is delivered. The issues are the plan:

- **Proposal**  States the problem and the goal, with no Work Breakdown.
- **Initiative**  States a goal and lists its epics.
- **Epic**  Lists its tasks in a Work Breakdown table.
- **Task**  One pull request's worth of work.
- **Standalone issue**  Work outside any initiative.
- **[Hot-fix](artifacts/hotfix-body.md)**  A fix to a long-lived branch beside all queued work.

Each theme's project board shows where its items stand. The [proposals board](configuration.md#proposals-board) holds proposals. A planning record holds what an initiative leaves out: the evidence, the decisions and each review.

Read [Rules](rules.md) and [Conventions](conventions.md) before selecting a mode.

## Modes

Select the mode as appropriate to fulfill the user request:

- **[Propose](modes/propose-mode.md)**
  - Forward-looking, scoped to one problem
  - Scoping a problem nothing is planned against yet
  - Raising a proposal issue with optional board placement
- **[Plan](modes/plan-mode.md)**
  - Forward-looking, scoped to one approved proposal
  - Turning an approved proposal into initiatives
  - Raising, breaking down and restructuring initiatives and epics
  - Review passes of a plan against its goal, dependencies included
  - Renumbering of epics and tasks
  - Folding review findings into issues
- **[Align](modes/align-mode.md)**
  - Backward-looking, scoped to one epic, initiative or board
  - Checks of existing issues against their templates and the rules that bind them, with fixes
  - Acceptance criteria checked for verifiability and against the sources the initiative marks
  - Epic branch structure and task pull request bases brought to the delivery shape
- **[Sync](modes/sync-mode.md)**
  - Backward-looking, scoped to one epic, initiative or board
  - Delivery recorded against the issues that planned it
  - Closure of complete task issues, epics and initiatives
  - The theme board brought current with its issues
- **[Advance](modes/advance-mode.md)**
  - Forward-looking, scoped to one board
  - Placement of initiatives and epics as In Progress or as Ready, and of hot-fixes as their [Board Status](artifacts/hotfix.md#board-status) gives
  - A parallel work map for initiatives with no priority
- **[Deliver](modes/deliver-mode.md)**
  - Forward-looking, scoped to one board
  - Delivery of a theme board's work, each unit planned, implemented and raised as a pull request
  - Dispatch of one session per unit of work
  - Merging task pull requests through the shared delivery procedure
- **[Understand](modes/understand-mode.md)**
  - Backward-looking, scoped to one pull request
  - An architecture overview of one pull request
  - Structural and functional diagrams of its changes
  - The order to read the diff in
- **[Hoist](modes/hoist-mode.md)**
  - Forward-looking, scoped to a repository's orphan issues
  - Discovery of orphan issues
  - Placements for each in an existing or new initiative, epic or task, or as a hot-fix
- **[Standup](modes/standup-mode.md)**
  - Backward-looking, scoped to one board's reporting window
  - Standup summaries of a theme's board for a Slack channel
- **[Revise](modes/revise-mode.md)**
  - Forward-looking, scoped to this skill's own files
  - Changes to SKILL.md, its modes, artifacts, references and scripts

## Dependencies

- **GitHub CLI (`gh`).**
- **Sandbox.** (`scripts/sbx`).
- **Python 3.10 or later.**
- **git.**
- **GitNexus.**
- **Sub-agents.**
- **Epic-base merge permission.**
  The agent harness grants the [Merge Permission](artifacts/pull-request.md#merge-permission) Deliver needs.
```

## 004-inventory

Exit: 0; receipt: [004-inventory.json](receipts/004-inventory.json).

```sh
cat /tmp/i17-e01-w06/final-package/inputs/README.md
```

Returned output:

```text
# Final Captured Walk Inputs

Read-only captures start 2026-11-05T13:03:23.661278+00:00 and finish 2026-11-05T13:04:08.652854+00:00. Initiative 1597 is [I17] Cutover Readiness in m2ux/workflow-server; issue 1598 is E00. Direct epic 1616 has AC7 ticked and its W07 row links merged pull request 1647. Its exact board item 291152098 on users/m2ux/projectsV2/17 has Status In Progress. Integration pull request 1641 remains draft at head 612da8d650f524eb05c3e2436bac3cdfd7f82e4c.

items.json and fields.json retain complete paginated REST responses. Each item's issue remains whole. prs.jsonl holds complete REST pull request objects, one per nonempty line, gathered from m2ux/prosiform-skills, m2ux/workflow-server and supplemented with every plan/Development-linked pull request the board requires. links.json is the complete closing-issue relation snapshot for that collection; the capture script succeeds only after every page arrives. pr-1643.json is the complete named Understand-request record. Other direct pull-request/issue and exact board-item records retain their observed states. pull-pages files preserve raw source pagination.

Captures establish their observed state; they are not continuing live evidence. No graph inventory, graph measurements or remote requirement-source contents are supplied. The source snapshot and project checkout are distinct evidence objects; commands requiring unavailable authority or graph/remote state remain explicit limitations. Walkers have local read-only authority only.
```

## 005-rules

Exit: 0; receipt: [005-rules.json](receipts/005-rules.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/rules.md
```

Returned output:

```text
# Rules

- **Linked sections.**
  Read a heading-linked section and its subsections, stopping before the next heading of equal or higher level. Read that file's Prerequisites first; reading prerequisites does not execute procedures. A mode named in another mode's Prerequisites is read as a document, and its own Prerequisites load only where a step runs it. Preserve boundaries in batched reads and recover truncated output. Reuse complete prerequisites already read at the same revision. Explicit whole-document requirements still apply.
- **Decisions.**
  Ask one at a time, following the [interview rules](guidelines.md#modes). A decision the run's [allowance](artifacts/plan-change.md#allowance) covers is taken with its recommended option rather than asked. Record each decision in the affected issues and, when there is one, the planning record.
- **Layers.**
  Modes, protocols, artifacts. A mode aggregates protocol calls, as an application calls services; a protocol runs artifact operations and other protocols; an artifact runs neither. A call goes down the stack, never up. A mode reaches an artifact operation directly only where no protocol owns that change.
- **Execution.**
  A call passes its named inputs. A protocol is one change that lands in several artifacts together, and is run whole. Run another mode, a protocol, or a named subsection only where the procedure calls it; finish that call and return its result before continuing, unless the procedure explicitly dispatches concurrent work.
```

## 006-conventions

Exit: 0; receipt: [006-conventions.json](receipts/006-conventions.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/conventions.md
```

Returned output:

```text
# Conventions

- **Session.**
  Once per session, before the first `gh` call, unset `GH_TOKEN` and `GITHUB_TOKEN` so `gh` uses its keyring login. Where shell state does not persist between commands, confirm instead that neither is set in the shell profile.
- **Repository.**
  `gh` resolves `{owner}/{repo}` from the git remote of the directory it runs in, so run `gh` commands inside a checkout of the repository that holds the issues. `{other}` is a further repository the board's issues live in.
- **Checkouts.**
  A command that runs git or GitNexus where it stands declares `**Acts on:** the checkout it runs in.`, and each call to it, or to an operation running it, names one as `the <name> checkout`. Each mode and protocol declares `**Runs in:** the <name> checkout.`, as does a procedure subsection running elsewhere.
  - `project`  The repository's main working tree.
  - `epic base`  An epic base's worktree.
  - `unit`  A unit's task worktree.
  - `engineering`  The [engineering branch](configuration.md#planning-records)'s worktree.
  - `review`  A pull request's detached review worktree.
- **Bodies.**
  - Bodies and long comments always go through a file (`-F body=@file`), never inline, which avoids quoting.
  - **Example.**  workflow-server's dynamic-shell restrictions deny a body inlined in the command.
  - A plan's draft bodies are files of its [planning record](artifacts/planning-record.md#layout). Keep every other body file in a working directory outside the repository.
- **Scripts.**
  Scripts run under `sbx`, invoked by its absolute path from `<workspace>`, the checkout holding this skill. A script that reaches the tracker calls `gh` itself, and one that adds a worktree writes the repository's git directory, which `sbx` leaves read-only; each runs from `<workspace>` outside `sbx`.
- **Boards.**
  A project board sits under `users/{owner}`, or `orgs/{owner}` when `gh api repos/{owner}/{repo} --jq .owner.type` is `Organization`.
- **Example values.**  Substitute the real ones:
  - `936` an initiative issue, `943` and `937` its epics, `637` a task issue, `874` an orphan, `946` an initiative off the board, `960` a proposal;
  - `950` a pull request, `I07` and `I08` initiative numbers;
  - board `9`, workflow-server's Canon theme, and `419167630` its Status field id;
  - `1` the Initiative Template board, `13` a board copied from it;
  - `14` the Proposals Template, `15` the Proposals board;
  - `m2ux` the user.
  - `<checkout>` any checkout of the project, a linked worktree included.
```

## 007-plan

Exit: 0; receipt: [007-plan.json](receipts/007-plan.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/plan-mode.md
```

Returned output:

```text
# Plan Mode

Scopes the solution: the design, the criteria, and the breakdown of an initiative and its epics, and keeps them current as work lands.

**Runs in:** the project checkout.

Follow the [Procedure](#procedure), adhering to [Rules](../rules.md) and [Conventions](../conventions.md) and ensure all [Outcomes](#outcomes) are met.

## Prerequisites

Read these files first.

- [Lane](../artifacts/lane.md)
- [Propose Mode](propose-mode.md)
- [Guidelines](../guidelines.md)
- [Planning Record](../artifacts/planning-record.md)
- [Pull Request](../artifacts/pull-request.md)
- [Issue](../artifacts/issue.md)
- [Initiative Issue Body](../artifacts/initiative-issue-body.md)
- [Epic Issue Body](../artifacts/epic-issue-body.md)
- [Work Item](../artifacts/work-item.md)
- [Repository Labels](../artifacts/repository-labels.md)
- [Issue Body](../artifacts/issue-body.md)
- [Epic](../artifacts/epic.md)
- [Delivery Branches](../artifacts/delivery-branches.md)
- [Sync Mode](sync-mode.md)
- [Review Finding](../artifacts/review-finding.md)
- [Goal Trace](../artifacts/goal-trace.md)
- [Dependency Graph](../artifacts/dependency-graph.md)

## Procedure

### 1. Take the Proposal

- When the user names a proposal, its associated issue body defines the problem scope.
- When the user names an initiative that already exists, Apply [Read Tracker Issue](../artifacts/issue.md#read-tracker-issue) for its body. That body defines the problem scope, and no proposal is raised for work it already carries.

When neither a proposal nor an existing initiative is named:

- Follow [Propose Mode](propose-mode.md) with the user's goal.
- Resume this selection step with its published proposal; an unresolved proposal blocks initiative drafting.

### 2. Prepare the Planning Record

- For an initiative, epic or complex plan, Apply [Populate Planning Record](../artifacts/planning-record.md#populate-planning-record) with the record identity, folder and supplied evidence files.
- Use [Layout](../artifacts/planning-record.md#layout) for draft paths.
- Apply [Publish Planning Record](../artifacts/planning-record.md#publish-planning-record) for the record's folder.

### 3. Draft Each Initiative Body

- For a new initiative, Apply [Select Tracker Number](../artifacts/issue.md#select-tracker-number) for its proposed prefix with the initiative prefix letter.
- Apply [Draft Initiative Issue Body](../artifacts/initiative-issue-body.md#draft-initiative-issue-body) for each initiative with the scoped proposal, confirmed goal clauses, requirement sources, epic summaries and an output path in the record's folder. The epics' acceptance criteria carry the detail that makes the initiative's criteria true.

### 4. Populate the Epics

- Ask once per initiative whether it uses lanes as an [Interview](../guidelines.md#modes), recommending a choice from its proposed parallel delivery. Reuse the initiative's recorded decision when it has one.
- For an initiative using lanes, propose each task row's [Lane](../artifacts/lane.md#index) index as a map for the user to confirm, assigning joined rows together as [Unit Consistency](../artifacts/lane.md#unit-consistency) requires. Record the confirmed map in the planning record. For an initiative without lanes, leave the row lanes empty.
- Apply [Populate Epic Issue Body](../artifacts/epic-issue-body.md#populate-epic-issue-body) for each epic and each new task row, passing each confirmed optional lane index with the row and an output path in the record's folder.
- Apply [Populate Work Item](../artifacts/work-item.md#populate-work-item) for each task with its scope, design, the component its implementation extends, criteria, test requirements and an output file in the record's folder.
- Register each draft body and returned work-item file in the planning record.
- Resolve Open Questions before work starts.
- Apply [Check Dependencies and Numbering](../artifacts/dependency-graph.md#check-dependencies-and-numbering) across the drafts and the returned work-item files.
- Return each epic draft and its format results to the review step.

### 5. Review the Drafts

Apply [Review Initiative Goal](../artifacts/goal-trace.md#review-initiative-goal).

- Apply [Report Review Finding](../artifacts/review-finding.md#report-review-finding) for each returned finding, with its scope, evidence and proposed resolution.

Apply each confirmed resolution to the drafts:

- For a local epic finding, Apply [Populate Epic Issue Body](../artifacts/epic-issue-body.md#populate-epic-issue-body) with the confirmed Proposal, row and criterion changes, including every new or renumbered criterion in Coverage, retaining the same output path in the record's folder.

For a confirmed distinct concern:

- Draft its own epic and initiative row.
- Repeat ordering review for the new epic and initiative row.

Record the finding, resolution and decision in the planning record.

- Apply [Review Initiative Goal](../artifacts/goal-trace.md#review-initiative-goal) again with the revised initiative and epic bodies and retained goal clauses and sources. No issue is created while a content or structural finding remains. Unresolved links to unpublished issues are recorded with their intended row identities and resolved during publication; no other finding is deferred.
- An acceptance criterion is created only once it meets [Initiative Acceptance Criteria](../artifacts/initiative-issue-body.md#initiative-acceptance-criteria).

### 6. Publish

Put the proposed [Epic Priority](../artifacts/dependency-graph.md#epic-priority) map for the reviewed epics to the user as an [Interview](../guidelines.md#modes), the proposal the recommended answer.

- Take the positive integer the user confirms for each epic.
- Apply [Ensure Repository Labels](../artifacts/repository-labels.md#ensure-repository-labels) with the required definitions, the priority label each confirmed number names among them, before saving the issues.

For a new initiative:

- Apply [Select Tracker Number](../artifacts/issue.md#select-tracker-number) with the initiative prefix letter.
- Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) for it, using temporary epic-row links until issue identities exist.
- Save the epics in dependency order, each carrying its confirmed priority label.
- Replace every temporary link in the initiative and epic bodies with the saved issue identity.
- Confirm no unresolved epic placeholder remains.

Apply [Validate Epic Body](../artifacts/epic-issue-body.md#validate-epic-body) with the saved initiative context.

- Apply [Validate Initiative Body](../artifacts/initiative-issue-body.md#validate-initiative-body) with every saved epic.
- Resolve findings.
- Save the corrected bodies.
- Update the planning record with evidence, decisions and issue links.
- Apply [Publish Planning Record](../artifacts/planning-record.md#publish-planning-record) for the record's folder.

### 7. Keep the Goal Current

When the goal, a criterion, a Problem, a Proposal or an epic changes:

- Apply [Review Initiative Goal](../artifacts/goal-trace.md#review-initiative-goal) again with the revised bodies and current sources.
- Apply [Report Review Finding](../artifacts/review-finding.md#report-review-finding) for each finding.
- Apply confirmed resolutions.
- Repeat that review until clear.
- After each round, Apply [Check Round of Edits](../artifacts/issue-body.md#check-round-of-edits) on affected bodies.

Whenever tasks, edges or a work item's component change, Apply [Check Dependencies and Numbering](../artifacts/dependency-graph.md#check-dependencies-and-numbering) again.

- Put the proposed Epic Priority map to the user again where the edges or the contention moved an epic's number.
- Save each confirmed change as that epic's priority label.

Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with affected bodies, matching titles to current numbers and Coverage to current criteria.

- Keep the record's body files as the source for the next pass.
- Update work-item files and the README inventory for added, renamed or removed tasks.
- Update the planning record.
- Apply [Publish Planning Record](../artifacts/planning-record.md#publish-planning-record) for the record's folder.

### 8. Prepare Epic Delivery

Before any task starts:

- Resolve every Open Question with the user.
- Record the answer.
- Update the affected bodies, removing each settled question.
- Split multi-condition criteria at the end of the list.
- Update Coverage for the split criteria.
- Apply [Check Epic Prerequisites](../artifacts/epic.md#check-epic-prerequisites) with current initiative and prerequisite evidence; stop on a failed or incomplete result.
- After prerequisites pass, Apply [Prepare Delivery Bases](../artifacts/delivery-branches.md#prepare-delivery-bases) with the project checkout.
- Apply [Publish Pull Request](../artifacts/pull-request.md#publish-pull-request) to retarget each affected open task pull request to its epic base.
- Repeat goal and ordering review on changed bodies before returning readiness.

### 9. Record Delivered Work

When work has landed:

- Follow [Sync Mode](sync-mode.md) for the affected initiative.

For an unplaced task issue:

- Apply [Populate Epic Issue Body](../artifacts/epic-issue-body.md#populate-epic-issue-body) with its new row and the output path in the record's folder.
- Save that body.
- Follow [Sync Mode](sync-mode.md) again with the refreshed epic.

Return the saved delivery state or blockers.

## Outcomes

- **A scoped initiative.**
  The user has an initiative scoped to the proposal they named, or to a proposal raised for that problem.
- **Several initiatives.**
  One proposal may become several initiatives. A partition by solution maturity, such as an MVP demo, a functional prototype, and a production-intent version, is an example of that result. Those initiatives may run in series or in parallel. The example does not limit the partition.
- **A goal made true.**
  Each clause of the goal the user confirmed is made true by the initiative's criteria, and the epics the initiative lists are the work that delivers those criteria.
- **Epics that start together.**
  The user has settled which of the initiative's epics start alongside each other, from a proposal the dependency graph makes.
- **Review before creation.**
  Findings on that initiative are folded in before any of its issues are created.
```

## 008-input-sizes

Exit: 0; receipt: [008-input-sizes.json](receipts/008-input-sizes.json).

```sh
wc -lc /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json /tmp/i17-e01-w06/final-package/inputs/epic-1616.json /tmp/i17-e01-w06/final-package/inputs/prs.jsonl
```

Returned output:

```text
      0    9120 /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json
      0   12621 /tmp/i17-e01-w06/final-package/inputs/epic-1616.json
    363 6753248 /tmp/i17-e01-w06/final-package/inputs/prs.jsonl
    363 6774989 total
```

## 009-prerequisite-sizes

Exit: 0; receipt: [009-prerequisite-sizes.json](receipts/009-prerequisite-sizes.json).

```sh
wc -lc /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/lane.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/propose-mode.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/guidelines.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/planning-record.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/pull-request.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative-issue-body.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic-issue-body.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/work-item.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/repository-labels.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue-body.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/delivery-branches.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/sync-mode.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/review-finding.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/goal-trace.md /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/dependency-graph.md
```

Returned output:

```text
   174   6222 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/lane.md
    83   3318 /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/propose-mode.md
   243  23529 /tmp/i17-e01-w06/final-package/source/skills/work-planner/guidelines.md
   219   7483 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/planning-record.md
  1146  47774 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/pull-request.md
   883  34054 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue.md
   371  16699 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative-issue-body.md
   566  32143 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic-issue-body.md
    86   3363 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/work-item.md
    71   1937 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/repository-labels.md
   440  17686 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue-body.md
   203  12021 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic.md
   721  27102 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/delivery-branches.md
   301  16809 /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/sync-mode.md
    73   2262 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/review-finding.md
   119   5127 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/goal-trace.md
   239  15882 /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/dependency-graph.md
  5938 273411 total
```

## 010-goal

Exit: 0; receipt: [010-goal.json](receipts/010-goal.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/goal-trace.md
```

Returned output:

```text
# Goal Trace

The table tying each clause of a confirmed goal to the initiative criteria that make it true, the epics that deliver them, and the source requirements they answer to, with the ranked gaps that trace exposes.

## Prerequisites

Read these files first.

- [Issue Body](issue-body.md)
- [Initiative Issue Body](initiative-issue-body.md)
- [Planning Record](planning-record.md)

## Operations

### Review Initiative Goal

The draft checked against the initiative outcomes.

**Inputs:** [Goal Evidence](#goal-evidence).

**Outputs:** [Trace Table](#trace-table), [Review Result](#review-result).

#### 1. Identify Confirmed Goal Clauses

Take the goal the user stated and confirmed, as clauses, each an outcome someone could observe.

#### 2. Build Goal Trace

Build the [Trace Table](#trace-table) from those clauses, the initiative criteria, the epics whose Coverage cells cite them and the epic criteria that deliver them.
- Every goal clause has an initiative criterion that makes it true.
- Every initiative criterion is delivered by an epic, and that epic's criteria make the criterion wholly true.
- Every initiative criterion traces to a goal clause.
- Remove one that traces to none, or put that scope to the user.
- Record any criterion no task row delivers as a gap from the supplied epic format results.

#### 3. Read Marked Requirement Sources

Apply [Read Requirement Sources](initiative-issue-body.md#read-requirement-sources) with the initiative References, checkout, authenticated access and output files.
- Extend the trace table with the source requirement each criterion answers to. Each unmatched requirement, each criterion that departs from the one it cites, and each source that could not be read is a gap [Sources](initiative-issue-body.md#sources) names.

#### 4. Check Acceptance Criteria

Check each criterion against the [shared acceptance criteria](issue-body.md#shared-acceptance-criteria) and [Initiative Acceptance Criteria](initiative-issue-body.md#initiative-acceptance-criteria).

#### 5. Validate Local Drafts

Apply [Build Body Snapshot](issue-body.md#build-body-snapshot) for each supplied local draft with its title, labels and existing identity when present.
- Apply [Validate Initiative Body](initiative-issue-body.md#validate-initiative-body) with the initiative JSON, every linked epic's current JSON, source evidence and output file.
- Incorporate its local findings into this review.

#### 6. Check Outside Threats

Apply [Check Outside Threats](#check-outside-threats) with the current initiative and epic bodies or drafts, and the artifacts and consumers the plan changes.

#### 7. Return Ranked Gaps

Rank the gaps, meeting [Gaps](#gaps).
- Flag the few that most threaten the goal.
- Record the trace table in the [planning record](planning-record.md), or give it to the user when the change has none.
- Return the trace and ranked findings to the caller.

### Check Outside Threats

An item the draft leaves open is a gap.

**Inputs:** [Plan Bodies](#plan-bodies), [Changed Surface](#changed-surface).

**Outputs:** [Review Result](#review-result).

#### 1. Check External Consumers

Check for anything outside the plan that reads, builds or ships what the plan changes or removes.

#### 2. Check Hidden Violations

Check for a skip, a fallback, or a fail-closed path that hides a violation.

#### 3. Check Completion Instrument

Check that done has a threshold, a baseline, and an instrument that is independent of the thing measured. The baseline is fixed before the plan changes what it measures.

#### 4. Check Consumer Alignment

Check for skew between an artifact the plan produces and an implementation that reads it.

#### 5. Return External Threats

Check for a change elsewhere that alters the ground the plan stands on.
- Return the evidenced threats and gaps to the calling goal review.

## Fields

### Trace Table

| Goal clause | Initiative criteria | Epics | Epic criteria | Source requirement |
| --- | --- | --- | --- | --- |
| The outcome the user confirmed | The criteria that make the clause true | The epics whose Coverage cells cite those criteria | The epic criteria that deliver them | The requirement the criterion answers to |

Every clause, criterion and epic the initiative holds occupies a row. A cell with no entry is a gap, not an omission.

### Gaps

A gap is a clause no criterion makes true, a criterion no epic delivers, a criterion tracing to no clause, a criterion no task row delivers, an unmatched source requirement, a criterion departing from the source it cites, a source that could not be read, or a threat the draft leaves open. Gaps are ranked, and the few that most threaten the goal are flagged.

### Goal Evidence

The current initiative and epic bodies or local drafts, confirmed goal clauses, marked requirement sources and supplied epic-format results.

### Changed Surface

The supplied artifacts and consumers the plan changes.

### Review Result

The trace table and ranked findings, including evidenced outside threats and gaps.

### Plan Bodies

The supplied current initiative and epic bodies or local drafts.
```

## 011-findings

Exit: 0; receipt: [011-findings.json](receipts/011-findings.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/review-finding.md
```

Returned output:

```text
# Review Finding

One evidenced problem and its proposed solution.

## Operations

### Populate Review Finding

One finding verified against its supplied source.

**Inputs:** [Finding Evidence](#finding-evidence).

**Outputs:** [Finding Result](#finding-result).

#### 1. Verify Supplied Problem

Verify the problem against the supplied source.

#### 2. Return Evidence Gaps

If evidence is missing or contradictory, return that finding for the caller to resolve.

#### 3. Populate Verified Finding

Populate the finding with its source quotation.
- It must meet [Finding Content](#finding-content) and [Decision State](#decision-state).

#### 4. Return Finding Decision

Return the finding and any pending decision.

### Report Review Finding

The verified findings presented for resolution.

**Inputs:** [Finding Set](#finding-set).

**Outputs:** [Finding Result](#finding-result).

#### 1. Populate Verified Findings

Apply [Populate Review Finding](#populate-review-finding) with the area, severity, problem, solution and source evidence.
- Resolve any evidence gap before reporting it.
- Group the returned findings by area.

#### 2. Resolve Pending Decisions

Put each pending decision to the user, one question at a time.
- Wait for the answer.
- Record the confirmed answer on the finding, meeting [Decision State](#decision-state).
- Return each confirmed resolution to the caller for application to its selected issue kind. A pending decision returns without applying a change.

## Fields

### Finding Content

Each finding has an area, severity, one problem/solution pair and a source quotation with file and line. The source establishes the stated problem. Findings are grouped by area when presented together.

### Decision State

A finding identifies whether it needs a user decision and records any supplied answer. An unanswered decision remains pending.

### Finding Evidence

The supplied area, severity, problem, proposed solution, source text and file:line, decision requirement and any confirmed answer.

### Finding Set

The supplied findings with their area, severity, problem, proposed solution and source evidence.

### Finding Result

The verified findings and their confirmed resolutions or pending decisions, retaining evidence gaps.
```

## 012-initiative

Exit: 0; receipt: [012-initiative.json](receipts/012-initiative.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative-issue-body.md
```

Returned output:

```text
# Initiative Issue Body

Populates one initiative body. The body states the goal as criteria and lists the epics that deliver them.

## Prerequisites

Read these files first.

- [Issue Body](issue-body.md)
- [Requirement Characteristics](../references/requirement-characteristics.md)
- [Initiative](initiative.md)

## Operations

### Populate Initiative Issue Body

One initiative body and its local validation findings.

**Inputs:** [Proposal Context](#proposal-context), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Validation Findings](#validation-findings).

#### 1. Draft Scoped Body

Apply [Draft Initiative Issue Body](#draft-initiative-issue-body) with the supplied proposal context and output path.

#### 2. Check Current Round

Apply [Check Round of Edits](issue-body.md#check-round-of-edits).

#### 3. Return Draft Findings

Return the populated body and its local format findings to the caller.

### Draft Initiative Issue Body

One initiative body, scoped to one proposal.

**Inputs:** [Proposal Context](#proposal-context), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files).

#### 1. Populate Initiative Template

Populate the body from the [Template](#template) into a local file at the supplied output path.
- That file must be the source for every later edit.
- All populated fields must meet [Fields](#fields).

#### 2. Derive Problem and Boundary

Derive the Problem and Non-Goals from the proposal this initiative is scoped to.
- The Problem must meet [Problem and Proposal](issue-body.md#problem-and-proposal).
- Each Non-Goal must meet [Non-Goals](#non-goals).

#### 3. Write Source-Based Criteria

Write the acceptance criteria before the Work Breakdown, so each row's Coverage can cite them.
- Each criterion must come from a confirmed clause and meet [Initiative Acceptance Criteria](#initiative-acceptance-criteria).
- The criteria must come from the requirements sources the proposal references. Where the proposal references none, they must come from the proposal's body alone.

#### 4. Populate Shared Table

Apply [Write Issue Table](issue-body.md#write-issue-table) with the supplied row data.

#### 5. Fill Initiative Cells

Fill the initiative-specific cells.
- Each row must meet [Work Breakdown](#work-breakdown).
- An item a test cannot observe must stay named as [Coverage Reports](issue-body.md#coverage-reports) define.

### Record Initiative Delivery

One initiative body with its epic delivery recorded.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Delivery Findings](initiative.md#delivery-findings).

#### 1. Record Supplied Epics

Apply [Sync Initiative](#sync-initiative) with the initiative and all linked epic records as `--epics`, supplying `--fix` when an output body is requested.

#### 2. Return Initiative Delivery

Return the body and [Delivery Findings](initiative.md#delivery-findings) from the supplied initiative and epic records. Delivery eligibility follows [Delivery State](initiative.md#delivery-state).

### Record Initiative Criteria

Verified criteria and completed rows in one initiative body.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Criterion Selection](#criterion-selection), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Criterion Selection](#criterion-selection).

#### 1. Record Verified Criteria

Apply [Tick Initiative Criteria](#tick-initiative-criteria) with the initiative, linked epics as `--epics`, verified ids as `--tick` and output as `--fix`. Refuse criteria not ready to verify.

#### 2. Return Criterion Disposition

Return the body and refused criteria.

### Validate Initiative Body

The body's local format and field findings.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Source Evidence](#source-evidence), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Validation Findings](#validation-findings).

#### 1. Validate Kind Conditions

Apply [Validate Issue Body](issue-body.md#validate-issue-body) with the current body, local [Fields](#fields), supplied related evidence and output file, supplying each linked epic as `--epic`.

#### 2. Retain Current Title

Use its current title for the initiative row.

#### 3. Identify Source Departures

Include excluded names in Problem and Proposal and criterion/source departures in the findings.

#### 4. Return Local Findings

Return the corrected body, mechanical diff and unresolved findings for the caller.

### Read Requirement Sources

The requirements evidence used to validate an initiative's criteria.

**Inputs:** [Requirement References](#requirement-references), [Source Evidence](#source-evidence), [Output Files](#output-files).

**Outputs:** [Source Evidence](#source-evidence), [Validation Findings](#validation-findings).

#### 1. Read Local Sources

Read each local source at its checkout path.

#### 2. Fetch Pinned Sources

For a pinned GitHub blob, Apply [Fetch Source](#fetch-source) with its repository, path, pinned revision and output file.

#### 3. Fetch Other URLs

Fetch other URLs through the harness's web access.

#### 4. Record Unreadable Sources

Record an unreadable or empty source as a [Sources](#sources) finding; its criteria remain unevaluated.

#### 5. Return Source Evidence

Return each source's contents and identity with those findings.

### Sync Initiative

Reports an initiative's delivery state against its epics, and ticks Done on an epic row whose issue is closed as completed. A row whose epic it is not given keeps its Done cell and is reported unchanged.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Delivery Findings](initiative.md#delivery-findings).

#### 1. Sync Initiative

Run this command from the workspace checkout with the supplied inputs.

- It takes every linked epic's current JSON. Delivery findings follow [Delivery State](initiative.md#delivery-state).

Pass every epic JSON file as a separate argument after `--epics`.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py '[**&lt;initiative-json-file&gt;**](#initiative-record)' --epics '[**&lt;epic-json-file&gt;**](#epic-records)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py issue-936.json --epics issue-943.json issue-937.json
</pre></big>

### Tick Initiative Criteria

Ticks confirmed initiative criteria, refusing any not ready to verify, and ticks completed rows.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Criterion Selection](#criterion-selection), [Output Files](#output-files).

**Outputs:** [Output Files](#output-files), [Criterion Selection](#criterion-selection).

#### 1. Tick Initiative Criteria

Run this command from the workspace checkout with the supplied inputs.

Pass every epic JSON file as a separate argument after `--epics`. `<criterion-ids>` is a comma-separated list of verified criterion ids.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py '[**&lt;initiative-json-file&gt;**](#initiative-record)' --epics '[**&lt;epic-json-file&gt;**](#epic-records)' --tick '[**&lt;criterion-ids&gt;**](#criterion-selection)' --fix '[**&lt;output-body-file&gt;**](#output-files)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py issue-936.json --epics issue-943.json issue-937.json --tick AC2 --fix fixed-936.md
</pre></big>

### Fetch Source

Saves one GitHub source at the revision its permalink pins.

**Inputs:** [Source Evidence](#source-evidence), [Output Files](#output-files).

**Outputs:** [Source Evidence](#source-evidence).

#### 1. Fetch Source

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#source-evidence)/[**&lt;repository&gt;**](#source-evidence)/contents/[**&lt;source-path&gt;**](#source-evidence)?ref=[**&lt;revision&gt;**](#source-evidence)' --jq .content | base64 -d > '[**&lt;source-file&gt;**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/m2ux/workflow-server/contents/docs/spec.md?ref=4a217fe6' --jq .content | base64 -d > source-R1.md
</pre></big>

## Fields

### Template

````markdown
## Overview

{{One paragraph: what the initiative achieves, stated as the end state. Name the goal the reviews will test against.}}

## Problem

{{One sentence on the friction, then one bullet per facet. Each bullet opens with a bold statement, and its body is on the next line.}}

- **{{Facet}}.**
  {{The evidence.}}

## Proposal

- **{{Move}}.**
  {{What is done, within two lines.}}

## Work Breakdown

| Epic | Description | Coverage | Depends on | Done |
| --- | --- | --- | --- | --- |
| [E00](https://github.com/{{OWNER}}/{{REPO}}/issues/{{EPIC_ISSUE}}) | {{The epic's title name, the part before the colon}} | AC{{n}}, AC{{m}} | {{Earlier epic}} | |

## Acceptance Criteria

- [ ] **AC1.** {{One invariant. It is specific, measurable, achievable, relevant, and time-bound. It carries no stale count. It names no initiative, epic, task, or issue. It states what the initiative achieves as a whole, and it ends by naming its instrument.}}

## Non-Goals

- {{One succinct sentence on what this initiative does not do. It names no initiative, epic, task or issue, and no owner.}}

## References

- **R1.** [{{Title}}]({{URL}}) — {{What the reader finds there.}}
- **R2.** **Source.** [{{Title}}]({{URL}}) — {{The requirements this initiative's criteria answer to.}}
````

### Titles

- The title is `[I07] Name: Subtitle`.
- Labels are `type:initiative` and a `theme:*`.
- `I` is the initiative number. Initiatives count from `00`.

### Problem

- A Problem meets [Problem and Proposal](issue-body.md#problem-and-proposal).

### Proposal

- A Proposal states the design, as [Problem and Proposal](issue-body.md#problem-and-proposal) defines.
- A Proposal names no epic, task, or acceptance criterion of its own initiative.

### Work Breakdown

The columns are `Epic | Description | Coverage | Depends on | Done`. The table has no Joins column.

- An epic row's id is the epic, linked to its issue: `[E01](…/issues/937)`.
- An epic row's Description is the epic's title name, and its Coverage names the initiative criteria the epic serves.
- An epic row is complete when its issue is closed as completed.
- An epic row whose issue is closed as not planned leaves the table. Each criterion only that row covers leaves with it, and a criterion another row also covers stays. The criteria that remain keep their [labels](issue-body.md#criterion-labels).
- Depends on names epics only. A cell that names a task fails. Name a prerequisite epic only when every task or joined unit in the dependent epic requires every task in that prerequisite epic, directly or through its dependencies. The consumed output and the work producing it establish that requirement. Dependencies on selected tasks remain in the task tables. An edge another named whole-epic prerequisite already implies is omitted.
- An initiative dependency that only some tasks need, or that requires only part of its prerequisite epic, is overbroad. The output and its producing tasks establish the edge.
- An epic depending on a later epic is a backward reference.
- Epic numbering meets [Numbering](issue-body.md#numbering).

### Initiative Acceptance Criteria

An initiative criterion meets the [shared acceptance criteria](issue-body.md#shared-acceptance-criteria) and [Requirement Characteristics](../references/requirement-characteristics.md), and:

- **No counts.**
  An initiative criterion carries no counts or figures, which go stale: it measures against a named baseline or check ("against the baseline", "as the budget test measures it"). A figure stays only where it is the criterion's own target, such as a bound it holds to.
- **SMART.**
  Each initiative criterion is specific about what holds, measurable by a named check or baseline, achievable by the epics that cite it, and relevant, tracing to a clause and to the Problem. It is time-bound by a release tag or another named milestone outside the initiative's own work, where one exists, and otherwise by the epics that cite it.
- **Local.**
  An initiative criterion names no initiative, epic, task or issue, and is solution-agnostic. Coverage cells link epics to criteria. One that holds only through another initiative's work is restated as what this initiative achieves, or it is dropped.
- **Whole.**
  An initiative criterion states what the initiative achieves as a whole. One that restates a single epic's criterion is a duplicate: it is raised to what the epics achieve together, or left to the epic.
- **Verified.**
  - An initiative criterion ends by naming its instrument. Which instruments keep a criterion is [Verifiable](issue-body.md#verifiable).
  - An automated test is an end-to-end walk through the real server, a smoke run of an agent against a live server, a live check on a deployed host, or a guard, fixture suite or check that continuous integration runs. The walk, smoke run or live check is preferred where the criterion is about what a run does.
  - A named test that does not exist yet is work the plan holds: a task in the epic whose subject it tests, or a discrete test-infrastructure epic when the tests serve several criteria. That epic's row cites the criteria its tests verify.

### Non-Goals

- One succinct sentence each on what the initiative does not do, naming no initiative, epic, task or issue, and no owner.

### References

- A proposal-derived initiative identifies its originating proposal in References with the proposal's exact title and issue URL, labelled as the originating proposal.
- A reference the criteria answer to carries **Source.** after its label: `- **R1.** **Source.** [Title](url) — what it binds`. An unmarked reference is background, and binds no criterion. What a marked one requires of the criteria is [Sources](#sources).
- A cross-initiative overlap is recorded in References. An approved edit to another initiative's issue stays minimal.
- An initiative that removes a not-planned epic's row carries a reference linking the issue that takes that epic's work.

### Sources

A marked source in References is a document the initiative's criteria answer to. The criteria are aligned with it in both directions.

- A criterion that misstates or contradicts a marked source fails the [Correct](../references/requirement-characteristics.md#individual) characteristic.
- A requirement a marked source states that no criterion makes true, and no Non-Goal excludes, is a gap.
- An epic is aligned against its initiative's marked sources, through the initiative criteria its row covers.
- A marked source that cannot be read leaves its criteria unaligned until it is read.

### Breakdown Prose

Work Breakdown contains its table. Explanatory prose belongs in Proposal. The body does not narrate execution order or how the tables work; Depends on carries the order.

### Proposal Context

The scoped proposal, confirmed goal clauses, requirement sources and epic summaries supplied for drafting.

### Initiative Record

The supplied complete current initiative issue JSON.

### Epic Records

Every linked epic's current JSON.

### Source Evidence

The source locations, checkout paths and authenticated source access supplied for reading, with the contents and source identities once read. A pinned GitHub source has its repository owner and name, path and pinned revision, URL-encoded for the request.

### Output Files

The supplied local destinations for source contents or a complete body; the body output is optional when only a delivery report is requested.

### Criterion Selection

The supplied verified criterion ids.

### Validation Findings

The corrected body, mechanical diff and unresolved findings, including unreadable or empty requirement sources.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.

### Requirement References

The supplied initiative References entries identifying the requirements sources to read.
```

## 013-dependencies

Exit: 0; receipt: [013-dependencies.json](receipts/013-dependencies.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/dependency-graph.md
```

Returned output:

```text
# Dependency Graph

The task edges an initiative's epics declare, and the row numbers that graph permits.

## Prerequisites

Read these files first.

- [Lane](lane.md)
- [Issue](issue.md)
- [Initiative Issue Body](initiative-issue-body.md)
- [Work Item](work-item.md)
- [Plan Change](plan-change.md)
- [Delivery Branches](delivery-branches.md)

## Operations

### Check Dependencies and Numbering

The task graph and the row numbers it permits, checked and renumbered across the supplied bodies.

**Inputs:** [Graph Inputs](#graph-inputs).

**Outputs:** [Graph Result](#graph-result).

#### 1. Check Supplied Task Graph

Use the supplied local drafts when reviewing unpublished work.
- For published issues, Apply [Read Tracker Issue](issue.md#read-tracker-issue) for the initiative and each epic body.
- Apply [Check Dependencies](#check-dependencies) with the initiative body, every epic body and every supplied work-item file. The computation invokes Apply [Check Unit Lanes](lane.md#check-unit-lanes) internally with each derived unit’s epic body and complete ids.

#### 2. Resolve Graph Findings

For each finding, Apply [Check Plan Change Autonomy](plan-change.md#check-plan-change-autonomy) with the supplied allowance.
- Take an automatic correction.
- Settle a held finding as [Held Change](plan-change.md#held-change) states.
- Name the producing row for each consumed output, meeting [Edges](#edges), replacing an epic a task row names with the rows the task consumes.
- Read tasks for implied consumption edges.
- Answer every open candidate unit as [Joins](#joins) states.
- Account for every contending pair through [Component Contention](#component-contention).
- Resolve backward references by moving work to the epic owning its inputs, or removing duplicate work already owned there. Work claimed twice has one owner and a boundary in both bodies.

#### 3. Apply Confirmed Numbering

Renumber the confirmed maps, preserving the numbers [Numbering Map](#numbering-map) protects.
- For a confirmed epic map, Apply [Renumber Epics](#renumber-epics) with current pull request records and every affected body.
- For a confirmed task map, Apply [Renumber Tasks](#renumber-tasks) with the initiative and epic identities, owning epic body, confirmed old-to-new task-number map and every affected body file.
- Re-sort rewritten tables.
- Inspect every reported range.
- Search prose for references the script cannot see.
- After each edge or numbering change, Apply [Check Dependencies](#check-dependencies) with the refreshed initiative and epic bodies and every supplied work-item and split-unit record file. Repeat that operation until it reports no problem.
- Record the printed longest chains and each printed contending pair in the planning record.
- Return the checked bodies, the proposed [Epic Priority](#epic-priority) map and unresolved findings to the caller; do not publish a failed renumbering.

### Check Dependencies

Checks the task dependency graph across the epics given, and with `I=` the initiative's Depends on cells.

**Inputs:** [Dependency Files](#dependency-files).

**Outputs:** [Graph Result](#graph-result).

#### 1. Check Dependencies

Run the following command with the supplied inputs.

- Keep `I=` for the initiative. Repeat the `<epic-id>=<epic-body-file>` argument once per epic, the `<epic-id>:<task-id>=<work-item-file>` argument once per work item, and `R=<record-file>` once per record.
- The command runs in `<workspace>`, and each file sits in a planning record or a working directory beyond it. Supply the paths as [Dependency Files](#dependency-files) defines them.

- Initiative edges follow the [whole-epic prerequisite rule](initiative-issue-body.md#work-breakdown); narrower dependencies stay in the task graph.
- It also reports dependencies listed twice or already implied, Joins pairs that do not name each other or that a dependency links, and a joined unit covering more than six criteria.
- It refuses a joined unit that fails the [lane condition](#joins), naming each row and its lane, and exits nonzero.
- It prints each candidate unit its rows do not join and no `R=` record line names exactly, with both resolutions and each direct edge a join drops, and each candidate split by rule with its reason, as [Joins](#joins) states. An `R=` file it cannot read is a problem.
- An entry it cannot resolve is a problem naming the entry as written, as [Edges](#edges) states. Its second clause says what this run could not find, which is the epics it was given.
- It prints each pair of rows in different epics whose work items declare one component, meeting [Component Contention](#component-contention), and names the rows it was given no work item for, so a partial report says what it passed over.
- A task row naming an epic rather than the rows it consumes is a problem, as [Edges](#edges) states. That row still reaches the epic's rows, so a body carrying the retired form is reported once rather than taking its initiative's gates down with it.
- It reads a declared component without its link, a wrapping code span, a trailing full stop or a leading `./`, and reports a work item it cannot read.
- It reports a work item declaring a directory: a path ending in `/`, carrying a glob, or naming a directory under `<workspace>`.
- It prints the proposed [Epic Priority](#epic-priority) of each epic, largest first.
- Its supplied inputs are published body text or local drafts.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deps.py 'I=[**&lt;initiative-body-file&gt;**](#dependency-files)' '[**&lt;epic-id&gt;**](#dependency-files)=[**&lt;epic-body-file&gt;**](#dependency-files)' '[**&lt;epic-id&gt;**](#dependency-files):[**&lt;task-id&gt;**](#dependency-files)=[**&lt;work-item-file&gt;**](#dependency-files)' 'R=[**&lt;record-file&gt;**](#dependency-files)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deps.py I=/drafts/live-936.md E00=/drafts/live-943.md E01=/drafts/live-937.md E00:W01=/drafts/e00/w01.md E01:W01=/drafts/e01/w01.md R=/records/joins.md
</pre></big>

### Renumber Tasks

Renumbers one epic's tasks by the map given, in the files given.

**Inputs:** [Renumber Inputs](#renumber-inputs).

**Outputs:** [Rewritten Bodies](#rewritten-bodies).

#### 1. Renumber Tasks

Run the following command with the supplied inputs.

- `<task-number-map>` is a comma-separated list of `<old-number>:<new-number>` pairs. Pass each affected body file as a separate argument.

- It renumbers `<epic-id> Wxx` and `<epic-id>:Wxx` everywhere, and bare `Wxx` inside that epic's own body. **Example:** for `E01`, the qualified forms are `E01 Wxx` and `E01:Wxx`.
- The map assigns each old task number a distinct new number. A source absent from the files or a duplicate destination is refused.
- Append `--outside` followed by each explicitly authorized outside-initiative body file when supplied; only this initiative's prefixed references change there.
- Only rows no pull request names may be renumbered. Inspect the rewritten files before publishing them.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/renumber.py --initiative '[**&lt;initiative-number&gt;**](#renumber-inputs)' --epic '[**&lt;epic-number&gt;**](#renumber-inputs)' --own '[**&lt;epic-body-file&gt;**](#dependency-files)' --tasks '[**&lt;task-number-map&gt;**](#renumber-inputs)' '[**&lt;affected-body-file&gt;**](#renumber-inputs)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/renumber.py --initiative 07 --epic 1 --own live-937.md --tasks 7:3,3:5 live-*.md
</pre></big>

### Renumber Epics

Renumbers an initiative's epics across supplied body files.

**Inputs:** [Renumber Inputs](#renumber-inputs), [Pull Request Records](#pull-request-records).

**Outputs:** [Rewritten Bodies](#rewritten-bodies).

#### 1. Renumber Epics

Run the following command with the supplied inputs.

- The map is a comma-separated list of `<old-number>:<new-number>` pairs. Pass each body file as a separate argument; append `--outside` followed by each outside-initiative file when supplied.
- Files are rewritten in place. Outside files change only references carrying this initiative's prefix; links retain their targets. A source absent from the files, a collision or a number already named by a pull request is refused.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/renumber.py --initiative '[**&lt;initiative-number&gt;**](#renumber-inputs)' --prs '[**&lt;pull-request-records-file&gt;**](#pull-request-records)' --map '[**&lt;epic-number-map&gt;**](#renumber-inputs)' '[**&lt;body-file&gt;**](#renumber-inputs)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/renumber.py --initiative 07 --prs prs.json --map 6:0,0:1 live-936.md live-943.md
</pre></big>

## Fields

### Scope

One initiative, its epics and their task rows.

### Source

The initiative body and every epic body it links, published or as local drafts.

### Edges

A task edge names the producing row for each output the depending row consumes. An edge a task's prose implies is carried explicitly.

- **An edge names rows, never an epic.**
  A row naming an epic gates its task on every row of that epic, including the rows it consumes nothing from, which is how a [whole-epic edge](#whole-epic-edges) the rows do not justify reaches the initiative.
- **A task consuming from every row of an epic names the producing row for each output.**
  An edge another in the cell already implies is dropped, so a prerequisite chain is named by its last row, and the whole-epic reach is what the rows establish either way.
- **An edge to another epic's row waits for that row's outputs.**
  The dependent row starts once the producing row is delivered and its outputs are available at the dependent epic's base, as [Producer Outputs](delivery-branches.md#producer-outputs) states; the producing epic's other rows and its closure gate nothing.
- **An entry that cannot resolve is a permanent condition, not a prerequisite to come.**
  An entry naming no row and linking no issue, naming an issue the run was not given, or naming a row the epic it points to does not carry, cannot resolve. Every tool reading the cell names the entry as written, leaves the row where it stands rather than placing it as work still to come, and exits nonzero.

### Whole-Epic Edges

An initiative Depends on cell takes the epics it derives, as [Work Breakdown](initiative-issue-body.md#work-breakdown) states. It derives one only where every row of the dependent epic requires every row of the prerequisite, through the task edges alone: a task row names rows, so no cell can assert a whole epic that the rows do not already establish.

- **The edge is the coarsest gate the plan has.**
  It holds the dependent epic until the prerequisite closes, not until the row it consumes merges, and it drops the dependent a [priority](#epic-priority) number, so the board keeps it out of Ready while the prerequisite runs.
- **Its cost is why it is derived and never written.**
  A narrower dependency stays in the task graph, where it gates the row that consumes the output rather than the epic around it.

### Epic Priority

The map proposes one positive integer for each epic supplied, derived from the whole-epic edges and the components its rows declare. Epics sharing a number start together, so the number asserts they can run in parallel, and it holds a set only where both of these do.

- **Prerequisite depth establishes when an epic may start.**
  An epic with no prerequisite epic, one whose tasks are not yet written among them, carries the largest number, and each other epic takes one less than the smallest its prerequisites carry.
- **Component contention establishes whether it can.**
  An epic holding a row that contends with a row of an epic of the same depth takes the number below that depth, and the epics depending on it follow it down, as [Component Contention](#component-contention) states.

### Component Contention

Two task rows in different epics whose work items declare one [component](work-item.md#component) contend. Concurrent epics are two bases and two pull requests, so one component written from both is a merge conflict.

- Rows of one epic are out of scope: they land on one base, in the order Depends on and [Joins](#joins) set, so one component written twice is a rebase on that base rather than a conflict between two of them. [Joins](#joins) proposes them as one unit.
- A contending pair is answered by the number that separates its epics, or by moving the rows into one epic.

### Joins

The undelivered rows of one epic whose work items declare one [component](work-item.md#component) are a candidate unit: one pull request writes that file once, where separate ones each rebase on the last. Rows declaring different components need no accounting.

- **A joined unit has one lane.**
  Joined rows meet [Unit Consistency](lane.md#unit-consistency).
- **A candidate is answered once.**
  Its rows name each other in Joins, or one line of a record names exactly its rows and why they stay split. A line naming only some of its rows, or rows besides, accounts for none.
- **Both resolutions are stated where the candidate is reported.**
  Naming the rows in Joins asserts one pull request; the record line says why there are several. A report naming only the first makes the assertion the cheaper answer.
- **A direct edge inside a candidate is the edge a join drops.**
  The report names it, since the joined pull request orders the commits.
- **Some candidates are split by rule.**
  A candidate whose rows cover more than six criteria, or with a path between two of them through a row outside it, cannot join. The report names the reason, and no record line is asked for.

### Numbering Map

A comma-separated list of `<old-number>:<new-number>` pairs assigning each old number one distinct new number. A number a pull request already names is preserved, and a row a pull request names is not renumbered. A source absent from the supplied files, or a duplicate destination, is refused.

### Graph Inputs

The supplied initiative and epic bodies or local drafts, work-item files for tasks that have them, current pull request records, any confirmed numbering maps, caller allowance when present and explicitly authorized outside-initiative files.

### Dependency Files

The initiative body file, each epic id and body file, each task id and work-item file, and each record file accounting for split candidate units. Files are absolute paths.

### Renumber Inputs

The initiative number, epic number for task renumbering, owning epic body for task renumbering, confirmed numbering map and affected body files, with explicitly authorized outside-initiative files when supplied.

### Pull Request Records

The supplied current complete pull request records, one JSON object per nonempty line at the local file path.

### Graph Result

The checked bodies, proposed epic-priority map and unresolved dependency, numbering, component or lane findings, including the printed chains and contending pairs.

### Rewritten Bodies

The supplied bodies rewritten in place, with reported ranges and unresolved renumbering findings.

### Workspace

The absolute supplied checkout path holding the installed Work Planner scripts and sandbox helper.
```

## 014-initiative-recovery

Exit: 0; receipt: [014-initiative-recovery.json](receipts/014-initiative-recovery.json).

```sh
sed -n '253,295p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative-issue-body.md
```

Returned output:

```text

## Acceptance Criteria

- [ ] **AC1.** {{One invariant. It is specific, measurable, achievable, relevant, and time-bound. It carries no stale count. It names no initiative, epic, task, or issue. It states what the initiative achieves as a whole, and it ends by naming its instrument.}}

## Non-Goals

- {{One succinct sentence on what this initiative does not do. It names no initiative, epic, task or issue, and no owner.}}

## References

- **R1.** [{{Title}}]({{URL}}) — {{What the reader finds there.}}
- **R2.** **Source.** [{{Title}}]({{URL}}) — {{The requirements this initiative's criteria answer to.}}
````

### Titles

- The title is `[I07] Name: Subtitle`.
- Labels are `type:initiative` and a `theme:*`.
- `I` is the initiative number. Initiatives count from `00`.

### Problem

- A Problem meets [Problem and Proposal](issue-body.md#problem-and-proposal).

### Proposal

- A Proposal states the design, as [Problem and Proposal](issue-body.md#problem-and-proposal) defines.
- A Proposal names no epic, task, or acceptance criterion of its own initiative.

### Work Breakdown

The columns are `Epic | Description | Coverage | Depends on | Done`. The table has no Joins column.

- An epic row's id is the epic, linked to its issue: `[E01](…/issues/937)`.
- An epic row's Description is the epic's title name, and its Coverage names the initiative criteria the epic serves.
- An epic row is complete when its issue is closed as completed.
- An epic row whose issue is closed as not planned leaves the table. Each criterion only that row covers leaves with it, and a criterion another row also covers stays. The criteria that remain keep their [labels](issue-body.md#criterion-labels).
- Depends on names epics only. A cell that names a task fails. Name a prerequisite epic only when every task or joined unit in the dependent epic requires every task in that prerequisite epic, directly or through its dependencies. The consumed output and the work producing it establish that requirement. Dependencies on selected tasks remain in the task tables. An edge another named whole-epic prerequisite already implies is omitted.
- An initiative dependency that only some tasks need, or that requires only part of its prerequisite epic, is overbroad. The output and its producing tasks establish the edge.
- An epic depending on a later epic is a backward reference.
- Epic numbering meets [Numbering](issue-body.md#numbering).
```

## 015-initiative-recovery

Exit: 0; receipt: [015-initiative-recovery.json](receipts/015-initiative-recovery.json).

```sh
sed -n '296,322p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative-issue-body.md
```

Returned output:

```text
### Initiative Acceptance Criteria

An initiative criterion meets the [shared acceptance criteria](issue-body.md#shared-acceptance-criteria) and [Requirement Characteristics](../references/requirement-characteristics.md), and:

- **No counts.**
  An initiative criterion carries no counts or figures, which go stale: it measures against a named baseline or check ("against the baseline", "as the budget test measures it"). A figure stays only where it is the criterion's own target, such as a bound it holds to.
- **SMART.**
  Each initiative criterion is specific about what holds, measurable by a named check or baseline, achievable by the epics that cite it, and relevant, tracing to a clause and to the Problem. It is time-bound by a release tag or another named milestone outside the initiative's own work, where one exists, and otherwise by the epics that cite it.
- **Local.**
  An initiative criterion names no initiative, epic, task or issue, and is solution-agnostic. Coverage cells link epics to criteria. One that holds only through another initiative's work is restated as what this initiative achieves, or it is dropped.
- **Whole.**
  An initiative criterion states what the initiative achieves as a whole. One that restates a single epic's criterion is a duplicate: it is raised to what the epics achieve together, or left to the epic.
- **Verified.**
  - An initiative criterion ends by naming its instrument. Which instruments keep a criterion is [Verifiable](issue-body.md#verifiable).
  - An automated test is an end-to-end walk through the real server, a smoke run of an agent against a live server, a live check on a deployed host, or a guard, fixture suite or check that continuous integration runs. The walk, smoke run or live check is preferred where the criterion is about what a run does.
  - A named test that does not exist yet is work the plan holds: a task in the epic whose subject it tests, or a discrete test-infrastructure epic when the tests serve several criteria. That epic's row cites the criteria its tests verify.

### Non-Goals

- One succinct sentence each on what the initiative does not do, naming no initiative, epic, task or issue, and no owner.

### References

- A proposal-derived initiative identifies its originating proposal in References with the proposal's exact title and issue URL, labelled as the originating proposal.
- A reference the criteria answer to carries **Source.** after its label: `- **R1.** **Source.** [Title](url) — what it binds`. An unmarked reference is background, and binds no criterion. What a marked one requires of the criteria is [Sources](#sources).
- A cross-initiative overlap is recorded in References. An approved edit to another initiative's issue stays minimal.
- An initiative that removes a not-planned epic's row carries a reference linking the issue that takes that epic's work.
```

## 016-artifacts-lane.md

Exit: 0; receipt: [016-artifacts-lane.md.json](receipts/016-artifacts-lane.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/lane.md
```

Returned output:

```text
# Lane

A board-wide delivery lane, its task assignments and the units a request admits.

## Operations

### Read Task Lanes

Lane assignments and malformed-cell findings from supplied task tables.

**Inputs:** [Epic Body File](#epic-body-file).

**Outputs:** [Lane Result](#lane-result).

#### 1. Read Task Lane Cells

Apply [Read Lane Assignments](#read-lane-assignments) with the body file and return its row-to-index map and findings, meeting [Assignments](#assignments).

### Assign Task Lanes

A task table with confirmed lane assignments.

**Inputs:** [Epic Body File](#epic-body-file), [Confirmed Map](#confirmed-map), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body).

#### 1. Write Confirmed Lane Map

Apply [Write Lane Assignments](#write-lane-assignments) with the body, confirmed map and output path.
- Refuse unknown task ids or malformed resulting cells.

#### 2. Return Updated Body

Return the output body for the caller's full body and dependency validation.

### Check Unit Lanes

The common lane of a supplied work unit, or its assignment findings.

**Inputs:** [Epic Body File](#epic-body-file), [Unit Task Ids](#unit-task-ids).

**Outputs:** [Lane Result](#lane-result).

#### 1. Check Complete Unit Lane

Apply [Validate Lane Unit](#validate-lane-unit) with the body and unit ids and return the common index or findings, meeting [Unit Consistency](#unit-consistency).

### Determine Lane Admission

The lane decision for one free unit and current request.

**Inputs:** [Epic Body File](#epic-body-file), [Unit Task Ids](#unit-task-ids), [Requested Index](#requested-index).

**Outputs:** [Lane Result](#lane-result).

#### 1. Evaluate Requested Lane

Apply [Evaluate Lane Admission](#evaluate-lane-admission) with the body, unit ids and requested index and return its admitted flag and findings, meeting [Admission](#admission).

### Read Lane Assignments

Reads raw task-table Lane cells through the Lane module.

**Inputs:** [Epic Body File](#epic-body-file).

**Outputs:** [Lane Result](#lane-result).

#### 1. Read Lane Assignments

Run the following command with the supplied inputs.

<big><pre>
"[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 "[**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/lane.py" read '[**&lt;epic-body-file&gt;**](#epic-body-file)'
</pre></big>

### Write Lane Assignments

Writes confirmed assignments while preserving other body content.

**Inputs:** [Epic Body File](#epic-body-file), [Confirmed Map](#confirmed-map), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body).

#### 1. Write Lane Assignments

Run the following command with the supplied inputs.

<big><pre>
"[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 "[**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/lane.py" assign '[**&lt;epic-body-file&gt;**](#epic-body-file)' --map '[**&lt;confirmed-map-file&gt;**](#confirmed-map)' --out '[**&lt;output-body-path&gt;**](#output-body)'
</pre></big>

### Validate Lane Unit

Reports a unit's common lane or assignment findings.

**Inputs:** [Epic Body File](#epic-body-file), [Unit Task Ids](#unit-task-ids).

**Outputs:** [Lane Result](#lane-result).

#### 1. Validate Lane Unit

Run the following command with the supplied inputs.

<big><pre>
"[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 "[**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/lane.py" check '[**&lt;epic-body-file&gt;**](#epic-body-file)' --unit '[**&lt;task-ids&gt;**](#unit-task-ids)'
</pre></big>

### Evaluate Lane Admission

Reports whether the request admits a valid unit.

**Inputs:** [Epic Body File](#epic-body-file), [Unit Task Ids](#unit-task-ids), [Requested Index](#requested-index).

**Outputs:** [Lane Result](#lane-result).

#### 1. Evaluate Lane Admission

Run the following command with the supplied inputs.

Omit the lane option when the request supplies none.

<big><pre>
"[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 "[**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/lane.py" admit '[**&lt;epic-body-file&gt;**](#epic-body-file)' --unit '[**&lt;task-ids&gt;**](#unit-task-ids)' --lane '[**&lt;lane-index&gt;**](#requested-index)'
</pre></big>

## Fields

### Index

An index is an opaque board-wide decimal string. Its spelling is significant: `02` and `2` are distinct indices, and `0` is valid. The same index identifies one lane across the theme board.

### Assignments

Each task's Lane cell holds a bare [Index](#index), or is empty for an unlaned task. A populated cell's complete content is the index. Raw cells supply assignments independently of work-item links. Malformed cells supply findings and no assignment; a missing Lane column supplies no lane data.

### Unit Consistency

Every member of a unit carries the same index, or every member is unlaned. Missing assignments and differing values are findings. A differing assignment requires changing the row lanes or unjoining the rows.

### Admission

A request naming an index admits free units with that index and unlaned units. A request naming none admits only unlaned units. Malformed or inconsistent assignments admit no unit. Availability and priority are supplied by the caller; lane admission applies to free units and leaves other findings visible. A unit without task rows is unlaned.

### Report Label

A populated index is reported as `lane 2`, preserving its spelling; an unlaned unit is reported as `unlaned`.

### Epic Body File

The local file containing the supplied complete epic body text.

### Confirmed Map

The local JSON object keyed by task id, with decimal-string indices or `null` for unlaned rows.

### Output Body

The supplied local output path and resulting epic body. The output is absent until written.

### Unit Task Ids

The complete supplied unit task ids as a comma-separated list.

### Requested Index

The optional lane index named by the request; absence selects an unlaned request.

### Lane Result

The row-to-index map, common unit index or admitted flag selected by the operation, with its assignment findings.

### Workspace

The absolute supplied checkout path holding the installed Work Planner scripts and sandbox helper.
```

## 016-artifacts-planning-record.md

Exit: 0; receipt: [016-artifacts-planning-record.md.json](receipts/016-artifacts-planning-record.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/planning-record.md
```

Returned output:

```text
# Planning Record

A planning record is a folder. README.md is its entry point: it answers what the work is, and links to every other artifact the plan produces. Each artifact is the home of its own content. The progress of the work is the theme's project board.

## Prerequisites

Read these files first.

- [Planning Records Configuration](../configuration.md#planning-records)

## Operations

### Populate Planning Record

One planning directory and its artifact inventory.

**Inputs:** [Record Selection](#record-selection).

**Outputs:** [Planning Folder](#planning-folder).

#### 1. Prepare Selected Record

Prepare the selected record using the matching branch.

##### New Record

Apply [Add Planning Record](#add-planning-record) with the engineering checkout and supplied planning-folder path.
- Populate README.md from the [Template](#template).

##### Existing Record

Read its README, retaining its creation date, other artifacts and links.
- Update only the supplied content.

##### Common Record Conditions

The folder must meet [Layout](#layout).
- All populated README fields must meet [Fields](#fields).

#### 2. Register Supplied Artifacts

Register the artifact files supplied by the caller, using their chosen names.
- Each file must have a row meeting [Layout](#layout) and [Artifacts](#artifacts).
- File content remains supplied by the caller; this operation does not author that artifact's content.

### Publish Planning Record

The record's folder committed and pushed, so every link into it resolves for a reader.

**Inputs:** [Planning Folder](#planning-folder), [Commit Message File](#commit-message-file).

**Outputs:** [Publication Result](#publication-result).

#### 1. Find Engineering Checkout

Apply [Find Engineering Worktree](#find-engineering-worktree) for the path the record is written on.

#### 2. Publish Planning Files

Apply [Commit Planning Record](#commit-planning-record).
- Confirm the files this record wrote reached `origin/engineering`, meeting [Shared Worktree](#shared-worktree).
- Report a rebase that stops on a conflict rather than rewriting the branch.

### Find Engineering Worktree

Prints the checkout holding the engineering branch, which is where every planning record is written.

**Inputs:** [Project Checkout](#project-checkout).

**Outputs:** [Engineering Worktree](#engineering-worktree).

#### 1. Find Engineering Worktree

Run the following command with the supplied inputs.

- The engineering branch has one long-lived worktree and takes no further one.

<big><pre>
git -C '[**&lt;checkout&gt;**](#project-checkout)' worktree list | grep '\&#91;engineering\&#93;'
</pre></big>

### Commit Planning Record

Commits everything pending in the engineering worktree and publishes the branch, so every record's links resolve.

**Inputs:** [Engineering Worktree](#engineering-worktree), [Commit Message File](#commit-message-file).

**Outputs:** [Publication Result](#publication-result).

#### 1. Commit Planning Record

Run the following command with the supplied inputs.

- It stages the whole worktree, commits only when anything is staged, rebases on `origin/engineering` and pushes. A run with nothing new leaves the branch unchanged, so any session runs it at any time. See [Shared Worktree](#shared-worktree).
- Planning records go straight to the branch; they take no pull request.
- Pass the message through a file outside the worktree; the worktree is a linked one, so git writes here run unsandboxed.

<big><pre>
cd '[**&lt;engineering-worktree&gt;**](#engineering-worktree)' && git add -A && (git diff --cached --quiet || git commit -F '[**&lt;message-file&gt;**](#commit-message-file)') && git fetch origin engineering && git rebase origin/engineering && git push
</pre></big>

**Example:**

<big><pre>
cd .engineering && git add -A && (git diff --cached --quiet || git commit -F /tmp/msg.txt) && git fetch origin engineering && git rebase origin/engineering && git push
</pre></big>

### Add Planning Record

Adds the folder for one planning record on the long-lived engineering worktree.

**Inputs:** [Engineering Worktree](#engineering-worktree), [Planning Folder](#planning-folder).

**Outputs:** [Planning Folder](#planning-folder).

#### 1. Add Planning Record

Run the following command with the supplied inputs.

- `<planning-folder-path>` is `<yyyy-mm-dd>[-<ref>]-<slug>/` under the [configured planning directory](../configuration.md#planning-records). The date is the day the record is opened.
- `<ref>` is the bare number of the issue or the pull request the record is for. A record for ad hoc work, which has neither, has no ref segment.
- The slug is lowercase words separated by hyphens, a short name of the work.
- The folder's files are the [planning layout](planning-record.md#layout).
- Edits are made on that worktree. The engineering branch takes no further worktree and no branch.

<big><pre>
mkdir -p '[**&lt;planning-folder-path&gt;**](#planning-folder)'
</pre></big>

**Example:**

<big><pre>
mkdir -p artifacts/planning/2026-10-15-950-queue-plan
</pre></big>

## Fields

### Template

```markdown
# [Descriptive name] — [Month Year]

> [Classifier] · Created [YYYY-MM-DD]

## Executive Summary

[Two paragraphs on the purpose of this work and why it matters.]

## Artifacts

| Artifact | What it holds |
| --- | --- |
| [Name](file.md) | What this artifact holds |

## Links

| Resource | Link |
| --- | --- |
| [External reference] | [link] |
```

### Shared Worktree

The engineering branch has one worktree and every session writes its records there, so they share one index. A commit on engineering may include other sessions' uncommitted or unpushed work, a `design.md` amendment among them. A session confirms only that its own files reached `origin/engineering` after the push.

### Layout

README.md is the one file the folder must hold. Any file beyond README.md is added as the work needs it.

```text
./
├── README.md
└── …
```

Each file beyond README.md is a row in the README's Artifacts.

A plan's draft issue bodies and its work items are files of its record. Each draft is the source every later edit and save of its issue reads, and it reaches readers through [Publish Planning Record](#publish-planning-record).

### Header

One blockquote: the classifier, the day the record was created, and a revised date when the README is updated after the work is done.

### Executive Summary

Two paragraphs: the purpose of this work, and why it matters.

### Artifacts

- One row for every artifact in the record other than README.md, added when the file is produced.
- The link sits on the artifact's name. The row says what the artifact holds, and the artifact is the home of that content.

### Links

External references only: a tracker issue, a parent epic, a pull request. An artifact of this plan is an Artifacts row.

### Record Selection

The supplied record identity, folder path, artifact files and external links.

### Planning Folder

The supplied folder path and its registered artifact files, meeting [Layout](#layout). A new folder is absent until created.

### Engineering Worktree

The checkout holding the engineering branch, as an absolute path.

### Project Checkout

Any supplied checkout of the project.

### Commit Message File

The supplied local file holding the exact commit message.

### Publication Result

The published planning files and confirmed remote branch, or a stopped publication with its conflict or other blocker.
```

## 016-artifacts-repository-labels.md

Exit: 0; receipt: [016-artifacts-repository-labels.md.json](receipts/016-artifacts-repository-labels.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/repository-labels.md
```

Returned output:

```text
# Repository Labels

The labels available for issue metadata in one repository.

## Operations

### Ensure Repository Labels

The required label definitions available for issue publication.

**Inputs:** [Repository](#repository), [Label Identity](#label-identity).

**Outputs:** [Label Identity](#label-identity).

#### 1. Read Repository Labels

Apply [List Labels](#list-labels) for the repository.

#### 2. Compare Required Names

Compare the returned labels with the supplied required names.

#### 3. Create Missing Labels

Apply [Create Label](#create-label) for each absent required definition.

#### 4. Return Available Labels

Return the available labels; an unknown definition is a finding for the caller to resolve before publication.

### List Labels

Lists the labels that exist in the repository.

**Inputs:** [Repository](#repository).

**Outputs:** [Label Identity](#label-identity).

#### 1. List Labels

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/labels?per_page=100" --jq '.&#91;&#93;.name'
</pre></big>

### Create Label

Creates the label specified by its name, colour and description.

**Inputs:** [Repository](#repository), [Label Identity](#label-identity).

**Outputs:** [Label Identity](#label-identity).

#### 1. Create Label

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/labels' -f name='[**&lt;label&gt;**](#label-identity)' -f color='[**&lt;hex-colour&gt;**](#label-identity)' -f description='[**&lt;description&gt;**](#label-identity)' --jq .name
</pre></big>

## Fields

### Label Identity

Each label has a name, colour and description. Issue assignments use labels that exist in the repository.

### Repository

The supplied repository owner and name.
```

## 016-artifacts-review-finding.md

Exit: 0; receipt: [016-artifacts-review-finding.md.json](receipts/016-artifacts-review-finding.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/review-finding.md
```

Returned output:

```text
# Review Finding

One evidenced problem and its proposed solution.

## Operations

### Populate Review Finding

One finding verified against its supplied source.

**Inputs:** [Finding Evidence](#finding-evidence).

**Outputs:** [Finding Result](#finding-result).

#### 1. Verify Supplied Problem

Verify the problem against the supplied source.

#### 2. Return Evidence Gaps

If evidence is missing or contradictory, return that finding for the caller to resolve.

#### 3. Populate Verified Finding

Populate the finding with its source quotation.
- It must meet [Finding Content](#finding-content) and [Decision State](#decision-state).

#### 4. Return Finding Decision

Return the finding and any pending decision.

### Report Review Finding

The verified findings presented for resolution.

**Inputs:** [Finding Set](#finding-set).

**Outputs:** [Finding Result](#finding-result).

#### 1. Populate Verified Findings

Apply [Populate Review Finding](#populate-review-finding) with the area, severity, problem, solution and source evidence.
- Resolve any evidence gap before reporting it.
- Group the returned findings by area.

#### 2. Resolve Pending Decisions

Put each pending decision to the user, one question at a time.
- Wait for the answer.
- Record the confirmed answer on the finding, meeting [Decision State](#decision-state).
- Return each confirmed resolution to the caller for application to its selected issue kind. A pending decision returns without applying a change.

## Fields

### Finding Content

Each finding has an area, severity, one problem/solution pair and a source quotation with file and line. The source establishes the stated problem. Findings are grouped by area when presented together.

### Decision State

A finding identifies whether it needs a user decision and records any supplied answer. An unanswered decision remains pending.

### Finding Evidence

The supplied area, severity, problem, proposed solution, source text and file:line, decision requirement and any confirmed answer.

### Finding Set

The supplied findings with their area, severity, problem, proposed solution and source evidence.

### Finding Result

The verified findings and their confirmed resolutions or pending decisions, retaining evidence gaps.
```

## 016-artifacts-work-item.md

Exit: 0; receipt: [016-artifacts-work-item.md.json](receipts/016-artifacts-work-item.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/work-item.md
```

Returned output:

```text
# Work Item

The local plan for one task's work.

## Prerequisites

Read these files first.

- [Issue Body](issue-body.md)
- [Pull Request Body](pull-request-body.md)
- [Delivery Branches](delivery-branches.md)

## Operations

### Populate Work Item

One task's local implementation plan.

**Inputs:** [Task Context](#task-context), [Work Item File](#work-item-file).

**Outputs:** [Work Item File](#work-item-file).

#### 1. Populate Work Item File

Write the supplied task's file from [Template](#template), returning its path for registration in the planning record.
- Its name and content must meet [Identity](#identity) and [Sections](#sections).
- The supplied component must meet [Component](#component).
- The test row must meet [Test Coverage](pull-request-body.md#test-coverage), using the supplied criteria without copying them into the file.

## Fields

### Template

````markdown
**Component:** {{The long-lived branch and path of the one component this task's implementation extends}}

## Overview

{{What this task delivers and why.}}

## Problem

{{The present friction.}}

## Proposal

{{The scene, then the design. Lists of distinct items use bullets.}}

## Work Breakdown

| Part | Description |
| --- | --- |
| Analysis | {{The evidence to gather}} |
| Plan | {{The decisions and design}} |
| Implementation | {{The work to perform}} |
| Review | {{The review of that work}} |
| Test | {{The checks required by the work, including the project's system test when applicable}} |
````

### Identity

One file per task, named for its id in lowercase, such as `w01.md`: the name the epic row's link carries once its reservation is released. The record's README links each file by that name, and releasing the row refuses a record that does not hold it. The file names no other task and carries no acceptance criteria, Coverage, dependency or Joins; those belong to the epic table.

### Component

One declaration line ahead of the first heading, naming the single component the Implementation part extends as `<long-lived branch>:<path>`: the [long-lived branch](delivery-branches.md#branches) that holds it and the path to it there, such as `workspace:skills/work-planner/scripts/deliver.py`.

- A task that creates the component names the path it creates.
- The long-lived branch decides which of an epic's bases the task's unit changes, as [Task Branches](delivery-branches.md#task-branches) states.
- A task whose implementation extends more than one component is split into a task for each.
- A component is one file, never a directory, since the dependency check groups an epic's rows into candidate units by it.

### Sections

- Component names the component the Implementation part extends, meeting [Component](#component).
- Overview states what the task delivers and why.
- Problem and Proposal meet [Problem and Proposal](issue-body.md#problem-and-proposal); the Proposal starts with the scene.
- Work Breakdown decomposes the work into parts, such as analysis, plan, implementation, review and test. Its columns are Part and Description. The test row names the checks required by the work.

### Task Context

The supplied task id and scope, epic context, design, component, criteria and test requirements.

### Work Item File

The supplied local output path and the populated work item at that path. The file is absent until populated.
```

## 016-modes-propose-mode.md

Exit: 0; receipt: [016-modes-propose-mode.md.json](receipts/016-modes-propose-mode.md.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/propose-mode.md
```

Returned output:

```text
# Propose Mode

Scopes one problem: the friction, the evidence, and the boundary, and states the goal as clauses the user confirms. It raises one proposal on the proposals board.

**Runs in:** the project checkout.

Follow the [Procedure](#procedure), adhering to [Rules](../rules.md) and [Conventions](../conventions.md) and ensure all [Outcomes](#outcomes) are met.

## Prerequisites

Read these files first.

- [Proposal Body](../artifacts/proposal-body.md)
- [Repository Labels](../artifacts/repository-labels.md)
- [Issue](../artifacts/issue.md)
- [Board](../artifacts/board.md)

## Procedure

### 1. Understand the Problem

Ask the user until the friction and the boundary are clear.

- State the goal back as clauses meeting [Goal](../artifacts/proposal-body.md#goal).
- Have the user confirm those clauses.

### 2. Gather Evidence

- Measure the current state: counts, paths, and file:line.
- Delegate broad sweeps to parallel sub-agents.
- Spot-check what they return before recording it.

### 3. Draft the Body

Apply [Populate Proposal Body](../artifacts/proposal-body.md#populate-proposal-body) with the confirmed problem, evidence, goal clauses, boundary and output body path. The local file is the source for the issue.

- Apply [Select Tracker Number](../artifacts/issue.md#select-tracker-number) with the proposal prefix letter, and carry the returned proposal number in the title.
- The goal clauses are the clauses the user confirmed. The Non-Goals are the boundary.
- The design, the acceptance criteria, and the breakdown belong to a later goal.

### 4. Validate

Apply [Validate Proposal Body](../artifacts/proposal-body.md#validate-proposal-body) with the draft issue JSON and output file.

- Resolve each finding.
- Update the draft.
- Apply [Validate Proposal Body](../artifacts/proposal-body.md#validate-proposal-body) again with the revised JSON and the same output path. Proceed to publication only when validation passes.

### 5. Publish

Apply [Ensure Repository Labels](../artifacts/repository-labels.md#ensure-repository-labels) with the proposal's required label definitions.

- Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with the validated body, title and labels, leaving it unassigned.

### 6. Confirm Placement

Ask whether to add the issue to the proposals board.

- On acceptance, continue to the place step.
- On a decline, skip placement and continue to the report step with the issue URL.
- Wait for an unanswered decision.

### 7. Place

Apply [Locate Project Board](../artifacts/board.md#locate-project-board) for proposals.

- For an absent board, Apply [Create Proposals Board](../artifacts/board.md#create-proposals-board).
- Apply [Read Tracker Issue](../artifacts/issue.md#read-tracker-issue) for the saved issue id.
- Apply [Place Issue on Board](../artifacts/board.md#place-issue-on-board) with that id and initial status Suggested.
- Leave the issue unassigned.

### 8. Report

Give the issue's URL, and the board's when the issue was placed.

## Outcomes

- **A scoped problem.**
  The user has one problem scoped, and has confirmed its goal.
- **One proposal.**
  The user has that problem raised as one proposal.
- **On the proposals board.**
  When the user wants the proposal on the proposals board, it is there, raised, and unassigned.
```

## 017-issue-body

Exit: 0; receipt: [017-issue-body.json](receipts/017-issue-body.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue-body.md
```

Returned output:

```text
# Issue Body

The shape every issue body shares: its title, its Problem and Proposal, its acceptance criteria, and its work-breakdown table.

## Prerequisites

Read these files first.

- [Requirement Characteristics](../references/requirement-characteristics.md)
- [Issue](issue.md)

## Operations

### Write Issue Table

The shared table, before a kind fills its cells.

**Inputs:** [Body Evidence](#body-evidence), [Kind Conditions](#kind-conditions), [Row Data](#row-data).

**Outputs:** [Body Evidence](#body-evidence).

#### 1. Populate Shared Cells

Populate the shared Done, Coverage and Depends on cells from the supplied row data.
- The columns must match the kind's table.
- The shared cells must meet [Tables](#tables).

#### 2. Check Finished Table

Read the finished table against [Tables](#tables), [Numbering](#numbering), and [Reference form](#reference-form).

### Check Round of Edits

The shared check after a round of edits.

**Inputs:** [Changed Bodies](#changed-bodies), [Kind Conditions](#kind-conditions), [Output Files](#output-files).

**Outputs:** [Format Findings](#format-findings).

#### 1. Check Kind Conditions

Check each section of the issue against the field conditions for its kind and against [Fields](#fields) in this file.

#### 2. Run Body Format

Apply [Check Body Format](#check-body-format) on every issue the round changed.

### Validate Issue Body

One body checked against its supplied kind and template.

**Inputs:** [Body Record](#body-record), [Kind Conditions](#kind-conditions), [Output Files](#output-files).

**Outputs:** [Format Findings](#format-findings).

#### 1. Run Body Format

Apply [Check Body Format](#check-body-format) with the supplied issue JSON, kind inputs and output file as `--fix`.

#### 2. Review Supplied Conditions

Review the body against the supplied field conditions.

#### 3. Return Format Findings

Return the [Format Findings](#format-findings).

### Apply Body Corrections

One body rewritten from confirmed local findings.

**Inputs:** [Body Evidence](#body-evidence), [Kind Conditions](#kind-conditions), [Confirmed Corrections](#confirmed-corrections), [Output Files](#output-files).

**Outputs:** [Body Evidence](#body-evidence), [Format Findings](#format-findings).

#### 1. Populate Missing Sections

Populate missing sections from the supplied issue and related context.

#### 2. Apply Confirmed Decisions

Apply each confirmed decision to keep, fold or remove an extra section, and rewrite a wrong-kind body in the selected template.

#### 3. Record Kind Changes

Record a required tracker-kind change for the caller.

#### 4. State Current Design

Restate historical narration as the current design.

#### 5. Apply Criterion Changes

Apply confirmed criterion changes.
- The body must meet [Body](#body), [Shared Acceptance Criteria](#shared-acceptance-criteria) and the supplied kind conditions.

#### 6. Validate Corrected Body

Apply [Validate Issue Body](#validate-issue-body) with the corrected body and supplied validation inputs.

#### 7. Return Corrected File

Return the corrected file, validation findings and any required cross-body or metadata changes for the caller.

### Build Body Snapshot

A local issue-shaped record for body validation.

**Inputs:** [Body Evidence](#body-evidence), [Snapshot Metadata](#snapshot-metadata), [Output Files](#output-files).

**Outputs:** [Body Snapshot](#body-snapshot).

#### 1. Write Body Snapshot

Write the supplied body, title, labels and optional existing issue evidence to the destination in the [Body Snapshot](#body-snapshot) shape.

#### 2. Return Snapshot Path

Return the JSON path for validation. No tracker issue is created by this operation.

### Repair Issue Format

The saved format corrections for one issue and any unresolved content findings.

**Inputs:** [Body Record](#body-record), [Kind Conditions](#kind-conditions), [Output Files](#output-files).

**Outputs:** [Body Evidence](#body-evidence), [Format Findings](#format-findings).

#### 1. Validate Current Body

Apply [Validate Issue Body](#validate-issue-body) with the supplied JSON, kind conditions, related evidence and output path.
- Return an unreadable source as a blocker before editing.

#### 2. Review Mechanical Changes

Review the returned diff.
- For wording-preserving format, title and label corrections, Apply [Save Tracker Issue](issue.md#save-tracker-issue) without asking.
- Retain content decisions and cross-body findings separately; do not publish them as mechanical fixes.

#### 3. Resolve Local Content

Resolve a non-mechanical finding confined to this body.
- Obtain the user's decision.
- Apply [Apply Body Corrections](#apply-body-corrections) with the current body, kind template and conditions, related context, confirmed resolution and output path.
- Publish through Save Tracker Issue. An unanswered decision or a finding requiring changes to other issues returns to the caller as a blocker.

#### 4. Validate Saved Body

Apply [Read Tracker Issue](issue.md#read-tracker-issue) for the saved issue.
- Apply [Validate Issue Body](#validate-issue-body) again with the saved JSON and the same kind conditions, context and output path.
- Return the saved body, whether a correction was made, and the validation result to the caller. A remaining failure is a blocker.

### Check Reference Visibility

Repository visibility for the destination issue and its References entries.

**Inputs:** [Body Record](#body-record), [Output Files](#output-files).

**Outputs:** [Visibility Findings](#visibility-findings).

#### 1. Identify Reference Repositories

Apply [List Reference Repositories](#list-reference-repositories) to identify the destination and cited repositories.

#### 2. Fetch Repository Visibility

Apply [Fetch Reference Repository](#fetch-reference-repository) for each returned name; collect the returned objects into a JSON array at the snapshot path. Retain failed fetches as unresolved visibility, never as public visibility.

#### 3. Validate Reference Snapshot

Apply [Validate Reference Visibility](#validate-reference-visibility) with that snapshot and the issue record.

#### 4. Return Visibility Findings

Return each private reference on a public issue and each unavailable visibility as a finding. A private destination has no public-reference restriction; deciding how to replace or remove a private reference belongs to the caller.

### Check Body Format

Checks one issue against its template, and with `--fix` writes the body with the mechanical fixes made.

**Inputs:** [Body Record](#body-record), [Kind Conditions](#kind-conditions), [Output Files](#output-files).

**Outputs:** [Format Findings](#format-findings).

#### 1. Check Body Format

Run this command from the workspace checkout with the supplied inputs.

- The format reader takes the template fence from the body artifact and its table columns where present. A body with a Work Breakdown table requires coverage for every criterion.
- The input is one issue JSON. `--fix` names the output body file for mechanical fixes. Further inputs are specified by the calling body procedure.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/format.py '[**&lt;issue-json-file&gt;**](#body-record)' --fix '[**&lt;output-body-file&gt;**](#output-files)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/format.py issue.json --fix fixed.md
</pre></big>

### List Reference Repositories

List repository names from the issue destination and References section.

**Inputs:** [Body Record](#body-record).

**Outputs:** [Reference Repositories](#reference-repositories).

#### 1. List Reference Repositories

Run this command from the workspace checkout with the supplied inputs.

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py repositories '[**&lt;issue-json-file&gt;**](#body-record)'
</pre></big>

**Example:**

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py repositories issue-943.json
</pre></big>

### Fetch Reference Repository

Read one listed repository's visibility with the authenticated repository API.

**Inputs:** [Reference Repositories](#reference-repositories), [Output Files](#output-files).

**Outputs:** [Repository Snapshot](#repository-snapshot).

#### 1. Fetch Reference Repository

Run this command from the repository checkout with the supplied inputs.

- Save each object with its `full_name` and `private` fields; combine the objects into the caller's JSON array. A failed fetch supplies no visibility.

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#reference-repositories)/[**&lt;repo&gt;**](#reference-repositories)' > '[**&lt;repository-json-file&gt;**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api repos/{owner}/{repo} > repository.json
</pre></big>

### Validate Reference Visibility

Report private repository references on a public issue and unresolved repository visibility.

**Inputs:** [Body Record](#body-record), [Repository Snapshot](#repository-snapshot).

**Outputs:** [Visibility Findings](#visibility-findings).

#### 1. Validate Reference Visibility

Run this command from the workspace checkout with the supplied inputs.

- The snapshot is a JSON array of fetched repository objects. Exit 1 means findings remain.

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py references '[**&lt;issue-json-file&gt;**](#body-record)' --repositories '[**&lt;repositories-json-file&gt;**](#repository-snapshot)'
</pre></big>

**Example:**

<big><pre>
[**&lt;workspace&gt;**](#workspace)/scripts/sbx python3 [**&lt;workspace&gt;**](#workspace)/skills/work-planner/scripts/align.py references issue-943.json --repositories repositories.json
</pre></big>

## Fields

### Titles

- **Titles.**
  - A title is a short name, a colon, and a subtitle stating the outcome.
  - The name is two or three words and the subtitle a succinct summary of at most ten, in title case.
  - A prefixed title separates its levels with colons, then the name.
- **Bodies.**
  - Every body keeps the section order of its kind template and the columns of that kind's table.
  - Fill each `{{…}}` and delete a section the template marks as optional when it has nothing to say.
- **Code references.**
  A body references code as a link on the words it supports, a permalink pinned to a commit with its line anchors, never a bare `path:line`: `the [extrinsic type](…/blob/<sha>/runtime/src/lib.rs#L1231-L1232)`.
- **Succinct items.**
  Each Problem and Proposal item, and each of its sub-bullets, is at most two lines. A bold opener does not count toward the two. Several distinct points go in a bulleted list, never packed into those two lines.
- **Bold leads.**
  - A Problem or Proposal item that opens with a bold statement puts its body on the next line, indented under the bullet:

    ```markdown
    - **Length is the only check on entry.**
      The data source decodes the key and never checks its value.
    ```

  - A bulleted item with sub-bullets keeps the line introducing them on its bold statement's line:

    ```markdown
    - **Framing is undocumented.** Nothing describes:
      - the runtime's extrinsic type;
    ```
- **Labels.**
  - Add `enhancement`, `bug` and `tech-debt` as they apply.
  - **Example.**  workflow-server adds `workflows`.
  - Only labels that exist are applied.

### Problem and Proposal

- **Friction.**
  A Problem states the friction as it is now. Its evidence is a count or a code link for that friction. A Problem does not describe the plan.
- **Plan ids.**
  A Problem or Proposal names no epic, task or acceptance criterion of its own initiative. The Work Breakdown table holds those references; a sibling boundary is plain language.
- **Evidence that may be cited.**
  Code, a merged pull request, and an issue outside this initiative may be cited.

### Shared Acceptance Criteria

An acceptance criterion meets these. A kind adds its own under its Acceptance Criteria.

- States an end state, not an activity.
- Names or implies the instrument that observes it: a test, a guard, a command or a measure.
- Is unambiguous, so two readers agree on whether it holds.
- Meets [Requirement Characteristics](../references/requirement-characteristics.md).
- **One invariant.**
  Each criterion states a single condition that holds or does not. One joining several is split, and the Coverage cells cite the new ones. A condition over a list of subjects is one condition.

#### Criterion Labels

Criteria are labelled `AC1` onward, in ascending order. A criterion that leaves a body takes its label with it, and the criteria that remain keep theirs, since other work cites them, so the labels may ascend with a gap.

#### Verifiable

- Subjective wording is an observable pass or fail, or the criterion is absent.
- A fact that inspection, analysis, demonstration, or test can check is kept, such as every option having a description.
- A judgment about meaning, such as a claim that a description states what choosing means, is subjective wording.
- An item none of those methods can observe is named as [Coverage Reports](#coverage-reports) define, and it stays named there.

### Tables

- **Done.**
  The last column. Its cell is empty while the row is open, and a tick, ✓, when the row is complete.
- **Description.**
  A short phrase naming what the row delivers, at most eight words, with no list, semicolon or detail.
- **Coverage.**
  The acceptance criteria the row delivers, `AC2, AC5`, and nothing else. Every criterion is delivered by at least one row.
- **Depends on.**
  References only, with no prose, and only what no other entry in the cell already implies.

### Numbering

Rows are numbered in the order they can start, so every dependency points to an earlier row. Numbering that does not follow start order is advisory.

Work a pull request names keeps its number. Renumbering touches only a row no pull request names.

### Reference Form

Tables write references with colons, the form the scripts read. Prose uses a space.

### Body

- **Stale references.**
  A row number, issue link or decision wording agrees with the current plan.
- **Body.**
  A body states the plan as it is. It carries no change narrative. How the plan evolved belongs in the planning record and in commit and pull request bodies.

### Stale References

Task and epic numbers, issue links and wording must agree with the current decisions and bodies. References to superseded decisions are findings.

### References

An issue's References section does not link issues or pull requests on the same board. A public issue's References cite public repositories; unavailable visibility is unresolved.

### Coverage Reports

- **Unobservable items.**
  An item a test cannot observe is named in the plan or the coverage report. It stays in the report.
- **The check matches the criterion.**
  - A file or string check counts as coverage only when the criterion is a fact about that file.
  - A criterion about a run is covered by a run that shows it.
- **The specified set.**
  A coverage report lists every acceptance criterion the work under review is specified to cover.

### Format Findings

- **Fixed.**
  Structural changes preserve the wording and are present in the returned body file, with a body diff.
- **Apply.** Title or label changes for the caller to publish on the issue.
- **Decide.** Missing content or a judgement for the caller to resolve.

### Body Evidence

The supplied complete current issue body, held as text or at a local body-file path.

### Kind Conditions

The supplied kind template, table columns, field conditions and additional format inputs. Related evidence required by that kind accompanies the body.

### Row Data

The supplied row data for the kind's shared table cells.

### Changed Bodies

Every changed body's issue-shaped JSON record, with its kind conditions and format inputs.

### Confirmed Corrections

The confirmed local resolutions, criterion changes and selected decisions to keep, fold or remove extra sections, with the related context needed to populate them.

### Output Files

The supplied local destinations for a corrected complete body, a body-snapshot JSON record or repository visibility evidence.

### Body Snapshot

A local issue-shaped JSON record retaining the body's exact text, title and labels, plus the existing issue's identity and state when supplied. An unpublished draft uses `number: null` and `state: "open"`; labels are strings or objects with a name.

### Reference Repositories

The destination repository and the repositories cited in References, identified by owner and name.

### Repository Snapshot

The supplied JSON array of fetched repository objects, each retaining full_name and private.

### Visibility Findings

Findings carrying the issue identity, cited repository identities and their observed visibility or missing evidence.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.

### Body Record

The complete current issue-shaped JSON record: a saved tracker issue record, or a local [Body Snapshot](#body-snapshot) for an unpublished draft.

### Snapshot Metadata

The supplied title and labels for the body, with the existing issue JSON when its identity and state are available.
```

## 018-initiative-capture

Exit: 0; receipt: [018-initiative-capture.json](receipts/018-initiative-capture.json).

```sh
jq -r '.title,.body' /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json
```

Returned output:

```text
[I17] Cutover Readiness: Every Known Skill Fix Lands Before the Extraction
## Overview

Every Work Planner skill fix found before the skill leaves workflow-server is merged into workflow-server's `workspace` branch before the skill's extraction is cut, so the repository the skill moves to starts with every known fix. The goal the reviews test against: each fix found before the cutover is delivered in workflow-server ahead of the extraction, and the extraction carries it.

## Problem

Faults found in the skill before its move have no plan that the move respects.

- **A late fix misses the move.**
  The skill is extracted to prosiform-skills with its content unchanged, so a fix merged into `workspace` after the extraction reaches only the copy workflow-server drops.
- **Known faults are open.**
  Closing the skill's own initiative exposed faults in [Plan Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L42-L43), the [format check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/format.py#L1024-L1025), [board sync](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board.py#L578-L582) and the [pull request fetch](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L523-L539).

## Proposal

- **Fixes land in workflow-server first.**
  Each fix is a task row, merged into `workspace` through its epic base as any delivery is.
- **The extraction waits for the fixes.**
  I16's row that extracts the skill names these fixes as its prerequisite, so the extraction is cut from a `workspace` commit holding every one.
- **Faults found later join the plan.**
  A fault found before the extraction becomes a further task row, delivered ahead of the extraction like the rest.
- **A feature the skill must carry joins too.**
  A feature a workspace needs before the extraction, such as delivery lanes, is an epic of this initiative and lands ahead of the extraction as a fix does.

## Work Breakdown

| Epic | Description | Coverage | Depends on | Done |
| --- | --- | --- | --- | --- |
| [E00](https://github.com/m2ux/workflow-server/issues/1598) | Pre-Cutover Fixes | AC1 | | ✓ |
| [E01](https://github.com/m2ux/workflow-server/issues/1616) | Skill Style | AC1 | | |
| [E02](https://github.com/m2ux/workflow-server/issues/1615) | Skill Separation | AC1 | [E01](https://github.com/m2ux/workflow-server/issues/1616) | |
| [E03](https://github.com/m2ux/workflow-server/issues/1625) | Delivery Lanes | AC1 | | ✓ |

## Acceptance Criteria

- [ ] **AC1.** Every Work Planner fix and feature planned here is in the history of the workflow-server `workspace` commit the skill's extraction is cut from, as `git merge-base --is-ancestor` shows for each one's merge commit.

## Non-Goals

- It does not change the skill's layout, script paths or priority source, which the move to the new repository settles.
- It does not fix a fault found after the extraction is cut.

## References

- **R1.** [I16 Work Planner Home](https://github.com/m2ux/prosiform-skills/issues/1) — the skill's move to prosiform-skills, whose extraction waits for these fixes.
- **R2.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
- **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner) — the skill the fixes change.
```

## 019-epic-capture

Exit: 0; receipt: [019-epic-capture.json](receipts/019-epic-capture.json).

```sh
jq -r '.title,.body' /tmp/i17-e01-w06/final-package/inputs/epic-1616.json
```

Returned output:

```text
[I17:E01] Skill Style: The Groundwork for Prosiform Compliance
## Overview

The work-planner skill takes the file style its prosiform form will need, laying the groundwork for prosiform compliance before the skill's extraction is cut. The style is the one the example skill under `.project/main/example` shows. That example is an older work-planner and serves as a structural style reference only: no content carries over from it. Command presentation follows the linked Graph Index example in R5. Prerequisites sections stay, and no prosiform metadata is added.

## Problem

- **Steps are list items.**
  Every procedure is a numbered list with bold leads, so a step has no heading to link and no place for its own detail.
- **Commands sit apart from the steps that run them.**
  Artifacts hold a `## Commands` section that their operations reach by link.
- **Inputs and outputs are prose.**
  Operations keep their inputs and returned values in prose, without linked input/output contract sections for callers.
- **SKILL.md carries the rules.**
  The rules and conventions that bind every mode, and the deployment values, sit in SKILL.md and the guidelines rather than in files of their own.
- **The style model describes the installed layout.**
  The current declarations and checks do not define the proposed heading-based steps, linked contracts and HTML command blocks.

## Proposal

- **Per-skill style model.** The skill's own guidelines, `structure.json` and `rules.json` state the new model, and the shared checker reads each skill's declared model.
  - The shared guidelines and every other skill keep their current shape.
  - Checker support is proven against specimen skills before document conversion. The final task adopts Work Planner's new guidelines and model declarations once every conversion is complete; the installed declarations govern the live checks until that adoption.
- **Entry files.** SKILL.md keeps its opening, Modes and Dependencies.
  - `rules.md` holds the rules that bind every mode, `conventions.md` the conventions, and `configuration.md` the deployment values, each built from the live skill's own text.
- **Steps as sub-sections.** Each step is a heading of its position and action, with its instruction as a paragraph and flush bullets.
  - Calls use Apply for an artifact operation and Follow for a mode, protocol or child section.
  - Each mode and protocol opens with the preamble line that links Rules, Conventions and, for a mode, Outcomes.
- **Commands in steps.** Each command moves into the step that runs it, with where it runs, the inputs that fill it, and an example. No artifact keeps a `## Commands` section.
  - Command and tool-access invocations use raw HTML `<big><pre>…</pre></big>` blocks, matching the specific R5 step. Contract-backed input names are bold Markdown links inside the block, using `[**argument**](#argument-contract)`, while literal syntax, argument order, shell quoting and line breaks are preserved.
  - Checker fixtures accept this HTML command form and its resolving argument links, and reject Markdown-fenced command invocations. The example supplies presentation only; its tool names, graph behavior, content and metadata are outside this migration.
- **Inputs, outputs and contracts.**
  Each operation lists its Inputs and Outputs as links to `###` contract sections under Fields.
- **What does not change.** The skill's behaviour, its Prerequisites sections and its frontmatter stay as they are.
  - No prosiform metadata, no `pf` instruction and no prosiform link marks, which need its grammar to place.
  - No file or rule is taken from the example's content.

## Work Breakdown

| Task | Description | Coverage | Depends on | Joins | Lane | Done |
| --- | --- | --- | --- | --- | --- | --- |
| [W01](https://github.com/m2ux/workflow-server/pull/1640) | Per-skill style model and checker | AC1 | | | | ✓ |
| [W02](https://github.com/m2ux/workflow-server/pull/1642) | Rules, conventions and configuration files | AC2 | W01 | | | ✓ |
| [W03](https://github.com/m2ux/workflow-server/pull/1643) | Modes in the new style | AC3 | W02 | | | ✓ |
| [W04](https://github.com/m2ux/workflow-server/pull/1644) | Protocols in the new style | AC4 | W02 | | | ✓ |
| [W05](https://github.com/m2ux/workflow-server/pull/1646) | Issue and body artifacts in the new style | AC5 | W02 | | | ✓ |
| [W06](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1616-i17-e01-w06-board-queue-planning-and/) | Board, queue, planning and review artifacts restyled | AC6 | W02 | | | |
| [W07](https://github.com/m2ux/workflow-server/pull/1647) | Delivery, branch and pull-request artifacts restyled | AC7 | W02 | | | ✓ |
| W08 | Activate the Work Planner style model | AC8 | W03, W04, W05, W06, W07 | | | |

## Acceptance Criteria

- [x] **AC1.** `check_skill_files.py` validates specimen declarations of the proposed Work Planner style model, including its command style, as acceptance/rejection fixtures show.
- [x] **AC2.** SKILL.md holds only its opening, Modes and Dependencies, and `rules.md`, `conventions.md` and `configuration.md` hold what binds every mode, checked by Check Skill Files.
- [x] **AC3.** Every mode states its steps as sub-sections, opens with the preamble line and calls through Apply and Follow, using the [command style](#proposal), checked by Check Skill Files.
- [x] **AC4.** Every protocol states its steps as sub-sections, opens with the preamble line and calls through Apply and Follow, using the [command style](#proposal), checked by Check Skill Files.
- [x] **AC5.** Every issue and body artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.
- [ ] **AC6.** Every board, queue, planning and review artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.
- [x] **AC7.** Every delivery, branch and pull-request artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.

- [ ] **AC8.** The Work Planner guidelines, `structure.json` and `rules.json` declare the new style model over the converted skill, with zero findings from Check Skill Files over `skills/work-planner`.

## References

- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the artifact grouping and each task's work item.
- **R2.** [Example skill](https://github.com/m2ux/md-composer/tree/00f166920ec242f3565376e06a8838de72f8dc34/example/work-planner) — the older work-planner whose file style this epic adopts; style only.
- **R3.** [Example guidelines](https://github.com/m2ux/md-composer/blob/00f166920ec242f3565376e06a8838de72f8dc34/example/guidelines.md) — the shared guidelines that state that style.
- **R4.** [Work Planner at the migration baseline](https://github.com/m2ux/workflow-server/tree/03d353300ca4804194fd50d316d73e3bf1270d1d/skills/work-planner) — the skill this epic restyles.
- **R5.** [HTML command-style example](https://github.com/shieldedtech/midnight-agent-eng/blob/a710a42e82df7f18b27f8a6cfa4b6e9c801df903/skills/finding-classifier/artifacts/graph-index.md#1-fetch-the-first-inventory-page) — the specific command presentation adopted by this migration; style only.
```

## 020-input-files

Exit: 0; receipt: [020-input-files.json](receipts/020-input-files.json).

```sh
rg --files /tmp/i17-e01-w06/final-package/inputs
```

Returned output:

```text
/tmp/i17-e01-w06/final-package/inputs/pr-1647.json
/tmp/i17-e01-w06/final-package/inputs/pull-pages-m2ux-prosiform-skills.jsons
/tmp/i17-e01-w06/final-package/inputs/pull-pages-m2ux-workflow-server.jsons
/tmp/i17-e01-w06/final-package/inputs/prs.jsonl
/tmp/i17-e01-w06/final-package/inputs/links.json
/tmp/i17-e01-w06/final-package/inputs/README.md
/tmp/i17-e01-w06/final-package/inputs/epic-board-item.json
/tmp/i17-e01-w06/final-package/inputs/pr-1641.json
/tmp/i17-e01-w06/final-package/inputs/pr-1643.json
/tmp/i17-e01-w06/final-package/inputs/fields.json
/tmp/i17-e01-w06/final-package/inputs/items.json
/tmp/i17-e01-w06/final-package/inputs/epic-1616.json
/tmp/i17-e01-w06/final-package/inputs/initiative-1597.json
```

## 021-guidelines

Exit: 0; receipt: [021-guidelines.json](receipts/021-guidelines.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/guidelines.md
```

Returned output:

```text
# Guidelines

The rules this skill's files follow alongside the [shared skill guidelines](../guidelines.md). Modes, protocols and artifacts use the directory-specific structures below. A rule that binds only modes, only protocols, only artifacts, or only references is in that section.

## Titles

- **Title case.**
  A heading, a board title, an issue or pull request name and subtitle, and a template section heading are in title case.
  - A short word stays lowercase unless it is first or last: a, an, the, and, but, or, nor, for, as, at, by, in, of, on, to, up, with.
  - Each part of a hyphenated word is capitalized.
- **Action titles.**
  Operation, command and mode procedure titles name the action and subject directly, without articles such as a, an or the. Use meaningful subject words to meet the procedure title length.

## Procedure

These rules apply to mode procedures and artifact operations.

- **Explicit execution.**
  State the action, its inputs and any condition that selects it. Name the result used by the next step. Branches state where to continue or stop; retries name the repeated operation and refreshed inputs. Distinguish reading a definition from executing a procedure. Resolve timing, caller responsibility and return points in the instructions.

- **Subsection titles.**
  A procedure subsection title contains at least three words and names the action and its subject.
- **Numbered steps.**
  A procedure with multiple steps uses consecutive numbers starting at `1.`. Supporting bullets and command blocks are indented beneath their step. A single-step procedure has no numbering or bold action label.
- **Sub-bullets.**
  A sub-bullet under a numbered procedure step is in sentence case. The first word is capitalized, and a name keeps its own capitals.
- **Separate actions.**
  After a step's opening instruction or scope, put each sentence that advances the sequence in its own bullet, including sequences written as a paragraph. Split comma- and semicolon-separated actions the same way. Keep numbered steps as the outer sequence; use bullets for the actions within a step. Put a shared condition or iteration above its nested actions, preserving order, inputs, validation gates and return points. Keep an input list, action condition or explanatory sentence with the action it qualifies; these are not separate sequence elements.
- **List introductions.**
  Within a procedure step, a line that introduces or governs one list is plain text at the enclosing level, with the governed items as bullets directly beneath it. Determine this relationship from the meaning of the instructions, regardless of the opening verb, punctuation or existing indentation. Apply the rule at every nesting level. Use bullets for peer actions, alternative branches and sibling groups. Give actions outside an introduction's scope an explicit continuation at the enclosing level.
- **Dependent instructions.**
  Nest instructions that handle an action's specific output beneath that action. Keep peer actions at the enclosing list level. Name the returned object explicitly when a pronoun would leave its referent unclear.
- **Branch headers.**
  Nest named findings and conditional branches as sub-bulleted headers beneath the action or scope that governs them. Each header is a bold label on its own line, with its instructions in child bullets. Mutually exclusive choices share one decision step. Place actions common to all branches after the branch group at the enclosing sequence level, including a shared return to the caller.

## Prose

- **Input labels.**
  Artifact operation and command input declarations start with the bold label **Inputs:**. The input description uses normal text.

- **Rule homes.**
  A rule's [one home](../guidelines.md#prose) is the field or outcome it constrains, the procedure step it binds, or the Modes, Artifacts, or References section below. Operation inputs name the evidence that the caller must supply for those preconditions.
- **Scheme.**  The scheme is agent-engineering: an agent-engineering prefix, title, issue or table.
- **Examples.**
  A name, label, branch, path or board that belongs to one project is an example. The rule states what holds for every project.
- **Consumers.**
  A document states what it is and what it requires. A document may cite its own rules. The documents that use it are the ones that cite it.

- **Measured claims.**
  A count or a chain comes from a command's output.
- **Reachable dependencies.**
  Each required file, heading and operation has a resolving link. Prerequisites include the files those operations require; links to another file's operation include that file.

## Operations

These rules govern command and access specifications. Procedural operations follow Procedure and Artifacts below.

- **Spec layout.**
  A command specification takes the [shared spec layout](../guidelines.md#commands), and access instructions stand where a command has no block. Specifications have no numbered steps or bold action labels. The calling operation or mode procedure states when the command runs and what it passes; action preconditions and refusals belong to the governing step.
- **One command.**
  Each specification exposes one command or access action. Put sequencing, branching, repetition and readback in an artifact operation or mode procedure. A working-directory prefix and output-filter pipeline belong to the command they serve. Optional flags for one command share its specification.
- **One home.**
  A command specification sits under Commands in an artifact, or Operations in a mode. Artifact operations call their implementation commands by heading link. A kind supplies only its additional parameters to a common operation.
- **Direction.**
  The procedure names the command it runs. A command does not name that procedure.

- **Execution.**
  Run a command in the checkout of the repository it addresses. Resolve placeholders from the supplied inputs before execution. Use `orgs/<owner>` for an organisation's board and `users/<owner>` for a user's board.
- **Placed paths.**
  A command that creates a worktree or other lasting location takes a path its caller composes. Its specification cites the field that places that kind and states that the path resolves against the directory the command runs in.
- **Parameter placeholders.**
  Command templates use descriptive `<input-name>` placeholders for variable identities, branches, paths, dates, filters and values, aligned with their **Inputs:**. Quote shell arguments containing placeholders and escape substituted values for their shell, URL, query or payload context. Keep required literals, enum values, field names and installed script paths literal. State list separators, mapping syntax and repeated arguments beside the command. JSON templates preserve the required value types.
- **Concrete examples.**
  Retain hard-coded values in explicitly labelled examples alongside the generic command or payload template so their shape remains clear. Examples illustrate input values; they do not supply defaults or identify the current target.
- **Local scripts.**
  `<workspace>` is the checkout holding the installed scripts. Run its scripts with the absolute `<workspace>/scripts/sbx` path from that checkout.
- **Bodies.**
  Pass a complete body or multiline comment through a file. The file holds the exact intended text.

## Modes

Read this before adding or changing a mode.

- **Orchestration.**
  Modes coordinate; artifact operations perform and validate work on their own subject. Mode procedures are lean orchestration wrappers: they select scope, call artifact operations with named inputs, route returned findings and user decisions, and coordinate changes across artifacts. A procedure that manages multiple artifacts belongs in a mode. A mode keeps commands only for work spanning artifacts or validating the skill itself.
- **One goal.**
  A mode is the lifecycle of one user goal. It changes when that lifecycle changes.
- **Outcomes.**
  A mode outcome is a user goal to be met. It does not state an artifact shape, a table column, or a criterion.
- **No procedure in an outcome.**
  An outcome does not name a procedure, a step, or a command, and it does not link to one.
- **Procedure.**
  The top-level procedure is the main path. A short sequence that no other file references stays there. A subsection is an alternative path, a loop whose steps would otherwise be repeated, a unit another file references, or a sequence long enough that the top-level step only names it. Plan mode keeps review, and keeping the goal current, in that sequence. Keeping the goal current repeats the review. A subsection opens with one line on what it is for, and that line does not restate the steps. A step links to the user-goal outcome and does not restate it. A step calls the body artifact's procedure rather than copying it.
- **Prerequisites.**
  Prerequisites open with `Read these files first.` They list every file the mode's Procedure, Outcomes or Operations link to, including another mode that step runs. They do not list a family common the mode does not link to. Reading the body artifact includes the common file, because that artifact lists it. Recalculate the list after changing calls or references: retain direct dependencies, including files owning called subsections; remove entries whose last direct use is gone. Caller attribution and descriptions of another mode's internals do not create dependencies for the callee.
- **Procedure steps.**
  Each numbered step opens with a bold sentence-case action label, with its instructions on the next line. Mode procedures identify required context in their instructions and call sites, without a separate Inputs declaration.
- **Body files.**
  A file that populates a body is named `<subject>-body.md`. The mode owns how many of that subject a request becomes.
- **Other modes.**
  Invoke another mode with Run or Follow, naming the selected scope and the whole mode or exact subsection to execute. A subsection call executes that subsection only. Calls are sequential unless concurrency is explicitly stated: complete the called work, then resume the calling step with its result; a blocker returns to the caller. Prerequisites require reading documents, not executing their procedures. Define findings in their artifact and identify the operation returning them; passive attribution to a mode does not establish a call, prior execution or a concurrent process. Called modes are listed under Prerequisites.
- **No spare parts.**
  A mode does not carry an outcome, a procedure unit, or a command its procedure never uses.
- **A new mode.**
  A new mode is a new file. An artifact is not edited to name it.
- **Interview.**
  A question the user must decide is put this way.
  - A plain-language paragraph before the question gives the context the user needs to answer it.
  - The question offers more than one choice. The recommended choice is marked on its option.
  - Wait for the user's answer. An unanswered question stays pending. A recommendation or elapsed time supplies no answer.
  - The user can select Other and specify a response beyond the options.
  - Use the native tool for presenting the question when one is available.
- **Step rules.**
  A rule that binds one step sits in that step. A rule that binds every mode is added to this section.
- **Sections.**
  Prerequisites, Procedure, Outcomes, then Guidance when the file has an assistive statement that is not a step, a condition, or a mode outcome, then Operations. Procedure and Outcomes are required, and Operations holds cross-artifact command specifications. A mode has no Rules section.

## Protocols

Read this before adding or changing a protocol.

- **One change.**
  A protocol is one change to the work that lands in several artifacts together. It changes when that change does. Where the sequence produces one nameable output shape it is an artifact operation, not a protocol, and a derived shape with no persisted document still counts.
- **Named for the situation.**
  A protocol is named for the situation it governs, as a noun phrase: Task Merge, Issue Closure, Epic Integration. Its file is `<situation>.md`.
- **Entered whole.**
  One file holds one protocol. A caller runs the file; it does not link a step. A sequence worth calling on its own is its own protocol.
- **Procedure.**
  The steps follow the mode procedure rules: numbered, each opening with a bold sentence-case action label with its instructions on the next line. Protocols identify required context in their instructions and call sites, without a separate Inputs declaration.
- **No closing summary.**
  What a protocol changes, and what a blocker leaves unchanged, is stated by the step that changes it. A protocol carries no section restating the result; a reader following the procedure and its links has it already, and a summary goes stale against the steps it describes.
- **Prerequisites.**
  Prerequisites open with `Read these files first.` They list every file the protocol's Procedure links to, including each protocol it runs.
- **No spare parts.**
  A protocol nothing runs is not a protocol. One exists because a mode or another protocol follows it.
- **A new protocol.**
  A new protocol is a new file. An artifact is not edited to name it.
- **Step rules.**
  A rule that binds one step sits in that step. A rule that binds every protocol is added to this section.
- **Sections.**
  Prerequisites, Procedure, then Guidance when the file has an assistive statement that is not a step. Procedure is required. A protocol has no Outcomes, Fields, Rules, Operations or Commands section.

## Artifacts

Read this before adding or changing an artifact.

- **One shape.**
  An artifact owns one subject’s state, invariants and operations. Its shape and the transformations that produce it share that home, with shared executable operations in a subject module. It changes when that subject changes. Locate a procedure by the object and state it produces. A caller or a shared command does not determine ownership.
- **Virtual artifacts.**
  A derived artifact owns its output shape even when it has no persisted document. Fields defines that shape; its operations consume supplied evidence.
- **Descriptions.**
  Describe the artifact's subject and contents directly. Omit inconsequential implementation qualifiers such as virtual. Distinguish proposed changes from applied state where the caller needs that distinction; a queue is not itself proposed merely because its changes await application.
- **Prose API.**
  Artifact operations form a prose-based API addressed by subsection titles. Each names its inputs, the artifact state it reads or changes, and the output it returns. Modes call operation headings; operations call command headings. Related artifacts are supplied as evidence rather than managed through the operation.
- **Operation inputs.**
  Callers address an artifact operation through descriptive input names, such as board fields. CLI flags such as `--fields` belong to the artifact's implementation details, not the calling mode procedure. Repeated calls identify the inputs they refresh and retain.
- **Operation scope.**
  An operation exists because a procedure calls it. Classify the work by its subject and behaviour, not its verb or script name: a read that sequences access steps is an operation, and a plan that derives an artifact's state is an operation.
  - Reading, inspecting, planning, populating and validating are shapes an operation can take, not a set an artifact fills. A sibling operation is no reason to add its counterpart, and a wrapper whose body is one call to another operation is that operation.
- **Bodies and lifecycle.**
  A body artifact populates and validates document content. A subject artifact owns its readiness and completion checks from supplied evidence. Reading evidence about related artifacts does not make a check orchestration; coordinating changes to those artifacts does. Creation, metadata, linking and closure belong to the artifact for the tracked object.
- **No mode, no protocol.**
  An artifact never links to a mode or a protocol, including by naming one in prose.
- **Fields.**
  Fields defines the artifact's shape and the conditions on its elements. Common field conditions hold for the family; a kind supplements them. Fields is a `##` section, with each named field or group under `###`. The kind's template is a subsection of Fields and holds that kind's table. Field conditions do not state user goals. A condition that gates an action sits in the procedure step that performs it.
- **No procedure in Fields.**
  A field condition does not name a procedure, a step, or a command, and it does not link to one.
- **Name.**
  A file that populates a body is named `<subject>-body.md`. Its scope is that population. `issue-body.md` is the shared issue body. A kind file is `proposal-body.md`, `initiative-issue-body.md`, `epic-issue-body.md`, `task-body.md`, `standalone-body.md`, or `hotfix-body.md`.
- **Subject names.**
  Name an artifact for its subject and an operation for its action: `board-queue.md` owns Board Queue, and Plan Board Queue is its operation. A computation script can take the subject name, such as `board-queue.py`.
- **Common file.**
  The common file names no kind. A kind's table, its title, and a check that applies only to that kind live on that kind's file. The common file holds the rules every body shares.
- **Operations.**
  Every procedural sequence occupies a named `###` subsection under Operations, including a kind's population path. Operations itself contains no steps; incorporate any overarching sequence into the named operations that perform its constituent work. Omit Operations when the artifact has only command specifications. Each subsection opens with one line on what it is for, followed by its **Inputs:** line and instructions. The opening line does not restate the steps. A step links to the shape it produces and does not restate it. A kind step links to the common procedure unit it uses and adds only the further population. It does not copy the shared rules.
- **Prerequisites.**
  Prerequisites open with `Read these files first.` They list every file the artifact's Operations, Fields or Commands link to. A kind lists `issue-body.md` because it links to it. The common file does not link to a kind.
- **Operation steps.**
  Address instructions directly to the agent, leading each step with its action. Steps have no separate bold introductory label. Multiple steps use consecutive numbering; an operation with one step uses one bullet and counts as a procedure.
- **Returned output.**
  State what the operation returns within its instructions. Do not add a separate Result line.
- **Population conditions.**
  A population step leads with the writing action and its template or owning operation. Mandatory field conditions follow as nested bullets under that step, linked to their local or shared definitions. Each condition states what must hold; field rules remain at their linked home.
- **Command implementation.**
  Commands holds the artifact's command and access specifications. Operations holds the sequences that call them. Both expose named subsections to callers.
- **No spare parts.**
  An artifact does not carry an operation, a field or a command nothing reaches. An operation no procedure cites is surface that drifts from whatever it wraps, and its capability is already reachable through the operation it would call.
- **A new kind.**
  A new kind is a new file. The common file is not edited to name it.
- **Detail.**
  A change keeps every existing condition. A shorter file is not a reason to drop one.
- **Step rules.**
  Put each action's preconditions and refusal conditions in its governing procedure step. Shared preconditions belong to a common procedure that callers invoke. Command specifications require the resulting evidence or authorization as inputs. A rule that binds every artifact is added to this section.
- **Sections.**
  Prerequisites, Operations, Fields, then Guidance when it has an assistive statement that is not a step or a field condition, then Commands when the file has command specifications. Fields is required. An artifact has no Procedure, Outcomes or Rules section.

## References

Read this before adding or changing a reference.

- **Support.**
  A reference is an ad hoc document that supports the process. It is neither a mode nor an artifact.
- **Shape.**
  It follows the shared sections above. It does not use Prerequisites, Procedure, Fields, Operations, Commands, and Outcomes.
- **Cited only.**
  A reference is only ever referred to. It cites neither a mode nor an artifact.
- **Names.**
  A sentence that names a mode or an artifact loses that name. The statement it made stays.
- **Rules.**
  A rule that binds every reference is added to this section.

## Entry Point

- **Opening.**  The bulleted list has one item for each issue type.
- **Section order.**  The opening, Modes and Dependencies occupy the entry point.
- **Issue bodies.**
  The skill's prose layout applies to its instructions. Issue bodies follow [Issue Body](artifacts/issue-body.md#fields); pull request bodies follow [Pull Request Body](artifacts/pull-request-body.md#fields).
- **Common conventions.**
  The entry point requires [Rules](rules.md) and [Conventions](conventions.md) before mode selection. [Configuration](configuration.md) holds deployed values, reached by their consuming sections. Graph-specific setup belongs to [Repository Graph](artifacts/repository-graph.md).

## Progressive Disclosure

Apply the shared [progressive disclosure](../guidelines.md#progressive-disclosure) and [disclosure verification](../guidelines.md#disclosure-verification) rules to affected callers. Modes are read whole; supporting section reads inherit the mode's command prerequisites.

- **Mode routes.**
  Trace each affected mode through its common conventions, selected operations and supporting guides. Include cross-mode calls and explicit whole-file requirements.
- **Board operations.**
  Exercise a Standup request with captured board inputs, selecting multiple operations and reusing conventions. Preserve the generator's format and unresolved evidence.
- **Graph operations.**
  Exercise an Understand request with a named pull request, verifying graph-specific setup before selected graph commands and exclusion of unrelated command bodies.
- **Revision.**
  Exercise a bounded skill edit with its consumer guidance, required whole-file guidelines, local checks and reused common prerequisites.

## Changes

Follow the shared [change rules](../guidelines.md#changes) for worktree isolation, current user preferences and validation.

- **Planning adoption.**
  Commit and push the reviewed planning folder before applying its design to the installed skill. Keep the planning and installed guidelines aligned with the current preference set.
- **Integrated implementation.**
  Map the complete live skill to its intended homes. Apply document moves, embedded templates, consuming readers, script names, callers and tests together; preserve the existing conditions and remove obsolete paths.
- **Delivery.**
  Run the associated tests and integration checks before opening or updating the implementation pull request. Commit and push the changes from their owning worktrees; subsequent corrections update the same pull request.
```

## 022-requirements

Exit: 0; receipt: [022-requirements.json](receipts/022-requirements.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/references/requirement-characteristics.md
```

Returned output:

```text
# Requirement Characteristics

The characteristics an acceptance criterion meets, and the characteristics a set of them meets. Condensed from ISO/IEC/IEEE 29148:2018, clauses 5.2.4 to 5.2.7.

## Individual

Each criterion has these characteristics.

- **Necessary.**
  It states a capability, constraint, or quality the work must have. Leaving it out leaves that need unmet, and no other criterion meets it. It applies now.
- **Appropriate.**
  The detail matches the level of the work. It states what holds, and does not lock in a design the need does not require.
- **Unambiguous.**
  It can be read in only one way.
- **Complete.**
  It states the condition fully. Knowing whether it holds does not depend on some other text.
- **Singular.**
  It states one capability, constraint, or quality. Several conditions under which that one thing holds are still one criterion.
- **Feasible.**
  It can be met within the cost, schedule, and technical bounds of the work, at an acceptable risk.
- **Verifiable.**
  Its wording lets the realisation be proved, at the level the criterion is written, by inspection, analysis, demonstration, or test. A measure makes that proof easier.
- **Correct.**
  It states the need it came from, accurately.
- **Conforming.**
  It follows the acceptance-criterion form: an end state, one invariant, and a named instrument.

## A Set

The criteria of one issue, taken together, have these characteristics.

- **Complete.**
  Together they state what the work must achieve. Nothing the set needs is left to be defined later.
- **Consistent.**
  No two conflict or overlap. The same word means the same thing throughout.
- **Feasible.**
  The set can be met within the same cost, schedule, and technical bounds, at an acceptable risk.
- **Comprehensible.**
  A reader can see what the work is expected to achieve, and how that sits with the rest of the plan.
- **Able to be validated.**
  Meeting the set achieves the need the plan states, within its constraints.

## Wording

- **What, not how.**
  A criterion states the condition that holds. A design choice belongs in the Proposal.
- **Bounded words.**
  These make a criterion hard to prove, or open to more than one reading, unless a measure defines them:
  - superlatives, such as best or most;
  - subjective praise, such as easy or robust;
  - vague pronouns, such as it or this;
  - open comparatives, such as better or significant;
  - loopholes, such as if possible or as appropriate;
  - words of totality, such as all, always, or never, unless the set they cover is named;
  - an open-ended promise, such as provide support.
- **Assumptions.**
  An assumption is recorded beside the criterion, in the Problem or the Proposal. It is not written as the criterion.
- **Definitions.**
  A definition is a statement of what a term means. It is not a criterion.
```

## 023-issue

Exit: 0; receipt: [023-issue.json](receipts/023-issue.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/issue.md
```

Returned output:

```text
# Issue

A tracker issue: its identity, saved body, metadata, discussion and closure state. The caller supplies the populated body and the delivery decision.

## Operations

### Read Tracker Issue

The current issue, its saved body and discussion.

**Inputs:** [Repository](#repository), [Identity](#identity), [Output Files](#output-files), [Discussion Selection](#discussion-selection).

**Outputs:** [Issue Record](#issue-record) for a complete response or [Issue Body](#issue-body) for a body-only response, with [Discussion](#discussion) when requested.

#### 1. Select Issue Response

Apply [Fetch Tracker Issue](#fetch-tracker-issue) for the complete JSON, or Apply [Fetch Issue Body](#fetch-issue-body) for its body, with the issue number and destination file.

#### 2. Read Requested Discussion

Apply [Fetch Issue Comments](#fetch-issue-comments) when the request depends on the discussion.

### Save Tracker Issue

One populated body and its metadata, written to the tracker.

**Inputs:** [Repository](#repository), [Identity](#identity), [Issue Changes](#issue-changes), [Comment](#comment).

**Outputs:** [Issue Record](#issue-record).

#### 1. Take Supplied Changes

Take the supplied body and metadata, preserving each field the caller does not change for an existing issue.

#### 2. Check Assigned Labels

Check the assignments against [Label Names](#label-names); return a missing-label result for any unavailable name.

#### 3. Create New Issue

For a new issue, Apply [Create Tracker Issue](#create-tracker-issue) with the body's file, title and labels.

#### 4. Change Existing Fields

For an existing issue, Apply [Patch Issue Body](#patch-issue-body), Apply [Retitle Tracker Issue](#retitle-tracker-issue), Apply [Add Issue Labels](#add-issue-labels) or Apply [Remove Issue Label](#remove-issue-label) for the fields being changed.

#### 5. Publish Required Comment

Apply [Comment on Issue](#comment-on-issue) for an answer the caller requires, with the issue number and comment file.

#### 6. Read Saved Issue

Apply [Fetch Tracker Issue](#fetch-tracker-issue).

#### 7. Compare Saved Fields

Compare the saved fields with the intended body and metadata.

### Close Tracker Issue

Verified completion of an issue and its linked delivery.

**Inputs:** [Identity](#identity), [Delivery Evidence](#delivery-evidence), [Output Files](#output-files).

**Outputs:** [State](#state), [Closure Findings](#closure-findings).

#### 1. Capture Current Development

Apply [Capture Issue Development](#capture-issue-development) for the issue's current JSON and its Development snapshot.
- The issue's entire Development field establishes membership, across repositories and states. Titles, branch names, body mentions and a list filtered to one initiative do not. An empty field adds no pull request requirement.

#### 2. Check Closure Evidence

Apply [Check Issue Closure](#check-issue-closure) with those two files.

#### 3. Require Completed Delivery

Require normal delivery checks to pass, every criterion to be verified and ticked, and every currently linked pull request to be merged.
- Keep the issue open for an open, draft or closed-without-merge linked pull request, and for links never read.
- Return an abandoned or incorrect Development link to the caller for the user's decision on its removal. A replacement pull request does not remove the requirement on a link still present.

#### 4. Close Verified Issue

Apply [Close as Completed](#close-as-completed), which repeats the gate immediately before the write.

### Close Transferred Work

An issue whose work is tracked by another issue.

**Inputs:** [Identity](#identity), [Transfer Evidence](#transfer-evidence), [Comment](#comment).

**Outputs:** [State](#state).

#### 1. Confirm Destination Evidence

Confirm the supplied destination contains the work and cites its source issue.

#### 2. Comment With Destination

Apply [Comment on Issue](#comment-on-issue) with the destination reference and supplied comment file.

#### 3. Close Transferred Issue

Apply [Close as Not Planned](#close-as-not-planned), retaining the issue's body.

#### 4. Confirm Saved State

Apply [Fetch Tracker Issue](#fetch-tracker-issue) to confirm its state and reason.

### Comment on Issue

The supplied discussion text saved on one issue.

**Inputs:** [Repository](#repository), [Identity](#identity), [Comment](#comment).

**Outputs:** [Comment](#comment).

#### 1. Prepare Feedback Reply

When replying to feedback already folded into the body, compose a precise, factual reply addressing each point and mentioning the reviewer, with no thanks or filler. Name what the body now says, by criterion id where one carries it, or the issue that takes the point.

#### 2. Publish Supplied Comment

Publish the supplied comment:
- For a one-line comment, Apply [Post Inline Comment](#post-inline-comment) with the exact text.
- For a longer comment, Apply [Post Comment File](#post-comment-file) with the complete file.

#### 3. Return Comment URL

Return the saved comment URL.

### Close as Completed

An issue closed after its final evidence check.

**Inputs:** [Repository](#repository), [Identity](#identity), [Authenticated Access](#authenticated-access), [Delivery Evidence](#delivery-evidence), [Closure Evidence Paths](#closure-evidence-paths).

**Outputs:** [State](#state), [Closure Findings](#closure-findings).

#### 1. Capture Fresh Development

Apply [Capture Issue Development](#capture-issue-development) immediately before closure with the issue identity, authenticated access and evidence paths.

#### 2. Run Fresh Closure Gate

Apply [Check Issue Closure](#check-issue-closure) with the issue and Development files it wrote, using absolute evidence paths when changing directory.

#### 3. Require Passing Evidence

Require exit 0 and passing normal delivery checks; a sync report of closable does not permit skipping this gate.

#### 4. Set Completed State

Immediately after the gate passes, Apply [Set Completed State](#set-completed-state) with the issue's repository and number and the passing evidence.

#### 5. Return Saved State

Return the saved state or failure.

### Capture Issue Development

The issue's current content and its Development pull requests, as GitHub exposes them.

**Inputs:** [Identity](#identity), [Authenticated Access](#authenticated-access), [Output Files](#output-files).

**Outputs:** [Issue Record](#issue-record), [Development Snapshot](#development-snapshot).

#### 1. Fetch Current Issue

Apply [Fetch Tracker Issue](#fetch-tracker-issue) into `issue-943.json` or the supplied path.

#### 2. Read Development Links

Apply [Read Issue Development](#read-issue-development) with that file, saving `links-943.json` or the supplied path. An unreadable relation writes no snapshot, which blocks the caller; an empty array means the field was read and is empty.

#### 3. Return Captured Files

Return both files, or the unreadable relation.

### Read Issue Development

The Development pull requests of one issue, or of every issue in one repository, keyed by issue number.

**Inputs:** [Issue Collection](#issue-collection), [Authenticated Access](#authenticated-access), [Output Files](#output-files).

**Outputs:** [Development Snapshot](#development-snapshot).

#### 1. Capture Supplied Relations

Apply [Capture Issue Links](#capture-issue-links) with the supplied issues and destination.

#### 2. Return Complete Relations

Return each issue's observed pull requests, or stop and return each unreadable relation the capture names as a blocker.

### Audit Closure Evidence

Each closed issue in one repository whose criteria or Development links do not support its closure, with the reason it was closed.

**Inputs:** [Repository](#repository), [Authenticated Access](#authenticated-access), [Audit Selection](#audit-selection), [Output Files](#output-files).

**Outputs:** [Closure Findings](#closure-findings).

#### 1. Fetch Selected Closed Issues

Fetch the closed issues alone:
- For named issues, Apply [Fetch Selected Closed Issues](#fetch-selected-closed-issues) with their numbers.
- For the whole repository, Apply [Fetch Closed Issues](#fetch-closed-issues).
- An empty collection means none of the named issues is closed; return nothing listed.

#### 2. Read Complete Development

Apply [Read Issue Development](#read-issue-development) with that collection; an unreadable relation is returned as a blocker and the sweep does not run.

#### 3. Run Closure Sweep

Apply [Sweep Closure Evidence](#sweep-closure-evidence) with the collection and the issue-links file.

#### 4. Return Audit Findings

Return each unsupported issue with its state reason and findings, and each unevaluable issue as missing evidence, as findings. Return the not-planned closures apart, as listed for reference. The audit changes no issue.

### Confirm Repository Auto-Close

Whether the repository auto-closes issues whose linked pull requests merge, established for this session.

**Inputs:** [Repository](#repository), [Authenticated Access](#authenticated-access).

**Outputs:** [Auto-Close Setting](#auto-close-setting).

#### 1. Read Exposed Setting

Read the setting where the authenticated API exposes it, and take a read value as the answer.

#### 2. Confirm Unexposed Setting

Where no API field carries it, put the setting to the user and take their explicit answer, meeting [Auto-Close Setting](#auto-close-setting).

#### 3. Return Confirmed Setting

Return the confirmed value. An unconfirmed setting is a blocker, and an enabled one leaves the caller to obtain authorization before the repository is reconfigured.

### Read Repository Issues

The issue collection used for repository-wide selection.

**Inputs:** [Repository](#repository), [Output Files](#output-files).

**Outputs:** [Issue Collection](#issue-collection).

#### 1. Fetch Repository Issues

Apply [Fetch All Issues](#fetch-all-issues), saving the complete collection.

#### 2. Return Issue Collection

Return it with pull requests distinguishable from issues.

### Locate Initiative Issue

The tracker identity matching one initiative prefix.

**Inputs:** [Repository](#repository), [Tracker Prefix](#tracker-prefix).

**Outputs:** [Identity](#identity), [Tracker Number](#tracker-number).

#### 1. Find Supplied Prefix

Apply [Find Initiative Issue](#find-initiative-issue) with the supplied repository and prefix.

#### 2. Return Resolved Identity

Return its issue number or an unresolved identity.

### Select Tracker Number

The next unused number for one prefixed issue kind in the repository.

**Inputs:** [Repository](#repository), [Tracker Prefix](#tracker-prefix).

**Outputs:** [Tracker Number](#tracker-number).

#### 1. Read Existing Titles

Apply [List Prefixed Titles](#list-prefixed-titles) for the supplied repository and prefix letter, covering all issue states.

#### 2. Read Highest Prefix

Read the highest prefix carrying that letter.

#### 3. Confirm Unused Number

Confirm the following number, or `00` when there is no prefix, remains unused before creation.

#### 4. Return Confirmed Number

Return the confirmed number.

### Create Tracker Issue

Creates an issue from a body file, with its title and labels, and prints its number.

**Inputs:** [Repository](#repository), [Issue Changes](#issue-changes), [Label Names](#label-names).

**Outputs:** [Identity](#identity).

#### 1. Create Tracker Issue

Run this command from the repository checkout with the supplied inputs.

Repeat `-f 'labels[]=<label>'` for each supplied label.

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues' -f title='[**&lt;title&gt;**](#issue-changes)' -F 'body=@[**&lt;body-file&gt;**](#issue-changes)' -f 'labels&#91;&#93;=[**&lt;label&gt;**](#label-names)' --jq .number
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues' -f title='[**&lt;title&gt;**](#issue-changes)' -F body=@body.md -f 'labels&#91;&#93;=[**&lt;label&gt;**](#label-names)' --jq .number
</pre></big>

### Patch Issue Body

Replaces an issue's body from a file.

**Inputs:** [Repository](#repository), [Identity](#identity), [Issue Changes](#issue-changes).

**Outputs:** [Identity](#identity), [Content](#content).

#### 1. Patch Issue Body

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' -F 'body=@[**&lt;body-file&gt;**](#issue-changes)' --jq .number
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943' -F body=@body.md --jq .number
</pre></big>

### Fetch Issue Body

Saves an issue's body alone.

**Inputs:** [Repository](#repository), [Identity](#identity), [Output Files](#output-files).

**Outputs:** [Issue Body](#issue-body).

#### 1. Fetch Issue Body

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' --jq .body > '[**&lt;output-body-file&gt;**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943' --jq .body > live-943.md
</pre></big>

### Retitle Tracker Issue

Replaces an issue's title.

**Inputs:** [Repository](#repository), [Identity](#identity), [Issue Changes](#issue-changes).

**Outputs:** [Content](#content).

#### 1. Retitle Tracker Issue

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' -f title='[**&lt;title&gt;**](#issue-changes)' --jq .title
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943' -f title='[**&lt;title&gt;**](#issue-changes)' --jq .title
</pre></big>

### Add Issue Labels

Adds labels to an issue.

**Inputs:** [Repository](#repository), [Identity](#identity), [Label Names](#label-names).

**Outputs:** [Label Names](#label-names).

#### 1. Add Issue Labels

Run this command from the repository checkout with the supplied inputs.

Repeat `-f 'labels[]=<label>'` for each supplied label.

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)/labels' -f 'labels&#91;&#93;=[**&lt;label&gt;**](#label-names)' --jq '.&#91;&#93;.name'
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943/labels' -f 'labels&#91;&#93;=[**&lt;label&gt;**](#label-names)' --jq '.&#91;&#93;.name'
</pre></big>

### Remove Issue Label

Removes one label from an issue.

**Inputs:** [Repository](#repository), [Identity](#identity), [Label Names](#label-names).

**Outputs:** [Label Names](#label-names).

#### 1. Remove Issue Label

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method DELETE 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)/labels/[**&lt;label&gt;**](#label-names)' --jq '.&#91;&#93;.name'
</pre></big>

**Example:**

<big><pre>
gh api --method DELETE 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943/labels/[**&lt;label&gt;**](#label-names)' --jq '.&#91;&#93;.name'
</pre></big>

### Fetch Issue Comments

Prints an issue's comments.

**Inputs:** [Repository](#repository), [Identity](#identity).

**Outputs:** [Discussion](#discussion).

#### 1. Fetch Issue Comments

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --paginate 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)/comments'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/874/comments'
</pre></big>

### Fetch Tracker Issue

Saves an issue whole, as JSON, for the scripts that read issues.

**Inputs:** [Repository](#repository), [Identity](#identity), [Output Files](#output-files).

**Outputs:** [Issue Record](#issue-record).

#### 1. Fetch Tracker Issue

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' > '[**&lt;issue-json-file&gt;**](#issue-record)'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943' > issue-943.json
</pre></big>

### Check Issue Closure

Checks the issue's criteria and the state of every pull request its Development field holds.

**Inputs:** [Issue Record](#issue-record), [Development Snapshot](#development-snapshot).

**Outputs:** [Closure Findings](#closure-findings).

#### 1. Check Issue Closure

Run this command from the workspace checkout with the supplied inputs.

- The gate reads only those two files, each a field GitHub exposes.
- An issue the snapshot maps to an empty array adds no pull request requirement. An issue the snapshot holds no entry for, a missing or unreadable snapshot, or a snapshot of another repository's issues blocks as missing evidence.
- Exit 0 means the closure gate passes; normal delivery checks must also pass. Exit 1 reports blockers. The command performs no network calls or writes.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/closure.py --issue '[**&lt;issue-json-file&gt;**](#issue-record)' --development '[**&lt;issue-links-file&gt;**](#development-snapshot)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/closure.py --issue issue-943.json --development links-943.json
</pre></big>

### Sweep Closure Evidence

Lists each closed issue whose acceptance criteria are missing or unticked, or whose Development field holds a pull request that has not merged, with the issue's state reason.

**Inputs:** [Issue Collection](#issue-collection), [Development Snapshot](#development-snapshot).

**Outputs:** [Closure Findings](#closure-findings).

#### 1. Sweep Closure Evidence

Run this command from the workspace checkout with the supplied inputs.

- The sweep audits every closed issue in the collection, so the collection sets its scope. Apply [Check Issue Closure](#check-issue-closure) to each issue. Open issues and pull requests in the collection are skipped.
- `--issue-links` takes the issue-links file of the collection's repository alone; any other shape, or another repository's file, is refused as unreadable evidence.
- Each line names the issue, its state reason (`completed`, `not_planned`, or `unknown` when none is recorded) and its findings, under one of three labels:
- `unsupported:` for an issue closed for any reason but `not_planned` whose evidence does not support it.
- `unevaluable:` for a closed issue the file holds no link list for, which is missing evidence rather than an empty link set.
- `not planned:` for an issue closed as `not_planned` whose evidence would not support completion; these follow the findings, listed for reference.
- The last line counts each label. Exit 0 means no issue is unsupported or unevaluable. Exit 1 means at least one is, or the evidence is unreadable. The command performs no network calls or writes.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/closure-sweep.py --issues '[**&lt;issues-json-file&gt;**](#issue-collection)' --issue-links '[**&lt;issue-links-file&gt;**](#development-snapshot)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/closure-sweep.py --issues closed-issues.json --issue-links issue-links.json
</pre></big>

**Example output:**

```text
unsupported: owner/repo#943 closed as completed: acceptance criteria are missing or unticked; owner/repo#980 not merged (closed) - Work Title
unevaluable: owner/repo#944 closed as completed: Development links not captured - Other Title
not planned: owner/repo#945 closed as not_planned: acceptance criteria are missing or unticked - Moved Title
1 unsupported, 1 unevaluable, 1 not planned
```

### Close as Not Planned

Closes an issue whose work another issue tracks.

**Inputs:** [Identity](#identity), [Transfer Evidence](#transfer-evidence).

**Outputs:** [State](#state).

#### 1. Close as Not Planned

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' -f state=closed -f state_reason=not_planned --jq .state
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/874' -f state=closed -f state_reason=not_planned --jq .state
</pre></big>

### Post Inline Comment

Posts one line of exact comment text and returns its URL.

**Inputs:** [Repository](#repository), [Identity](#identity), [Comment](#comment).

**Outputs:** [Comment](#comment).

#### 1. Post Inline Comment

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)/comments' -f body='[**&lt;comment-text&gt;**](#comment)' --jq .html_url
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/637/comments' -f body='Delivered by #950.' --jq .html_url
</pre></big>

### Post Comment File

Posts a complete comment file and returns its URL.

**Inputs:** [Repository](#repository), [Identity](#identity), [Comment](#comment).

**Outputs:** [Comment](#comment).

#### 1. Post Comment File

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)/comments' -F 'body=@[**&lt;comment-file&gt;**](#comment)' --jq .html_url
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/874/comments' -F body=@comment-874.md --jq .html_url
</pre></big>

### Set Completed State

Sets an issue to closed with the completed reason and returns its state.

**Inputs:** [Repository](#repository), [Identity](#identity), [Delivery Evidence](#delivery-evidence), [Closure Findings](#closure-findings).

**Outputs:** [State](#state).

#### 1. Set Completed State

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/[**&lt;issue-number&gt;**](#identity)' -f state=closed -f state_reason=completed --jq .state
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues/943' -f state=closed -f state_reason=completed --jq .state
</pre></big>

### Capture Issue Links

Writes each issue's Development pull requests, read from the issue end of the relation, keyed by issue number.

**Inputs:** [Issue Collection](#issue-collection), [Authenticated Access](#authenticated-access), [Output Files](#output-files).

**Outputs:** [Development Snapshot](#development-snapshot).

#### 1. Capture Issue Links

Run this command from the repository checkout with the supplied inputs.

**REST gap:** REST exposes no read of the pull requests an issue's Development field holds.

- The snapshot names the repository its issues belong to. Each issue maps to every pull request its Development field holds, open, closed and merged, as repository, number and state, or to an empty array. Pull requests in the collection are skipped.
- Each batch of issues costs one `gh api graphql` call from a generated query file, so the command runs outside `sbx`, where `gh` reaches the tracker.
- A relation is unreadable when any page of it does not arrive whole: the tracker returns no node for its subject, names the subject in an error, or reports a further page it does not supply.
- Exit 0 means every relation was read. Exit 1 names each unreadable relation with the tracker's reason and writes nothing; the caller treats it as a blocker.
- A call the tracker refuses outright, such as a rejected credential, exits 1 with `GraphQL read failed:` and what `gh` reported, and writes nothing.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && python3 skills/work-planner/scripts/links-by-issue.py --issues '[**&lt;issues-json-file&gt;**](#issue-collection)' --out '[**&lt;issue-links-file&gt;**](#development-snapshot)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && python3 skills/work-planner/scripts/links-by-issue.py --issues issue-943.json --out links-943.json
</pre></big>

**Example payload:**

```json
{
  "943": [{"repo": "owner/repo", "number": 980, "state": "MERGED"}]
}
```

### Fetch All Issues

Saves every issue in the repository; the scripts skip the pull requests among them.

**Inputs:** [Repository](#repository), [Output Files](#output-files).

**Outputs:** [Issue Collection](#issue-collection).

#### 1. Fetch All Issues

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=all&per_page=100" > '[**&lt;issues-json-file&gt;**](#issue-collection)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=all&per_page=100" > issues.json
</pre></big>

### Fetch Closed Issues

Saves every closed issue in the repository; the scripts skip the pull requests among them.

**Inputs:** [Repository](#repository), [Output Files](#output-files).

**Outputs:** [Issue Collection](#issue-collection).

#### 1. Fetch Closed Issues

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=closed&per_page=100" > '[**&lt;issues-json-file&gt;**](#issue-collection)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=closed&per_page=100" > closed-issues.json
</pre></big>

### Fetch Selected Closed Issues

Saves the named issues that are closed, one per line; an issue that is open or absent is left out.

**Inputs:** [Repository](#repository), [Audit Selection](#audit-selection), [Output Files](#output-files).

**Outputs:** [Issue Collection](#issue-collection).

#### 1. Fetch Named Closed Records

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=closed&per_page=100" --jq '.&#91;&#93; | select(&#91;.number&#93; | inside(&#91;[**&lt;issue-numbers&gt;**](#audit-selection)&#93;))' > '[**&lt;issues-json-file&gt;**](#issue-collection)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=closed&per_page=100" --jq '.&#91;&#93; | select(&#91;.number&#93; | inside(&#91;637, 943, 946&#93;))' > closed-issues.json
</pre></big>

### Find Initiative Issue

Prints an initiative's issue number, found by its title's prefix.

**Inputs:** [Repository](#repository), [Tracker Prefix](#tracker-prefix).

**Outputs:** [Identity](#identity), [Tracker Number](#tracker-number).

#### 1. Find Initiative Issue

Run this command from the repository checkout with the supplied inputs.

`<initiative-prefix>` includes the initiative id and its enclosing brackets.

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=all&per_page=100" --jq '.&#91;&#93; | select(.pull_request == null) | select(.title | startswith("[**&lt;initiative-prefix&gt;**](#tracker-prefix)")) | .number'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**&lt;owner&gt;**](#repository)/[**&lt;repo&gt;**](#repository)/issues?state=all&per_page=100" --jq '.&#91;&#93; | select(.pull_request == null) | select(.title | startswith("&#91;I08&#93;")) | .number'
</pre></big>

### List Prefixed Titles

Lists titles carrying one kind's prefix letter, across all states.

**Inputs:** [Repository](#repository), [Tracker Prefix](#tracker-prefix).

**Outputs:** [Tracker Prefix](#tracker-prefix).

#### 1. List Prefixed Titles

Run this command from the repository checkout with the supplied inputs.

<big><pre>
gh api --paginate 'repos/[**&lt;owner&gt;**](#repository)/[**&lt;repository&gt;**](#repository)/issues?state=all&per_page=100' --jq '.&#91;&#93; | select(.title | test("^\\&#91;[**&lt;prefix-letter&gt;**](#tracker-prefix)&#91;0-9&#93;{2}\\&#93;")) | .title'
</pre></big>

**Example:** Initiatives in one repository.

<big><pre>
gh api --paginate 'repos/m2ux/workflow-server/issues?state=all&per_page=100' --jq '.&#91;&#93; | select(.title | test("^\\&#91;I&#91;0-9&#93;{2}\\&#93;")) | .title'
</pre></big>

## Fields

### Identity

The issue has its repository, number and URL. A new issue has its repository before creation supplies its number and URL.

### Content

The saved title, body and labels equal the supplied values.

### Discussion

The issue's comments, in saved order. A saved comment preserves the supplied text.

### State

The issue is open or closed with its recorded completion reason. Completed work satisfies its criteria and delivery checks; transferred work identifies the issue tracking it.

### Auto-Close Setting

GitHub's **Auto-close issues with merged linked pull requests** repository setting, which must be disabled before a delivery pull request is linked or merged, so that closure follows the criteria rather than the merge.

- The setting is confirmed per repository and holds for the session; it is not inferred from an issue that stayed open.
- No REST field and no GraphQL field of `gh` 2.46 carries it, so on such a host the user's explicit answer is the only source.
- An enabled or unconfirmed setting blocks delivery links and merges until the setting is confirmed disabled. Changing the setting requires the user's explicit authorization.
- The setting gates the links and merges that precede closure; the closure gate takes no input from it.

### Repository

The tracker repository owner and name. Commands use these supplied values as owner and repo, or repository.

### Issue Record

The complete current tracker issue JSON at the supplied local path, carrying its [Identity](#identity), [Content](#content) and [State](#state).

### Output Files

The supplied local destinations for the requested issue, body, discussion, collection or Development evidence.

### Closure Evidence Paths

The absolute local destinations for the current issue JSON and complete Development snapshot.

### Discussion Selection

Whether the supplied request needs the issue discussion.

### Issue Changes

The supplied complete body file, title and labels for creation, or the selected body and metadata changes for an existing issue, with an optional comment file.

### Label Names

The supplied repository label names for creation, addition or removal. An assignment names an existing repository label.

### Comment

The supplied exact comment text, as one line or a complete local file, with the reviewer identity and addressed feedback for a reply. A posted comment also has its saved URL.

### Delivery Evidence

The normal delivery result supplied by the caller, with its check results, criterion evidence and linked delivery records.

### Transfer Evidence

The supplied destination issue record, its destination reference and accompanying comment file.

### Authenticated Access

Authenticated access to the repository and its issue Development relations.

### Development Snapshot

A complete issue-links file, keyed by issue number and carrying its repository identity. Each issue maps to all Development pull requests across repositories and states, or an empty array after a complete empty read.

### Issue Collection

One supplied tracker issue JSON or a collection of issue records. Pull request entries carry a pull_request field.

### Audit Selection

The supplied issue numbers to audit, separated by commas, or the selection of every closed issue in the repository.

### Closure Findings

The closure gate verdict or the sweep results, retaining each issue identity, state reason and finding, with execution failures identified.

### Tracker Prefix

The supplied kind prefix letter, initiative prefix or existing prefixed titles. An initiative prefix includes the initiative id and its enclosing brackets.

### Tracker Number

The resolved two-digit tracker number, or an unresolved identity when lookup fails.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.

### Issue Body

The current issue body as text, saved at the supplied local Markdown path when requested without the surrounding issue record.
```

## 024-epic-body

Exit: 0; receipt: [024-epic-body.json](receipts/024-epic-body.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic-issue-body.md
```

Returned output:

```text
# Epic Issue Body

Populates one epic body. The body states one slice of the design and lists the tasks that deliver it.

## Prerequisites

Read these files first.

- [Lane](lane.md)
- [Issue Body](issue-body.md)
- [Pull Request](pull-request.md)
- [Epic](epic.md)
- [Issue](issue.md)
- [Dependency Graph](dependency-graph.md)
- [Delivery Plan](delivery-plan.md)

## Operations

### Populate Epic Issue Body

One epic body and its local validation findings.

**Inputs:** [Initiative Context](#initiative-context), [Draft Metadata](#draft-metadata), [Task Rows](#task-rows), [Pull Request Records](#pull-request-records), [Project Checkout](#project-checkout), [Evaluated Revision](#evaluated-revision), [Output Body](#output-body).

**Outputs:** [Row Result](#row-result), [Validation Findings](#validation-findings), [Output Body](#output-body).

#### 1. Populate Epic Template

Populate the body from the [Template](#template) at the supplied output path.
- Every section must meet [Fields](#fields).
- Shared content must meet the common [body conditions](issue-body.md#fields).

#### 2. Populate Shared Table

Apply [Write Issue Table](issue-body.md#write-issue-table) with the supplied row data.

#### 3. Fill Epic Cells

Fill the epic-specific cells.
- Each row must meet [Work Breakdown](#work-breakdown).
- Apply [Assign Task Lanes](lane.md#assign-task-lanes) with the populated body, confirmed task-to-index map and output path.

#### 4. Build Draft Snapshot

Apply [Build Body Snapshot](issue-body.md#build-body-snapshot) with the draft body, title, labels and existing issue JSON when present.

#### 5. Validate Draft Body

Apply [Validate Epic Body](#validate-epic-body) with that snapshot, initiative context, available pull request records, project checkout, evaluated revision and output file.

#### 6. Identify Pending Links

Identify unresolved publication links separately; they remain pending until tracker identities exist.

#### 7. Return Draft Findings

Return the draft rows, their dependency references and the validation findings for the caller's cross-body ordering check.

### Record Epic Delivery

One epic body with supplied delivery matches and completed rows recorded.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Task Records](#task-records), [Delivery Matches](#delivery-matches), [Project Checkout](#project-checkout), [Epic Bases](#epic-bases), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Delivery Findings](epic.md#delivery-findings).

#### 1. Record Supplied Matches

Apply [Sync Epic](#sync-epic), mapping pull requests to `--prs`, links to `--links`, task issues to `--tasks`, each confirmed match to `--link`, the checkout to `--project`, each fetched epic base to a `--revision` and the output file to `--fix`.
- Row changes must meet [Task Delivery](#task-delivery) and [Work Breakdown](#work-breakdown).

#### 2. Return Updated Body

Return the updated body and [Delivery Findings](epic.md#delivery-findings) for the caller to resolve and publish. An unmerged epic base prevents a closable result.

### Record Epic Criteria

Verified criteria and completed rows in one epic body.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Criterion Selection](#criterion-selection), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Criterion Selection](#criterion-selection).

#### 1. Record Verified Criteria

Apply [Tick Epic Criteria](#tick-epic-criteria) with the epic JSON, records as `--prs`, snapshot as `--links`, verified ids as `--tick` and output as `--fix`. Refuse criteria not ready to verify.

#### 2. Return Criterion Disposition

Return the body and refused criteria.

### Reserve Task Rows

Task rows held for one confirmed delivery session.

**Inputs:** [Epic Record](#epic-record), [Task Selection](#task-selection), [Board Items](#board-items), [Planning Folder](#planning-folder), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Row Result](#row-result).

#### 1. Require Reservable Unit

Require the caller's confirmed unit and existing planning folder. Refuse a row already held or linked to a pull request or commit, and a unit [Work Units](delivery-plan.md#work-units) does not admit.

#### 2. Reserve Complete Unit

Apply [Reserve Row](#reserve-row) with the epic as `--epic`, every id of the unit as `--reserve`, the board items as `--items`, supplied base URL as `--records`, record date as `--date` and output as `--fix`.

#### 3. Return Reserved Body

Return the reserved body meeting [Task Delivery](#task-delivery).

### Release Task Rows

Held task rows returned to their work-item links.

**Inputs:** [Epic Record](#epic-record), [Task Selection](#task-selection), [Engineering Worktree](#engineering-worktree), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Row Result](#row-result).

#### 1. Require Release Decision

Require the supplied release decision and refuse any row that is not held.

#### 2. Release Complete Unit

Apply [Release Row](#release-row) with the epic as `--epic`, every id of each released unit as `--release`, the engineering worktree as `--engineering` and output as `--fix`.

#### 3. Return Released Body

Return the released body meeting [Task Delivery](#task-delivery).

### Validate Epic Body

The body's local format and field findings.

**Inputs:** [Epic Record](#epic-record), [Initiative Context](#initiative-context), [Pull Request Records](#pull-request-records), [Project Checkout](#project-checkout), [Evaluated Revision](#evaluated-revision), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Validation Findings](#validation-findings).

#### 1. Read Changed Paths

For each epic pull request reaching a branch the project's [Required Criteria](#required-criteria) declare, Apply [Read Pull Request State](pull-request.md#read-pull-request-state) to read its changed paths.

#### 2. Validate Kind Conditions

Apply [Validate Issue Body](issue-body.md#validate-issue-body) with the current body, local [Fields](#fields), supplied related evidence and output file, supplying initiative JSON as `--initiative`, pull requests as `--prs`, each pull request's changed paths as `--files <number>=<changed-paths-file>`, the checkout as `--project` and the revision as `--revision`.
- The evaluated revision is the epic's base on the long-lived branch that holds the project's configuration, such as `origin/i07/e00/workspace`, or that branch itself, such as `origin/workspace`, while the epic has no base on it. Fetch it before the check reads it.

#### 3. Read Delivery Reach

Read reach from each epic pull request's base, through an epic base or initiative branch. Without pull requests, no criterion is lacking.

#### 4. Identify Required Criteria

Include in the findings each [Required Criteria](#required-criteria) criterion an epic lacks whose work changes the criterion's paths on its branch, required criteria the declaration or the changed paths leave unevaluable, and any epic criterion no task row delivers.

#### 5. Return Local Findings

Return the corrected body, mechanical diff and unresolved findings for the caller.

### Revise Epic Rows

One epic body with confirmed task-grain and coverage corrections.

**Inputs:** [Epic Body](#epic-body), [Task Rows](#task-rows), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Validation Findings](#validation-findings).

#### 1. Apply Confirmed Changes

Apply [Populate Epic Issue Body](#populate-epic-issue-body) with the confirmed row changes, preserving unrelated content.
- Description, Coverage, Depends on, Joins, Lane and task grain must meet [Work Breakdown](#work-breakdown).
- Split a task exceeding the allowed criterion grain into the confirmed tasks.

#### 2. Return Revised Body

Return the revised body and any cross-body numbering or dependency changes for the caller.

### Plan Gap Task

The agreed disposition of criteria a delivered row left unmet.

**Inputs:** [Epic Record](#epic-record), [Epic Body](#epic-body), [Task Rows](#task-rows), [Criterion Selection](#criterion-selection), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Project Checkout](#project-checkout), [Epic Bases](#epic-bases), [Output Body](#output-body).

**Outputs:** [Row Result](#row-result).

#### 1. Resolve Unmet Criteria

Present each unmet criterion and its missing evidence to the user.
- Return the criteria the user confirms already hold to the caller for verification and ticking. The delivered task retains them.
- Record an unanswered decision as pending.
- If no criteria need further work, return the pending findings to the caller.
- Continue to the draft step with only the criteria the user confirms need further work.

#### 2. Confirm Further Task

Draft a further task for the criteria selected for further work, meeting [Work Breakdown](#work-breakdown).
- Confirm the draft with the user.
- On acceptance, Apply [Revise Epic Rows](#revise-epic-rows) with the further row and the criteria it adopts from the delivered task's Coverage.
- Return an unanswered draft as pending without continuing to the reconcile step.

#### 3. Reconcile Revised Delivery

Apply [Record Epic Delivery](#record-epic-delivery) with the revised epic, the supplied delivery evidence, the project checkout and the fetched epic bases.
- Apply [Save Tracker Issue](issue.md#save-tracker-issue) with the returned body.
- Return the saved row and criterion disposition to the caller.

### Sync Epic

Links each named task's id to the pull requests naming the epic it is delivered through, open or merged, and ticks Done on a row once it is complete.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Task Records](#task-records), [Delivery Matches](#delivery-matches), [Project Checkout](#project-checkout), [Epic Bases](#epic-bases), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Delivery Findings](epic.md#delivery-findings).

#### 1. Sync Epic

Run this command from the workspace checkout with the supplied inputs.

- A row whose id links its task issue links the pull request instead.
- A pull request whose head is an epic base is the pull request that merges that base, and is not matched to a task.
- An unmerged epic base keeps the epic open, even when every row is delivered and every criterion is ticked.
- An epic base is reported `draft` only where it holds a commit its long-lived branch lacks. The base is read at the `--revision` naming it and the long-lived branch beside it on the same remote, so `origin/i07/e00/main` is compared with `origin/main`; a base no `--revision` names is reported `unevaluable`.
- `--project` is a checkout of the project and each `--revision` one of the epic's bases, such as `origin/i07/e00/main`. The long-lived branch names are the ones `config/branches` states at those commits, and each `source` line names a path, commit and repository.
- An absent, empty or unreadable statement, and statements that disagree across the bases, are reported `unevaluable` with their source. Without the long-lived branch names, the run names each check it did not make as `not checked`, and an epic that would otherwise be closable is not.
- An open review pull request's Changes paths are read at its head commit in the `--project` repository: a path with a directory stands where the head holds a file or a directory at it, and a bare file name anywhere in the tree. A head commit the repository does not hold is reported `unevaluable`.
- Passed checks settle criteria under [Test Evidence](#test-evidence).
- `--link` names each task id and the pull request number it links. An id repeats once for each pull request, one per long-lived branch its unit changes. The row keeps the deliveries it links in place and gains each named one it lacks, so a repeated run leaves it unchanged. `--tasks` is the task issues. `--links` is the pull requests' Development-linked issues. `--fix` is the body written with the Done ticks.

`<task-pull-request-map>` is a comma-separated list of `<task-id>=<pull-request-number>` pairs, with a pair for each pull request a task id links. Pass each task JSON file as a separate argument after `--tasks`.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py '[**&lt;epic-json-file&gt;**](#epic-record)' --prs '[**&lt;pull-request-records-file&gt;**](#pull-request-records)' --links '[**&lt;issue-link-snapshot-file&gt;**](#issue-links)' --tasks '[**&lt;task-json-file&gt;**](#task-records)' --link '[**&lt;task-pull-request-map&gt;**](#delivery-matches)' --project '[**&lt;checkout&gt;**](#project-checkout)' --revision '[**&lt;epic-base-revision&gt;**](#epic-bases)' --fix '[**&lt;output-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py issue-943.json --prs prs.json --links links.json --tasks issue-637.json --link W01=950,W01=951,W02=950 --project '[**&lt;checkout&gt;**](#project-checkout)' --revision origin/i07/e00/main --revision origin/i07/e00/workflows --fix fixed-943.md
</pre></big>

### Tick Epic Criteria

Ticks confirmed epic criteria, refusing any not ready to verify, and ticks completed rows.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Criterion Selection](#criterion-selection), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Criterion Selection](#criterion-selection).

#### 1. Tick Epic Criteria

Run this command from the workspace checkout with the supplied inputs.

`<criterion-ids>` is a comma-separated list of verified criterion ids.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py '[**&lt;epic-json-file&gt;**](#epic-record)' --prs '[**&lt;pull-request-records-file&gt;**](#pull-request-records)' --links '[**&lt;issue-link-snapshot-file&gt;**](#issue-links)' --tick '[**&lt;criterion-ids&gt;**](#criterion-selection)' --fix '[**&lt;output-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py issue-943.json --prs prs.json --links links.json --tick AC1,AC3 --fix fixed-943.md
</pre></big>

### Reserve Row

Holds each named unit for one session, by setting its record folder as the single link of every row in it.

**Inputs:** [Epic Record](#epic-record), [Task Selection](#task-selection), [Board Items](#board-items), [Planning Folder](#planning-folder), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Row Result](#row-result).

#### 1. Reserve Row

Run this command from the workspace checkout with the supplied inputs.

- `--items` is the board's items with Status.
- `--records` is the URL of the planning records folder, needed when no row id in the epic links a record.
- The caller supplies the planned folder identity; `--date` is the day it is opened.
- The folder is the one the unit's first task id and Description give it, as the available-work report's `unit` line names it. A call naming some rows of a joined unit and not the others is refused.

`<task-ids>` is a comma-separated list of task ids; `<records-base-url>` identifies the planning records folder.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deliver.py --epic '[**&lt;epic-json-file&gt;**](#epic-record)' --reserve '[**&lt;task-ids&gt;**](#task-selection)' --items '[**&lt;board-items-file&gt;**](#board-items)' --records '[**&lt;records-base-url&gt;**](#planning-folder)' --fix '[**&lt;output-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deliver.py --epic issue-943.json --reserve W01,W02 --items items.json --records 'https://github.com/[**&lt;owner&gt;**](#planning-folder)/[**&lt;repo&gt;**](#planning-folder)/tree/engineering/artifacts/planning' --fix fixed-943.md
</pre></big>

### Release Row

Frees each named task row, by replacing the planning-folder link with its work-item file link.

**Inputs:** [Epic Record](#epic-record), [Task Selection](#task-selection), [Engineering Worktree](#engineering-worktree), [Output Body](#output-body).

**Outputs:** [Output Body](#output-body), [Row Result](#row-result).

#### 1. Release Row

Run this command from the workspace checkout with the supplied inputs.

- The file is the task id in lowercase within that folder, as [Task ids](#task-delivery) defines.
- `--engineering` is the checkout holding the planning records. A row whose folder there holds no such file, or whose README does not link it, is refused.
- A call naming some rows of a joined unit and not the others is refused.

`<task-ids>` is a comma-separated list of task ids.

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deliver.py --epic '[**&lt;epic-json-file&gt;**](#epic-record)' --release '[**&lt;task-ids&gt;**](#task-selection)' --engineering '[**&lt;engineering-worktree&gt;**](#engineering-worktree)' --fix '[**&lt;output-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/deliver.py --epic issue-943.json --release W01 --engineering .engineering --fix fixed-943.md
</pre></big>

## Fields

### Template

````markdown
## Overview

{{One paragraph: what this epic delivers and why it exists within the initiative.}}

## Problem

{{The friction as it is now. Bullets for distinct facets, sub-bullets for several items.}}

## Proposal

{{The design, in bullets or paragraphs, each opening with a bold statement, and its body on the next line.}}

## Work Breakdown

| Task | Description | Coverage | Depends on | Joins | Lane | Done |
| --- | --- | --- | --- | --- | --- | --- |
| W01 | {{What the task delivers, at most eight words}} | AC{{n}}, AC{{m}} | {{Earlier task in this epic, [Exx:Wyy](…) or [Exx](…) in an earlier epic, or #issue}} | {{Tasks that can land in the same pull request}} | {{Lane index, or empty}} | |

## Acceptance Criteria

- [ ] **AC1.** {{An end state of one invariant. It ends by naming its instrument.}}

## Open Questions

- {{An undecided point the epic cannot start without, with a recommendation in the planning record. Resolve every one before the first task starts, then delete the section.}}

## References

- **R1.** [Planning record]({{PLANNING_RECORD_URL}}) — {{What the reader finds there.}}
````

### Titles

- The title is `[I07:E00] Name: Subtitle`. Its prefix matches its row in the initiative table.
- Labels are `type:epic` and its initiative's `theme:*`.
- `E` is the epic within its initiative. Epics count from `00`.
- The prefix separates levels with colons, then a short name, a colon, and a subtitle: `[I07:E06] Reliability Evaluation: Briefs, Measures and the Thresholds That Define Reliable`.

### Proposal

- A boundary with a sibling epic is plain language.

### Work Breakdown

New tasks exist as epic rows with their details, discussion and evidence in the epic and planning record. Planning creates no separate task issues. Existing issues hoisted into an epic retain their records and row links when new tasks are planned.

The columns are `Task | Description | Coverage | Depends on | Joins | Lane | Done`.

- **Done.**
  A task row is complete when it is delivered, and every criterion its Coverage names is ticked.
- **Row id.**
  The row id is the task, `W01`. `W00` holds preparatory work that must land before the first real task.
- **Description.**
  Each detail beyond the phrase is a criterion stating one invariant.
- **Coverage.**
  Coverage names the epic's criteria the task delivers, whether its Done cell is ticked or empty. Each row claims only criteria its work makes true; it cannot claim a criterion another row delivers alone or one its work cannot meet. A cell is empty only on a delivered task whose criteria a further task adopts, as task grain states.
- **Depends on.**
  A task row names the rows it depends on. An earlier task in the epic (`W03`, `W04–W09`), a row of an earlier epic (`[E01:W02](…)`), or something outside the initiative (`#750`, `[I05:E00:W02](…)`).
  - A task row names rows, never an epic. It names the row producing each output it consumes (`[E01:W01](…), [E01:W02](…)`), and where the task consumes from every row of an epic that is what establishes the whole-epic reach.
  - Cross-epic dependencies name rows before any issue of the epic is created. Both tables exist, and each edge names the row that produces what the dependent row consumes.
  - A dependency listed twice or already implied by another in the cell is unsound. A task that measures, extends or consumes another task's output depends on it, even when the prose does not say so.
- **Task grain.**
  - A task is one pull request's worth of work.
  - A criterion a merged pull request left unticked belongs to a further task. The further task depends on the delivered task, and its Coverage is that criterion. Criteria one pull request can deliver share one further task. The delivered task's Coverage omits each criterion a further task adopts.
  - A task delivering more than three criteria is split into tasks one pull request each can deliver.
  - A task covers at least one acceptance criterion. A criterion more than one row cites is imprecise: it is split into the invariant each task makes true, and each is cited from the row that delivers it.
  - Every test the work calls for accompanies that task. The content steers which kinds those are, including the project's system test when the work is something that test can exercise. A failure in any test the task carries keeps the task open. None of those tests is a later row.
  - Reusable routines, techniques, and resources are specced, created, and tested before an activity binds them. The grain of an existing resource is in that work.
  - When the behaviour a wired activity produces differs from the behaviour the work expected, that task changes the routine, technique, or resource, and the tests that cover the change, until fit, form, and function hold.
- **Joins.**
  The tasks that share one pull request. Two tasks sharing one name each other, and tasks linked by such pairs are one joined unit.
  - A joined unit holds no Depends on between its members: the pull request orders their commits.
  - Only a path between two members through a task outside the unit bars a join.
  - A joined unit covers at most six criteria, two full rows' worth, so it stays one pull request's worth.
  - Joins are complete before any issue of the epic is created. Each candidate unit, the rows declaring one component, is answered as [Joins](dependency-graph.md#joins) states.
  - An empty cell is a task that shares no pull request.
- **Lane.**
  The row's delivery lane meets [Assignments](lane.md#assignments).
- **Numbering.**
  Task numbering meets [Numbering](issue-body.md#numbering); a row whose id links a pull request is fixed.
- **Reference form.**
  A table reference uses colons (`E01:W03`, `I05:E00:W02`), and every epic reference links to that epic's issue: `[E01:W03](…/issues/937)`. Prose uses a space (`E01 W03`).

### Test Evidence

A criterion receives an automatic tick when every task covering it is delivered and supplies an observing check in its linked pull requests. Every observing check must pass in a merged pull request; absent records, unreadable plans and incomplete checks supply no verification. Evidence applies only to the linked task's Coverage. Existing ticks are preserved, and explicitly verified criteria remain subject to delivery readiness.

### Acceptance Criteria

An epic criterion meets the [shared acceptance criteria](issue-body.md#shared-acceptance-criteria). Contradictions between criteria in one epic are findings.

### Open Questions

Each question holds only what is undecided and has a recommendation in the planning record. A settled point belongs in that record. No question remains when the epic starts.

### Required Criteria

A project states the criteria its epics must carry in `config/required-criteria.json` at its root. The file is a JSON array, and each entry is one required criterion with these fields, each a non-empty string except `paths`:

| Field | What it states |
| --- | --- |
| `branch` | The long-lived branch the criterion's work reaches. |
| `paths` | A non-empty list of files and directories on `branch`. An epic carries the criterion when a pull request of its work reaching `branch` changes a file that is one of them or lies under one. |
| `criterion` | The criterion's text, which the epic carries after its `**ACn.**` label. |
| `phrase` | A phrase identifying the criterion in an epic that carries it, matched without regard to case. |
| `row` | The Description of the task row that delivers the criterion. |

- **The declared row delivers the criterion.**
  It carries the declared `row` as its Description, depends on the rows whose work changes the declared paths, and covers that criterion alone.
- **The tracker states what the work changes.**
  The check reads each pull request's changed files as the tracker lists them. A pull request reaching the declared branch whose changed files are not supplied leaves the criterion unevaluable, unless another pull request of the epic is known to change a declared path.
- **The evaluated commit holds the statement.**
  The check reads the file at the commit its evaluated revision resolves to, in the repository its checkout locates, and names that path, commit and repository as its source. Which worktree the checkout is, and what its working files hold, choose nothing.
- **A project declaring nothing requires nothing.**
  A missing or empty file at the evaluated commit, or an empty array, declares no required criterion, and the check reports none. A project declaring nothing acquires no other project's criteria.
- **An unreadable statement is unevaluable.**
  A revision resolving to no commit, unreadable JSON, a value other than an array, or an entry lacking a field or stating `paths` as anything but a non-empty list of non-empty strings leaves the project's required criteria unevaluable. The check reports that and names the fault, and reports no epic as lacking a criterion.
- **Example.**
  workflow-server requires its corpus audit of work that changes the workflow definitions under `corpus` on `workflows`:

  ```json
  [
    {
      "branch": "workflows",
      "paths": ["corpus"],
      "criterion": "The definitions this epic changes carry no outstanding confirmed finding, one neither fixed on the epic's branch nor taken by an issue, as the canon audit's coverage report shows.",
      "phrase": "canon audit",
      "row": "Canon audit of the changed definitions"
    }
  ]
  ```

### Task Delivery

- **Task ids.**
  - An unreserved task awaiting its pull request links its file in the planning record: `[W01](…/w01.md)`. The file name is the task id in lower case.
  - Every link on a task row names that row's id, and the row carries one delivery per long-lived branch its unit changes. A reserved task links only its planning folder: `[W01](…/2026-10-06-943-i07-e00-w01-queue-plan/)`. Every row of a joined unit links the one folder its first row names. The folder's README links each work-item file by the name the row's link carries. Releasing the reservation points the row to that file.
  - Once a pull request is open, its link replaces the planning link: `[W01](…/pull/950)`. A unit changing two long-lived branches links the pull request on each: `[W01](…/pull/950), [W01](…/pull/951)`. Further delivery work on one of those branches gets another task row under Task grain. Joined rows each link their shared pull request.
  - The task is delivered when a linked pull request has merged, or its id links a commit.
  - A link to an open pull request does not deliver the task.
  - A linked pull request whose title names another epic delivers the task once it has merged. The mismatch is reported, and the row stays open while a criterion its Coverage names is unticked.
- **Tasks with their own issue.**
  - A task issue belongs to one epic. Its title carries that epic's prefix.
  - When that epic's table has no row for its id, the issue is unplaced. Once the row exists, that epic's planning manages the issue.
  - The row links the pull request, not the issue.
  - The pull request's Development field links the issue as [Issue Links](pull-request.md#issue-links) state.
  - A completed task issue has all criteria verified and every Development-linked pull request merged.
- **Issues backing several tasks.**
  An issue backing several tasks, such as an investigation, is a reference: the epic cites it under References, no row id links it, and its title carries no agent-engineering prefix.
- **Work another issue takes.**
  It leaves the table. Its criteria go with it, or to another row that delivers them.

### Breakdown Prose

Work Breakdown contains its table. Explanatory prose belongs in Proposal. The body does not narrate execution order or how the tables work; Depends on carries the order.

### Epic Record

The supplied complete current epic issue JSON.

### Initiative Context

The supplied current initiative context, epic scope and criteria.

### Task Rows

The proposed task rows or confirmed row changes, including descriptions, Coverage, dependencies, Joins, task grain and optional lane indices. Cross-body dependency references and field findings accompany a revision.

### Pull Request Records

The supplied current pull request records for the epic.

### Issue Links

The complete supplied issue-link snapshot.

### Task Records

The supplied task issue JSON files.

### Delivery Matches

The confirmed task-to-pull-request matches supplied by the caller.

### Project Checkout

The supplied project checkout.

### Evaluated Revision

The fetched revision supplied for evaluation at the project checkout.

### Epic Bases

The fetched epic bases supplied for recording delivery, each identified by its revision.

### Output Body

The supplied local output path for the complete body.

### Criterion Selection

The supplied verified criterion ids, or the unmet criterion ids and their delivery evidence for gap planning.

### Task Selection

The confirmed task ids for the selected delivery units. A release selection also carries the supplied explicit user decision releasing the hold.

### Board Items

The supplied current board items, including Status.

### Planning Folder

The existing supplied planning-folder identity, planning-records base URL and the date the record is opened.

### Engineering Worktree

The supplied engineering checkout containing the planning records.

### Validation Findings

The corrected body, mechanical diff and unresolved local or cross-body field findings, including pending publication links.

### Row Result

The resulting task rows, dependency references and their reservation, release or criterion disposition, with any pending decisions.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.

### Epic Body

The supplied complete current epic body text.

### Draft Metadata

The supplied draft title and labels, with the existing complete issue JSON when one is available for the body snapshot.
```

## 025-delivery-branches

Exit: 0; receipt: [025-delivery-branches.json](receipts/025-delivery-branches.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/delivery-branches.md
```

Returned output:

```text
# Delivery Branches

The long-lived branches, epic bases and task branches used for delivery.

## Prerequisites

Read these files first.

- [Work Item](work-item.md)
- [Hot-fix](hotfix.md)

## Operations

### Prepare Delivery Bases

The branches a task pull request targets.

**Inputs:** [Project Checkout](#project-checkout), [Epic Identity](#epic-identity), [Changed Branches](#changed-branches), [Prerequisite Evidence](#prerequisite-evidence).

**Outputs:** [Epic-Base Names](#epic-base-names), [Failure](#failure).

#### 1. Read Changed Branches

For each changed long-lived branch, Apply [Fetch Remote Branch](#fetch-remote-branch) in the project checkout, then Apply [List Long-Lived Branches](#list-long-lived-branches) with `--project` set to the checkout and `--revision` to that remote branch, such as `origin/main`, as [Branches](#branches) names for base preparation.

#### 2. List Existing Epic Bases

Apply [List Epic Bases](#list-epic-bases) in the project checkout for the epic.

#### 3. Resolve Missing Branch Configuration

If `config/branches` is missing or empty at that revision, or does not name the changed branch:
- Report the names as unevaluable at that revision.
- Obtain the project's branch names before creating delivery branches.

#### 4. Require Confirmed Prerequisites

Require the caller's confirmed prerequisite evidence before creating a base. The board status alone supplies no such evidence.

#### 5. Create Missing Epic Bases

Apply [Create Epic Base](#create-epic-base) in the project checkout for each missing base, passing the corresponding long-lived branch, epic base name and confirmed prerequisite evidence.

### Create Epic Base

The missing epic branch rooted in its remote long-lived branch.

**Inputs:** [Project Checkout](#project-checkout), [Source Branch](#source-branch), [Epic-Base Name](#epic-base-name), [Prerequisite Evidence](#prerequisite-evidence).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Require Missing Destination

Require the confirmed prerequisites and a missing destination. Refuse a destination that already exists.

#### 2. Fetch Long-Lived Source

Apply [Fetch Remote Branch](#fetch-remote-branch) in the project checkout with the corresponding long-lived source branch, such as `main`.

#### 3. Publish Missing Epic Base

After a successful fetch:
- Apply [Publish Epic Base](#publish-epic-base) in the project checkout with that remote source and the missing epic base name, such as `i07/e00/main`, meeting [Epic Bases](#epic-bases).
- Return the created branch or the failure.

### Update Epic Base

The current long-lived target merged into an epic base.

**Inputs:** [Project Checkout](#project-checkout), [Epic-Base Name](#epic-base-name).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Resolve Epic Target

Take the long-lived target and the epic base checkout's path from the base name, meeting [Epic Bases](#epic-bases).

#### 2. Fetch Current Epic Base

Apply [Fetch Remote Branch](#fetch-remote-branch) in the project checkout with that epic base; stop on failure.

#### 3. Prepare Epic Base Checkout

Apply [Add Epic Base Worktree](#add-epic-base-worktree) in the project checkout for an absent epic base checkout, and reuse an existing one; stop on failure, which a base checked out elsewhere returns.

#### 4. Fetch Long-Lived Target

Apply [Fetch Remote Branch](#fetch-remote-branch) in the epic base checkout with the long-lived target, such as `main`; stop on failure.

#### 5. Merge Current Target

Apply [Merge Remote Branch](#merge-remote-branch) in the epic base checkout with the target branch name, such as `main`, to merge `origin/main`. A conflict stops the update, leaves the pull request open and is reported.

#### 6. Publish Updated Epic Base

After a successful merge:
- Apply [Push Epic Base](#push-epic-base) in the epic base checkout.
- Return the updated branch or the failure.

### Update Task Branch

The current base merged into a unit's task branch.

**Inputs:** [Unit Checkout](#unit-checkout), [Task Branch](#task-branch), [Base Branch](#base-branch).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Fetch Current Task Base

Apply [Fetch Remote Branch](#fetch-remote-branch) in the unit checkout with the base, such as `i07/e00/main`.

#### 2. Stop on Fetch Failure

Stop on failure.

#### 3. Merge Current Task Base

Apply [Merge Remote Branch](#merge-remote-branch) in the unit checkout with the base name, such as `i07/e00/main`, to merge `origin/i07/e00/main`. A conflict stops the update, leaves the pull request open and is reported.

#### 4. Publish Updated Task Branch

After a successful merge:
- Apply [Push Task Branch](#push-task-branch) in the unit checkout with the task branch as destination.
- Return the updated branch or the failure.

### Create Task Worktree

The worktree and branch one unit's session works in.

**Inputs:** [Project Checkout](#project-checkout), [Worktree Path](#worktree-path), [Task Branch](#task-branch), [Base Branch](#base-branch), [Prerequisite Evidence](#prerequisite-evidence).

**Outputs:** [Worktree Result](#worktree-result), [Failure](#failure).

#### 1. Require Unit Prerequisites

Require the supplied prerequisites and names meeting [Task Branches](#task-branches).

#### 2. Fetch Task Base

Apply [Fetch Remote Branch](#fetch-remote-branch) in the project checkout of the repository the work changes, passing the base; stop on failure.

#### 3. Add Unit Worktree

Apply [Add Task Worktree](#add-task-worktree) in the project checkout with the supplied path and task branch, rooted in the fetched base.

#### 4. Return Unit Checkout

Return the worktree path, branch and base, or the failure.

A unit that changes several long-lived branches runs this once for each epic base, with the branch and worktree [Task Branches](#task-branches) names for it.

### Create Pull Request Worktree

The detached worktree where the graph reads the reviewed change.

**Inputs:** [Project Checkout](#project-checkout), [Pull Request Number](#pull-request-number), [Verified Head](#verified-head).

**Outputs:** [Worktree Result](#worktree-result), [Failure](#failure).

#### 1. Fetch Verified Review Head

Apply [Fetch Review Head](#fetch-review-head) in the project checkout of the repository the pull request changes, passing its number; stop on failure.

#### 2. Resolve Fetched Review Commit

Apply [Read Checkout Revision](#read-checkout-revision) on the project checkout for `FETCH_HEAD`.

#### 3. Check Verified Head

If it differs from the verified head, return a changed-head finding before creating a worktree.

#### 4. Place Review Worktree

Take the worktree path from the pull request number, meeting [Review Worktrees](#review-worktrees).

#### 5. Check Existing Review Worktree

If that worktree already exists:
- Apply [Read Checkout Revision](#read-checkout-revision) in that review checkout for `HEAD`.
- Apply [Read Checkout Status](#read-checkout-status) there.
- Reuse it only at the verified head and when its status reports detached HEAD with no tracked or untracked changes.
- Otherwise retain it and select an unused path suffixed with the verified commit.

#### 6. Add Detached Review Worktree

For an unused path, Apply [Add Review Worktree](#add-review-worktree) in the project checkout with that path and the verified commit.

#### 7. Confirm Review Checkout Head

Apply [Read Checkout Revision](#read-checkout-revision) in the selected review checkout for `HEAD` to confirm its commit.

#### 8. Return Review Checkout

Return the selected detached worktree path and head, or the discrepancy before measuring.

### Read Target Requirements

The protection and active rules governing one target branch.

**Inputs:** [Repository](#repository), [Target Branch](#target-branch), [Output Files](#output-files).

**Outputs:** [Target Requirements](#target-requirements), [Failure](#failure).

#### 1. Fetch Target Protection

Apply [Fetch Branch Protection](#fetch-branch-protection) for the supplied target.

#### 2. Fetch Active Target Rules

Apply [Fetch Active Branch Rules](#fetch-active-branch-rules) for the same target.

#### 3. Return Target Requirements

Return both records. An unreadable requirement remains unresolved; a protection 404 does not establish the absence of active rules.

### Read Delivery Branches

The configured long-lived branches and existing epic bases.

**Inputs:** [Project Checkout](#project-checkout), [Epic Identity](#epic-identity), [Revision](#revision).

**Outputs:** [Branch Names](#branch-names), [Epic-Base Names](#epic-base-names), [Failure](#failure).

#### 1. Read Declared Branch Names

Apply [List Long-Lived Branches](#list-long-lived-branches) with the supplied checkout and revision. Absent, empty or unreadable configuration at that revision leaves branch names unevaluable, reported with its source.

#### 2. List Current Epic Bases

Apply [List Epic Bases](#list-epic-bases) in the project checkout for the supplied epic.

#### 3. Return Delivery Branches

Return both collections and any missing configuration.

### List Epic Bases

Prints one epic's base branch names, one per line.

**Inputs:** [Project Checkout](#project-checkout), [Epic Identity](#epic-identity).

**Outputs:** [Epic-Base Names](#epic-base-names), [Failure](#failure).

#### 1. List Epic Bases

**Acts on:** the checkout it runs in.

- A base is `<epic-branch-prefix>/<name>` whose `<name>` is a [long-lived branch](#branches), named as [Epic Bases](#epic-bases) states.
- The prefix has the form `i<initiative-number>/e<epic-number>`. **Example:** `i07/e00`; a corresponding base is `i07/e00/main`.

<big><pre>
git ls-remote --heads origin 'refs/heads/[**<epic-branch-prefix>**](#epic-identity)/*' | cut -f2 | sed 's|refs/heads/||'
</pre></big>

**Example:**

<big><pre>
git ls-remote --heads origin 'refs/heads/i07/e00/*' | cut -f2 | sed 's|refs/heads/||'
</pre></big>

### List Long-Lived Branches

Prints the long-lived branch names, one per line.

**Inputs:** [Workspace](#workspace), [Project Checkout](#project-checkout), [Revision](#revision).

**Outputs:** [Branch Names](#branch-names), [Failure](#failure).

#### 1. List Long-Lived Branches

- The names meet [Branches](#branches).
- `--project` is any checkout of the project. `--revision` is the evaluated revision [Branches](#branches) names for the run.
- The names are the ones `config/branches` states at the commit `--revision` resolves to. Standard error carries their source: the configuration path, that commit and the repository.
- `--names` reads one `--revision`.
- An absent, empty or unreadable statement, or a revision resolving to no commit, prints `unevaluable:` with the source and why, and exits 1.

<big><pre>
cd "[**<workspace>**](#workspace)" && "[**<workspace>**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py --names --project '[**<checkout>**](#project-checkout)' --revision '[**<revision>**](#revision)'
</pre></big>

**Example:**

<big><pre>
cd "[**<workspace>**](#workspace)" && "[**<workspace>**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py --names --project '[**<checkout>**](#project-checkout)' --revision origin/i07/e00/main
</pre></big>

### Fetch Remote Branch

Fetches one source branch from origin.

**Inputs:** [Checkout](#checkout), [Source Branch](#source-branch).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Fetch Remote Branch

**Acts on:** the checkout it runs in.

<big><pre>
git fetch origin '[**<source-branch>**](#source-branch)'
</pre></big>

### Publish Epic Base

Creates a remote epic base from the fetched source branch.

**Inputs:** [Project Checkout](#project-checkout), [Source Branch](#source-branch), [Epic-Base Name](#epic-base-name), [Prerequisite Evidence](#prerequisite-evidence), [Missing Destination](#missing-destination).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Publish Epic Base

**Acts on:** the checkout it runs in.

<big><pre>
git push origin 'origin/[**<source-branch>**](#source-branch):refs/heads/[**<epic-base>**](#epic-base-name)'
</pre></big>

### Merge Remote Branch

Merges one fetched remote branch into the branch of the checkout it runs in.

**Inputs:** [Checkout](#checkout), [Source Branch](#source-branch).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Merge Remote Branch

**Acts on:** the checkout it runs in.

<big><pre>
git merge --no-edit 'origin/[**<source-branch>**](#source-branch)'
</pre></big>

### Push Epic Base

Pushes the epic base checked out where it runs to its configured upstream.

**Inputs:** [Checkout](#checkout), [Successful Merge](#successful-merge).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Push Epic Base

**Acts on:** the checkout it runs in.

<big><pre>
git push
</pre></big>

### Push Task Branch

Pushes the head of the checkout it runs in to its named remote task branch.

**Inputs:** [Unit Checkout](#unit-checkout), [Task Branch](#task-branch), [Successful Merge](#successful-merge).

**Outputs:** [Branch Result](#branch-result), [Failure](#failure).

#### 1. Push Task Branch

**Acts on:** the checkout it runs in.

<big><pre>
git push origin 'HEAD:refs/heads/[**<task-branch>**](#task-branch)'
</pre></big>

**Example:**

<big><pre>
git push origin HEAD:refs/heads/i07/e00/w01-queue-plan
</pre></big>

### Add Task Worktree

Creates a task branch and worktree at the fetched base.

**Inputs:** [Project Checkout](#project-checkout), [Worktree Path](#worktree-path), [Task Branch](#task-branch), [Base Branch](#base-branch), [Prerequisite Evidence](#prerequisite-evidence).

**Outputs:** [Worktree Result](#worktree-result), [Failure](#failure).

#### 1. Add Task Worktree

**Acts on:** the checkout it runs in.

- The path resolves against the directory the command runs in, so supply it as [Task Branches](#task-branches) anchors it rather than relative to a linked worktree.

<big><pre>
git worktree add '[**<worktree-path>**](#worktree-path)' -b '[**<task-branch>**](#task-branch)' 'origin/[**<base>**](#base-branch)'
</pre></big>

**Example:**

<big><pre>
git worktree add .worktrees/i07/e00/w01-queue-plan -b i07/e00/w01-queue-plan origin/i07/e00/main
</pre></big>

### Fetch Review Head

Fetches one pull request head into FETCH_HEAD.

**Inputs:** [Project Checkout](#project-checkout), [Pull Request Number](#pull-request-number).

**Outputs:** [Checkout Commit](#checkout-commit), [Failure](#failure).

#### 1. Fetch Review Head

**Acts on:** the checkout it runs in.

<big><pre>
git fetch origin 'pull/[**<pull-request-number>**](#pull-request-number)/head'
</pre></big>

**Example:**

<big><pre>
git fetch origin pull/950/head
</pre></big>

### Add Epic Base Worktree

Creates the worktree for an existing epic base.

**Inputs:** [Project Checkout](#project-checkout), [Worktree Path](#worktree-path), [Epic-Base Name](#epic-base-name).

**Outputs:** [Worktree Result](#worktree-result), [Failure](#failure).

#### 1. Add Epic Base Worktree

**Acts on:** the checkout it runs in.

- The path resolves against the directory the command runs in, so supply it as [Epic Bases](#epic-bases) anchors it rather than relative to a linked worktree.

<big><pre>
git worktree add '[**<worktree-path>**](#worktree-path)' '[**<epic-base>**](#epic-base-name)'
</pre></big>

**Example:**

<big><pre>
git worktree add .worktrees/i07/e00/main i07/e00/main
</pre></big>

### Add Review Worktree

Creates a detached worktree at the fetched review head.

**Inputs:** [Project Checkout](#project-checkout), [Worktree Path](#worktree-path), [Verified Head](#verified-head).

**Outputs:** [Worktree Result](#worktree-result), [Failure](#failure).

#### 1. Add Review Worktree

**Acts on:** the checkout it runs in.

- The path resolves against the directory the command runs in, so supply it as [Review Worktrees](#review-worktrees) anchors it rather than relative to a linked worktree.

<big><pre>
git worktree add --detach '[**<worktree-path>**](#worktree-path)' '[**<head-commit>**](#verified-head)'
</pre></big>

### Fetch Branch Protection

Saves the target branch protection response.

**Inputs:** [Repository](#repository), [Target Branch](#target-branch), [Output Files](#output-files).

**Outputs:** [Target Requirements](#target-requirements), [Failure](#failure).

#### 1. Fetch Branch Protection

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/branches/[**<target-branch>**](#target-branch)/protection' > '[**<branch-protection-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/branches/main/protection' > protection.json
</pre></big>

### Fetch Active Branch Rules

Saves every active rule for the target branch.

**Inputs:** [Repository](#repository), [Target Branch](#target-branch), [Output Files](#output-files).

**Outputs:** [Target Requirements](#target-requirements), [Failure](#failure).

#### 1. Fetch Active Branch Rules

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/rules/branches/[**<target-branch>**](#target-branch)' > '[**<branch-rules-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/rules/branches/main' > branch-rules.json
</pre></big>

### Read Checkout Revision

Resolves one revision to its commit in the selected checkout.

**Inputs:** [Checkout](#checkout), [Revision](#revision).

**Outputs:** [Checkout Commit](#checkout-commit), [Failure](#failure).

#### 1. Read Checkout Revision

<big><pre>
git -C '[**<checkout>**](#checkout)' rev-parse '[**<revision>**](#revision)^{commit}'
</pre></big>

### Read Checkout Status

Reports branch or detached-HEAD state and tracked and untracked changes in one checkout.

**Inputs:** [Checkout](#checkout).

**Outputs:** [Checkout Status](#checkout-status), [Failure](#failure).

#### 1. Read Checkout Status

<big><pre>
git -C '[**<checkout>**](#checkout)' status --porcelain --branch
</pre></big>

## Fields

### Branches

A project states its long-lived branches in `config/branches` at its root, one name per line. A run reads the statement at the commit it evaluates, in the repository its checkout locates; which worktree the checkout is, and what its working files hold, choose nothing. The evaluated revision is fetched before it is read.

- An epic sync evaluates each of its epic bases, such as `origin/i07/e00/main` and `origin/i07/e00/workflows`. Declarations that disagree across those bases leave the names unevaluable, and each is reported with its source.
- A read of one epic's branches evaluates its epic base, such as `origin/i07/e00/main`.
- Base preparation, before a base exists, evaluates the long-lived branch the base is cut from, such as `origin/main`.
- A delivery survey evaluates the long-lived branch that states the project's branches, such as `origin/workspace`.
- Verification of merged delivery evaluates the merged commit.

- **Example.**
  workflow-server's `config/branches` names `docker`, `main`, `workflows` and `workspace`.

### Epic Bases

- Each long-lived branch an epic changes has a base branch, named for the initiative, the epic and that branch, and rooted in that long-lived branch. Its prerequisite epics are closed as completed with every delivery base merged.
- **Example.**
  An epic base cut from `main` is `i07/e00/main`.
- The base's last segment is its long-lived branch, which gives the target it merges and is merged into.
- Each base is worked in one worktree, named by the base under the worktree directory of the repository's main working tree.
- **Example.**
  `i07/e00/main` merges `main`, and is checked out at `.worktrees/i07/e00/main`.
- Every pull request delivering the epic's tasks targets that epic base.
- A completed epic is delivered by merging each base into its long-lived branch. The epic stays open until every base has merged. Another epic still incomplete holds no base back unless it is a prerequisite.
- An epic sync reports each open or merged pull request off these routes as `target`: a task pull request into anything but one of its epic's bases, and an integration pull request into anything but the long-lived branch its head names.

### Producer Outputs

A task row naming another epic's row starts once that row is delivered and each output it delivered is available at the consumer's base commit.

- **The output.**
  Each merged pull request the producer row links carries its merge commit, on the long-lived branch its base names. Each commit the row links is an output of its own.
- **Available.**
  The output is an ancestor of the consumer epic's base on that branch, as the remote holds it at the evaluated commit, or of the long-lived branch itself while the consumer has no base there. An output another repository holds is available once it has reached its long-lived branch: delivered there, or carried by an integration pull request merged after it.
- **Not available.**
  A merge into the producer's own base alone, a merge into a ref that is neither an epic base nor a long-lived branch, such as a task branch, an output recording no merge commit, a commit the checkout does not hold, and a consumer base moved to a commit without the output each leave the row waiting.
- **Not gates.**
  The producer epic's other rows and its closure.
- **Record.**
  Each reading names the producer row, the delivery, the output commit, the consumer revision and commit, and the answer. The integration, review and human-approval gates on each epic stand apart from it.
- **Example.**
  `#944 W02: E00:W01 #9 3f2a1c0d9b1e available at origin/i07/e01/main 8c4d2e7a1f30`.

### Review Worktrees

A reviewed pull request is read in a detached worktree, named by its number under the `pr` folder of the worktree directory of the repository's main working tree.

- **Example.**
  Pull request 950 is read at `.worktrees/pr/950`.

### Task Branches

A unit's task branch is cut from the epic base for the long-lived branch the unit changes, named for its initiative, epic and first task in lowercase separated by slashes, and hyphenated with a slug of at most four words from its Description when one exists: `i01/e02/w04-write-defaults`. The unit's pull request is opened from this branch into that base.

- **Changed branches.**
  A unit changes the long-lived branches its rows' work items name in their [Component](work-item.md#component) declarations. A unit of an epic with one base changes that base.
- **Unplanned rows.**
  A free row linking no work item is unplanned: its session writes the work item after dispatch. Its unit changes every epic base, and the session opens a pull request only from each branch its work changes.
- **Several long-lived branches.**
  A unit whose rows name more than one long-lived branch takes one task branch per epic base it changes, cut from that base, since the bases share no history. Each is the unit's branch with the base's long-lived branch as its last slug word, and opens its own pull request into its own base.
- **Example.**
  A unit changing `main` and `workflows` works on `i01/e02/w04-write-defaults-main` from `i01/e02/main` and `i01/e02/w04-write-defaults-workflows` from `i01/e02/workflows`.
- **Hot-fix.**
  A hot-fix works on the branch its [Branch](hotfix.md#branch) names.

Each worktree is named by its branch under the worktree directory of the repository's main working tree.

### Stash Entries

Every worktree of a repository shares one stash list, so a delivery session that stashes names its entry with a message no other session's entry carries, and acts on that entry alone.

- **Found.**
  An entry is found by its message, never by its position in the list.
- **Restored.**
  An entry is restored with `git stash apply` on that entry's commit, never with a bare `git stash pop`, which takes whichever entry tops the list.
- **Dropped.**
  The session that made an entry drops it once restored, by the `stash@{<n>}` reference its message holds at that moment, since `git stash drop` takes no bare commit.
- **Example.**
  `git stash push -m "i11/e10/w29 before base merge"`, then `git stash list --format='%H %gd %s'` to find the entry, `git stash apply <entry-commit>`, and `git stash drop "stash@{<n>}"`.

### Epic Identity

The initiative and epic identifier, with an epic branch prefix of `i<initiative-number>/e<epic-number>`; **Example:** `i07/e00`.

### Changed Branches

The long-lived branches the unit changes.

### Prerequisite Evidence

The caller’s confirmed evidence that the prerequisite epics are completed with every delivery base merged.

### Source Branch

The source branch name without the `origin/` prefix.

### Epic-Base Name

The full epic-base branch name.

### Task Branch

The destination task branch name.

### Base Branch

The fetched base from which the task branch is rooted.

### Worktree Path

The caller-composed lasting path, resolved against the checkout running the command and placed under the project’s worktree directory.

### Pull Request Number

The repository-local pull request number.

### Verified Head

The literal verified head commit used to read a reviewed change.

### Target Branch

The long-lived target branch whose current protection and active rules govern readiness.

### Output Files

Destination paths for the requested protection and active-rule responses.

### Branch Names

The configured long-lived names, with the configuration path, commit and repository identifying their source on standard error.

### Epic-Base Names

The full existing epic-base names, one per line.

### Branch Result

The created, fetched, merged or published branch and successful command result.

### Worktree Result

The selected checkout path, branch or detached head, and base where applicable.

### Target Requirements

The complete branch-protection and active-rule responses.

### Checkout Commit

The commit a selected checkout’s revision resolves to.

### Checkout Status

Branch or detached-HEAD state and all tracked and untracked changes.

### Workspace

The checkout holding the installed skill, its scripts and tests.

### Repository

The owner and repository addressed by the operation, written as `owner/repo`.

### Project Checkout

The project repository checkout supplied for branch and delivery reads or writes.

### Unit Checkout

The task branch checkout supplied for this unit.

### Checkout

The supplied repository checkout in which a git operation acts; callers name the project, epic base, unit or review checkout for that call.

### Revision

The fetched commit or revision evaluated by the run.

### Failure

The operation and error, discrepancy or missing evidence that prevents a verified result.

### Missing Destination

The supplied evidence that the destination epic base does not exist.

### Successful Merge

The successful result of merging the fetched source into the checked-out branch.
```

## 026-pr-1

Exit: 0; receipt: [026-pr-1.json](receipts/026-pr-1.json).

```sh
sed -n '1,575p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/pull-request.md
```

Returned output:

```text
# Pull Request

A pull request's identity, head and base, issue links, review state and merge result. Its populated body is an input.

## Prerequisites

Read these files first.

- [Issue](issue.md)
- [Delivery Branches](delivery-branches.md)
- [Agent Review](agent-review.md)
- [Hot-fix](hotfix.md)

## Operations

### Merge Delivery Pull Request

One task or epic pull request's merge result, or its handoff for human approval.

**Inputs:** [Identity](#identity), [Kind](#kind), [Verified Head](#verified-head), [Target Requirements](#target-requirements), [Readiness Evidence](#readiness-evidence), [Repository Prerequisite](#repository-prerequisite).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Read Target Review Requirements

Read the supplied target branch's current required reviews and checks alongside the verified head. A branch whose protection or active rules require an approving review takes that review from a person. An agent cannot approve a pull request it opened; on such a branch, the merge belongs to the reviewer even when every other condition holds.
- Report the pull request as ready for approval, naming what was verified.
- Stop merge attempts. This handoff is a finished outcome.
- Keep approval with that reviewer. Another account, an administrative bypass or a setting change cannot supply it. Changing repository protection requires the user's explicit authorization, asked for separately.
- For example, workflow-server's `main` requires one approving review, so carry an epic to ready and stop.

#### 2. Merge Approved Delivery

When approval permits the agent to merge:
- Apply [Merge Pull Request](#merge-pull-request) for a task or Apply [Merge Epic Pull Request](#merge-epic-pull-request) for an epic, passing the verified readiness evidence and authorization result. For an epic, also supply the target requirements and exact verified head SHA.
- If GitHub refuses the merge, return the refusal to the caller for fresh verification.
- If the agent's own permission layer refuses it, the harness declines to run the merge command and GitHub returns nothing. On a target with no review requirement, that refusal is neither a handoff for approval nor a branch blocker. Return the pull request as ready and verified, naming the refusal and the [merge permission](#merge-permission) it lacks, and stop merge attempts. A later Deliver run merges it in its merge step or reports the missing permission; neither asks the user to approve it.

#### 3. Return Delivery Merge Result

Return the merge result, including its merge commit when supplied, for the caller's readback.

### Access Development Links

The observed or updated Development relation for a pull request.

**Inputs:** [Identity](#identity), [Authenticated Access](#authenticated-access), [Link Request](#link-request); for an edit, [Issue Identity](#issue-identity) and [Repository Prerequisite](#repository-prerequisite); for removal, [Removal Decision](#removal-decision).

**Outputs:** [Development Relation](#development-relation), [Failure](#failure).

#### 1. Read Complete Development Relation

For a read-only request:
- Apply [Read Pull Request State](#read-pull-request-state) for the pull request's metadata, which carries the `html_url` the capture keys it by.
- Apply [Capture Pull Request Links](#capture-pull-request-links) with that record and return its entry, every page read. An unreadable relation is a blocker, not an empty link set.

#### 2. Edit Authorized Development Relation

For a link edit:
- Take the supplied repository prerequisite from [Repository Prerequisite](#repository-prerequisite); an unconfirmed setting blocks the edit.
- For an addition, Apply [Set Development Link](#set-development-link) with the pull request and issue identities.

For removal of an abandoned or incorrect link:
- Require the supplied user decision.
- Apply [Remove Development Link](#remove-development-link) with those identities.

#### 3. Return Verified Relation

Return the relation the command verified from both ends, or the discrepancy or failure it names. A failed write is a blocker carrying its operation and error, never an unavailable field.

### Fetch Pull Request Issue Links

The complete issue-link snapshot for a supplied set of pull requests.

**Inputs:** [Pull Request Records](#pull-request-records), [Authenticated Access](#authenticated-access), [Link-Snapshot Path](#link-snapshot-path).

**Outputs:** [Issue-Link Snapshot](#issue-link-snapshot), [Failure](#failure).

#### 1. Capture Complete Issue Links

Apply [Capture Pull Request Links](#capture-pull-request-links) with `prs.json` and destination `links.json`.

#### 2. Require Complete Relation Evidence

If it names an unreadable relation, stop and return each one named as a blocker. Incomplete evidence is never a partial snapshot.

#### 3. Refresh Changed Link Snapshot

After a link changes, Apply [Capture Pull Request Links](#capture-pull-request-links) again with the refreshed pull request records, the same authenticated access and destination.

#### 4. Return Complete Snapshot

Return the snapshot for the scripts' `--links` input.

### Link Pull Request to Issue

The verified delivery-issue relation for a pull request.

**Inputs:** [Identity](#identity), [Issue Identity](#issue-identity), [Pull Request Records](#pull-request-records), [Link-Snapshot Path](#link-snapshot-path), [Authenticated Access](#authenticated-access), [Repository Prerequisite](#repository-prerequisite).

**Outputs:** [Development Relation](#development-relation), [Issue-Link Snapshot](#issue-link-snapshot), [Failure](#failure).

#### 1. Add Development Relation

Apply [Access Development Links](#access-development-links) with the supplied identities, requested link addition and confirmed repository prerequisite.

#### 2. Require Verified Edit

Stop on a blocker or an unverified edit.

#### 3. Refresh Issue-Link Snapshot

Apply [Fetch Pull Request Issue Links](#fetch-pull-request-issue-links) with the current records and destination after the edit.

#### 4. Return Relation Evidence

Return the verified relation and refreshed snapshot.

### Merge Epic Pull Request

The epic's verified merge into its long-lived target.

**Inputs:** [Identity](#identity), [Verified Head](#verified-head), [Target Requirements](#target-requirements), [Readiness Evidence](#readiness-evidence), [Merge Authorization](#merge-authorization).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Require Epic Merge Evidence

Require the supplied target requirements, readiness evidence and authorization.

#### 2. Submit Verified Epic Merge

Apply [Submit Epic Merge](#submit-epic-merge) with the exact head whose checks and target requirements were verified; return a refusal without continuing.

#### 3. Read Epic Merge Result

Apply [Read Merge Result](#read-merge-result) for that pull request.

#### 4. Confirm Exact Merge State

Confirm the merged state, merge commit, verified head and target.

#### 5. Return Epic Merge Result

Return the result or discrepancy.

### Fetch All Delivery Pull Requests

The pull request collection covering every supplied board repository and every pull request the board's issues link.

**Inputs:** [Repository List](#repository-list), [Issue Records](#issue-records), [Collection Path](#collection-path).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Create Fresh Pull Collection

Apply [Fetch Repository Delivery Pull Requests](#fetch-repository-delivery-pull-requests) for the first repository and destination `prs.json`. This replaces the destination with a fresh collection.

#### 2. Stop on Initial Failure

Stop on failure.

#### 3. Append Remaining Repositories

Apply [Append Repository Delivery Pull Requests](#append-repository-delivery-pull-requests) for each further repository, passing the same destination.

#### 4. Fetch Plan-Linked Pull Requests

Apply [Fetch Linked Pull Requests](#fetch-linked-pull-requests) with that destination and the board items file.

#### 5. Report Incomplete Fetch

If any fetch failed, return incomplete evidence.

#### 6. Return Complete Pull Collection

Return the complete collection only after every fetch succeeds.

### Read Initiative Pull Requests

The current delivery pull requests for one initiative: each one whose title names it, and each one its plan links, whatever its title.

**Inputs:** [Repository](#repository), [Initiative Prefix](#initiative-prefix), [Issue Records](#issue-records), [Collection Path](#collection-path).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Fetch Initiative-Prefixed Pull Requests

Apply [Fetch Initiative Pull Requests](#fetch-initiative-pull-requests) with the supplied repository and prefix, saving the collection to the supplied file.

#### 2. Fetch All Plan-Linked Pull Requests

Apply [Fetch Linked Pull Requests](#fetch-linked-pull-requests) with that collection and the supplied issue files.

#### 3. Return Initiative Pull Collection

Return the collection, or an incomplete-fetch finding naming each unreadable relation or pull request.

### Read Pull Request State

One current pull request and its requested supporting records.

**Inputs:** [Identity](#identity), [Output Files](#output-files), [Record Selection](#record-selection).

**Outputs:** [Pull Request Record](#pull-request-record), [Changed Paths](#changed-paths), [Reviews](#reviews), [Failure](#failure).

#### 1. Save Complete Pull Response

Apply [Save Pull Request Snapshot](#save-pull-request-snapshot) with the pull request identity and destination JSON path.

#### 2. Fetch Requested Supporting Records

Apply [Fetch Pull Request Files](#fetch-pull-request-files) or Apply [Fetch Pull Request Reviews](#fetch-pull-request-reviews) when the caller requests those records.

#### 3. Return Requested Pull Records

Return the snapshots or missing evidence.

### Publish Pull Request

One pull request created or updated from supplied content and metadata.

**Inputs:** [Repository](#repository), [Kind](#kind), [Selected Changes](#selected-changes); [Identity](#identity) for an existing pull request; [Body File](#body-file) for creation or body replacement; for creation with a delivery issue, [Issue Identity](#issue-identity), [Repository Prerequisite](#repository-prerequisite) and [Link-Snapshot Path](#link-snapshot-path).

**Outputs:** [Pull Request Record](#pull-request-record), [Failure](#failure).

#### 1. Create Delivery Pull Request

For creation, Apply [Open Task Pull Request](#open-task-pull-request) or Apply [Open Epic Pull Request](#open-epic-pull-request) for the supplied kind, body, title, head and base.
- For a task or epic pull request with a delivery issue, Apply [Link Pull Request to Issue](#link-pull-request-to-issue) with it, the supplied delivery issue, that confirmed setting and the snapshot destination, meeting [Issue Links](#issue-links).

#### 2. Update Selected Pull Fields

For an existing pull request, Apply [Patch Pull Request Body](#patch-pull-request-body), Apply [Retitle Pull Request](#retitle-pull-request) or Apply [Retarget Pull Request](#retarget-pull-request) for the supplied changes, preserving other fields.

#### 3. Read Saved Pull State

Apply [Read Pull Request State](#read-pull-request-state) again.

#### 4. Return Saved Pull Record

Return the saved state or discrepancy.

### Locate Review Pull Request

The review pull request for a supplied epic base.

**Inputs:** [Repository](#repository), [Head Branch](#head-branch).

**Outputs:** [Review Number](#review-number), [Failure](#failure).

#### 1. Find Epic Review Pull

Apply [Find Review Pull Request](#find-review-pull-request) with the supplied head.

#### 2. Return Review Pull Number

Return its number or an absent-review finding.

### Read Head Evidence

The check-run and status evidence for one literal head commit.

**Inputs:** [Repository](#repository), [Verified Head](#verified-head), [Output Files](#output-files).

**Outputs:** [Head Checks](#head-checks), [Head Status](#head-status), [Failure](#failure).

#### 1. Fetch Literal Head Checks

Apply [Fetch Head Check Runs](#fetch-head-check-runs) for the supplied literal SHA.

#### 2. Fetch Literal Head Status

Apply [Fetch Head Status](#fetch-head-status) for the same SHA.

#### 3. Return Current Head Evidence

Return both snapshots, retaining missing or pending evidence as unresolved. The caller compares them with supplied target requirements and current reviews.

### Merge Task Pull Requests

Merges each open task pull request whose test plan has passed.

**Inputs:** [Identity](#identity), [Base Branch](#base-branch), [Project Checkout](#project-checkout), [Unit Checkout](#unit-checkout), [Repository Prerequisite](#repository-prerequisite), [Readiness Evidence](#readiness-evidence).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Confirm Repository and Base

Apply [Confirm Repository Auto-Close](issue.md#confirm-repository-auto-close) for the repository, and confirm the task pull request's base, as [Task Branches](delivery-branches.md#task-branches) names it. An epic base carries no review requirement of its own; carry any applicable target review requirement into the merge step.

#### 2. Merge Verified Task Pull

Merge the task pull request.
- Where its base is an epic base, Apply [Update Epic Base](delivery-branches.md#update-epic-base) with the project checkout and that base.
- Apply [Fetch Merge Readiness](#fetch-merge-readiness) for the task pull request and its base.
- Apply [Merge Delivery Pull Request](#merge-delivery-pull-request) with delivery kind task, the verified head, target requirements, repository prerequisite and passing evidence, without further confirmation.
- Stop on a handoff for human approval or a permission-layer refusal, returning it to the caller.

If GitHub refuses the merge:
- Apply [Update Task Branch](delivery-branches.md#update-task-branch) with the unit checkout, the task branch and its base.
- Apply [Fetch Merge Readiness](#fetch-merge-readiness) again for the updated task head.
- Apply [Merge Delivery Pull Request](#merge-delivery-pull-request) once more with that verified evidence. A conflict or repeated refusal leaves the pull request open with the blocker reported.

#### 3. Confirm Task Merge Result

Apply [Read Pull Request State](#read-pull-request-state) to confirm the merged state, head, base and merge commit.
- Return that result to the caller.

### Fetch Merge Readiness

The current pull request's readiness against its target requirements and head checks.

**Inputs:** [Identity](#identity), [Base Branch](#base-branch), [Output Files](#output-files).

**Outputs:** [Verified Head](#verified-head), [Target Requirements](#target-requirements), [Readiness Evidence](#readiness-evidence), [Failure](#failure).

#### 1. Read Current Pull Head

Apply [Read Pull Request State](#read-pull-request-state) with the pull request identity and destination `epic-pr.json`.
- Retain the literal head SHA and target branch for the evidence calls.

#### 2. Read Current Target Requirements

Apply [Read Target Requirements](delivery-branches.md#read-target-requirements) with the repository, target and protection/rules output paths.
- Carry any unresolved requirement into the readiness result.

#### 3. Read Literal Head Evidence

Read the head evidence.
- Apply [Read Head Evidence](#read-head-evidence) with the exact head SHA and check/status output paths.
- Apply [Read Pull Request State](#read-pull-request-state) for reviews with the pull request identity and reviews output path. A missing or pending check, blocked merge state or unmet required review leaves readiness unresolved.

#### 4. Confirm Stable Pull Head

Apply [Read Pull Request State](#read-pull-request-state) again with the same identity and destination.
- Compare its head with the retained SHA; a changed head requires fresh evidence.
- Return the verified head, target requirements and readiness result, including unresolved conditions.

### Hold Epic Review

An open epic review returned to draft while its handoff evidence is unresolved.

**Inputs:** [Identity](#identity).

**Outputs:** [Review State](#review-state), [Failure](#failure).

#### 1. Return Open Review to Draft

Apply [Read Pull Request State](#read-pull-request-state) for full metadata. For an open ready pull request, Apply [Mark Review Draft](#mark-review-draft).

#### 2. Confirm Review Draft State

Apply [Read Pull Request State](#read-pull-request-state) again with the same identity and return the confirmed draft state or discrepancy.

### Ready Epic Review

The complete epic's pull request made ready for review.

**Inputs:** [Identity](#identity), [Published Reviews](#published-reviews), [Epic Readiness](#epic-readiness).

**Outputs:** [Review State](#review-state), [Failure](#failure).

#### 1. Require Complete Epic Evidence

Require the supplied readiness evidence and Apply [Read Pull Request State](#read-pull-request-state) for the pull request.

#### 2. Check Published Review Evidence

Apply [Check Agent Review](agent-review.md#check-agent-review) with the fresh metadata and published records. On a finding, Apply [Hold Epic Review](#hold-epic-review) and stop. For a draft with passing evidence, Apply [Mark Review Ready](#mark-review-ready) with the node id its metadata names.

#### 3. Confirm Current Review State

Apply [Read Pull Request State](#read-pull-request-state) again with the same identity, then Apply [Check Agent Review](agent-review.md#check-agent-review) again with that fresh metadata and the same published records. For a changed revision, Apply [Hold Epic Review](#hold-epic-review) and report the discrepancy. Return the confirmed ready state only with current evidence. Target review requirements still govern the merge.

### Ready Hot-fix Pull Request

A hot-fix's draft delivering pull request made ready for review once its review cycle is complete.

**Inputs:** [Identity](#identity), [Published Reviews](#published-reviews).

**Outputs:** [Review State](#review-state), [Failure](#failure).

#### 1. Read Current Hot-Fix Metadata

Apply [Read Pull Request State](#read-pull-request-state) for its full metadata.

#### 2. Check Published Hot-Fix Review

Apply [Check Agent Review](agent-review.md#check-agent-review) with that metadata and the published records.
- On a finding, return it to the caller; the pull request stays a draft.

#### 3. Mark Verified Hot-Fix Ready

For a draft with passing evidence, Apply [Mark Review Ready](#mark-review-ready) with the node id its metadata names.

#### 4. Confirm Hot-Fix Review State

Apply [Read Pull Request State](#read-pull-request-state) again with the same identity, then Apply [Check Agent Review](agent-review.md#check-agent-review) again with that fresh metadata and the same published records. Return the confirmed ready state, or the changed revision or finding that leaves it unconfirmed.

### Retarget Pull Request

Points a pull request at another base branch, such as its epic's base branch.

**Inputs:** [Identity](#identity), [Base Branch](#base-branch).

**Outputs:** [Base Branch](#base-branch), [Failure](#failure).

#### 1. Retarget Pull Request

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)' -f base='[**<target-branch>**](#base-branch)' --jq .base.ref
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/950' -f base='i07/e00/main' --jq .base.ref
</pre></big>

### Retitle Pull Request

Replaces a pull request's title.

**Inputs:** [Identity](#identity), [Title](#title).

**Outputs:** [Title](#title), [Failure](#failure).

#### 1. Retitle Pull Request

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)' -f title='[**<title>**](#title)' --jq .title
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/950' -f title='[I07:E00] Purpose' --jq .title
</pre></big>

### Open Task Pull Request

Creates a pull request from a unit's branch to its base.

**Inputs:** [Repository](#repository), [Title](#title), [Head Branch](#head-branch), [Base Branch](#base-branch), [Body File](#body-file).

**Outputs:** [Identity](#identity), [Failure](#failure).

#### 1. Open Task Pull Request

- Supply the title, the task branch as head, the base [Task Branches](delivery-branches.md#task-branches) names as base, and the complete body file.
- A title opening with a hot-fix prefix, `[F00]`, always adds `-F draft=true`, as a [delivering pull request](hotfix.md#delivering-pull-request) opens.

<big><pre>
gh api --method POST 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls' -f title='[**<title>**](#title)' -f head='[**<task-branch>**](#head-branch)' -f base='[**<base>**](#base-branch)' -F 'body=@[**<body-file>**](#body-file)' --jq .html_url
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls' -f title='[I07:E00] Purpose' -f head='i07/e00/w01-purpose' -f base='i07/e00/main' -F body=@body.md --jq .html_url
</pre></big>

**Example:** A hot-fix's delivering pull request.

<big><pre>
gh api --method POST 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls' -f title='[F00] Reject Bad Keys' -f head='f00-key-validation' -f base='workspace' -F body=@body.md -F draft=true --jq .html_url
</pre></big>

### Open Epic Pull Request

Creates the draft pull request from an epic base to its long-lived target.

**Inputs:** [Repository](#repository), [Title](#title), [Head Branch](#head-branch), [Base Branch](#base-branch), [Body File](#body-file).

**Outputs:** [Identity](#identity), [Failure](#failure).

#### 1. Open Epic Pull Request

- Supply the epic prefix and name as title, the epic base as head, its long-lived branch as base, and the populated review body file.
- `draft` is true, including when the work is already complete.

<big><pre>
gh api --method POST 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls' -f title='[**<title>**](#title)' -f head='[**<epic-base>**](#head-branch)' -f base='[**<long-lived-base>**](#base-branch)' -F draft=true -F 'body=@[**<body-file>**](#body-file)' --jq .html_url
</pre></big>

**Example:**

<big><pre>
gh api --method POST 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls' -f title='[I07:E00] Name' -f head='i07/e00/main' -f base='main' -F draft=true -F body=@body.md --jq .html_url
</pre></big>

### Merge Pull Request

Merges the task pull request into its base.

**Inputs:** [Identity](#identity), [Readiness Evidence](#readiness-evidence), [Merge Authorization](#merge-authorization).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Merge Pull Request

- Require the supplied readiness evidence and authorization before issuing the merge.
- The merge method is a merge commit.

<big><pre>
gh api --method PUT 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)/merge' -f merge_method='merge' --jq .merged
</pre></big>

**Example:**

<big><pre>
gh api --method PUT 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/950/merge' -f merge_method='merge' --jq .merged
</pre></big>

### Patch Pull Request Body

Replaces a pull request's body.

**Inputs:** [Identity](#identity), [Body File](#body-file).

**Outputs:** [Identity](#identity), [Failure](#failure).

#### 1. Patch Pull Request Body

- The file is the whole body. The issue a pull request delivers is linked on the pull request itself, so this call leaves that link standing.

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)' -F 'body=@[**<body-file>**](#body-file)' --jq .html_url
</pre></big>

**Example:**

<big><pre>
gh api --method PATCH 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/950' -F body=@pr-950.md --jq .html_url
</pre></big>

### Find Review Pull Request

Returns the open pull request whose head is the supplied epic base, or no result when none exists.

**Inputs:** [Repository](#repository), [Head Branch](#head-branch).

**Outputs:** [Review Number](#review-number), [Failure](#failure).

#### 1. Find Review Pull Request

<big><pre>
gh api "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=open&head=[**<owner>**](#repository):[**<epic-base>**](#head-branch)" --jq '.[0].number'
</pre></big>

**Example:**

<big><pre>
gh api "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=open&head=[**<owner>**](#repository):i07/e00/main" --jq '.[0].number'
</pre></big>

### Submit Epic Merge

Merges the epic base into its long-lived target at the supplied head.

**Inputs:** [Identity](#identity), [Verified Head](#verified-head), [Target Requirements](#target-requirements), [Readiness Evidence](#readiness-evidence), [Merge Authorization](#merge-authorization).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Submit Epic Merge

The merge method is a merge commit. The endpoint refuses a different head.

<big><pre>
gh api --method PUT 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)/merge' -f merge_method='merge' -f sha='[**<head-sha>**](#verified-head)' --jq '{merged, message, sha}'
</pre></big>

**Example:**
```

## 027-pr-2

Exit: 0; receipt: [027-pr-2.json](receipts/027-pr-2.json).

```sh
sed -n '576,1146p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/pull-request.md
```

Returned output:

```text
<big><pre>
gh api --method PUT 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/980/merge' -f merge_method='merge' -f sha='[**<head-sha>**](#verified-head)' --jq '{merged, message, sha}'
</pre></big>

### Read Merge Result

Returns a pull request's merge state, merge commit, head and base.

**Inputs:** [Identity](#identity).

**Outputs:** [Merge Result](#merge-result), [Failure](#failure).

#### 1. Read Merge Result

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)' --jq '{merged, merge_commit_sha, head: .head.sha, base: .base.ref}'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/980' --jq '{merged, merge_commit_sha, head: .head.sha, base: .base.ref}'
</pre></big>

### Set Development Link

Adds one pull request to an issue's Development relation, and reads the relation back from both ends.

**Inputs:** [Workspace](#workspace), [Identity](#identity), [Issue Identity](#issue-identity), [Authenticated Access](#authenticated-access), [Repository Prerequisite](#repository-prerequisite).

**Outputs:** [Development Relation](#development-relation), [Failure](#failure).

#### 1. Set Development Link

**REST gap:** REST exposes no write to the Development relation; `addCloseIssueReferences` is a GraphQL mutation alone.

- The issue and pull request may sit in different repositories, and the pull request may be a draft on any base branch.
- The script reads both node ids through REST and sends `addCloseIssueReferences` from a generated query file, so the command runs outside `sbx`, where `gh` reaches the tracker.
- Exit 0 means the issue holds the pull request exactly once, the pull request holds the issue, and every other link on the issue stands. Running it again for a linked pair holds the same relation.
- Exit 1 prints `failed:` with the operation, the step and the tracker's error, or `discrepancy:` with the relation read back.

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/development-link.py add --issue '[**<issue-owner>**](#issue-identity)/[**<issue-repo>**](#issue-identity)#[**<issue-number>**](#issue-identity)' --pull '[**<pr-owner>**](#identity)/[**<pr-repo>**](#identity)#[**<pull-request-number>**](#identity)'
</pre></big>

**Example:**

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/development-link.py add --issue 'm2ux/workflow-server#637' --pull 'm2ux/workflow-server#950'
</pre></big>

**Example output:**

```text
issue m2ux/workflow-server#637: m2ux/workflow-server#950
pull request m2ux/workflow-server#950: m2ux/workflow-server#637
verified: add m2ux/workflow-server#950 -> m2ux/workflow-server#637
```

### Remove Development Link

Removes one pull request from an issue's Development relation, and reads the relation back from both ends.

**Inputs:** [Workspace](#workspace), [Identity](#identity), [Issue Identity](#issue-identity), [Authenticated Access](#authenticated-access), [Removal Decision](#removal-decision).

**Outputs:** [Development Relation](#development-relation), [Failure](#failure).

#### 1. Remove Development Link

**REST gap:** REST exposes no write to the Development relation; `removeCloseIssueReferences` is a GraphQL mutation alone.

- The script sends `removeCloseIssueReferences` from a generated query file, so the command runs outside `sbx`.
- Exit 0 means neither end holds the other and every other link on the issue stands.
- Exit 1 prints `failed:` or `discrepancy:` with the operation, step and tracker error, or the relation read back.

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/development-link.py remove --issue '[**<issue-owner>**](#issue-identity)/[**<issue-repo>**](#issue-identity)#[**<issue-number>**](#issue-identity)' --pull '[**<pr-owner>**](#identity)/[**<pr-repo>**](#identity)#[**<pull-request-number>**](#identity)'
</pre></big>

**Example:**

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/development-link.py remove --issue 'm2ux/workflow-server#637' --pull 'm2ux/workflow-server#950'
</pre></big>

**Example output:**

```text
failed: remove m2ux/workflow-server#950 -> m2ux/workflow-server#637: removeCloseIssueReferences: Resource not accessible by integration
```

### Capture Pull Request Links

Writes the complete issue-link snapshot for a pull request collection, read from the pull-request end of the Development relation.

**Inputs:** [Workspace](#workspace), [Pull Request Records](#pull-request-records), [Link-Snapshot Path](#link-snapshot-path), [Authenticated Access](#authenticated-access).

**Outputs:** [Issue-Link Snapshot](#issue-link-snapshot), [Failure](#failure).

#### 1. Capture Pull Request Links

**REST gap:** REST exposes no read of a pull request's closing issue references.

- The snapshot meets [Issue-Link Snapshot](#issue-link-snapshot).
- Each batch of pull requests costs one `gh api graphql` call from a generated query file, so the command runs outside `sbx`, where `gh` reaches the tracker.
- A relation is unreadable when any page of it does not arrive whole: the tracker returns no node for its subject, names the subject in an error, or reports a further page it does not supply.
- Exit 0 means the snapshot is complete. Exit 1 names each unreadable relation with the tracker's reason and writes no snapshot; the caller treats it as a blocker.
- A call the tracker refuses outright, such as a rejected credential, exits 1 with `GraphQL read failed:` and what `gh` reported, and writes nothing.

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/links-by-pull-request.py --prs '[**<pull-request-records-file>**](#pull-request-records)' --out '[**<issue-link-snapshot-file>**](#link-snapshot-path)'
</pre></big>

**Example:**

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/links-by-pull-request.py --prs prs.json --out links.json
</pre></big>

**Example payload:**

```json
[
  {
    "repo": "owner/repo",
    "number": 950,
    "closingIssuesReferences": [{"repo": "owner/repo", "number": 637}]
  }
]
```

### Save Pull Request Snapshot

Saves one complete pull request response, replacing the destination file.

**Inputs:** [Identity](#identity), [Output Files](#output-files).

**Outputs:** [Pull Request Record](#pull-request-record), [Failure](#failure).

#### 1. Save Pull Request Snapshot

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)' > '[**<pull-request-json-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/980' > epic-pr.json
</pre></big>

### Fetch Pull Request Reviews

Saves every review on one pull request.

**Inputs:** [Identity](#identity), [Output Files](#output-files).

**Outputs:** [Reviews](#reviews), [Failure](#failure).

#### 1. Fetch Pull Request Reviews

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)/reviews?per_page=100' > '[**<reviews-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/980/reviews?per_page=100' > reviews.json
</pre></big>

### Fetch Initiative Pull Requests

Saves the task and epic pull requests that name one initiative's epics.

**Inputs:** [Repository](#repository), [Initiative Prefix](#initiative-prefix), [Collection Path](#collection-path).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Fetch Initiative Pull Requests

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[**<initiative-prefix>**](#initiative-prefix)"))' > '[**<pull-request-records-file>**](#pull-request-records)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I07"))' > prs.json
</pre></big>

### Fetch Linked Pull Requests

Appends to a pull request collection each pull request the plan links that the collection lacks, whatever its title.

**Inputs:** [Workspace](#workspace), [Collection Path](#collection-path), [Issue Records](#issue-records).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Fetch Linked Pull Requests

**REST gap:** REST exposes no read of the pull requests an issue's Development field holds.

- A pull request is linked when a Work Breakdown row's id cell links it or an issue's Development field names it, open, closed or merged, in whichever repository it lives.
- A pull request no row or Development link names is found by its title alone, through the title-matched fetch this command follows.
- The command reads the Development field by `gh api graphql` and each missing pull request by REST, so it runs outside `sbx`, where `gh` reaches the tracker.
- Exit 0 means every linked pull request is in the collection. Exit 1 names each unreadable relation or pull request and appends nothing; the caller treats it as a blocker.

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/linked-pull-requests.py --prs '[**<pull-request-records-file>**](#pull-request-records)' --issues '[**<issue-file>**](#issue-records)' ...
</pre></big>

**Example:**

<big><pre>
cd "[**<workspace>**](#workspace)" && python3 skills/work-planner/scripts/linked-pull-requests.py --prs prs.json --issues issue-936.json issue-943.json issue-637.json
</pre></big>

### Fetch Repository Delivery Pull Requests

Starts a collection with all initiative- and hot-fix-prefixed pull requests from one repository.

**Inputs:** [Repository](#repository), [Collection Path](#collection-path).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Fetch Repository Delivery Pull Requests

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I") or startswith("[F"))' > '[**<pull-request-records-file>**](#pull-request-records)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I") or startswith("[F"))' > prs.json
</pre></big>

### Append Repository Delivery Pull Requests

Appends all initiative- and hot-fix-prefixed pull requests from one further repository.

**Inputs:** [Repository](#repository), [Collection Path](#collection-path).

**Outputs:** [Pull Request Records](#pull-request-records), [Failure](#failure).

#### 1. Append Repository Delivery Pull Requests

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I") or startswith("[F"))' >> '[**<pull-request-records-file>**](#pull-request-records)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate "repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls?state=all&per_page=100" --jq '.[] | select(.title | startswith("[I") or startswith("[F"))' >> prs.json
</pre></big>

### Fetch Pull Request Files

Saves the paths a pull request changes.

**Inputs:** [Identity](#identity), [Output Files](#output-files).

**Outputs:** [Changed Paths](#changed-paths), [Failure](#failure).

#### 1. Fetch Pull Request Files

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/[**<pull-request-number>**](#identity)/files' --jq '.[].filename' > '[**<changed-paths-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/pulls/950/files' --jq '.[].filename' > changed-files.txt
</pre></big>

### Fetch Head Check Runs

Saves every check run for one exact commit.

**Inputs:** [Repository](#repository), [Verified Head](#verified-head), [Output Files](#output-files).

**Outputs:** [Head Checks](#head-checks), [Failure](#failure).

#### 1. Fetch Head Check Runs

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/commits/[**<head-sha>**](#verified-head)/check-runs?per_page=100' > '[**<check-runs-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/commits/[**<head-sha>**](#verified-head)/check-runs?per_page=100' > checks.json
</pre></big>

### Fetch Head Status

Saves commit status evidence for one exact commit.

**Inputs:** [Repository](#repository), [Verified Head](#verified-head), [Output Files](#output-files).

**Outputs:** [Head Status](#head-status), [Failure](#failure).

#### 1. Fetch Head Status

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/commits/[**<head-sha>**](#verified-head)/status?per_page=100' > '[**<commit-status-file>**](#output-files)'
</pre></big>

**Example:**

<big><pre>
gh api --paginate 'repos/[**<owner>**](#repository)/[**<repo>**](#repository)/commits/[**<head-sha>**](#verified-head)/status?per_page=100' > status.json
</pre></big>

### Mark Review Ready

Marks a draft pull request ready for review.

**Inputs:** [Node Metadata](#node-metadata), [Query File](#query-file).

**Outputs:** [Review State](#review-state), [Failure](#failure).

#### 1. Mark Review Ready

**REST gap:** REST has no endpoint that marks a draft ready for review.

- The query file holds the mutation with the node id inlined, since a GraphQL variable is a literal `$`:

  ```graphql
  mutation { markPullRequestReadyForReview(input: {pullRequestId: "<pull-request-node-id>"}) { pullRequest { isDraft } } }
  ```

<big><pre>
gh api graphql -F query=@'[**<query-file>**](#query-file)' --jq .data.markPullRequestReadyForReview.pullRequest.isDraft
</pre></big>

### Mark Review Draft

Returns an open integration pull request with blocked handoff evidence to draft.

**Inputs:** [Identity](#identity).

**Outputs:** [Review State](#review-state), [Failure](#failure).

#### 1. Mark Review Draft

<big><pre>
gh pr ready '[**<pull-request-number>**](#identity)' --undo --repo '[**<owner>**](#repository)/[**<repository>**](#repository)'
</pre></big>

## Fields

### State

A pull request is open, draft, ready for review, merged or closed without merge. A draft is never merged. A merged result identifies the verified head, target and merge commit. An epic review is draft from the first task merge until every task is delivered, every epic criterion is verified and ticked, and current agent review evidence passes.

### Scope

A task pull request delivers one task, or a set of tasks that name each other in Joins.

### Other Pull Requests

A pull request outside epic delivery targets a long-lived branch. An open stacked pull request targets its long-lived branch once its base merges.

### Merge Permission

The agent harness lets a delivery session merge a task pull request into an [epic base](delivery-branches.md#epic-bases), such as `i07/e00/main`, without a prompt. A merge into the default branch stays with a person.

- **Claude Code.**
  User settings (`~/.claude/settings.json`) grant it with an `autoMode.allow` rule and an `autoMode.environment` entry, each array keeping `"$defaults"`; auto mode reads neither from project settings. `claude auto-mode config` prints the rules in effect.

  ```json
  {
    "autoMode": {
      "environment": [
        "$defaults",
        "Source control: github.com/m2ux/workflow-server. Epic bases named iNN/eNN/<branch> carry no review requirement; the default branch requires an approving review"
      ],
      "allow": [
        "$defaults",
        "Merging a task pull request into an epic base iNN/eNN/<branch> of github.com/m2ux/workflow-server is allowed: the work-planner skill's Deliver mode authorizes it and the base requires no review. Merges into the default branch are not covered"
      ]
    }
  }
  ```

### Issue Links

- GitHub shows the link in the pull request's Development field and in the issue's Linked pull requests field, which the project board reads.
- A task pull request links the task's issue, and a review pull request links its epic's issue.
- The link is addressed by issue, so a pull request whose work carries no issue links nothing. A task pull request delivering rows that have no issue of their own is the whole of what stays unlinked.
- The link is stored on the pull request. It holds on any base branch and on a pull request that has merged, and a later body edit leaves it standing.
- A linked issue remains open until its criteria and delivery requirements hold and every Development-linked pull request is merged.
- The field is the whole of the relation: neither body links the other. The pull request's References carry its sources, and the issue it delivers is not among them.
- A pull request with a delivery issue but no Development link is uncited.

### Identity

The pull request’s repository-qualified identity, or its repository and local number. A new pull request has no saved identity until creation succeeds.

### Kind

The selected task or epic delivery kind.

### Verified Head

The literal head commit SHA verified by current checks and target requirements.

### Target Requirements

The supplied current protection and active rules of the target branch.

### Readiness Evidence

Current passing test-plan and head evidence, reviews and target requirements; unresolved conditions remain explicit.

### Repository Prerequisite

The caller’s repository auto-close setting confirmed for the session, meeting [Auto-Close Setting](issue.md#auto-close-setting).

### Merge Authorization

The confirmed authorization for the agent to merge.

### Merge Result

The merge command result and merge commit when supplied, with the verified head and target; a refusal or discrepancy remains explicit.

### Link Request

The requested read, addition or removal of a Development relation.

### Issue Identity

The delivery issue’s repository-qualified identity; absent where the work carries no issue of its own.

### Removal Decision

The user decision authorizing removal of the supplied abandoned or incorrect Development link.

### Pull Request Records

Complete pull request REST responses stored as JSON lines, from one or more repositories. Each record includes its repository identity and `html_url`.

### Issue-Link Snapshot

The complete saved Development snapshot, with one entry per pull request and every linked issue’s repository and number, or an empty array.

### Link-Snapshot Path

The supplied destination for a complete Development snapshot. The snapshot is absent before a successful capture writes it.

### Development Relation

The issue and pull request identities verified from both ends, or an explicit unreadable or failed relation.

### Repository List

The ordered repositories included in a board delivery fetch.

### Issue Records

The fetched plan issues supplied as issue files, or board items containing their complete issues.

### Collection Path

The JSON-lines pull request collection destination. It is absent before a fresh fetch creates it; an append receives the existing collection.

### Initiative Prefix

The opening bracket and initiative id matched against task and epic titles, such as `[I07`.

### Output Files

The caller-supplied destinations for complete metadata, changed-paths, reviews, protection, rules, check and status snapshots, selected by the operation.

### Record Selection

The requested supporting records: full metadata, changed paths or reviews.

### Pull Request Record

One complete pull request REST JSON response, including `html_url`, `node_id`, draft state, literal head and base.

### Changed Paths

The saved path list for the requested pull request.

### Reviews

Every page of reviews for the selected pull request.

### Body File

The complete populated body text supplied through a file.

### Title

The complete selected pull request title.

### Head Branch

The task branch or epic-base head selected for creation.

### Base Branch

The task base, epic’s long-lived target or replacement base selected by the operation.

### Selected Changes

The supplied body, title, head or base fields for creation or update; an existing pull request retains fields the caller does not select.

### Review Number

The open review pull request number for an epic-base head, or an absent-review finding.

### Head Checks

Every check-run page for the exact verified head SHA.

### Head Status

Every status page for the exact verified head SHA.

### Published Reviews

The published agent review records supplied for the current revision.

### Epic Readiness

Confirmed readiness showing every task delivered, every criterion verified and ticked, and no unresolved question or delivery discrepancy.

### Review State

The freshly confirmed draft or ready state, or the discrepancy that leaves it unconfirmed.

### Node Metadata

The pull request’s REST `node_id`, used by the ready-for-review mutation.

### Query File

The working file holding the complete GraphQL mutation with its node id inlined.

### Workspace

The checkout holding the installed skill, its scripts and tests.

### Repository

The owner and repository addressed by the operation, written as `owner/repo`.

### Project Checkout

The project repository checkout supplied for branch and delivery reads or writes.

### Unit Checkout

The task branch checkout supplied for this unit.

### Authenticated Access

Authenticated tracker access for the selected repositories.

### Failure

The operation and error, discrepancy or missing evidence that prevents a verified result.
```

## 028-epic

Exit: 0; receipt: [028-epic.json](receipts/028-epic.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/epic.md
```

Returned output:

```text
# Epic

An epic's prerequisite evidence, task delivery findings, integration readiness and completion state.

## Prerequisites

Read these files first.

- [Initiative Issue Body](initiative-issue-body.md)
- [Issue](issue.md)

## Operations

### Check Epic Prerequisites

The evidence required before starting an epic's work.

**Inputs:** [Initiative Evidence](#initiative-evidence), [Epic Body](#epic-body), [Prerequisite Records](#prerequisite-records).

**Outputs:** [Prerequisite Evidence](#prerequisite-evidence).

#### 1. Identify Named Prerequisites

Identify each prerequisite the supplied initiative row names.

#### 2. Apply Whole-Epic Dependency

Apply the initiative's [whole-epic dependency rule](initiative-issue-body.md#work-breakdown); a task row's reference to a row of another epic gates that row rather than this epic.

#### 3. Confirm Prerequisite Delivery

Confirm each prerequisite epic is closed as completed and every one of its bases has merged. Missing records leave the prerequisite unconfirmed.

#### 4. Return Prerequisite Evidence

Return the [Prerequisite Evidence](#prerequisite-evidence), identifying each confirmed prerequisite and missing condition. Only a confirmed result permits an unstarted epic's bases to be created or its task to be dispatched.

### Inspect Epic Delivery

The delivery findings for one epic from supplied evidence.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Output Body](#output-body).

**Outputs:** [Delivery Findings](#delivery-findings).

#### 1. Match Supplied Delivery

Apply [Match Pull Requests](#match-pull-requests) with the epic JSON, pull request records as `--prs` and link snapshot as `--links`, supplying a local scratch output body as `--fix`.
- A closed epic is normalized to the current Work Breakdown columns before its tasks are read, using the shared format rules. Ambiguous or unsupported table content is a blocker.
- For reported table normalization, Apply [Save Tracker Issue](issue.md#save-tracker-issue), fetch the saved epic and repeat the match before returning its evidence.

#### 2. Return Delivery Findings

Return the [Delivery Findings](#delivery-findings); missing linked pull requests are missing evidence for the caller to supply.

### Check Epic Readiness

The epic's eligibility for integration from current delivery and criterion evidence.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Verification Evidence](#verification-evidence).

**Outputs:** [Delivery State](#delivery-state).

#### 1. Inspect Current Delivery

Apply [Inspect Epic Delivery](#inspect-epic-delivery) with the supplied epic JSON, pull request records and complete issue-link snapshot.

#### 2. Confirm Integration Conditions

Confirm every task is delivered, every epic criterion is verified and ticked, and no open question or unresolved delivery discrepancy remains. An unmerged epic base awaiting integration is expected at this stage. Missing or stale verification leaves readiness unconfirmed.

#### 3. Return Integration Readiness

Return the integration readiness in [Delivery State](#delivery-state), with the evidence revisions and each blocker. Readiness establishes the epic's content conditions; the caller supplies pull-request review, target and head-check evidence for the merge.

### Check Epic Completion

The epic's normal delivery result before tracker closure.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Verification Evidence](#verification-evidence), [Base Merges](#base-merges).

**Outputs:** [Delivery State](#delivery-state).

#### 1. Check Current Readiness

Apply [Check Epic Readiness](#check-epic-readiness) with the current epic, pull request records, issue-link snapshot and criterion verification evidence.

#### 2. Reconcile Expected Bases

Reconcile the expected bases with the task delivery targets.

#### 3. Confirm Base Merges

Confirm every base has merged into its corresponding long-lived branch. An unknown or incomplete base list, or missing merge evidence, leaves completion unconfirmed even when every task is delivered and every criterion is ticked.

#### 4. Return Completion Result

Return the completion result in [Delivery State](#delivery-state), identifying remaining blockers. Passing normal delivery checks supplies the caller's closure evidence; the tracker issue's current Development-link gate still governs the write.

### Match Pull Requests

Reports an epic's delivery state against the pull requests that name it.

**Inputs:** [Epic Record](#epic-record), [Pull Request Records](#pull-request-records), [Issue Links](#issue-links), [Output Body](#output-body).

**Outputs:** [Delivery Findings](#delivery-findings).

#### 1. Match Pull Requests

Run this command from the workspace checkout with the supplied inputs.

- Results follow [Delivery Findings](#delivery-findings).

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py '[**&lt;epic-json-file&gt;**](#epic-record)' --prs '[**&lt;pull-request-records-file&gt;**](#pull-request-records)' --links '[**&lt;issue-link-snapshot-file&gt;**](#issue-links)' --fix '[**&lt;epic-body-file&gt;**](#output-body)'
</pre></big>

**Example:**

<big><pre>
cd "[**&lt;workspace&gt;**](#workspace)" && "[**&lt;workspace&gt;**](#workspace)/scripts/sbx" python3 skills/work-planner/scripts/sync.py issue-943.json --prs prs.json --links links.json --fix epic-body.md
</pre></big>

## Fields

### Prerequisite Evidence

Each prerequisite has its issue identity and completion state, expected delivery bases and their merge evidence. The result identifies confirmed and missing conditions for the candidate epic.

### Delivery State

The epic is identified by its repository and issue number. Its state contains task delivery findings, criterion verification and ticks, open questions, expected delivery bases and their merges, and the revisions supporting the evidence. Integration readiness and completion are separate results, each with its unresolved conditions. An epic may be ready to integrate while one or more bases await merging.

### Delivery Findings

| Line | What it names |
| --- | --- |
| Normalized | Closed-epic table corrections present in the output body. |
| Retitle | A merged pull request linked by a task row whose title has no prefix or only a matching initiative or task prefix, or any pull request whose title names an epic of the initiative by a task id, with the required title for publication and readback. |
| Conflict | Tasks that share a pull request and do not name each other in Joins. A row linked to a pull request whose title names another epic. |
| Unmatched | A merged pull request that names the epic and that no row links. |
| In flight | An open pull request that names the epic and that no row links. A pull request whose head is an epic base is not a task match. |
| Draft | An epic base a merged task targets that holds a commit its long-lived branch lacks and has no open pull request merging it, while a task is undelivered or a criterion is unticked. A base level with or behind its branch is not draft. |
| Unmerged | An epic base its pull requests target that has not merged into its long-lived branch, once every task is delivered and every criterion is ticked. A draft pull request is named draft. |
| References | A review pull request whose cited pull requests differ from the task pull requests merged into its base. |
| Changes | A review pull request whose Changes section names, in a code span, a file absent from the head commit of the base it fronts, with that span. A span, less any `#anchor` or `:line` suffix, names a path when it holds a directory and carries an extension or opens with a top-level directory of that head, or is a bare name whose extension a file at that head carries; a component `<branch>:<path>` names its path only for the base of that branch. A path stands where the head holds a file or a directory at it. |
| Uncited | A linked pull request whose task has its own issue and does not link it, or a review pull request that does not link the epic's issue. |
| Note | A row that links its task issue. |
| Unchanged | A row that links a task issue the run was not given. Its Done cell stands, and the epic is not closable until a run is given that issue. |
| Unplaced | A task issue of this epic whose id is not a row. |
| Open questions | The epic's Open Questions section remains. |
| Ready to verify | An unticked criterion whose delivering rows are all delivered and whose linked passed checks do not settle it. |
| Ticked early | A criterion ticked while a delivering row is not delivered. |
| Disagreement | A linked pull request's test plan against the Coverage of the rows it delivers. |
| Target | An open or merged pull request naming the epic off its delivery routes: a task pull request into anything but one of the epic's bases, or an integration pull request into anything but the long-lived branch its head names. Each names the base it belongs in: for a task pull request, the epic base of the long-lived branch its task branch's last slug word names where another of the epic's pull requests comes from a branch of the same stem ending in another long-lived branch, as a unit changing several takes one task branch per base; else of the one its target names; else each epic base as one of them. |
| No epic | A pull request whose title opens with the initiative's id, `[I07`, and names neither an epic as `[I07:E00]` nor a task as `[I07:E00:W01]`: a bare `[I07]`, or an epic id in any other form, such as `[I07:E1]`. Nothing reads it as delivery. |
| Source | The configuration path, commit and repository of each `config/branches` statement the long-lived branch names were read from. |
| Unevaluable | A `config/branches` statement that is absent, empty or unreadable at its epic base, or a revision resolving to no commit, with its source; statements that disagree across the epic bases, each with its source and names; no long-lived branches given; a base that would be draft whose commits cannot be compared with its long-lived branch; or a review whose head commit the checkout does not hold, so its Changes paths are unread; each with the reason. |
| Not checked | Each epic check that reads the long-lived branches, while their names are unevaluable. |

An unmet row links a merged pull request while a covered criterion remains unticked. A linked pull request naming another epic is a conflict and delivers its linked task once merged. A missing linked pull request leaves the supplied evidence incomplete.

A coverage disagreement identifies the pull request and row, a criterion absent from either the test plan or row Coverage, an empty Test cell, or prose assigning the criterion to another task. Recording links, verified criteria and Done continues despite that finding.

### Epic Record

The supplied complete current epic issue JSON.

### Initiative Evidence

The current initiative body and row, including each prerequisite the row names.

### Prerequisite Records

The current issue and base-merge records for every prerequisite named by the initiative row.

### Pull Request Records

The supplied current pull request records for the epic.

### Issue Links

The complete supplied snapshot of the pull requests' Development-linked issues.

### Verification Evidence

The criterion verification evidence for the current delivery revisions.

### Base Merges

The complete expected epic-base list and each base's merge evidence into its corresponding long-lived branch.

### Output Body

The supplied local scratch destination for the corrected epic body.

### Workspace

The absolute checkout holding the installed Work Planner scripts and sandbox helper.

### Epic Body

The supplied complete current epic body text.
```

## 029-sync

Exit: 0; receipt: [029-sync.json](receipts/029-sync.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/modes/sync-mode.md
```

Returned output:

```text
# Sync Mode

Records delivery on an initiative, its epics, and their task issues. Each task that has a pull request is linked to that pull request, open or merged. Criteria that now hold are recorded, complete rows are marked done, complete issues are closed, and the initiative's theme board is brought up to date.

**Runs in:** the project checkout.

Follow the [Procedure](#procedure), adhering to [Rules](../rules.md) and [Conventions](../conventions.md) and ensure all [Outcomes](#outcomes) are met.

## Prerequisites

Read these files first.

- [Issue](../artifacts/issue.md)
- [Issue Body](../artifacts/issue-body.md)
- [Acceptance Criteria](../artifacts/acceptance-criteria.md)
- [Task Body](../artifacts/task-body.md)
- [Pull Request](../artifacts/pull-request.md)
- [Delivery Evidence](../artifacts/delivery-evidence.md)
- [Epic](../artifacts/epic.md)
- [Epic Issue Body](../artifacts/epic-issue-body.md)
- [Initiative Issue Body](../artifacts/initiative-issue-body.md)
- [Board](../artifacts/board.md)
- [Work Item](../artifacts/work-item.md)
- [Understand Mode](understand-mode.md)
- [Board Delivery](../artifacts/board-delivery.md)
- [Issue Closure](../protocols/issue-closure.md)
- [Review Pull Request](../protocols/review-pull-request.md)
- [Epic Integration](../protocols/epic-integration.md)
- [Plan Change](../artifacts/plan-change.md)

## Procedure

### 1. Select

Select an initiative with its open epics, or the epics the user names.

- Apply [Read Tracker Issue](../artifacts/issue.md#read-tracker-issue) for each selected issue before inspecting its Open Questions or format.
- Use the returned current JSON and body in the following checks.

For an epic with Open Questions:

- Obtain the user's decision on each question.
- Apply [Apply Body Corrections](../artifacts/issue-body.md#apply-body-corrections) with confirmed resolutions with the epic template and field conditions.
- Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with the returned body.
- Fetch the saved epic.
- Continue only when its Open Questions section is resolved; otherwise return the unresolved questions as blockers.

Apply [Validate Issue Body](../artifacts/issue-body.md#validate-issue-body). For a rejected issue:

- Apply [Repair Issue Format](../artifacts/issue-body.md#repair-issue-format) with that issue identity, current JSON, kind template and field conditions, required related evidence and output body path.
- When it returns, fetch the saved body again.
- Validate that saved body before continuing to the fetch step.
- Return a remaining format failure as a blocker.

### 2. Fetch

- Apply [Read Tracker Issue](../artifacts/issue.md#read-tracker-issue) for each issue, including each task issue under an epic being synced, titled as [Titles](../artifacts/task-body.md#titles) states.
- Apply [Read Delivery Evidence](../artifacts/delivery-evidence.md#read-delivery-evidence) with the selected repositories and initiative prefix, the fetched initiative, epic and task issue JSON, authenticated access and destination snapshot files.
- Use its returned pull request records, complete issue-link snapshot and findings in the following steps.
- Apply [Confirm Repository Auto-Close](../artifacts/issue.md#confirm-repository-auto-close) for the repository holding the issues, which gates every link, merge and closure this run makes.
- Capture each issue's Development links.

### 3. Unnamed Deliveries

When the user says work has landed but no pull request names its epic:

- Find the pull request.
- Confirm it with the user.
- Apply [Publish Pull Request](../artifacts/pull-request.md#publish-pull-request) with the epic's reference, `[I07:E00] Purpose`.
- Apply [Read Initiative Pull Requests](../artifacts/pull-request.md#read-initiative-pull-requests) again, with the fetched issue files.
- Apply [Fetch Pull Request Issue Links](../artifacts/pull-request.md#fetch-pull-request-issue-links) again.

### 4. Match Pull Requests to Tasks

Apply [Inspect Epic Delivery](../artifacts/epic.md#inspect-epic-delivery) for each epic.

- Use the unmatched and in-flight results defined in [Delivery Findings](../artifacts/epic.md#delivery-findings).
- Read its changes and description against the tasks' Descriptions.
- Name the tasks it works on: one task, or tasks that name each other in Joins.
- Put any match that is not clear to the user.

### 5. Sync Each Task Issue

For a task with a delivering pull request, open or merged, Apply [Verify Selected Criteria](../artifacts/acceptance-criteria.md#verify-selected-criteria) with its current body, selected criteria, delivery evidence, revisions, named instruments and the project checkout.

- Apply [Record Task Delivery](../artifacts/task-body.md#record-task-delivery) with the task JSON, pull request records, complete issue-link snapshot, delivering pull request number, returned verified criterion ids and output body path.
- Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with the returned body before closure.
- Once the pull request has merged, Apply [Comment on Issue](../artifacts/issue.md#comment-on-issue) to record it: `Delivered by #950.`
- Follow [Issue Closure](../protocols/issue-closure.md) when it reports closable.

### 6. Sync Each Epic

Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery), linking every match from the match step, open or merged, with the task issues, the project checkout and the fetched epic bases its long-lived branch names are read at. Linking a pull request replaces the planning-record link on that task.

Handle the returned delivery findings:

**Normalized.**

- The patch step publishes the corrected table.

**Retitle.**

- Apply [Publish Pull Request](../artifacts/pull-request.md#publish-pull-request) with the pull request and the title it names.

**Conflict.**

- Put it to the user.

**Unmatched.**

- Match them as in the match step.

**In flight.**

- Match them as in the match step.

**Draft.**

- Open it as a draft review pull request.
- Leave the epic open while its delivery is incomplete.

**Unmerged.**

- The close step opens or merges that pull request.

**Target.**

Confirm the base it names against its work item's [Component](../artifacts/work-item.md#component): the confirmed base is the epic base of the long-lived branch that Component names, whether the finding names that base, another, or one of several.

- A unit whose work items name several long-lived branches takes each task branch's base from the long-lived branch its last slug word names.

Apply [Publish Pull Request](../artifacts/pull-request.md#publish-pull-request) with an open pull request and the confirmed base.

- Put a merged one to the user, since its merge cannot be moved.

**References.**

- Follow [Review Pull Request](../protocols/review-pull-request.md) to bring the body up to the merges, with the project checkout and the fetched epic bases.

**Changes.**

- Follow [Review Pull Request](../protocols/review-pull-request.md) to restate the bullet naming the absent path, with the project checkout and the fetched epic bases.

**No epic.**

- Give it the epic it works on as the unnamed-deliveries step does, once the user confirms which.

**Uncited.**

- Apply [Link Pull Request to Issue](../artifacts/pull-request.md#link-pull-request-to-issue) with the link.
- Apply [Fetch Pull Request Issue Links](../artifacts/pull-request.md#fetch-pull-request-issue-links) again.

**Note.**

- Link the pull request as in the match step.

**Unplaced.**

- Draft the missing task row against [Work Breakdown](../artifacts/epic-issue-body.md#work-breakdown).

Apply [Check Plan Change Autonomy](../artifacts/plan-change.md#check-plan-change-autonomy) for the row, which is a task creation, with the allowance the caller supplied.

- Confirm an automatic row as drafted and Apply [Record Plan Change](../artifacts/plan-change.md#record-plan-change) with that row.
- A held row is settled as [Held Change](../artifacts/plan-change.md#held-change) states; an unanswered placement stays pending.

Apply [Revise Epic Rows](../artifacts/epic-issue-body.md#revise-epic-rows) with the confirmed row.

- Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with the returned body.
- Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery) again with the saved epic, refreshed task records and the same epic bases. An unanswered placement stays pending.

**Open questions.**

- Return to the select step for this epic.
- Resolve the questions there.
- Fetch the saved body, then Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery) again with the same epic bases.

**Ready to verify.**

- The verify step settles them.

**Unmet.**

- The verify step settles the unticked criteria, planning a gap task for any that need further work.

**Ticked early.**

- Untick them, or link the missing delivery.

**Disagreement.**

- Continue recording links, verified criteria and Done despite the reported coverage disagreement.

**Unevaluable.**

- Report each source and why to the user, with each check the run names not checked.
- Leave an unmatched or in-flight pull request whose head is an epic base unmatched, since the run could not tell it from a task delivery.
- Fetch each draft base, long-lived branch or review head named unread, and Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery) again with the same epic bases.
- The epic stays open until every epic base states the same readable declaration.

**Source.**

- Report it with the results.

**Not checked.**

- Report each check with the unevaluable sources that left it unread.

After applying the returned findings, Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery) again with the revised epic body and refreshed delivery records, retaining the complete issue-link snapshot, the same epic bases and output body path. Recording the epic's delivery is finished when unmatched, in flight, uncited, note, unchanged, and unplaced are clear, apart from a pull request the user leaves unmatched.

### 7. Verify

Apply [Verify Selected Criteria](../artifacts/acceptance-criteria.md#verify-selected-criteria) for the criteria reported ready to verify, supplying the current issue body, delivery findings, relevant delivery revisions, named instruments and the project checkout.

- Retain the returned verified criterion ids and evidence for the tick step.

For an unresolved epic criterion requiring further work:

- Apply [Plan Gap Task](../artifacts/epic-issue-body.md#plan-gap-task) with the current epic JSON and body, delivered task row, unmet criterion ids, delivery records, complete issue-link snapshot, project checkout, fetched epic bases and output body path.
- For each criterion it returns as already holding, Apply [Verify Selected Criteria](../artifacts/acceptance-criteria.md#verify-selected-criteria) again with that criterion id, the current epic body, delivery findings, delivery revisions, named instruments and the project checkout.
- Apply [Tick Verified Criteria](../artifacts/acceptance-criteria.md#tick-verified-criteria) with the returned verified ids, the current epic JSON, pull request records, complete issue-link snapshot and output body path, and Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with the returned body.
- Resume with its recorded disposition; a criterion that cannot be confirmed stays unticked.

### 8. Tick

Apply [Tick Verified Criteria](../artifacts/acceptance-criteria.md#tick-verified-criteria) with the confirmed criteria.

### 9. Patch

Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with each changed body from its output body file.

### 10. Close

- Apply [Select Project Board](../artifacts/board.md#select-project-board) for the initiative theme when the caller supplied no board identity. Report an absent board; integration still follows its own evidence gates.
- When the preceding Record Epic Delivery call reports an epic base unmerged and names no open pull request, open it as a draft review pull request and leave the epic open. Epic Integration establishes readiness from the completed delivery evidence.

For each open epic pull request:

- Follow [Epic Integration](../protocols/epic-integration.md) with the epic identity and body, review identity, project checkout, current delivery records, complete issue-link snapshot, criterion verification evidence and selected board identity or its confirmed absence.
- Report incomplete delivery or unmet merge requirements.

Fetch the pull requests again after merging.

- Apply [Record Epic Delivery](../artifacts/epic-issue-body.md#record-epic-delivery) again with the refreshed records, the same project checkout and the same epic bases.
- Follow [Issue Closure](../protocols/issue-closure.md) each epic the re-run reports closable.

### 11. Sync the Initiative

Apply [Record Initiative Delivery](../artifacts/initiative-issue-body.md#record-initiative-delivery) with the epic JSON fetched after closing.

For returned criteria ready to verify:

- Apply [Verify Selected Criteria](../artifacts/acceptance-criteria.md#verify-selected-criteria) with their ids, current initiative body, delivery findings, delivery revisions, named instruments and the project checkout.
- Apply [Tick Verified Criteria](../artifacts/acceptance-criteria.md#tick-verified-criteria) with returned verified ids, the initiative JSON, every linked epic record and output body file.
- Report the remaining findings as pending.

#### Save Verified Initiative

When a tick changed the initiative, Apply [Save Tracker Issue](../artifacts/issue.md#save-tracker-issue) with its output body file, so the board sync reads every criterion ticked.

#### Close Complete Initiative

Follow [Issue Closure](../protocols/issue-closure.md) for the initiative when it reports closable.

### 12. Sync the Board

Apply [Select Project Board](../artifacts/board.md#select-project-board) for the initiative's theme.

When the board is absent:

- Apply [Read Tracker Issue](../artifacts/issue.md#read-tracker-issue) for the originating proposal identified in the initiative's [References](../artifacts/initiative-issue-body.md#references); return unresolved provenance before board creation for a proposal-derived initiative.
- Apply [Copy Project Board](../artifacts/board.md#copy-project-board) with the owner, repository, theme title and originating proposal record when applicable.

Apply [Record Board Delivery](../artifacts/board-delivery.md#record-board-delivery) after the issue bodies and closures are saved.

### 13. Explain Each Change Entering Review

For each epic newly confirmed In Review by the board step:

- Follow [Understand Mode](understand-mode.md) with each epic review pull request, one run per base.
- Complete each overview before continuing; an initiative has no overview of its own. An issue already In Review when the sync began keeps the overview it has: the pull request it explains is the one already reviewed. A reviewer meets the overview on the pull request it explains. The run that integrates an epic base owns that epic's overview; this step writes one only where the board step confirms an epic In Review that integration did not already explain.

### 14. Report

Return saved delivery results and unresolved findings to the caller, or present them to the user for a direct request.

- Report queue decisions unevaluated by this run.
- Apply [Audit Closure Evidence](../artifacts/issue.md#audit-closure-evidence) for the repository holding the issues, naming the initiative, epics and tasks this run touched. Report each unsupported and unevaluable issue it returns, with its state reason and findings, and the not-planned closures apart. This run changes none of them.
- Report per issue: tasks linked, criteria ticked, rows marked done, criteria left unticked and why, conflicts, test plan disagreements, what was closed, each board and assignee change, and each overview written. What the report names about criteria is [Coverage Reports](../artifacts/issue-body.md#coverage-reports).

## Outcomes

- **Delivery recorded.**
  The user has each landed task tied to the pull request that delivered it, and has what now holds recorded on the initiative and its epics.
- **Complete work closed.**
  Work that is complete is closed.
- **The board is current.**
  The theme board shows where the initiative and its epics stand, including what a reviewer can take up.
- **A change entering review is explained.**
  Each epic that enters review has an overview on the pull request a reviewer reads.
- **The queue stays undecided.**
  A sync on its own leaves the choice of what to start next undecided.
```

## 030-config-read

Exit: 1; receipt: [030-config-read.json](receipts/030-config-read.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/i17-e01-w06/final-package/neutral-read.py --log /tmp/w06-walk-final-goal2/reads /tmp/i17-e01-w06/final-package/source/skills/work-planner/configuration.md --heading 'Planning Records'
```

Returned output:

```text
Failed to create stream fd: Operation not permitted
Failed to create stream fd: Operation not permitted
Failed to create stream fd: Operation not permitted
bwrap: No permissions to create a new namespace, likely because the kernel does not allow non-privileged user namespaces. See <https://deb.li/bubblewrap> or <file:///usr/share/doc/bubblewrap/README.Debian.gz>.
sbx: exit 1; writable: /tmp  (name more with SBX_EXTRA_ROOTS=dir1:dir2)
```

## 031-config-read-escalated

Exit: 0; receipt: [031-config-read-escalated.json](receipts/031-config-read-escalated.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/i17-e01-w06/final-package/neutral-read.py --log /tmp/w06-walk-final-goal2/reads /tmp/i17-e01-w06/final-package/source/skills/work-planner/configuration.md --heading 'Planning Records'
```

Returned output:

```text
## Planning Records

Planning records live under `artifacts/planning/` on the `engineering` branch.
```

## 032-initiative-artifact

Exit: 0; receipt: [032-initiative-artifact.json](receipts/032-initiative-artifact.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/initiative.md
```

Returned output:

```text
# Initiative

An initiative's epic delivery, criterion verification and completion state.

## Operations

### Check Initiative Completion

The initiative's normal delivery result before tracker closure.

**Inputs:** [Initiative Record](#initiative-record), [Epic Records](#epic-records), [Verification Evidence](#verification-evidence), [Development Evidence](#development-evidence).

**Outputs:** [Delivery State](#delivery-state).

#### 1. Evaluate Supplied Evidence

Evaluate the supplied evidence against [Delivery State](#delivery-state).

#### 2. Identify Missing Conditions

Identify each missing, open or cancelled epic, each unverified or unticked criterion, and each unmerged or unreadable Development-linked pull request. Incomplete link evidence leaves completion unconfirmed.

#### 3. Return Completion Result

Return the completion result and its supporting issue identities, evidence revisions and blockers. Passing normal delivery checks supplies the caller's closure evidence; the tracker issue's current Development-link gate still governs the write.

## Fields

### Identity

An initiative is identified by its repository and issue number. It groups and tracks its epics, with no branch or delivery pull request of its own.

### Delivery State

The state records every linked epic's completion, each initiative criterion's verification and tick, and the complete Development-linked pull request set and merge states. Each finding retains its source identity and evidence revision.

An epic is delivered when its issue is closed as completed. An open or cancelled epic remains undelivered, including when all initiative criteria are ticked. An epic the run was not given is unchecked: its row's Done cell stands, the sync reports the row unchanged, and completion stays unconfirmed. Criterion readiness and premature ticks are [Delivery Findings](#delivery-findings); delivery alone does not verify a criterion.

Initiative completion requires every linked epic to be closed as completed, every criterion verified and ticked, and every Development-linked pull request merged. Incomplete evidence leaves completion unconfirmed. The result names each missing condition.

### Delivery Findings

| Finding | Condition in the Supplied Initiative and Epic Records |
| --- | --- |
| Ready to verify | The initiative criterion is unticked and every epic whose Coverage cites it is delivered. |
| Ticked early | The initiative criterion is ticked and an epic whose Coverage cites it is undelivered. |

Epic delivery follows [Delivery State](#delivery-state). Each finding names the criterion and the supporting or missing epic evidence.

### Initiative Record

The supplied current initiative JSON.

### Epic Records

Every linked epic's current JSON.

### Verification Evidence

The supplied criterion verification evidence and its delivery revisions.

### Development Evidence

The current complete Development-link and linked pull-request records, including merge states.
```

## 033-items-shape

Exit: 0; receipt: [033-items-shape.json](receipts/033-items-shape.json).

```sh
jq 'type, (if type == "array" then .[0] | keys else keys end)' /tmp/i17-e01-w06/final-package/inputs/items.json
```

Returned output:

```text
"array"
[
  "archived_at",
  "content",
  "content_type",
  "created_at",
  "creator",
  "fields",
  "id",
  "item_url",
  "node_id",
  "project_url",
  "updated_at"
]
```

## 034-relevant-prs

Exit: 0; receipt: [034-relevant-prs.json](receipts/034-relevant-prs.json).

```sh
jq -c 'select((.title | startswith("[I17")) or (.base.repo.full_name=="m2ux/prosiform-skills")) | {number,title,state,draft,merged_at,merge_commit_sha,head:.head.ref,head_sha:.head.sha,base:.base.ref,repo:.base.repo.full_name}' /tmp/i17-e01-w06/final-package/inputs/prs.jsonl
```

Returned output:

```text
{"number":1647,"title":"[I17:E01] Delivery, Branch and Pull Request Artifact Contracts","state":"closed","draft":false,"merged_at":"2026-11-05T12:41:16Z","merge_commit_sha":"652ef07ea5b8553d3bdb73542c3a393ac20e6ea9","head":"i17/e01/w07-delivery-branch-and-pull","head_sha":"aed3e1715de513ad7efb620e0d95cd18c79dd8ba","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1646,"title":"[I17:E01] Issue Artifacts: Linked Contracts and Executing Commands","state":"closed","draft":false,"merged_at":"2026-11-05T11:49:11Z","merge_commit_sha":"709a038e40aafb59a05c1798f3d1a6b1f9248e83","head":"i17/e01/w05-issue-and-body-artifacts","head_sha":"c2b3dc2292fb7ba6aedc4b014d0e5bef084bd7a9","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1644,"title":"[I17:E01] Protocols in the New Style","state":"closed","draft":false,"merged_at":"2026-11-05T11:15:22Z","merge_commit_sha":"11e6085570ea60bd1132e32a5bd375d4fa03a77c","head":"i17/e01/w04-protocols-in-the-new","head_sha":"790370ae2eff38a5619ec68c2ca431748c31982a","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1643,"title":"[I17:E01] Modes in the New Style","state":"closed","draft":false,"merged_at":"2026-11-05T10:25:02Z","merge_commit_sha":"fb9a834c940cbed9742709d7e03594900e31d22f","head":"i17/e01/w03-modes-in-the-new","head_sha":"c28be9980208c469e2c119e715a5b9b50b9e246e","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1642,"title":"[I17:E01] Common Files: Rules, Conventions and Configuration","state":"closed","draft":false,"merged_at":"2026-11-05T09:23:37Z","merge_commit_sha":"238b652aaa52057f66c86c9651c379296a7ba5b2","head":"i17/e01/w02-rules-conventions-and-configuration","head_sha":"83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1641,"title":"[I17:E01] Skill Style: The Groundwork for Prosiform Compliance","state":"open","draft":true,"merged_at":null,"merge_commit_sha":"44f4a0746f61de8693149cd72023afee16baac24","head":"i17/e01/workspace","head_sha":"612da8d650f524eb05c3e2436bac3cdfd7f82e4c","base":"workspace","repo":"m2ux/workflow-server"}
{"number":1640,"title":"[I17:E01] Skill Models: Validate Heading Procedures and HTML Invocations","state":"closed","draft":false,"merged_at":"2026-11-05T08:42:20Z","merge_commit_sha":"dd44528b3fdea032c4128e1e0f638d038261498a","head":"i17/e01/w01-per-skill-style-model","head_sha":"3a73f75ba250942869d0f407990efc2b3b7869bc","base":"i17/e01/workspace","repo":"m2ux/workflow-server"}
{"number":1638,"title":"[I17:E03] Advance Reports: Show Ready Unit Lanes","state":"closed","draft":false,"merged_at":"2026-11-05T04:45:48Z","merge_commit_sha":"dbfe21c2bc88d97034c3de8e64e8b490ae54688f","head":"i17/e03/w13-advance-mode-reports-ready","head_sha":"a6d025d3025f08ad4b0a027d9762ccd0096a780b","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1637,"title":"[I17:E03] Ready Unit Lanes: Queue Reports Task Table Assignments","state":"closed","draft":false,"merged_at":"2026-11-05T04:35:26Z","merge_commit_sha":"f29df94515dc4c4d229cfa5c07db18cea3f4307a","head":"i17/e03/w11-board-queue-reports-ready","head_sha":"baef322b8b6fb83e5b1ffbd90d7de3afa33ad743","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1635,"title":"[I17:E03] Joined Units: Bound Joins to Their Owning Epic","state":"closed","draft":false,"merged_at":"2026-11-05T04:20:47Z","merge_commit_sha":"b5c0654013269a382883c4e41fe20937e20ed60b","head":"i17/e03/w14-cross-epic-joins-receive","head_sha":"a2169bc306fa55f7450aab555a6db515e6d8b190","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1634,"title":"[I17:E03] Requested Delivery Lanes: Every Survey Uses the Request","state":"closed","draft":false,"merged_at":"2026-11-05T04:15:19Z","merge_commit_sha":"1eb5ea97dc29202cd3dd8d15e0c191363a7316f7","head":"i17/e03/w09-deliver-mode-passes-the","head_sha":"66ec92c4fea05169e8dc8cda3c02f41fd63e625d","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1633,"title":"[I17:E03] Planned Lanes: Confirm Task Row Assignments","state":"closed","draft":false,"merged_at":"2026-11-05T04:08:09Z","merge_commit_sha":"8ffeaeaa9e1e201950efe5629c563aac8e5db97a","head":"i17/e03/w10-plan-mode-writes-task","head_sha":"2fc0ea4322fc2d2a4d3ecc2c3079bea2dca3e75b","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1632,"title":"[I17:E03] Delivery Admission: Available Units Follow the Requested Lane","state":"closed","draft":false,"merged_at":"2026-11-05T04:02:06Z","merge_commit_sha":"6cc09a5c65de546fc4f10ba6692478b66b157dfb","head":"i17/e03/w07-delivery-plan-admits-units","head_sha":"2468d37694e795786305d7657afb71ffb29ddf2e","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1629,"title":"[I17:E03] Joined Task Lanes: Validate and Preserve Table Indices","state":"closed","draft":false,"merged_at":"2026-11-04T18:46:50Z","merge_commit_sha":"dffa25a9b1cf35225e5b83a83e9b2e7a8f1204c2","head":"i17/e03/w04-joined-rows-share-one","head_sha":"9420b0369d721e71dbc8d13c056361cb6410dc44","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1628,"title":"[I17:E03] Task Lanes: Keep Lane Indices in the Work Breakdown","state":"closed","draft":false,"merged_at":"2026-11-04T17:07:01Z","merge_commit_sha":"74e19867e905523b85d2da84c7b1cb35b2b60b53","head":"i17/e03/w02-task-table-carries-the","head_sha":"f5c2ce46ed6e1203e9e1cdc7360c9e400649af3d","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1627,"title":"[I17:E03] Delivery Lanes: Each Task Row Carries Its Lane","state":"closed","draft":false,"merged_at":"2026-11-05T07:08:36Z","merge_commit_sha":"03d353300ca4804194fd50d316d73e3bf1270d1d","head":"i17/e03/workspace","head_sha":"1ebd241841fc5963743cb0440dfaeb97d9e9ab34","base":"workspace","repo":"m2ux/workflow-server"}
{"number":1626,"title":"[I17:E03] Work Item Lanes: Declare an Optional Delivery Lane","state":"closed","draft":false,"merged_at":"2026-11-04T15:46:26Z","merge_commit_sha":"6f7370b864d848c2877ae695230e297b1225a36e","head":"i17/e03/w01-work-item-declares-an","head_sha":"2551eac0a26baa61b072a3e37d80f8daf1d5675a","base":"i17/e03/workspace","repo":"m2ux/workflow-server"}
{"number":1607,"title":"[I17:E00] Sync reads every linked pull request","state":"closed","draft":false,"merged_at":"2026-11-02T11:33:26Z","merge_commit_sha":"c300fcef6a56e2fa4455e4b82b26830d1c701fb4","head":"i17/e00/w04-sync-reads-every-linked","head_sha":"6e649fd483761af2ed8ce502e24d1c55a83fc83a","base":"i17/e00/workspace","repo":"m2ux/workflow-server"}
{"number":1605,"title":"[I17:E00] Planning commits directly to engineering","state":"closed","draft":false,"merged_at":"2026-11-02T11:28:35Z","merge_commit_sha":"91fbb5848b43a63fae3614c43f225a13f8abe622","head":"i17/e00/w01-planning-commits-directly-to","head_sha":"5998729491bcf1226af5e2025791173bd515ae28","base":"i17/e00/workspace","repo":"m2ux/workflow-server"}
{"number":1604,"title":"[I17:E00] Pre-Cutover Fixes","state":"closed","draft":false,"merged_at":"2026-11-02T12:07:32Z","merge_commit_sha":"48f4ac592814d6c74bd67d94350909d096835c45","head":"i17/e00/workspace","head_sha":"6a6041c8e2d924d80809b7ad71ebf3ebb5988b70","base":"workspace","repo":"m2ux/workflow-server"}
{"number":1603,"title":"[I17:E00] Board sync removes uncited not-planned items","state":"closed","draft":false,"merged_at":"2026-11-02T11:26:45Z","merge_commit_sha":"2d89d3b6b00761936e5d239fce108825b32fd3ac","head":"i17/e00/w03-board-sync-removes-uncited","head_sha":"5ac29e1b603583b6686e1215a7f1a346e6fd4884","base":"i17/e00/workspace","repo":"m2ux/workflow-server"}
{"number":1602,"title":"[I17:E00] Not-Planned Epic Leaves Its Initiative","state":"closed","draft":false,"merged_at":"2026-11-02T11:25:25Z","merge_commit_sha":"7f74d2d457aa0251c0a6bfd4bc0cc0b4319e8f2e","head":"i17/e00/w02-not-planned-epic-leaves","head_sha":"8c12e7a7b80d9adae59ad7a484c2c05590bac5ae","base":"i17/e00/workspace","repo":"m2ux/workflow-server"}
```

## 035-format-options

Exit: 0; receipt: [035-format-options.json](receipts/035-format-options.json).

```sh
rg -n 'add_argument|--epic|sources|source|ArgumentParser' /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/format.py
```

Returned output:

```text
6:  python3 format.py issue-936.json --epic issue-943.json --epic issue-937.json … [--fix fixed-936.md]
13:run prints the declaration path, the resolved commit and the repository as its source. A missing or
44:    for each epic given with --epic
356:    """The criteria a project requires of its epics and the source they were read from.
360:    source: str
388:    repository's worktrees it is, do not choose the criteria. The source names the declaration path,
395:        source = f'{DECLARATION} at {revision} in {project}'
396:        return Required((), source, f'{revision} resolves to no commit in {project}')
399:    source = f'{DECLARATION} at {commit} in {repository}'
402:        return Required((), source)
406:        return Required((), source, f'{source} is not JSON')
408:        return Required((), source, f'{source} is not an array')
412:            return Required((), source, f'an entry in {source} lacks {", ".join(missing)}')
413:    return Required(tuple(entries), source)
1094:    parser = argparse.ArgumentParser()
1095:    parser.add_argument('issue', help='issue JSON as the REST API returns it')
1096:    parser.add_argument('--initiative', help="epic: its initiative's issue JSON, for epic links")
1097:    parser.add_argument('--epic', action='append', help="initiative: an epic's issue JSON, whose title "
1099:    parser.add_argument('--fix', help='write the mechanically fixed body here')
1100:    parser.add_argument('--prs', help='epic: pull requests as JSON lines, for the required criteria check')
1101:    parser.add_argument('--files', action='append', default=[], metavar='NUMBER=FILE',
1104:    parser.add_argument('--project', default='', help='epic: any checkout of the repository whose '
1106:    parser.add_argument('--revision', default='', help='epic: the commit the declaration is read at, its epic '
1129:        print(f'  source: {required.source}')
```

## 036-items-matching

Exit: 0; receipt: [036-items-matching.json](receipts/036-items-matching.json).

```sh
jq -r '.[] | select(.content.number == 1598 or .content.number == 1615 or .content.number == 1625 or ((.content.title // "") | startswith("[I16"))) | {item:.id,issue:.content.number,title:.content.title,fields,content_keys:(.content|keys)}' /tmp/i17-e01-w06/final-package/inputs/items.json
```

Returned output:

```text
{
  "item": 290671545,
  "issue": 1,
  "title": "[I16] Work Planner Home: The Skill in a Repository of Its Own",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290671560,
  "issue": 2,
  "title": "[I16:E00] Skill Cutover: The Skill Moves Unchanged with Its History",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290671577,
  "issue": 3,
  "title": "[I16:E01] Workspace Linkage: Prosiform's Workspace Runs the Skill From a Pinned Submodule",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290671590,
  "issue": 4,
  "title": "[I16:E03] Priority Field: The Board's Number Ranks the Work",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290685597,
  "issue": 5,
  "title": "[I16:E02] Skill Refactor: Scripts and the Shared Check Hold at the New Root",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290697568,
  "issue": 6,
  "title": "[I16:E04] Shared Prosiform Rules: The Guide States How a Skill Compiles",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290697577,
  "issue": 7,
  "title": "[I16:E05] Check Definitions: Each Check Defined in the Shared Guide, Named by Link",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290697584,
  "issue": 8,
  "title": "[I16:E06] Work Planner Links: Each Link Carries the Content Its Reader Needs",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290697591,
  "issue": 9,
  "title": "[I16:E07] Use Through Prosiform: Every Mode Compiles Within Budget and the Check Enforces It",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 290714416,
  "issue": 1598,
  "title": "[I17:E00] Pre-Cutover Fixes: Skill Corrections Merged Before the Extraction",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "98236657",
        "name": {
          "raw": "Done",
          "html": "Done"
        },
        "description": {
          "raw": "Closed or merged",
          "html": "Closed or merged"
        },
        "color": "GREEN"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 291137184,
  "issue": 1615,
  "title": "[I17:E02] Skill Separation: Every Rule in One Home Before the Extraction",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "f75ad846",
        "name": {
          "raw": "Backlog",
          "html": "Backlog"
        },
        "description": {
          "raw": "Not yet ready to start",
          "html": "Not yet ready to start"
        },
        "color": "GRAY"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
{
  "item": 291913055,
  "issue": 1625,
  "title": "[I17:E03] Delivery Lanes: Each Task Row Carries Its Lane",
  "fields": [
    {
      "id": 422017304,
      "name": "Status",
      "data_type": "single_select",
      "value": {
        "id": "98236657",
        "name": {
          "raw": "Done",
          "html": "Done"
        },
        "description": {
          "raw": "Closed or merged",
          "html": "Closed or merged"
        },
        "color": "GREEN"
      }
    }
  ],
  "content_keys": [
    "active_lock_reason",
    "assignee",
    "assignees",
    "author_association",
    "body",
    "closed_at",
    "comments",
    "comments_url",
    "created_at",
    "events_url",
    "html_url",
    "id",
    "issue_dependencies_summary",
    "labels",
    "labels_url",
    "locked",
    "milestone",
    "node_id",
    "number",
    "performed_via_github_app",
    "pinned_comment",
    "reactions",
    "repository",
    "repository_url",
    "state",
    "state_reason",
    "sub_issues_summary",
    "timeline_url",
    "title",
    "updated_at",
    "url",
    "user"
  ]
}
```

## 037-pr-repository-inventory

Exit: 0; receipt: [037-pr-repository-inventory.json](receipts/037-pr-repository-inventory.json).

```sh
jq -s 'group_by(.base.repo.full_name) | map({repo:.[0].base.repo.full_name,count:length})' /tmp/i17-e01-w06/final-package/inputs/prs.jsonl
```

Returned output:

```text
[
  {
    "repo": "m2ux/workflow-server",
    "count": 363
  }
]
```

## 038-format-header

Exit: 0; receipt: [038-format-header.json](receipts/038-format-header.json).

```sh
sed -n '1,70p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/format.py
```

Returned output:

```text
"""Check a proposal, initiative, epic, task, hot-fix or standalone issue against its agent-engineering template, and
fix what is mechanical.

Usage:
  python3 format.py issue-943.json [--initiative issue-936.json] [--fix fixed-943.md]
  python3 format.py issue-936.json --epic issue-943.json --epic issue-937.json … [--fix fixed-936.md]
  python3 format.py issue-943.json --prs prs.json --files 950=changed-950.txt … --project <checkout> \
    --revision origin/i07/e00/workspace

An epic checked with --project and --revision is held to the criteria its project requires. They are
the ones config/required-criteria.json declares at the commit --revision resolves to, in the repository
--project locates. Which worktree --project is, and what its working files hold, choose nothing. The
run prints the declaration path, the resolved commit and the repository as its source. A missing or
empty declaration at that commit, or an empty array, requires no criterion. A revision resolving to
no commit, unreadable JSON, a value other than an array, or an entry lacking a field leaves the
required criteria unevaluable: the run reports that and names the fault, and reports no criterion
as lacking. Each declared criterion is required of an epic one of whose pull requests, from
--prs, reaches its branch through an epic base or initiative branch and changes a file at or under one
of its paths. --files gives each pull request's changed files, the path list the tracker returns for
it. A pull request reaching a declared branch without its changed files leaves that criterion
unevaluable, unless another one is known to change a declared path. An epic carries a criterion when
one of its acceptance criteria holds its phrase, in any case.

issue-943.json is the issue as `gh api repos/{owner}/{repo}/issues/943` returns it. The kind comes
from the title prefix: [P00] proposal, [I07] initiative, [I07:E00] epic, [I07:E00:W01] task, [F00]
hot-fix. A proposal also carries type:proposal; the [F00] prefix alone makes an issue a hot-fix,
which also carries type:hot-fix. A type:task issue is a task whatever its prefix depth, so one whose
prefix has no task id is checked as a task and reported as missing it. A hot-fix takes the standalone
template, as artifacts/hotfix-body.md states. No prefix and no type:proposal is a standalone issue,
which belongs to no initiative and takes artifacts/standalone-body.md. The format is read
from the Markdown template under Fields in each body artifact: its sections and their order, the sections it marks
optional ("delete the section", in any case), and its Work Breakdown columns.

Fixed in the body written to --fix, keeping the issue's wording:
  - template sections put in template order, each extra section moving with the one before it
  - Work Breakdown columns put in template order, and missing ones added empty, when every column
    present is a template column. A checkbox in Done is set to ✓ or cleared
  - table rows padded to the header's width
  - Work Breakdown references given colons (E01 W02 to E01:W02, I05 E00 to I05:E00), and each
    reference to an epic of the same initiative linked to that epic's issue. The epic issues come
    from the row-id links of the initiative's table: the issue's own, or --initiative's when the
    issue is an epic
  - an initiative row's Description set to its epic's title name, the part before the colon,
    for each epic given with --epic
  - prose Non-Goals made a bulleted list, one sentence per bullet
  - a Problem or Proposal item that opens with a bold statement given its body on the next line,
    indented under the bullet, except a bulleted item with sub-bullets, whose line introducing
    them stays on, or rejoins, its bold statement's line
  - acceptance criteria made checkboxes, labelled **ACn.** when none is labelled; references
    labelled **Rn.** when none is; plain ACn. or Rn. labels made bold in place, keeping their numbers
Printed as fixes to apply to the issue itself:
  - a title prefix that separates levels with spaces, with its colon form
  - a type:* label that does not match the issue's kind, a theme:* label on a proposal, any type:* label on
    a standalone issue, or a hot-fix without priority: 10 or with another priority:* label
  - an epic checked with --initiative whose row there does not carry the epic's title name
Left to decide, since each needs new content or a judgement:
  - a type:task issue whose title prefix has no task id, which its row in its epic's Work Breakdown supplies
  - a type:hot-fix label on a title without an [F00] prefix, which is retitled or loses the label
  - each condition of a hot-fix body that no other kind carries, as hotfix.hotfix_faults reads it,
    prefixed "hot-fix:": one Target: line, no open question, and a criterion
  - a body that follows another kind's template
  - a required section missing, an extra section, or text before the first section
  - prose in the Work Breakdown outside its table
  - an epic's task delivering more than three criteria, a candidate for splitting, and a criterion
    more than one task cites, which is imprecise and is split so each task covers at least one
    acceptance criterion
  - wording that narrates how the plan changed (moved to, was W06, renumbered, formerly,
    previously, no longer, discharged, superseded, subsumed, used to)
  - a Problem or Proposal that names an epic, task, or acceptance criterion of its own initiative
  - an initiative's acceptance criterion that may state several invariants (a colon or semicolon in
```

## 040-extract-1598

Exit: 0; receipt: [040-extract-1598.json](receipts/040-extract-1598.json).

```sh
jq '.[] | select(.content.number == 1598 and (.content.repository_url | endswith("/workflow-server"))) | .content' /tmp/i17-e01-w06/final-package/inputs/items.json > /tmp/w06-walk-final-goal2/epic-1598.json
```

Returned output:

```text
(empty)
```

## 040-extract-1615

Exit: 0; receipt: [040-extract-1615.json](receipts/040-extract-1615.json).

```sh
jq '.[] | select(.content.number == 1615 and (.content.repository_url | endswith("/workflow-server"))) | .content' /tmp/i17-e01-w06/final-package/inputs/items.json > /tmp/w06-walk-final-goal2/epic-1615.json
```

Returned output:

```text
(empty)
```

## 040-extract-1625

Exit: 0; receipt: [040-extract-1625.json](receipts/040-extract-1625.json).

```sh
jq '.[] | select(.content.number == 1625 and (.content.repository_url | endswith("/workflow-server"))) | .content' /tmp/i17-e01-w06/final-package/inputs/items.json > /tmp/w06-walk-final-goal2/epic-1625.json
```

Returned output:

```text
(empty)
```

## 040-extract-cutover

Exit: 0; receipt: [040-extract-cutover.json](receipts/040-extract-cutover.json).

```sh
jq '.[] | select(.content.title | startswith("[I16:E00]")) | .content' /tmp/i17-e01-w06/final-package/inputs/items.json > /tmp/w06-walk-final-goal2/cutover-2.json
```

Returned output:

```text
(empty)
```

## 041-body-cutover-2

Exit: 0; receipt: [041-body-cutover-2.json](receipts/041-body-cutover-2.json).

```sh
jq -r '.body' /tmp/w06-walk-final-goal2/cutover-2.json > /tmp/w06-walk-final-goal2/cutover-2.md
```

Returned output:

```text
(empty)
```

## 041-body-epic-1598

Exit: 0; receipt: [041-body-epic-1598.json](receipts/041-body-epic-1598.json).

```sh
jq -r '.body' /tmp/w06-walk-final-goal2/epic-1598.json > /tmp/w06-walk-final-goal2/epic-1598.md
```

Returned output:

```text
(empty)
```

## 041-body-epic-1615

Exit: 0; receipt: [041-body-epic-1615.json](receipts/041-body-epic-1615.json).

```sh
jq -r '.body' /tmp/w06-walk-final-goal2/epic-1615.json > /tmp/w06-walk-final-goal2/epic-1615.md
```

Returned output:

```text
(empty)
```

## 041-body-epic-1616

Exit: 0; receipt: [041-body-epic-1616.json](receipts/041-body-epic-1616.json).

```sh
jq -r '.body' /tmp/i17-e01-w06/final-package/inputs/epic-1616.json > /tmp/w06-walk-final-goal2/epic-1616.md
```

Returned output:

```text
(empty)
```

## 041-body-epic-1625

Exit: 0; receipt: [041-body-epic-1625.json](receipts/041-body-epic-1625.json).

```sh
jq -r '.body' /tmp/w06-walk-final-goal2/epic-1625.json > /tmp/w06-walk-final-goal2/epic-1625.md
```

Returned output:

```text
(empty)
```

## 041-body-initiative-1597

Exit: 0; receipt: [041-body-initiative-1597.json](receipts/041-body-initiative-1597.json).

```sh
jq -r '.body' /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json > /tmp/w06-walk-final-goal2/initiative-1597.md
```

Returned output:

```text
(empty)
```

## 042-read-cutover-2

Exit: 0; receipt: [042-read-cutover-2.json](receipts/042-read-cutover-2.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/cutover-2.md
```

Returned output:

```text
     1	## Overview
     2	
     3	This epic cuts the work-planner skill over to its own repository. The skill, with its history and the shared guide, rules, check and tests it is held to, moves from workflow-server's `skills/` folder to the root of prosiform-skills as it is, with no change to its content.
     4	
     5	## Problem
     6	
     7	The skill shares a repository with work it has nothing to do with.
     8	
     9	- **It lives in workflow-server.**
    10	  Its [entry point](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/SKILL.md#L1-L5) sits beside three unrelated skills, so its history and pull requests are workflow-server's.
    11	- **The new repository has no `main`.**
    12	  prosiform-skills holds only its orphan `engineering` branch, which GitHub made its default branch.
    13	- **Nothing states its branches.**
    14	  prosiform-skills has no `config/branches`, so the skill's branch reads there report the names unevaluable.
    15	
    16	## Proposal
    17	
    18	- **History moves with the files.**
    19	  `git filter-repo` keeps `skills/work-planner/`, `skills/guidelines.md`, `skills/rules.json`, `skills/scripts/check_skill_files.py` and `skills/test/test_check_skill_files.py`, and moves them up one level.
    20	- **Content moves unchanged.**
    21	  No file's content changes. The skill's commands still name `skills/work-planner/scripts/<name>.py`, which holds in a workspace that links the skill at `skills/work-planner`.
    22	- **The extraction is `main`'s first history.**
    23	  It is pushed directly, before any epic base exists, and `main` becomes the default branch. It is cut from workflow-server's `workspace` head once I17's Pre-Cutover Fixes, Skill Separation and Skill Style epics close, and its tree is compared with workflow-server's at that commit.
    24	- **The repository states its branches.**
    25	  `config/branches` names `main`, which task and epic pull requests target, and `engineering`, which holds planning records.
    26	
    27	## Work Breakdown
    28	
    29	| Task | Description | Coverage | Depends on | Joins | Lane | Done |
    30	| --- | --- | --- | --- | --- | --- | --- |
    31	| [W00](https://github.com/m2ux/prosiform-skills/blob/engineering/artifacts/planning/2026-11-02-1-i16-work-planner-repository/e00/w00.md) | Skill history extracted into main | AC1, AC2, AC3 | [I17:E00](https://github.com/m2ux/workflow-server/issues/1598), [I17:E01](https://github.com/m2ux/workflow-server/issues/1616), [I17:E02](https://github.com/m2ux/workflow-server/issues/1615) | | | |
    32	| [W01](https://github.com/m2ux/prosiform-skills/blob/engineering/artifacts/planning/2026-11-02-1-i16-work-planner-repository/e00/w01.md) | Long-lived branches stated | AC4 | W00 | | | |
    33	
    34	## Acceptance Criteria
    35	
    36	- [ ] **AC1.** Each of `work-planner/`, `guidelines.md`, `rules.json`, `scripts/check_skill_files.py` and `test/test_check_skill_files.py` on prosiform-skills' `main` has the content its `skills/` counterpart has at the extracted workflow-server commit, as a `git diff` of the two trees shows.
    37	- [ ] **AC2.** `work-planner/SKILL.md` on `main` carries the commits that changed `skills/work-planner/SKILL.md` in workflow-server up to the extracted commit, as a comparison of the two `git log --format=%s` listings shows.
    38	- [ ] **AC3.** prosiform-skills' default branch is `main`, as `gh api repos/m2ux/prosiform-skills --jq .default_branch` shows.
    39	- [ ] **AC4.** The long-lived branches stated on `main` are `engineering` and `main`, as `sync.py --names --revision origin/main` prints.
    40	
    41	## References
    42	
    43	- **R1.** [Planning record](https://github.com/m2ux/prosiform-skills/tree/engineering/artifacts/planning/2026-11-02-1-i16-work-planner-repository) — the decisions, the goal trace and each task's work item.
    44	- **R2.** [workflow-server `skills/` at the evidence revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills) — the folder this epic extracts from.
    45	
    46	🤖 Generated with [Claude Code](https://claude.com/claude-code)
    47	
```

## 042-read-epic-1598

Exit: 0; receipt: [042-read-epic-1598.json](receipts/042-read-epic-1598.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/epic-1598.md
```

Returned output:

```text
     1	## Overview
     2	
     3	This epic delivers each Work Planner fix found before the skill's extraction to its own repository, merged into `workspace` so the extraction carries it. Each fix is a task row, and a fault found later joins as a further row.
     4	
     5	## Problem
     6	
     7	The skill carries faults its own planning and sync runs have exposed.
     8	
     9	- **Planning takes a branch the record forbids.**
    10	  [Plan Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L42-L43) opens a draft discussion pull request from a planning branch, while the [planning record](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/planning-record.md#L153) states the engineering branch takes no further branch.
    11	- **Draft bodies sit outside the record.**
    12	  The [Bodies convention](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/SKILL.md#L96) keeps body files outside the repository, so a plan's drafts are not part of its committed record.
    13	- **A not-planned epic has no rule.**
    14	  [Initiative rows](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/initiative-issue-body.md#L143-L153) say nothing of an epic closed as not planned; only [task rows another issue takes](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/epic-issue-body.md#L267-L268) leave a table.
    15	- **A criterion gap asks for a decision.**
    16	  The [format check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/format.py#L1024-L1025) asks to decide criterion labels not numbered from one without a gap. When #1427 closed as not planned, #1166 dropped its row by hand.
    17	- **Uncited closed items stay on the board.**
    18	  [Board sync](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board.py#L578-L582) removes an item closed other than as completed only when a plan body cites it, so #1427 and #1475 were deleted from their board by hand.
    19	- **Sync misses untitled pull requests.**
    20	  [Read Initiative Pull Requests](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L95-L102) keeps only [titles carrying the initiative prefix](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L523-L539), so older task pull requests that #1166's epic rows link went unread until fetched by hand.
    21	
    22	## Proposal
    23	
    24	- **Planning commits straight to engineering.**
    25	  Every planning artifact, draft bodies and work items included, is committed to the engineering branch in its planning record's folder. Planning opens no branch and no pull request.
    26	- **A not-planned epic leaves its initiative.**
    27	  Its row and the criteria only it covers are removed, and References name where its work went. Criterion numbers other work cites are kept, and the format check accepts the gap.
    28	- **Every item closed other than as completed leaves the board.**
    29	  Board sync applies that status to each such item on the board, whether or not a plan body cites it.
    30	- **Sync reads pull requests by their links.**
    31	  The fetch selects each pull request a row or a Development link of the plan names, whatever its title.
    32	
    33	## Work Breakdown
    34	
    35	| Task | Description | Coverage | Depends on | Joins | Done |
    36	| --- | --- | --- | --- | --- | --- |
    37	| [W01](https://github.com/m2ux/workflow-server/pull/1605) | Planning commits directly to engineering | AC1, AC2, AC3 | | | ✓ |
    38	| [W02](https://github.com/m2ux/workflow-server/pull/1602) | Not-planned epic leaves its initiative | AC4, AC5, AC6 | | | ✓ |
    39	| [W03](https://github.com/m2ux/workflow-server/pull/1603) | Board sync removes uncited not-planned items | AC7 | | | ✓ |
    40	| [W04](https://github.com/m2ux/workflow-server/pull/1607) | Sync reads every linked pull request | AC8 | | | ✓ |
    41	
    42	## Acceptance Criteria
    43	
    44	- [x] **AC1.** Plan Mode writes every draft body and work item into its planning record's folder, as the skill's fixture suite checks against the mode's procedure.
    45	- [x] **AC2.** Plan Mode publishes its planning record by committing it to the engineering branch and pushing that branch, as the skill's fixture suite checks against the mode's procedure.
    46	- [x] **AC3.** No skill file names a planning branch or a discussion pull request, as a search of the skill's files shows.
    47	- [x] **AC4.** An initiative row whose epic is closed as not planned is removed with every criterion only that row covers, as the initiative body's Work Breakdown conditions state.
    48	- [x] **AC5.** An initiative that removes such a row names where its work went in References, as the initiative body's References conditions state.
    49	- [x] **AC6.** The format check reports no finding on criterion labels that ascend with a gap, as the format check's fixture suite shows.
    50	- [x] **AC7.** Board sync removes every board item closed other than as completed, whether or not a plan body cites it, as the board fixture suite shows for a cited and an uncited item.
    51	- [x] **AC8.** Sync's pull request records hold every pull request a row or a Development link of the plan names, whatever its title, as the sync fixture suite shows for a linked pull request whose title carries no initiative prefix.
    52	
    53	## References
    54	
    55	- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
    56	
```

## 042-read-epic-1615

Exit: 0; receipt: [042-read-epic-1615.json](receipts/042-read-epic-1615.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/epic-1615.md
```

Returned output:

```text
     1	## Overview
     2	
     3	The work-planner skill gains SOLID guidelines fitted to its architecture, and the whole skill is audited and fixed against them in workflow-server before the skill's extraction is cut. Artifact and protocol files are treated as classes, and their linked operations as method calls that encapsulate each file's state. Each rule has one owning file or script module, and no general file names a specific kind of work, so the skill moves to prosiform-skills already separated.
     4	
     5	## Problem
     6	
     7	- **No separation grain is defined.** The guidelines define an artifact as one shape and a protocol as one change. They say nothing of how files encapsulate, extend or depend on one another.
     8	  - Open–closed is stated only for the issue-body family: "the common file names no kind".
     9	- **General files enumerate kinds of work.** The delivery plan, Deliver mode, pull request, board queue and Task Merge each name hot-fixes and branch on them.
    10	  - Adding a kind means editing every general file again.
    11	- **Scripts branch on kinds inline.**
    12	  The delivery and board-queue scripts run hot-fix paths beside the epic paths.
    13	- **No map of the breaches.**
    14	  Nobody has audited the whole skill, so the remaining breaches and their owning homes are unknown.
    15	
    16	## Proposal
    17	
    18	- **Files as classes, operations as methods.** An artifact or protocol file is a class, an operation is a public method, and a link to an operation heading is a method call.
    19	  - Commands are private methods, reached only from their own file's operations.
    20	  - Fields are the file's state and its public shape.
    21	  - Prerequisites are its imports.
    22	- **SOLID guidelines first.** The first task adds a SOLID section to the skill's guidelines.
    23	  - Single responsibility: one reason to change per file.
    24	  - Open–closed: a new kind is a new file, and general files name no kind.
    25	  - Liskov substitution: every kind fills an interface operation with the same contract.
    26	  - Interface segregation: small operations, and prerequisites that list only what is called.
    27	  - Dependency inversion: general files never link down to a kind, and kinds are listed in one registry.
    28	  - Each file-type section links that section rather than restating it.
    29	- **Audit against the guidelines.** The second task reviews every artifact, mode, protocol and script against the guidelines' audit questions.
    30	  - It records each breach in the planning record with its file, the guideline it breaks and the home that owns it.
    31	- **Fix rows from the audit.**
    32	  The fix tasks take the audit's findings by concern, and each is split into one row per group of files it touches, so parallel rows never edit the same file.
    33	- **Behaviour.**
    34	  Every fix moves where a rule is stated or implemented and keeps what the skill does.
    35	
    36	## Work Breakdown
    37	
    38	| Task | Description | Coverage | Depends on | Joins | Lane | Done |
    39	| --- | --- | --- | --- | --- | --- | --- |
    40	| W01 | SOLID guidelines for files and operations | AC1 | [E01:W08](https://github.com/m2ux/workflow-server/issues/1616) |  |  |  |
    41	| W02 | Audit the skill against the guidelines | AC2 | W01 | | | |
    42	| W03 | Generic prose in general artifacts and modes | AC3 | W02 | | | |
    43	| W04 | Generic interfaces in general scripts | AC4 | W02 | | | |
    44	| W05 | Each audited rule in one home | AC5 | W02 | | | |
    45	
    46	## Acceptance Criteria
    47	
    48	- [ ] **AC1.** The skill's guidelines state each SOLID principle for artifact, protocol and mode files, and every file-type section links to them, read in the skill guidelines.
    49	- [ ] **AC2.** Every breach of those guidelines in the skill's artifacts, modes, protocols and scripts is listed with its file, its guideline and its owning home, as the audit in the planning record shows.
    50	- [ ] **AC3.** No general artifact, mode or protocol names a specific kind of work as a case it handles, checked by a search of the skill.
    51	- [ ] **AC4.** No general script branches on a kind of work, and each kind's logic lives in its own module, checked by a search of the scripts.
    52	- [ ] **AC5.** Each rule the audit lists is stated in its owning home alone, and every other file links to it, checked by a search of the skill for each listed rule.
    53	
    54	## References
    55	
    56	- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the audit and each task's work item.
    57	- **R2.** [SOLID guidelines draft](https://github.com/m2ux/workflow-server/blob/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes/e02/solid-guidelines.md) — the guidelines the first task lands, with the class model and the audit questions.
    58	- **R3.** [Delivery Units](https://github.com/m2ux/workflow-server/issues/1614) — the delivery-path breach that prompted this review.
    59	- **R4.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/9d71790c2668debbc03a2ba1d00509e8bea3bff6/skills/work-planner) — the skill the review audits.
    60	
```

## 043-read-epic-1625

Exit: 0; receipt: [043-read-epic-1625.json](receipts/043-read-epic-1625.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/epic-1625.md
```

Returned output:

```text
     1	## Overview
     2	
     3	A board can be delivered by more than one session at once, each serving its own lane of task rows. Each row carries its lane as a bare index in the epic Work Breakdown table, Plan mode assigns it, and a Deliver run naming a lane takes its lane’s rows and unlaned rows. The epic lands before the skill’s extraction, so the skill moves with lanes.
     4	
     5	## Problem
     6	
     7	- **The live task table has no lane column.**
     8	  Its Task, Description, Coverage, Depends on, Joins and Done cells contain no lane assignment.
     9	- **Work-item declarations split the row’s plan.**
    10	  The epic base’s Work Item artifact defines a separate Lane declaration, so the task table alone cannot show or supply a row’s lane.
    11	- **Every session sees one queue.**
    12	  The delivery survey offers available units by priority and dependencies, so two sessions on one board can select the same unit.
    13	- **A label cannot carry it.**
    14	  A label marks an issue, while task rows in one epic can belong to different lanes and have no task issue.
    15	
    16	## Proposal
    17	
    18	- **The task table owns the lane.**
    19	  Its columns are `Task | Description | Coverage | Depends on | Joins | Lane | Done`. Lane contains a bare decimal index such as `2`; an empty cell is unlaned.
    20	- **A lane is an opaque board-wide index.**
    21	  The same index names one lane across the theme board. Its cell contains the index alone.
    22	- **The request names the run’s lane.**
    23	  A Deliver request states its lane each time. A request naming none is offered only unlaned units.
    24	- **A laned run also admits unlaned work.**
    25	  A run is offered its lane’s units and unlaned units, ordered by priority. Hot-fix units are unlaned.
    26	- **Plan mode writes the task cells.**
    27	  It asks whether the initiative uses lanes, proposes each row’s index for confirmation and passes the confirmed values to Populate Epic Issue Body.
    28	- **Joined rows share one lane.**
    29	  Their Lane cells carry the same index or are all empty. The dependency check refuses a split unit, settled by changing a lane or unjoining.
    30	- **Readers use the issue body.**
    31	  Dependency checks, delivery and queue reporting use one task-table lane reader. Work-item files supply components and implementation plans.
    32	- **Table operations preserve lanes.**
    33	  Format validation checks bare indices, and normalization, reservation, release, linking and Done ticks preserve the Lane cell.
    34	- **The queue reports unit lanes.**
    35	  Board Queue reports each Ready unit’s lane from its existing issue snapshots, and Advance carries those report lines.
    36	
    37	## Work Breakdown
    38	
    39	| Task | Description | Coverage | Depends on | Joins | Lane | Done |
    40	| --- | --- | --- | --- | --- | --- | --- |
    41	| [W01](https://github.com/m2ux/workflow-server/pull/1626) | Work item declares an optional lane | | | | | ✓ |
    42	| [W02](https://github.com/m2ux/workflow-server/pull/1628) | Task table carries the lane column | AC11 | | W03 | | ✓ |
    43	| [W03](https://github.com/m2ux/workflow-server/pull/1628) | Work item holds its component declaration | AC12 | W01 | W02 | | ✓ |
    44	| [W04](https://github.com/m2ux/workflow-server/pull/1629) | Joined rows share one lane | AC3 | W02 | W05, W06 | | ✓ |
    45	| [W05](https://github.com/m2ux/workflow-server/pull/1629) | Dependency check reads task table lanes | AC4 | W02 | W04, W06 | | ✓ |
    46	| [W06](https://github.com/m2ux/workflow-server/pull/1629) | Lane cells validate and survive table writes | AC13, AC14 | W02 | W04, W05 | | ✓ |
    47	| [W07](https://github.com/m2ux/workflow-server/pull/1632) | Delivery plan admits units by lane | AC2 | W02 | W08 | | ✓ |
    48	| [W08](https://github.com/m2ux/workflow-server/pull/1632) | Available-work survey filters units by lane | AC5 | W05 | W07 | | ✓ |
    49	| [W09](https://github.com/m2ux/workflow-server/pull/1634) | Deliver mode passes the requested lane | AC6 | W07 | | | ✓ |
    50	| [W10](https://github.com/m2ux/workflow-server/pull/1633) | Plan mode writes task row lanes | AC7 | W04 | | | ✓ |
    51	| [W11](https://github.com/m2ux/workflow-server/pull/1637) | Board queue reports Ready units' lanes | AC8 | W07 | W12 | | ✓ |
    52	| [W12](https://github.com/m2ux/workflow-server/pull/1637) | Board-queue script prints Ready unit lanes | AC9 | W05 | W11 | | ✓ |
    53	| [W13](https://github.com/m2ux/workflow-server/pull/1638) | Advance mode reports Ready unit lanes | AC10 | W11 | | | ✓ |
    54	| [W14](https://github.com/m2ux/workflow-server/pull/1635) | Cross-epic joins receive bounded diagnostics | AC15 | W05 | | | ✓ |
    55	
    56	## Acceptance Criteria
    57	
    58	- [x] **AC2.** The Delivery Plan artifact states lane admission from task-table Lane cells: a run naming an index is offered units in that lane and unlaned units, a run naming none is offered only unlaned units, priority orders admitted units, and each unit line names its lane, as a read of the artifact shows.
    59	- [x] **AC3.** The Dependency Graph artifact states that joined rows share one Lane index or all have empty Lane cells, and a split unit is refused with moving a lane or unjoining as its resolutions, as a read of the artifact shows.
    60	- [x] **AC4.** The dependency check reads and validates the task-table Lane cells and refuses a joined unit with different lane values, naming each row and its lane, as test_deps.py fixtures with equal, different, empty and malformed Lane cells show.
    61	- [x] **AC5.** The available-work survey reads task-table Lane cells and offers only the units admitted by the requested lane, including laned rows with no work-item link, as test_deliver.py fixtures with two lanes and unlaned rows show.
    62	- [x] **AC6.** Deliver mode passes the lane its request names to every Plan Available Work call, passes none when the request names none, and stores no lane per session, as a read of the mode shows.
    63	- [x] **AC7.** Plan mode asks whether an initiative uses lanes, proposes each row’s lane for confirmation and passes each confirmed index to Populate Epic Issue Body for its Lane cell, as a read of the mode shows.
    64	- [x] **AC8.** The Board Queue artifact states that each Ready unit’s reported lane comes from its task-table Lane cells in the supplied issue bodies, as a read of the artifact shows.
    65	- [x] **AC9.** The board-queue script reports each Ready unit’s task-table lane while producing identical placement calls for the same delivery state, as test_board_queue.py fixtures with laned and unlaned rows show.
    66	- [x] **AC10.** Advance mode reports each Ready unit’s lane from the returned board queue lines, as a read of the mode shows.
    67	- [x] **AC11.** The Epic Issue Body artifact defines and populates the exact task-table columns Task, Description, Coverage, Depends on, Joins, Lane, Done, with Lane holding a bare board-wide index such as 2 or an empty unlaned cell, as an artifact read and specimen row population show.
    68	- [x] **AC12.** The Work Item artifact’s population inputs, template, fields and section rules describe Component as its declaration and contain no Lane declaration path, as a read and search of the artifact show.
    69	- [x] **AC13.** The issue-format check rejects populated Lane cells that are not bare indices, as test_format.py fixtures for valid, empty, marked-up and prose cells show.
    70	- [x] **AC14.** Valid and empty Lane values stay attached to their task rows through normalization, reservation, release and delivery recording, as test_format.py, test_deliver.py and test_sync.py round-trip fixtures show.
    71	- [x] **AC15.** Joins entries outside their row’s epic produce a row-specific nonzero dependency-check result before epic-priority calculation, as CLI regression fixtures for the pinned reciprocal-join reproducer and ordinary same-epic joins show.
    72	
    73	## References
    74	
    75	- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the dependency report and each task's work item.
    76	- **R2.** [prosiform I10 Evaluation and Checks](https://github.com/m2ux/prosiform/issues/464) — the initiative whose two delivery sessions wait on the lane filter.
    77	- **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/b2844c821ce800ed3d12735bdf339049594e5ec5/skills/work-planner) — the skill this epic changes.
    78	
    79	- **R4.** [Cross-epic join input](https://github.com/m2ux/workflow-server/issues/1630) — the pinned unsupported-input priority recursion and its bounded-diagnostic fix.
    80	
```

## 044-format-initiative

Exit: 0; receipt: [044-format-initiative.json](receipts/044-format-initiative.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/format.py /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json --epic /tmp/w06-walk-final-goal2/epic-1598.json --epic /tmp/i17-e01-w06/final-package/inputs/epic-1616.json --epic /tmp/w06-walk-final-goal2/epic-1615.json --epic /tmp/w06-walk-final-goal2/epic-1625.json --fix /tmp/w06-walk-final-goal2/format-proposed-1597.md
```

Returned output:

```text
#1597 initiative (open): 0 fixed, 0 to apply, 0 to decide
```

## 045-git-revisions

Exit: 0; receipt: [045-git-revisions.json](receipts/045-git-revisions.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and rev-parse HEAD origin/workspace origin/i17/e01/workspace
```

Returned output:

```text
612da8d650f524eb05c3e2436bac3cdfd7f82e4c
03d353300ca4804194fd50d316d73e3bf1270d1d
612da8d650f524eb05c3e2436bac3cdfd7f82e4c
```

## 046-git-config

Exit: 0; receipt: [046-git-config.json](receipts/046-git-config.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and show 612da8d650f524eb05c3e2436bac3cdfd7f82e4c:config/branches
```

Returned output:

```text
docker
main
workflows
workspace
```

## 047-git-required

Exit: 0; receipt: [047-git-required.json](receipts/047-git-required.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and show 612da8d650f524eb05c3e2436bac3cdfd7f82e4c:config/required-criteria.json
```

Returned output:

```text
[
  {
    "branch": "workflows",
    "paths": ["corpus"],
    "criterion": "The definitions this epic changes carry no outstanding confirmed finding, one neither fixed on the epic's branch nor taken by an issue, as the canon audit's coverage report shows.",
    "phrase": "canon audit",
    "row": "Canon audit of the changed definitions"
  }
]
```

## 048-state-evidence

Exit: 0; receipt: [048-state-evidence.json](receipts/048-state-evidence.json).

```sh
jq '{number,title,state,state_reason,updated_at}' /tmp/w06-walk-final-goal2/epic-1598.json /tmp/w06-walk-final-goal2/epic-1615.json /tmp/w06-walk-final-goal2/epic-1625.json /tmp/w06-walk-final-goal2/cutover-2.json
```

Returned output:

```text
{
  "number": 1598,
  "title": "[I17:E00] Pre-Cutover Fixes: Skill Corrections Merged Before the Extraction",
  "state": "closed",
  "state_reason": "completed",
  "updated_at": "2026-11-02T12:08:38Z"
}
{
  "number": 1615,
  "title": "[I17:E02] Skill Separation: Every Rule in One Home Before the Extraction",
  "state": "open",
  "state_reason": null,
  "updated_at": "2026-11-05T08:10:02Z"
}
{
  "number": 1625,
  "title": "[I17:E03] Delivery Lanes: Each Task Row Carries Its Lane",
  "state": "closed",
  "state_reason": "completed",
  "updated_at": "2026-11-05T07:23:48Z"
}
{
  "number": 2,
  "title": "[I16:E00] Skill Cutover: The Skill Moves Unchanged with Its History",
  "state": "open",
  "state_reason": null,
  "updated_at": "2026-11-05T07:47:36Z"
}
```

## 049-numbered-initiative

Exit: 0; receipt: [049-numbered-initiative.json](receipts/049-numbered-initiative.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/initiative-1597.md
```

Returned output:

```text
     1	## Overview
     2	
     3	Every Work Planner skill fix found before the skill leaves workflow-server is merged into workflow-server's `workspace` branch before the skill's extraction is cut, so the repository the skill moves to starts with every known fix. The goal the reviews test against: each fix found before the cutover is delivered in workflow-server ahead of the extraction, and the extraction carries it.
     4	
     5	## Problem
     6	
     7	Faults found in the skill before its move have no plan that the move respects.
     8	
     9	- **A late fix misses the move.**
    10	  The skill is extracted to prosiform-skills with its content unchanged, so a fix merged into `workspace` after the extraction reaches only the copy workflow-server drops.
    11	- **Known faults are open.**
    12	  Closing the skill's own initiative exposed faults in [Plan Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L42-L43), the [format check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/format.py#L1024-L1025), [board sync](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board.py#L578-L582) and the [pull request fetch](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L523-L539).
    13	
    14	## Proposal
    15	
    16	- **Fixes land in workflow-server first.**
    17	  Each fix is a task row, merged into `workspace` through its epic base as any delivery is.
    18	- **The extraction waits for the fixes.**
    19	  I16's row that extracts the skill names these fixes as its prerequisite, so the extraction is cut from a `workspace` commit holding every one.
    20	- **Faults found later join the plan.**
    21	  A fault found before the extraction becomes a further task row, delivered ahead of the extraction like the rest.
    22	- **A feature the skill must carry joins too.**
    23	  A feature a workspace needs before the extraction, such as delivery lanes, is an epic of this initiative and lands ahead of the extraction as a fix does.
    24	
    25	## Work Breakdown
    26	
    27	| Epic | Description | Coverage | Depends on | Done |
    28	| --- | --- | --- | --- | --- |
    29	| [E00](https://github.com/m2ux/workflow-server/issues/1598) | Pre-Cutover Fixes | AC1 | | ✓ |
    30	| [E01](https://github.com/m2ux/workflow-server/issues/1616) | Skill Style | AC1 | | |
    31	| [E02](https://github.com/m2ux/workflow-server/issues/1615) | Skill Separation | AC1 | [E01](https://github.com/m2ux/workflow-server/issues/1616) | |
    32	| [E03](https://github.com/m2ux/workflow-server/issues/1625) | Delivery Lanes | AC1 | | ✓ |
    33	
    34	## Acceptance Criteria
    35	
    36	- [ ] **AC1.** Every Work Planner fix and feature planned here is in the history of the workflow-server `workspace` commit the skill's extraction is cut from, as `git merge-base --is-ancestor` shows for each one's merge commit.
    37	
    38	## Non-Goals
    39	
    40	- It does not change the skill's layout, script paths or priority source, which the move to the new repository settles.
    41	- It does not fix a fault found after the extraction is cut.
    42	
    43	## References
    44	
    45	- **R1.** [I16 Work Planner Home](https://github.com/m2ux/prosiform-skills/issues/1) — the skill's move to prosiform-skills, whose extraction waits for these fixes.
    46	- **R2.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
    47	- **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner) — the skill the fixes change.
    48	
```

## 050-local-log

Exit: 0; receipt: [050-local-log.json](receipts/050-local-log.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and log --oneline -10 612da8d650f524eb05c3e2436bac3cdfd7f82e4c
```

Returned output:

```text
612da8d65 name checkout inputs on coordinated calls
652ef07ea Merge pull request #1647 from m2ux/i17/e01/w07-delivery-branch-and-pull
aed3e1715 Work Planner: execute delivery commands through linked contracts
ecbbae624 Work Planner: validate contract arguments beside literal brackets
709a038e4 Merge pull request #1646 from m2ux/i17/e01/w05-issue-and-body-artifacts
c2b3dc229 define issue artifact contracts and executing steps
99c6866d0 recognize indented Markdown closing fences
11e608557 Merge pull request #1644 from m2ux/i17/e01/w04-protocols-in-the-new
790370ae2 Protocols: State Ordered Steps and Layered Calls
fb9a834c9 Merge pull request #1643 from m2ux/i17/e01/w03-modes-in-the-new
```

## 051-pr-1641-body

Exit: 0; receipt: [051-pr-1641-body.json](receipts/051-pr-1641-body.json).

```sh
jq -r '.body' /tmp/i17-e01-w06/final-package/inputs/pr-1641.json
```

Returned output:

```text
## Overview

Work Planner loads common rules and conventions before mode selection and keeps deployed values in linked configuration sections. The shared checker validates heading procedures and HTML invocations for each selected model, using the same parser and contract ownership for citation and interface checks. Modes and protocols expose ordered heading steps and explicit artifact and procedure calls. Issue and body artifacts link accepted record shapes and execute their commands within ordered steps. Delivery, branch and pull-request artifacts expose linked contracts and execute commands in their owning steps.

## Changes

The epic base carries the declared-model checker capability, its acceptance/rejection specimens, Work Planner's common context files and its mode, protocol, issue/body and delivery artifact presentation.

### Declared Models

- **Structure selection.**
  Explicit file entries select entry layouts; typed options describe heading steps, preambles, field contracts and call verbs.
- **Procedure contracts.**
  Step sequences follow their parent procedure, and Inputs/Outputs resolve the owning artifact's field contracts.

### Invocation Reading

- **Literal command payload.**
  One lexical reader owns Markdown fences and HTML invocations, preserving shell text and required bold argument links.
- **Execution and interfaces.**
  Selected invocation models require executing-step placement, with GraphQL REST-gap evidence scoped there and Projects V2 checks preserved.

- **Argument classification.**
  Bold contract arguments are validated before ordinary Markdown links, preserving literal title-prefix filters and rejection of unsupported contract targets.

### Common Context

- **Rules and conventions.**
  `skills/work-planner/SKILL.md` selects modes after loading `rules.md` and `conventions.md`, preserving their operative conditions.
- **Configuration.**
  Board titles and fields, planning-record placement and the reporting default have one documented home; consuming sections select applicable configuration reads.
- **Reader ownership.**
  Guidelines and checkout-vocabulary validation use the extracted homes while installed model declarations remain selected.

### Mode Procedures

- **Ordered actions.**
  Mode procedures use numbered heading steps, scoped flush detail and Rules/Conventions/Outcomes preambles, preserving prerequisite and checkout declarations.
- **Verification procedures.**
  Revise's named verification procedures hold HTML invocations and linked argument contracts with preserved command syntax and explicit examples.
- **Source readers.**
  Mode readers select heading steps and recognize Apply calls while preserving draft-publication, caller-coverage and epic-base assertions.

### Protocol Procedures

- **Ordered coordination.**
  Protocols use numbered heading steps, Rules/Conventions preambles and scoped flush conditions while preserving prerequisites, inputs, refusals and return points.
- **Layered invocation.**
  Artifact operations use Apply and whole-protocol calls use Follow, including repeated calls to existing required callees.
- **Evidence boundaries.**
  Literal-head and merged-revision instruments preserve the walked protocol bytes and test the actual source composition. Independent reading observations remain Partial; inherited prerequisite, receipt, authority and live-evidence limits remain recorded.

### Issue and Body Artifacts

- **Contracted operations.**
  Operations link their accepted inputs and returned states, distinguishing complete JSON records, body text, identities and supplied versus posted values.
- **Executing steps.**
  Commands use raw HTML within ordered heading steps, with linked argument contracts and preserved literal syntax, examples and prerequisites.
- **Template and interface readers.**
  Body-template fences recognize valid closing indentation; document readers verify linked contracts, step order, fetched-base inputs and cited executable reach.
- **Evidence boundaries.**
  Repeated bounded walks produce correct local results; prerequisite order, transitive closure and unavailable live evidence remain explicitly Partial.

### Delivery Artifacts

- **Contracted operations.**
  Delivery plans, briefs, dispatch batches, branches and pull requests link accepted input and result contracts, with distinct record, identity, metadata and destination shapes.
- **Executing steps.**
  Commands and named retries sit in ordered heading steps with preserved literal syntax, examples, anchors and original prerequisites.
- **Worktree verification.**
  The placement reader discovers executing commands and retains placement-field and real-git relative-path assertions.
- **Evidence boundaries.**
  Repeated bounded results are correct while prerequisite order/closure, broad and repeated reads, selective truncation recovery and external evidence limits remain Partial; interrupted instrument observations are separately retained.

## References

- **R1.** [Skill Models](https://github.com/m2ux/workflow-server/pull/1640) — declared-model validation and specimen coverage.
- **R2.** [Common Files](https://github.com/m2ux/workflow-server/pull/1642) — shared rules, conventions and configuration with their consuming readers.
- **R3.** [Mode Procedures](https://github.com/m2ux/workflow-server/pull/1643) — heading steps, preserved command inputs and maintained readers, with explicit partial disclosure observations.
- **R4.** [Protocol Procedures](https://github.com/m2ux/workflow-server/pull/1644) — heading steps, preserved operative conditions and explicit repeated calls, with separately qualified reading observations.
- **R5.** [Issue and Body Artifacts](https://github.com/m2ux/workflow-server/pull/1646) — linked contracts, executing commands and maintained readers, with separately qualified Partial disclosure.
- **R6.** [Delivery Artifacts](https://github.com/m2ux/workflow-server/pull/1647) — linked contracts, executing commands and maintained readers, with separately qualified Partial disclosure.
```

## 052-local-ancestor-E00

Exit: 0; receipt: [052-local-ancestor-E00.json](receipts/052-local-ancestor-E00.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and merge-base --is-ancestor 48f4ac592814d6c74bd67d94350909d096835c45 03d353300ca4804194fd50d316d73e3bf1270d1d
```

Returned output:

```text
(empty)
```

## 053-local-ancestor-E03

Exit: 0; receipt: [053-local-ancestor-E03.json](receipts/053-local-ancestor-E03.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and merge-base --is-ancestor 03d353300ca4804194fd50d316d73e3bf1270d1d 612da8d650f524eb05c3e2436bac3cdfd7f82e4c
```

Returned output:

```text
(empty)
```

## 054-local-ancestor-W07

Exit: 0; receipt: [054-local-ancestor-W07.json](receipts/054-local-ancestor-W07.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and merge-base --is-ancestor 652ef07ea5b8553d3bdb73542c3a393ac20e6ea9 612da8d650f524eb05c3e2436bac3cdfd7f82e4c
```

Returned output:

```text
(empty)
```

## 055-plan-change

Exit: 0; receipt: [055-plan-change.json](receipts/055-plan-change.json).

```sh
cat /tmp/i17-e01-w06/final-package/source/skills/work-planner/artifacts/plan-change.md
```

Returned output:

```text
# Plan Change

One change to the plan that a run makes as it works, and whether the run applies it or the user decides it.

## Operations

### Check Plan Change Autonomy

One pending change assessed against the run's allowance.

**Inputs:** [Pending Change](#pending-change), [Allowance](#allowance).

**Outputs:** [Autonomy Result](#autonomy-result).

#### 1. Classify Pending Change

Match the change to one kind in [Change Kinds](#change-kinds).

#### 2. Return Allowed Change

Return it as automatic where the supplied allowance names that kind, with the supplied recommendation as the option the caller applies.

#### 3. Return Held Change

Return it as held otherwise, for the caller to settle as [Held Change](#held-change) states.
- A change matching no kind is held, as is one matching [Initiative Creation](#initiative-creation) or [Hot-fix Creation](#hot-fix-creation).
- An absent allowance holds every change, so a run the user drives decides nothing on their behalf.

### Record Plan Change

One entry in the run's list, for a change it applied or held.

**Inputs:** [Change Details](#change-details), [Change List](#change-list).

**Outputs:** [Change List](#change-list).

#### 1. Record Applied or Held Entry

Add one entry meeting [Entry](#entry) to the supplied [Change List](#change-list), marked applied or held.

#### 2. Return Updated List

Return the updated list for the caller to publish and report.

## Fields

### Allowance

The caller names the change kinds its run applies without asking. A run the user drives directly is supplied none.

### Change Kinds

| Kind | What It Covers |
| --- | --- |
| Task creation | A new task row |
| Epic creation | A new epic, and the initiative row that carries it |
| Migration | Work moved from one issue to another, with the renumbering that move forces |
| Re-prioritisation | A priority label, a queue order or a board status |
| Folded work | Criteria, scope or design added to an existing issue because the work in hand needs it |

An option deciding to leave work where it is changes no plan, so it needs no allowance and takes no entry, unlike a change [held](#held-change) for the user to decide.

### Initiative Creation

A new initiative is outside every allowance. The work stays where it is, open and unplaced, until the user decides where it belongs.

### Hot-fix Creation

A new hot-fix is outside every allowance, since it runs ahead of all queued work. The work stays where it is until the user decides it is a hot-fix.

### Change List

One list for the run, holding every change it applied and every change it held. It is what the run reports and what its record keeps.

### Entry

One line: the kind, the issue or row it concerns, and the option applied or recommended. The entry states the change, not the alternatives weighed against it.

### Held Change

A held change is left unapplied and its subject stays as it stands, so the next run sees the same decision. Its entry carries the recommended option, which is what the user is answering.

A run working under an allowance records and reports a held change rather than asking, since the work it was dispatched for does not wait on an answer. A run supplied no allowance puts it to the user.

### Pending Change

The supplied pending change, its subject and recommended option.

### Change Details

The supplied change, its kind, applied or recommended option and affected issue identities.

### Autonomy Result

The change classified as automatic or held, retaining its recommendation.
```

## 056-format-epic

Exit: 0; receipt: [056-format-epic.json](receipts/056-format-epic.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/format.py /tmp/i17-e01-w06/final-package/inputs/epic-1616.json --initiative /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json --prs /tmp/i17-e01-w06/final-package/inputs/prs.jsonl --project /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and --revision 612da8d650f524eb05c3e2436bac3cdfd7f82e4c --fix /tmp/w06-walk-final-goal2/format-proposed-1616.md
```

Returned output:

```text
#1616 epic (open): 0 fixed, 0 to apply, 0 to decide
  source: config/required-criteria.json at 612da8d650f524eb05c3e2436bac3cdfd7f82e4c in /home/mike1/projects/dev/workflow-server/.git
```

## 057-dependencies

Exit: 0; receipt: [057-dependencies.json](receipts/057-dependencies.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/deps.py I=/tmp/w06-walk-final-goal2/initiative-1597.md E00=/tmp/w06-walk-final-goal2/epic-1598.md E01=/tmp/w06-walk-final-goal2/epic-1616.md E02=/tmp/w06-walk-final-goal2/epic-1615.md E03=/tmp/w06-walk-final-goal2/epic-1625.md
```

Returned output:

```text
--- problems
none

--- joins: candidate units, rows of one epic extending one component
none

--- advisory: numbering against start order
E03:W14 (level 2) is numbered after E03:W13 (level 3)

--- levels (0 = can start now)
0 E00:W01 - Planning commits directly to engineering
0 E00:W02 - Not-planned epic leaves its initiative
0 E00:W03 - Board sync removes uncited not-planned items
0 E00:W04 - Sync reads every linked pull request
0 E01:W01 - Per-skill style model and checker
0 E03:W01 - Work item declares an optional lane
0 E03:W02 - Task table carries the lane column
1 E01:W02 - Rules, conventions and configuration files
1 E03:W03 - Work item holds its component declaration
1 E03:W04 - Joined rows share one lane
1 E03:W05 - Dependency check reads task table lanes
1 E03:W06 - Lane cells validate and survive table writes
1 E03:W07 - Delivery plan admits units by lane
2 E01:W03 - Modes in the new style
2 E01:W04 - Protocols in the new style
2 E01:W05 - Issue and body artifacts in the new style
2 E01:W06 - Board, queue, planning and review artifacts restyled
2 E01:W07 - Delivery, branch and pull-request artifacts restyled
2 E03:W08 - Available-work survey filters units by lane
2 E03:W09 - Deliver mode passes the requested lane
2 E03:W10 - Plan mode writes task row lanes
2 E03:W11 - Board queue reports Ready units' lanes
2 E03:W12 - Board-queue script prints Ready unit lanes
2 E03:W14 - Cross-epic joins receive bounded diagnostics
3 E01:W08 - Activate the Work Planner style model
3 E03:W13 - Advance mode reports Ready unit lanes
4 E02:W01 - SOLID guidelines for files and operations
5 E02:W02 - Audit the skill against the guidelines
6 E02:W03 - Generic prose in general artifacts and modes
6 E02:W04 - Generic interfaces in general scripts
6 E02:W05 - Each audited rule in one home

--- component contention: rows of different epics extending one component
none
not checked, no component read: E00:W01, E00:W02, E00:W03, E00:W04, E01:W01, E01:W02, E01:W03, E01:W04, E01:W05, E01:W06, E01:W07, E01:W08, E02:W01, E02:W02, E02:W03, E02:W04, E02:W05, E03:W01, E03:W02, E03:W03, E03:W04, E03:W05, E03:W06, E03:W07, E03:W08, E03:W09, E03:W10, E03:W11, E03:W12, E03:W13, E03:W14

--- epic priority (epics sharing a number start together)
2 E00
2 E01
2 E03
1 E02

--- longest chains: 15, each of 7 steps
on every chain: E01:W01, E01:W02, E01:W08, E02:W01, E02:W02
E01:W01 -> E01:W02 -> E01:W03 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W04 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W05 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W06 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W07 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W03 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W04 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W05 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W06 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W07 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
... 5 more
```

## 058-W07-workspace

Exit: 1; receipt: [058-W07-workspace.json](receipts/058-W07-workspace.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and merge-base --is-ancestor 652ef07ea5b8553d3bdb73542c3a393ac20e6ea9 03d353300ca4804194fd50d316d73e3bf1270d1d
```

Returned output:

```text
Failed to create stream fd: Operation not permitted
Failed to create stream fd: Operation not permitted
Failed to create stream fd: Operation not permitted
```

## 059-W07-workspace-retry

Exit: 1; receipt: [059-W07-workspace-retry.json](receipts/059-W07-workspace-retry.json).

```sh
git -C /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and merge-base --is-ancestor 652ef07ea5b8553d3bdb73542c3a393ac20e6ea9 03d353300ca4804194fd50d316d73e3bf1270d1d
```

Returned output:

```text
(empty)
```

## 060-deps-chain-options

Exit: 0; receipt: [060-deps-chain-options.json](receipts/060-deps-chain-options.json).

```sh
rg -n 'add_argument|more|chains\[' /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/deps.py
```

Returned output:

```text
42:whose rows cover more than six criteria.
46:its reason, where its rows cover more than six criteria or a path between two of them runs through
205:    """The row sets a planning record accounts for: each line naming two or more task ids accounts
376:            problems.append(f'initiative {epic}: Depends on names more than epics ({", ".join(other)}); '
496:                                f'more than the bound of {UNIT_BOUND}')
552:        print(f'... {len(found) - MAX_CHAINS} more')
```

## 061-format-diff

Exit: 1; receipt: [061-format-diff.json](receipts/061-format-diff.json).

```sh
diff -u /tmp/w06-walk-final-goal2/initiative-1597.md /tmp/w06-walk-final-goal2/format-proposed-1597.md
```

Returned output:

```text
--- /tmp/w06-walk-final-goal2/initiative-1597.md	2026-11-05 14:18:26.052628278 +0100
+++ /tmp/w06-walk-final-goal2/format-proposed-1597.md	2026-11-05 14:18:56.969906146 +0100
@@ -45,4 +45,3 @@
 - **R1.** [I16 Work Planner Home](https://github.com/m2ux/prosiform-skills/issues/1) — the skill's move to prosiform-skills, whose extraction waits for these fixes.
 - **R2.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
 - **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner) — the skill the fixes change.
-
```

## 062-numbered-epic

Exit: 0; receipt: [062-numbered-epic.json](receipts/062-numbered-epic.json).

```sh
nl -ba /tmp/w06-walk-final-goal2/epic-1616.md
```

Returned output:

```text
     1	## Overview
     2	
     3	The work-planner skill takes the file style its prosiform form will need, laying the groundwork for prosiform compliance before the skill's extraction is cut. The style is the one the example skill under `.project/main/example` shows. That example is an older work-planner and serves as a structural style reference only: no content carries over from it. Command presentation follows the linked Graph Index example in R5. Prerequisites sections stay, and no prosiform metadata is added.
     4	
     5	## Problem
     6	
     7	- **Steps are list items.**
     8	  Every procedure is a numbered list with bold leads, so a step has no heading to link and no place for its own detail.
     9	- **Commands sit apart from the steps that run them.**
    10	  Artifacts hold a `## Commands` section that their operations reach by link.
    11	- **Inputs and outputs are prose.**
    12	  Operations keep their inputs and returned values in prose, without linked input/output contract sections for callers.
    13	- **SKILL.md carries the rules.**
    14	  The rules and conventions that bind every mode, and the deployment values, sit in SKILL.md and the guidelines rather than in files of their own.
    15	- **The style model describes the installed layout.**
    16	  The current declarations and checks do not define the proposed heading-based steps, linked contracts and HTML command blocks.
    17	
    18	## Proposal
    19	
    20	- **Per-skill style model.** The skill's own guidelines, `structure.json` and `rules.json` state the new model, and the shared checker reads each skill's declared model.
    21	  - The shared guidelines and every other skill keep their current shape.
    22	  - Checker support is proven against specimen skills before document conversion. The final task adopts Work Planner's new guidelines and model declarations once every conversion is complete; the installed declarations govern the live checks until that adoption.
    23	- **Entry files.** SKILL.md keeps its opening, Modes and Dependencies.
    24	  - `rules.md` holds the rules that bind every mode, `conventions.md` the conventions, and `configuration.md` the deployment values, each built from the live skill's own text.
    25	- **Steps as sub-sections.** Each step is a heading of its position and action, with its instruction as a paragraph and flush bullets.
    26	  - Calls use Apply for an artifact operation and Follow for a mode, protocol or child section.
    27	  - Each mode and protocol opens with the preamble line that links Rules, Conventions and, for a mode, Outcomes.
    28	- **Commands in steps.** Each command moves into the step that runs it, with where it runs, the inputs that fill it, and an example. No artifact keeps a `## Commands` section.
    29	  - Command and tool-access invocations use raw HTML `<big><pre>…</pre></big>` blocks, matching the specific R5 step. Contract-backed input names are bold Markdown links inside the block, using `[**argument**](#argument-contract)`, while literal syntax, argument order, shell quoting and line breaks are preserved.
    30	  - Checker fixtures accept this HTML command form and its resolving argument links, and reject Markdown-fenced command invocations. The example supplies presentation only; its tool names, graph behavior, content and metadata are outside this migration.
    31	- **Inputs, outputs and contracts.**
    32	  Each operation lists its Inputs and Outputs as links to `###` contract sections under Fields.
    33	- **What does not change.** The skill's behaviour, its Prerequisites sections and its frontmatter stay as they are.
    34	  - No prosiform metadata, no `pf` instruction and no prosiform link marks, which need its grammar to place.
    35	  - No file or rule is taken from the example's content.
    36	
    37	## Work Breakdown
    38	
    39	| Task | Description | Coverage | Depends on | Joins | Lane | Done |
    40	| --- | --- | --- | --- | --- | --- | --- |
    41	| [W01](https://github.com/m2ux/workflow-server/pull/1640) | Per-skill style model and checker | AC1 | | | | ✓ |
    42	| [W02](https://github.com/m2ux/workflow-server/pull/1642) | Rules, conventions and configuration files | AC2 | W01 | | | ✓ |
    43	| [W03](https://github.com/m2ux/workflow-server/pull/1643) | Modes in the new style | AC3 | W02 | | | ✓ |
    44	| [W04](https://github.com/m2ux/workflow-server/pull/1644) | Protocols in the new style | AC4 | W02 | | | ✓ |
    45	| [W05](https://github.com/m2ux/workflow-server/pull/1646) | Issue and body artifacts in the new style | AC5 | W02 | | | ✓ |
    46	| [W06](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1616-i17-e01-w06-board-queue-planning-and/) | Board, queue, planning and review artifacts restyled | AC6 | W02 | | | |
    47	| [W07](https://github.com/m2ux/workflow-server/pull/1647) | Delivery, branch and pull-request artifacts restyled | AC7 | W02 | | | ✓ |
    48	| W08 | Activate the Work Planner style model | AC8 | W03, W04, W05, W06, W07 | | | |
    49	
    50	## Acceptance Criteria
    51	
    52	- [x] **AC1.** `check_skill_files.py` validates specimen declarations of the proposed Work Planner style model, including its command style, as acceptance/rejection fixtures show.
    53	- [x] **AC2.** SKILL.md holds only its opening, Modes and Dependencies, and `rules.md`, `conventions.md` and `configuration.md` hold what binds every mode, checked by Check Skill Files.
    54	- [x] **AC3.** Every mode states its steps as sub-sections, opens with the preamble line and calls through Apply and Follow, using the [command style](#proposal), checked by Check Skill Files.
    55	- [x] **AC4.** Every protocol states its steps as sub-sections, opens with the preamble line and calls through Apply and Follow, using the [command style](#proposal), checked by Check Skill Files.
    56	- [x] **AC5.** Every issue and body artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.
    57	- [ ] **AC6.** Every board, queue, planning and review artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.
    58	- [x] **AC7.** Every delivery, branch and pull-request artifact runs its commands inside its steps and lists linked Inputs and Outputs, using the [command style](#proposal), checked by Check Skill Files.
    59	
    60	- [ ] **AC8.** The Work Planner guidelines, `structure.json` and `rules.json` declare the new style model over the converted skill, with zero findings from Check Skill Files over `skills/work-planner`.
    61	
    62	## References
    63	
    64	- **R1.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the artifact grouping and each task's work item.
    65	- **R2.** [Example skill](https://github.com/m2ux/md-composer/tree/00f166920ec242f3565376e06a8838de72f8dc34/example/work-planner) — the older work-planner whose file style this epic adopts; style only.
    66	- **R3.** [Example guidelines](https://github.com/m2ux/md-composer/blob/00f166920ec242f3565376e06a8838de72f8dc34/example/guidelines.md) — the shared guidelines that state that style.
    67	- **R4.** [Work Planner at the migration baseline](https://github.com/m2ux/workflow-server/tree/03d353300ca4804194fd50d316d73e3bf1270d1d/skills/work-planner) — the skill this epic restyles.
    68	- **R5.** [HTML command-style example](https://github.com/shieldedtech/midnight-agent-eng/blob/a710a42e82df7f18b27f8a6cfa4b6e9c801df903/skills/finding-classifier/artifacts/graph-index.md#1-fetch-the-first-inventory-page) — the specific command presentation adopted by this migration; style only.
    69	
```

## 063-I16-initiative

Exit: 0; receipt: [063-I16-initiative.json](receipts/063-I16-initiative.json).

```sh
jq -r '.[] | select(.content.title | startswith("[I16]")) | .content.body' /tmp/i17-e01-w06/final-package/inputs/items.json
```

Returned output:

```text
## Overview

The work-planner skill lives in prosiform-skills, with its history and the shared files it is checked against, and the workspace that uses it runs it from a pinned commit of that repository. workflow-server's `workspace` template carries no copy, the skill then fits its new root, and each board's Priority field is the one source of a rank. The skill is used through prosiform: a session starts by running `pf` and follows the bundle of the mode it selects, every mode compiles within prosiform's default output budget with no warning, a link stands only where its reader must have the content and names the section it needs, and the shared guide and check state, define and enforce those rules. The goal the reviews test against is one home for the skill, cut over and linked before any refactoring, ranking work by the board and used through prosiform.

## Problem

The skill has no home of its own, and it is written for a reader who follows links one at a time while prosiform compiles every local link into one bundle.

- **It lives inside an unrelated repository.**
  Its [entry point](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/SKILL.md#L1-L5) sits in workflow-server's `skills/` beside three other skills, so its history and pull requests are workflow-server's.
- **Its install is a copy.**
  prosiform's workspace receives the skill as plain files from workflow-server's template, and records no version.
- **Its commands assume that layout.**
  71 occurrences of `skills/work-planner` in 22 of its files hold only under a `skills/` folder.
- **A rank has two homes.**
  Board Queue ranks by [`priority:` labels](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board-queue.py#L33), while board 17's Priority field is a single-select nothing reads.
- **Five modes overflow the default budget.**
  At [785a5ee8c](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner), Deliver compiles to 353717 bytes, Plan 328950, Advance 314874, Standup 273929 and Sync 264276, against a default output budget of 262144.
- **A mode's prerequisites compile other modes whole.**
  [Plan Mode's Prerequisites](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L11-L27) link Propose Mode and Sync Mode, so the Plan bundle carries both although its steps run each in only one case.
- **Hand-offs are prose.**
  [Deliver Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/deliver-mode.md#L101-L105) starts a unit's session through a sentence, and no link carries a dispatch or deferral operator.
- **Links name whole files.**
  245 of the skill's 1075 internal links name a whole file whose content carries sections, and each compiles that whole file into the bundle.
- **The rules describe reading, not compiling.**
  The [shared Links rules](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/guidelines.md#L105-L118) type links for a reader who chooses what to open, and say nothing of a bundle, an operator or a budget.
- **Nothing compiles the skill.**
  The [shared skill-file check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/scripts/check_skill_files.py#L1025-L1029) reads link resolution and placement, so a mode that overflows the budget or reaches another mode whole draws no finding.
- **A check is named by its path.**
  The shared guidelines' [Verified rule](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/guidelines.md#L198) names the shared check as a code span, and their [Files rule](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/guidelines.md#L27-L28) says where checks sit without saying what any of them decides.

## Proposal

- **Cut over first, unchanged.**
  The skill's history and the shared guide, rules, check and tests move as they are to the root of prosiform-skills, in the shape workflow-server's `skills/` folder had.
- **Planning and delivery follow the skill.**
  Task and epic pull requests target `main`, and planning records live on an orphan `engineering` branch.
- **Skills belong to each workspace.**
  The workspace that uses the skill vendors prosiform-skills as a submodule pinned to a commit and links the skill into its `skills/`. workflow-server's template supports that pattern, vendors nothing itself, and drops its copy.
- **Refactor after the link.**
  Only once the skill is linked does it change: its commands and the shared check fit the new root, and the board's Priority field replaces the priority labels.
- **The shared guide states the prosiform rules.**
  A skill bootstraps by running `pf`; a link names the section its reader must have, and a mention is plain text; `⇉` and `⫽` carry hand-offs and `¬` conditional reads; each mode fits the default budget.
- **A check is defined where prose names it.**
  The shared guide defines each check prosiform-skills runs, and prose names a check by linking to that definition.
- **The skill is brought to the rules, then held to them.**
  Its links, hand-offs, entry point and modes conform first; the shared check then enforces the prosiform rules over every skill it runs over, and each mode's bundle size is recorded against a fixed baseline revision.

## Work Breakdown

| Epic | Description | Coverage | Depends on | Done |
| --- | --- | --- | --- | --- |
| [E00](https://github.com/m2ux/prosiform-skills/issues/2) | Skill Cutover | AC1 | | |
| [E01](https://github.com/m2ux/prosiform-skills/issues/3) | Workspace Linkage | AC3, AC4 | | |
| [E02](https://github.com/m2ux/prosiform-skills/issues/5) | Skill Refactor | AC2 | [E00](https://github.com/m2ux/prosiform-skills/issues/2), [E01](https://github.com/m2ux/prosiform-skills/issues/3) | |
| [E03](https://github.com/m2ux/prosiform-skills/issues/4) | Priority Field | AC5, AC6 | [E00](https://github.com/m2ux/prosiform-skills/issues/2), [E01](https://github.com/m2ux/prosiform-skills/issues/3) | |
| [E04](https://github.com/m2ux/prosiform-skills/issues/6) | Shared Prosiform Rules | AC12 | [E00](https://github.com/m2ux/prosiform-skills/issues/2), [E01](https://github.com/m2ux/prosiform-skills/issues/3) | |
| [E05](https://github.com/m2ux/prosiform-skills/issues/7) | Check Definitions | AC14 | [E02](https://github.com/m2ux/prosiform-skills/issues/5) |  |
| [E06](https://github.com/m2ux/prosiform-skills/issues/8) | Work Planner Links | AC9, AC10 | [E02](https://github.com/m2ux/prosiform-skills/issues/5), [E04](https://github.com/m2ux/prosiform-skills/issues/6) | |
| [E07](https://github.com/m2ux/prosiform-skills/issues/9) | Use Through Prosiform | AC7, AC8, AC9, AC11, AC13 | [E06](https://github.com/m2ux/prosiform-skills/issues/8) | |

## Acceptance Criteria

- [ ] **AC1.** The work-planner skill and the shared files it is checked against stand at the root of prosiform-skills' `main` with the history they had in workflow-server, as a tree and log comparison against the extracted workflow-server commit shows.
- [ ] **AC2.** The skill's tests and the shared check pass from the root of a prosiform-skills checkout, as their runs on `main` show.
- [ ] **AC3.** workflow-server's `workspace` template carries no copy of the skill, and none of its skill files outside workflow-canon names it, as a listing and a grep of its head show.
- [ ] **AC4.** prosiform's workspace runs the skill from a prosiform-skills commit it pins, as the skill's test suite run through its link in a fresh clone shows.
- [ ] **AC5.** Board Queue ranks each theme board's work by its board item's Priority number, as the queue's tests show.
- [ ] **AC6.** No repository whose issues a theme board holds carries a `priority:` label, as a label listing of each shows.
- [ ] **AC7.** Every Work Planner mode on `main` compiles under the pinned `pf` within its default output budget with no warning, as the shared skill-file check's compile run reports over `work-planner`.
- [ ] **AC8.** A session given a Work Planner request runs `pf` from the entry point and follows the bundle of the mode it selects, as a walk of a representative request from the entry point records.
- [ ] **AC9.** No Work Planner link compiles content its reader need not have, whether a whole file whose target carries sections or another mode reached outside a dispatch or a deferral, as the shared skill-file check reports over `work-planner`.
- [ ] **AC10.** Each Work Planner hand-off to a sub-agent dispatches the procedure followed, and each citation a step reads only in some cases is deferred, as the hand-off and conditional-citation inventories the planning record holds show against the compiled bundles.
- [ ] **AC11.** No Work Planner mode's compiled bundle is larger than at the baseline revision the planning record fixes, as the bundle-size comparison records using one prosiform version on both revisions.
- [ ] **AC12.** `guidelines.md` states the rules a skill used through prosiform follows — its bootstrap, its links, its operators and its budget — as a read of the guidelines on `main` shows.
- [ ] **AC13.** The shared skill-file check reports a violation of each prosiform rule it decides in any skill it runs over, as the check's own test suite shows against specimen skills.
- [ ] **AC14.** Prose in Work Planner and the shared guide reaches each check prosiform-skills runs through a definition stating what it decides, which skills it binds, how it is run and where its tests live, as the shared skill-file check reports over `work-planner`.

## Non-Goals

- It moves no skill other than work-planner.
- It keeps the two repositories' copies of the shared skill files in step by no mechanism.
- It adds no prosiform-skills submodule to workflow-server's template, so a workspace made from it receives no work-planner.
- It leaves workflow-canon's `references/revise-mode.md` naming `skills/work-planner`.
- It leaves the proposals boards' Priority field as it stands.
- It sets no Priority value beyond the one a numbered label carried.
- It changes neither prosiform nor its default budgets.
- It generates and checks no read-set manifest for any skill.
- It walks neither retrieval order nor citation efficacy, which compilation settles.

## References

- **R1.** [workflow-server `skills/` at the evidence revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills) — the folder the skill and its shared files come from. The extraction is cut from workflow-server's `workspace` head once I17's Pre-Cutover Fixes epic closes.
- **R2.** [m2ux/workflow-server#1595](https://github.com/m2ux/workflow-server/issues/1595) — the Priority field change this initiative carries over.
- **R3.** [Planning record](https://github.com/m2ux/prosiform-skills/tree/engineering/artifacts/planning/2026-11-02-1-i16-work-planner-repository) — the decisions, the evidence, the goal trace, each review and each task's work item.
- **R4.** [m2ux/workflow-server#1427](https://github.com/m2ux/workflow-server/issues/1427) — a plan for Work Planner citations under link-following reading; its section-link, mention, hand-off and check-definition evidence feeds this initiative's Problem.
- **R5.** [Prosiform references](https://github.com/m2ux/prosiform/blob/23882b7d/docs/references.md) — what makes a link a dependency, and the deferral and dispatch operators.
- **R6.** [Prosiform dispatch](https://github.com/m2ux/prosiform/blob/23882b7d/docs/dispatch.md) — the bundle a dispatch publishes and the protocol a sub-agent follows.
- **R7.** [Prosiform validation](https://github.com/m2ux/prosiform/blob/23882b7d/docs/validation.md) — the budgets each bundle is held to and the warnings a run reports.

🤖 Generated with [Claude Code](https://claude.com/claude-code)
```

## 064-I16-save

Exit: 0; receipt: [064-I16-save.json](receipts/064-I16-save.json).

```sh
jq -r '.[] | select(.content.title | startswith("[I16]")) | .content.body' /tmp/i17-e01-w06/final-package/inputs/items.json > /tmp/w06-walk-final-goal2/extraction-initiative-1.md
```

Returned output:

```text
(empty)
```

## 065-deps-chain-read

Exit: 0; receipt: [065-deps-chain-read.json](receipts/065-deps-chain-read.json).

```sh
sed -n '500,565p' /tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts/deps.py
```

Returned output:

```text
    print('--- problems')
    print('\n'.join(problems) if problems else 'none')
    if cyclic or unsupported_joins:
        return 1
    print('\n--- joins: candidate units, rows of one epic extending one component')
    print('\n'.join(joins) if joins else 'none')

    level: dict[str, int] = {}

    def lv(n: str) -> int:
        if n not in level:
            level[n] = 1 + max((lv(m) for m in graph[n]), default=-1)
        return level[n]

    for epic in epics:
        own = sorted(k for k in tasks if k.startswith(epic + ':'))
        for a, b in zip(own, own[1:]):
            if lv(b) < lv(a):
                advisory.append(f'{b} (level {lv(b)}) is numbered after {a} (level {lv(a)})')

    print('\n--- advisory: numbering against start order')
    print('\n'.join(advisory) if advisory else 'none')
    print('\n--- levels (0 = can start now)')
    for n in sorted(tasks, key=lambda k: (lv(k), k)):
        print(lv(n), n, '-', tasks[n][0][:70])
    pairs = contention(components)
    unchecked = sorted(key for key in tasks if key not in components)
    print('\n--- component contention: rows of different epics extending one component')
    print('\n'.join(f'{left} and {right} both extend {components[left]}'
                    for left, right in pairs) or 'none')
    if unchecked:
        print('not checked, no component read:', ', '.join(unchecked))
    print('\n--- epic priority (epics sharing a number start together)')
    proposed = epic_priority(tasks, tuple(epics),
                             {(left.split(':')[0], right.split(':')[0]) for left, right in pairs})
    for epic in sorted(proposed, key=lambda e: (-proposed[e], e)):
        print(proposed[epic], epic)

    top = max(level.values(), default=0)
    ends = sorted(k for k, v in level.items() if v == top)

    def chains(n: str) -> list[list[str]]:
        preds = [m for m in graph[n] if level[m] == level[n] - 1]
        return [[n]] if not preds else [c + [n] for m in preds for c in chains(m)]

    found = [c for end in ends for c in chains(end)]
    shared = set(found[0]).intersection(*found[1:]) if found else set()
    print(f'\n--- longest chains: {len(found)}, each of {top + 1} steps')
    print('on every chain:', ', '.join(sorted(shared)) or 'none')
    for c in found[:MAX_CHAINS]:
        print(' -> '.join(c))
    if len(found) > MAX_CHAINS:
        print(f'... {len(found) - MAX_CHAINS} more')
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
```

## 066-final-prompt-receipt

Exit: 0; receipt: [066-final-prompt-receipt.json](receipts/066-final-prompt-receipt.json).

```sh
cat /tmp/i17-e01-w06/final-package/prompts/review-goal.md
```

Returned output:

```text
Use the Work Planner skill at /tmp/i17-e01-w06/final-package/source/skills/work-planner/SKILL.md. This is an immutable captured source tree. Work only from this prompt, that source and the supplied captures. Do not read other workers’ worktrees or this conversion’s planning, preservation, diff, review or validation records.

You may read the snapshot and supplied captures, inspect local git evidence in /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and without changing it, and create outputs only under your own /tmp/w06-walk-* directory. You have no authority to modify source, write to GitHub or another external service, change tracker or board state, create worktrees, commit, push, merge or spawn agents. Do not use network access. Run local Python through /home/mike1/projects/dev/md-composer/scripts/sbx from your scratch directory, setting PYTHONPYCACHEPREFIX to a path in that directory. If the outer sandbox prevents namespace setup, exec_command with require_escalated is authorized for the same mandatory sbx read-only helper command, with no network access, no source changes and scratch-only output. The snapshot root is the workspace holding its installed scripts. The unit checkout is supplied read-only project evidence. Treat captures as observed evidence, with freshness bounded by their recorded capture time. Record any action requiring unavailable access, authority or evidence as a limitation.

Follow the skill’s instructions and reading rules as you judge necessary for the request. Return the result, local output paths, commands actually run and outcomes, and missing evidence or authority. Preserve a trace of reads and incomplete retrievals so the coordinator can inspect actual tool calls and returned content. The optional neutral reader /tmp/i17-e01-w06/final-package/neutral-read.py accepts --log <your-own-log-directory>, a path and optional --heading; it records the exact bytes it emits and does not select content for you.


The user asks: “Review whether the captured I17 plan delivers this confirmed goal: every Work Planner fix and required feature found before extraction lands in workflow-server workspace before the extraction is cut, and the extraction carries it. Prepare a local goal trace and ranked review findings, retaining evidence gaps. Do not apply plan or tracker changes.”

Inputs are /tmp/i17-e01-w06/final-package/inputs/initiative-1597.json, /tmp/i17-e01-w06/final-package/inputs/epic-1616.json and /tmp/i17-e01-w06/final-package/inputs/prs.jsonl. The capture inventory is /tmp/i17-e01-w06/final-package/inputs/README.md. Use /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w06-board-queue-planning-and only for read-only local git evidence. The request grants no plan-change allowance; leave decisions pending and report what needs a decision. Write outputs under your scratch directory.
```

## 067-dependencies-full-chains

Exit: 0; receipt: [067-dependencies-full-chains.json](receipts/067-dependencies-full-chains.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 -c 'import sys; sys.path.insert(0, "/tmp/i17-e01-w06/final-package/source/skills/work-planner/scripts"); import deps; deps.MAX_CHAINS = 100; sys.exit(deps.main(sys.argv[1:]))' I=/tmp/w06-walk-final-goal2/initiative-1597.md E00=/tmp/w06-walk-final-goal2/epic-1598.md E01=/tmp/w06-walk-final-goal2/epic-1616.md E02=/tmp/w06-walk-final-goal2/epic-1615.md E03=/tmp/w06-walk-final-goal2/epic-1625.md
```

Returned output:

```text
--- problems
none

--- joins: candidate units, rows of one epic extending one component
none

--- advisory: numbering against start order
E03:W14 (level 2) is numbered after E03:W13 (level 3)

--- levels (0 = can start now)
0 E00:W01 - Planning commits directly to engineering
0 E00:W02 - Not-planned epic leaves its initiative
0 E00:W03 - Board sync removes uncited not-planned items
0 E00:W04 - Sync reads every linked pull request
0 E01:W01 - Per-skill style model and checker
0 E03:W01 - Work item declares an optional lane
0 E03:W02 - Task table carries the lane column
1 E01:W02 - Rules, conventions and configuration files
1 E03:W03 - Work item holds its component declaration
1 E03:W04 - Joined rows share one lane
1 E03:W05 - Dependency check reads task table lanes
1 E03:W06 - Lane cells validate and survive table writes
1 E03:W07 - Delivery plan admits units by lane
2 E01:W03 - Modes in the new style
2 E01:W04 - Protocols in the new style
2 E01:W05 - Issue and body artifacts in the new style
2 E01:W06 - Board, queue, planning and review artifacts restyled
2 E01:W07 - Delivery, branch and pull-request artifacts restyled
2 E03:W08 - Available-work survey filters units by lane
2 E03:W09 - Deliver mode passes the requested lane
2 E03:W10 - Plan mode writes task row lanes
2 E03:W11 - Board queue reports Ready units' lanes
2 E03:W12 - Board-queue script prints Ready unit lanes
2 E03:W14 - Cross-epic joins receive bounded diagnostics
3 E01:W08 - Activate the Work Planner style model
3 E03:W13 - Advance mode reports Ready unit lanes
4 E02:W01 - SOLID guidelines for files and operations
5 E02:W02 - Audit the skill against the guidelines
6 E02:W03 - Generic prose in general artifacts and modes
6 E02:W04 - Generic interfaces in general scripts
6 E02:W05 - Each audited rule in one home

--- component contention: rows of different epics extending one component
none
not checked, no component read: E00:W01, E00:W02, E00:W03, E00:W04, E01:W01, E01:W02, E01:W03, E01:W04, E01:W05, E01:W06, E01:W07, E01:W08, E02:W01, E02:W02, E02:W03, E02:W04, E02:W05, E03:W01, E03:W02, E03:W03, E03:W04, E03:W05, E03:W06, E03:W07, E03:W08, E03:W09, E03:W10, E03:W11, E03:W12, E03:W13, E03:W14

--- epic priority (epics sharing a number start together)
2 E00
2 E01
2 E03
1 E02

--- longest chains: 15, each of 7 steps
on every chain: E01:W01, E01:W02, E01:W08, E02:W01, E02:W02
E01:W01 -> E01:W02 -> E01:W03 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W04 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W05 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W06 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W07 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W03
E01:W01 -> E01:W02 -> E01:W03 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W04 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W05 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W06 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W07 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W04
E01:W01 -> E01:W02 -> E01:W03 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W05
E01:W01 -> E01:W02 -> E01:W04 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W05
E01:W01 -> E01:W02 -> E01:W05 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W05
E01:W01 -> E01:W02 -> E01:W06 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W05
E01:W01 -> E01:W02 -> E01:W07 -> E01:W08 -> E02:W01 -> E02:W02 -> E02:W05
```

## 068-index-generation

Exit: 0; receipt: [068-index-generation.json](receipts/068-index-generation.json).

```sh
PYTHONPYCACHEPREFIX=/tmp/w06-walk-final-goal2/pycache /home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w06-walk-final-goal2/build-receipt-index.py
```

Returned output:

```text
Indexed 79 recorded command responses; no external files read by index builder.
```

## 069-parent-quote-line

Exit: 0; receipt: [069-parent-quote-line.json](receipts/069-parent-quote-line.json).

```sh
rg -n 'The extraction is cut|^## References' /tmp/w06-walk-final-goal2/extraction-initiative-1.md
```

Returned output:

```text
91:## References
93:- **R1.** [workflow-server `skills/` at the evidence revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills) — the folder the skill and its shared files come from. The extraction is cut from workflow-server's `workspace` head once I17's Pre-Cutover Fixes epic closes.
```
