## Overview

Every Work Planner skill fix found before the skill leaves workflow-server is merged into workflow-server's `workspace` branch before the skill's extraction is cut, so the repository the skill moves to starts with every known fix. The goal the reviews test against: each fix found before the cutover is delivered in workflow-server ahead of the extraction, and the extraction carries it.

## Problem

Faults found in the skill before its move have no plan that the move respects.

- **A late fix misses the move.**
  The skill is extracted to prosiform-skills with its content unchanged, so a fix merged into `workspace` after the extraction reaches only the copy workflow-server drops.
- **Known faults are open.**
  Closing the skill's own initiative exposed faults in [Plan Mode](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/modes/plan-mode.md#L42-L43), the [format check](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/format.py#L1024-L1025), [board sync](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/scripts/board.py#L578-L582) and the [pull request fetch](https://github.com/m2ux/workflow-server/blob/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner/artifacts/pull-request.md#L523-L539).

## Proposal

- **Fixes land in workflow-server first.**
  Each fix is a task row, merged into `workspace` through its epic base as any delivery is.
- **The extraction waits for the fixes.**
  I16's row that extracts the skill names these fixes as its prerequisite, so the extraction is cut from a `workspace` commit holding every one.
- **Faults found later join the plan.**
  A fault found before the extraction becomes a further task row, delivered ahead of the extraction like the rest.
- **A feature the skill must carry joins too.**
  A feature a workspace needs before the extraction, such as delivery lanes, is an epic of this initiative and lands ahead of the extraction as a fix does.

## Work Breakdown

| Epic | Description | Coverage | Depends on | Done |
| --- | --- | --- | --- | --- |
| [E00](https://github.com/m2ux/workflow-server/issues/1598) | Pre-Cutover Fixes | AC1 | | ✓ |
| [E01](https://github.com/m2ux/workflow-server/issues/1616) | Skill Style | AC1 | | |
| [E02](https://github.com/m2ux/workflow-server/issues/1615) | Skill Separation | AC1 | [E01](https://github.com/m2ux/workflow-server/issues/1616) | |
| [E03](https://github.com/m2ux/workflow-server/issues/1625) | Delivery Lanes | AC1 | | ✓ |

## Acceptance Criteria

- [ ] **AC1.** Every Work Planner fix and feature planned here is in the history of the workflow-server `workspace` commit the skill's extraction is cut from, as `git merge-base --is-ancestor` shows for each one's merge commit.

## Non-Goals

- It does not change the skill's layout, script paths or priority source, which the move to the new repository settles.
- It does not fix a fault found after the extraction is cut.

## References

- **R1.** [I16 Work Planner Home](https://github.com/m2ux/prosiform-skills/issues/1) — the skill's move to prosiform-skills, whose extraction waits for these fixes.
- **R2.** [Planning record](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-02-1597-i17-pre-cutover-fixes) — the decisions, the goal trace, the review and each task's work item.
- **R3.** [Work Planner at the planned revision](https://github.com/m2ux/workflow-server/tree/785a5ee8c715b802498aa41712e0489425a22cfa/skills/work-planner) — the skill the fixes change.
