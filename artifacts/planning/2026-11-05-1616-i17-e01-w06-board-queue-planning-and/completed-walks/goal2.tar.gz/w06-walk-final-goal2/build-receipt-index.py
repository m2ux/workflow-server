import json
from pathlib import Path

root = Path('/tmp/w06-walk-final-goal2')
entries = []
lines = [
    '# Commands actually recorded',
    '',
    'Each receipt preserves the command and its returned exec_command result. '
    'Python commands ran from this scratch directory through the mandated sbx wrapper. '
    'Other commands used the session default directory unless their literal git -C selected the permitted checkout. '
    'Read read-trace.md for the initial unreceipted transcript actions, blocked attempt039 and outer presentation truncation.',
    '',
]
for path in sorted((root / 'receipts').glob('*.json')):
    record = json.loads(path.read_text())
    output = record.get('output', '')
    entry = {
        'receipt': str(path.relative_to(root)),
        'command': record.get('cmd'),
        'exit_code': record.get('exit_code'),
        'returned_output_reencoded_utf8_bytes': len(output.encode('utf-8')),
        'original_token_count_tool_metadata': record.get('original_token_count'),
        'chunk_id': record.get('chunk_id'),
        'outer_visibility': 'partially truncated, recovered via receipts014-015'
            if path.name.startswith(('010-', '011-', '012-', '013-')) else 'see read-trace.md',
    }
    entries.append(entry)
    lines.extend([
        f'## {path.stem}', '',
        f'Exit: {record.get("exit_code")}; receipt: [{path.name}](receipts/{path.name}).', '',
        '```sh', record.get('cmd', ''), '```', '',
        'Returned output:', '', '```text', output.rstrip('\n') or '(empty)', '```', '',
    ])
(root / 'tool-output-manifest.json').write_text(json.dumps(entries, indent=2) + '\n')
(root / 'commands.md').write_text('\n'.join(lines))
print(f'Indexed {len(entries)} recorded command responses; no external files read by index builder.')
