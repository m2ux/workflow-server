# Ranked I17 review findings

**Disposition: gaps remain; the confirmed goal is not yet fully guaranteed by the captured plan.** F1 and F2 are the highest threats. Existing incomplete delivery is reported separately in goal-trace.md, not misclassified as a defect in work that is still planned.

All quoted files are scratch body copies derived from the named supplied captures. Recommendations have no approval and were not applied. There is no plan-change allowance.

## Scope and intake

### F1 — P1: The measured set can exclude a known pre-cut requirement

**Problem.** Initiative AC1 can pass for every item entered into I17 while a known pre-cut fix or required feature remains outside it. The Proposal promises later discoveries join, but the criterion and delivering epic criteria supply no complete register or reconciliation at the cut. In particular, the separation audit can list new breaches without a criterion requiring every listed breach to have a delivered resolution.

**Evidence.** initiative-1597.md:36: “Every Work Planner fix and feature planned here is in the history”. The larger requirement appears at line21: “A fault found before the extraction becomes a further task row”. epic-1615.md:49 requires breaches to be “listed with its file, its guideline and its owning home”; lines50–52 check specific generic-prose, generic-script and rule-home conditions, without an explicit disposition invariant for the complete audit set. These establish a plan-proof gap, not an observed undispatched defect.

**Proposed solution.** Agree a discoverable intake register and cut boundary, with every known fix/required feature mapped to a delivering row and final integration evidence. Reconcile later discoveries and the SOLID audit against it before extraction, retaining any unresolved entry as a blocker. Fix the baseline before the plan changes what it measures.

**Decision: pending.** Recommended: require the complete intake reconciliation. Alternative: explicitly narrow the confirmed goal to an enumerated selected set. Neither option has been selected.

## Completion proof

### F2 — P1: Ancestry and equal trees can preserve a reverted fix

**Problem.** `git merge-base --is-ancestor` proves a merge is in history even if later work reverts or changes its fix. Comparing the extracted tree with that source faithfully copies any such regression. I17's local epic criteria do not own a final check that every included fix/feature still holds at the selected source and destination. Consequently all named instruments can pass while the extraction lacks a correction in effect.

**Evidence.** initiative-1597.md:36 ends with “as `git merge-base --is-ancestor` shows for each one's merge commit.” cutover-2.md:36 observes “the content its `skills/` counterpart has at the extracted workflow-server commit”. The source criterion tests history and the destination criterion tests equality to source; neither tests continued correctness of the required set. E01's mechanical instrument at epic-1616.md:60 is “zero findings from Check Skill Files”, which does not by itself establish every behavioral fix or discovery was retained. This is a logical counterexample; the review found no actual revert.

**Proposed solution.** Keep ancestry and tree equality, and assign final evidence ownership for the complete inventory's regression/invariant checks at a literal workspace source SHA and extracted tree. Reuse existing independent fixtures where they observe the requirement; retain anything unobservable or not run as unresolved. The baseline should precede changes to the checker or measured corpus. A pre-cut source designation/reconciliation and a post-extraction tree check must have an explicit order without making the cut depend on its own completed result.

**Decision: pending.** Recommended: add the retained-correctness evidence and its responsible row(s) before accepting the goal. Alternative: explicitly agree that historical inclusion alone satisfies the requirement. No criterion or row was drafted or applied.

## Extraction consumer

### F3 — P2: The extraction gate tracks a fixed subset and its parent states a weaker cutoff

**Problem.** The external extraction task explicitly waits for E00/E01/E02 rather than reconciling the complete current pre-cut requirement set. E03 is not in its gate, and any further required feature epic can likewise be absent. Its parent initiative still says the extraction waits only for Pre-Cutover Fixes. The current named gate does hold the cut for E01/E02, so this is a stale-contract and late-addition threat, not evidence extraction has bypassed work.

**Evidence.** cutover-2.md:31 names exactly `[I17:E00]`, `[I17:E01]`, `[I17:E02]` in W00 Depends on; initiative-1597.md:32 adds E03 under the same AC1. extraction-initiative-1.md:93 says: “The extraction is cut from workflow-server's `workspace` head once I17's Pre-Cutover Fixes epic closes.” I17's Proposal at initiative-1597.md:23 says a required feature “lands ahead of the extraction as a fix does.”

**Mitigating evidence.** E03 is closed completed and PR #1627 merged into workspace. Its integration SHA equals cached origin/workspace. The omission therefore does not establish a present loss of delivery lanes. The supplied cutover issue remains open, and its explicit child gate includes the still-open E01/E02.

**Proposed solution.** Align parent and child cutoff statements and require extraction readiness to reconcile the current approved intake set, integrations and designated source SHA. On new pre-cut findings, refresh that gate before cutting. When plan edits are authorized, task dependencies should name producing rows as the captured Dependency Graph requires; no automatic rewriting is warranted in this review.

**Decision: pending.** Recommended: one current-set reconciliation gate shared by the producer and consumer plans. Alternative: maintain an explicit fixed list, with a required update on every admitted pre-cut epic. No external issue change was made.

## Retained evidence gaps

- No marked I17 requirement source exists. Background URLs and the external style example are not supplied source contents, and were not fetched; no semantic compliance with those remote documents is claimed.
- The register of every actual discovery and required-before-cut decision is absent. F1 does not assert an actual omitted finding.
- Work-item component files and the SOLID audit are unavailable under this walk's input/reading limits. Graph output explicitly leaves contention unchecked.
- Capture-time merged states do not establish present-day CI, remote refs, approvals or destination content. No final extraction-source or destination commit was supplied.
- The draft E01 integration, pending W06/W08 and open E02 prevent a delivery-complete conclusion now. These are known planned work, not additional review findings.

The authority boundary forbids source/plan edits, network access, tracker writes, worktree creation, commits, pushes, merges and agents. Pending decisions are returned for later resolution as the prompt requests; no recommendation counts as an answer.
