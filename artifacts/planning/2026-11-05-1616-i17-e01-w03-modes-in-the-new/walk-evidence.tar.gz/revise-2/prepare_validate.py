from pathlib import Path
import ast
import difflib
import hashlib
import json
import os
import shutil
import subprocess
import sys

SOURCE = Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new')
OUT = Path('/tmp/w03-walk-source/revise-2')
CANDIDATE = OUT / 'candidate'
EVIDENCE = OUT / 'evidence'
TARGET = Path('skills/work-planner/scripts/progress.py')
EVIDENCE.mkdir(exist_ok=True)
(EVIDENCE / 'tmp').mkdir(exist_ok=True)
ENV = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'TMPDIR': str(EVIDENCE / 'tmp'), 'COLUMNS': '120'}

def command(name, args, cwd):
    result = subprocess.run(args, cwd=cwd, env=ENV, text=True, capture_output=True)
    record = {'command': args, 'cwd': str(cwd), 'returncode': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr}
    (EVIDENCE / (name + '.json')).write_text(json.dumps(record, indent=2))
    print(name, 'exit', result.returncode, flush=True)
    print(result.stdout[-2500:] + result.stderr[-2500:], flush=True)
    return result

def hashes():
    return {str(p.relative_to(SOURCE)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (SOURCE / 'skills').rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}

before = hashes()
(EVIDENCE / 'source-hashes-before.json').write_text(json.dumps(before, indent=2))
status_before = command('source-status-before', ['git', '--no-optional-locks', 'status', '--porcelain=v1'], SOURCE)
command('source-revision', ['git', '--no-optional-locks', 'rev-parse', 'HEAD'], SOURCE)
shutil.copytree(SOURCE / 'skills', CANDIDATE / 'skills',
                ignore=shutil.ignore_patterns('__pycache__', '*.pyc'), dirs_exist_ok=True)
original = (SOURCE / TARGET).read_text()
old = "parser.add_argument('--since', help='the first day of the window, YYYY-MM-DD')"
new = "parser.add_argument('--since', help='the local-date start of the reporting window, YYYY-MM-DD')"
assert original.count(old) == 1
changed = original.replace(old, new)
(CANDIDATE / TARGET).write_text(changed)
(OUT / 'candidate.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), changed.splitlines(keepends=True),
    fromfile='a/' + str(TARGET), tofile='b/' + str(TARGET))))

left, right = ast.parse(original), ast.parse(changed)
replaced = 0
for node in ast.walk(left):
    if isinstance(node, ast.Constant) and node.value == 'the first day of the window, YYYY-MM-DD':
        node.value = 'the local-date start of the reporting window, YYYY-MM-DD'
        replaced += 1
assert replaced == 1
assert ast.dump(left) == ast.dump(right)
differences = [str(p.relative_to(CANDIDATE)) for p in (CANDIDATE / 'skills').rglob('*')
               if p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest() != before[str(p.relative_to(CANDIDATE))]]
assert differences == [str(TARGET)], differences
(EVIDENCE / 'candidate-invariants.json').write_text(json.dumps({
    'only_changed_file': differences, 'only_ast_difference': '--since help string',
    'argument_names_defaults_and_runtime_ast_preserved': True}, indent=2))
print('Candidate invariants pass', flush=True)

help_result = command('candidate-help', [sys.executable, '-B', str(CANDIDATE / TARGET), '--help'], CANDIDATE)
assert help_result.returncode == 0
assert 'the local-date start of the reporting window, YYYY-MM-DD' in ' '.join(help_result.stdout.split())
command('work-planner-suite', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'test'], CANDIDATE / 'skills/work-planner')
command('shared-checker-suite', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'skills/test'], CANDIDATE)
command('source-skill-check', [sys.executable, '-B', 'skills/scripts/check_skill_files.py', 'skills/work-planner'], SOURCE)
command('candidate-skill-check', [sys.executable, '-B', 'skills/scripts/check_skill_files.py', 'skills/work-planner'], CANDIDATE)
after = hashes()
(EVIDENCE / 'source-hashes-after.json').write_text(json.dumps(after, indent=2))
status_after = command('source-status-after', ['git', '--no-optional-locks', 'status', '--porcelain=v1'], SOURCE)
assert before == after, 'source skills content changed'
assert status_before.stdout == status_after.stdout, 'source git status changed'
print('Source skills hashes and git status are identical before/after', flush=True)
