# Temporary Candidate

`candidate.patch` changes only `skills/work-planner/scripts/progress.py`:

```diff
-    parser.add_argument('--since', help='the first day of the window, YYYY-MM-DD')
+    parser.add_argument('--since', help='the local-date start of the reporting window, YYYY-MM-DD')
```

- AST comparison proves the help constant is the sole code difference; names, defaults and runtime logic are preserved.
- Executed `--help`: passes and displays the requested wording.
- Executed existing Work Planner tests: 923 tests, OK, one skipped.
- Executed existing shared checker tests: 255 tests, OK.
- Executed skill-file checker on source and candidate: both fail with the same inherited finding, `modes/revise-mode.md:128: section outside the set — Fields` (58 files checked).
- Source skills hashes and Git status are identical before and after. No source edits, source commits, source pushes or remote writes occurred.

The help-only candidate is ready to review. Full delivery is not established: the existing skill-checker gate remains failing, and this exercise prohibits applying, committing and pushing. Delivery requires authorized work in the owning linked worktree, preserving existing staged edits, resolving that finding in its appropriate scope, rerunning required checks, then committing and plain `git push`.

`account.md` records actual reading order, recovery, command attempts, validation, unnecessary context and authority limits. `reads/reads.jsonl` records source emissions; `evidence/` holds complete subprocess evidence. These are local validation results, not live board or delivery evidence.
