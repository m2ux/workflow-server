import json
from pathlib import Path
import subprocess
import sys

out = Path('/tmp/w03-walk-source/understand-2')
name, *command = sys.argv[1:]
result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(out / (name + '.stdout')).write_text(result.stdout)
(out / (name + '.stderr')).write_text(result.stderr)
with (out / 'commands.jsonl').open('a') as stream:
    stream.write(json.dumps({'name': name, 'command': command, 'returncode': result.returncode, 'stdout': name + '.stdout', 'stderr': name + '.stderr'}) + '\n')
print(result.stdout, end='')
print(result.stderr, end='', file=sys.stderr)
print('EXIT', result.returncode)
