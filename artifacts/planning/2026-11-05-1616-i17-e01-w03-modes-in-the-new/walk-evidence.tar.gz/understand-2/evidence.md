# Evidence and publication proposal

## Change identity

- Supplied historical capture: `/tmp/w03-walk-source/captured/merged-pr.json`.
- PR: `m2ux/workflow-server#1642`, `[I17:E01] Common Files: Rules, Conventions and Configuration`.
- Named head: `83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2`.
- Captured base: `dd44528b3fdea032c4128e1e0f638d038261498a`, `i17/e01/workspace`.
- Captured merge: `238b652aaa52057f66c86c9651c379296a7ba5b2`; the local merge object names that base and head as its two parents and names PR #1642 in its subject.
- Captured merged time: `2026-11-05T09:23:37Z`. This is supplied historical evidence, not a fresh GitHub observation.
- `change-stat.stdout` reports 10 changed files, 108 insertions, 70 deletions, matching the capture. `change-diff.stdout` retains the complete local three-dot diff.

## Available structural evidence

- The exact-head diff places rules and conventions in separate common files, required by the entry point before mode selection.
- Configuration contains deployed board titles and fields, labelled project examples, the engineering planning path and the default report window.
- The diff exposes links from board creation, planning records and standup reporting to their configuration homes, plus guidance and vocabulary-test consumers.
- These are source relationships. They do not supply graph-measured component boundaries, callers, callees or containing flows.

## Available functional evidence

- Source instructions prescribe conditional configuration reads and the board creation sequence. They were read as documentation; their procedures were not executed.
- Executed in `/tmp/w03-walk-source/understand-2/review-copy` at the literal named head:
  `python3 -m unittest discover -s skills/work-planner/test -p test_checkouts.py`.
- Result: 7 tests, OK, process return code 0. See `checkout-vocabulary-tests.stdout` and `.stderr`.
- The capture's T1–T5 test-plan rows are historical claims. Their linked validation document and its test outputs were not opened or independently re-established. No complete-suite or full-workflow success is claimed.

## Graph evidence gap

1. Installed executable: `/usr/local/bin/gitnexus`, reporting version 1.6.12.
2. Initial status in the isolated head copy: `Repository not indexed.`
3. Required bare compare command was attempted; it failed because multiple registered repositories exist and none was selected. No measurements arrived.
4. Help was inspected. Indexing was attempted only inside the isolated `/tmp` copy with `analyze --index-only --skip-fts --workers 2` under `scripts/sbx`.
5. Analyze failed with EROFS opening `/home/mike1/.gitnexus/registry.json.tmp.b58e5bffc18d4017`. The global registry remained read-only. The command returned 1 and left `.gitnexus/` only in the temporary copy.
6. Its diagnostic reported dropped entry points, skipped callees and budget-cut walks. Those diagnostics are incomplete analyzer progress, not a returned change surface or complete set of flows.
7. Post-attempt status still reported `Repository not indexed.`
8. The documented `--repo` option was then used with the exact temporary checkout path. Compare failed with `Repository ... not found.` No symbol context or flow identities were available to pass to downstream queries.

The exact unmet requirement is a successful, isolated graph index registered for the reviewed head and base, followed by a change surface, per-symbol context and ordered flow traces with current freshness evidence. This environment's default registration writes outside `/tmp`; this exercise does not authorize that write. A documented way to keep registration and all index state under `/tmp`, or separately supplied valid graph captures at these revisions, would allow further permitted measurement. No such setting or captures were established here. The candidate therefore contains no invented component or sequence diagrams and does not satisfy the skill's completed measured-overview outcome.

## Proposed publication destination

Configuration places records on `engineering` under `artifacts/planning/`. Local `origin/engineering` resolved to `0ac2342d825a1eeadd22c2e89c68bd873400de38` when checked. The retained one-level folder listing contains no identity with reference `1642`; it contains the W02 delivery record cited by the captured PR. This is not a remote or content-wide proof that no differently named overview exists.

Subject to confirming or reusing the existing overview identity, the proposed record is:

`artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/`

Proposed overview URL, currently unverified and unpublished:

`https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/architecture-overview.md`

The captured PR body already has R1 for its delivery record. The proposed additional References row is:

```markdown
- **R2.** [Architecture Overview](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/architecture-overview.md) — the change's structure, its flows, and the order to read the diff.
```

That row is a proposal for a future completed and published overview, not a claim that the URL resolves. Publication would require fresh body/identity checks, completion of graph evidence and diagrams, preservation of an existing overview record when found, authorization for engineering writes and publication, then link and publication readback. No write, commit, push, PR edit or remote readback was performed.

## Authority and remaining evidence

- The exercise forbids authoritative checkout/git mutations and publication. The skill's fetch/review-worktree operation was not executed because it writes authoritative git metadata. A separate local clone under `/tmp` supplied a historical detached candidate copy instead.
- No current GitHub metadata or changed-path API response was fetched. The capture and exact local git diff supplied the explicitly requested historical snapshot.
- Required diagram evidence is missing. A complete Understand/Change Overview execution is not claimed.
- Board/report workflows, full suite results, live disclosure performance, published record resolution and PR-body readback are absent.
- The optional integration capture was not needed to identify this task PR and was not read.
