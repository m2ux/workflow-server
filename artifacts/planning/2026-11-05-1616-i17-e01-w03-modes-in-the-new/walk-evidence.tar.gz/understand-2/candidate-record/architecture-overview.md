# Architecture Overview — Common Files: Rules, Conventions and Configuration

> architecture-overview · [m2ux/workflow-server#1642](https://github.com/m2ux/workflow-server/pull/1642) · 2026-11-05

**Local preliminary overview.** This account describes historical head `83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2`, compared with captured base `dd44528b3fdea032c4128e1e0f638d038261498a`. It has source and focused-test evidence. Required fresh graph measurements and their diagrams are pending; it is not a completed measured overview or a published artifact.

## Summary

Work Planner places shared reading rules, execution conventions and deployed values in three common documents. Its entry point loads rules and conventions before choosing a mode, while consuming sections link to the configuration values they need. The change reaches the skill's Markdown instructions and its checkout-vocabulary test.

## Structure

The [entry point](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/SKILL.md#L18-L24) provides the shared-context reading gate and mode selection. [Rules](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/rules.md#L1-L10) owns reading boundaries and procedure execution; [Conventions](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/conventions.md#L1-L29) owns session, repository, checkout, body-file and script conventions. [Configuration](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/configuration.md#L1-L33) owns board values, labelled theme examples, the planning-record location and the standup default. These are responsibilities and explicit links observed in source, not graph-derived component boundaries.

### Common Context

- **Rules.**
  Heading-linked reads stop at the next equal or higher heading; prerequisite reading alone does not execute procedures. Procedure calls pass named inputs, run whole and return before their caller continues, except where concurrency is explicit.
- **Conventions.**
  Checkout names and the context in which commands act have one shared vocabulary. Scripts and tracker calls retain their documented execution environments.

### Value Consumers

- **Boards.**
  [Board prerequisites](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L5-L10) condition configuration reads on proposals-board selection or creation, and on theme-board creation. Its creation operations use configuration links for template titles, proposal-board title and theme fields.
- **Planning records.**
  [The record prerequisite](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/planning-record.md#L5-L9) links the configured engineering-branch location. [Folder identities](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/planning-record.md#L139-L149) retain a date, optional issue or PR number, and slug.
- **Standup reports.**
  [The conditional prerequisite](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/standup-report.md#L5-L11) reaches configuration when a start date is missing. [Scope](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/standup-report.md#L32-L36) preserves an explicitly supplied start date.

### Reader Checks

- **Authoring guidance.**
  [Entry Point guidance](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/guidelines.md#L212-L220) names the entry-point sections and shared document homes.
- **Checkout vocabulary.**
  [The vocabulary reader](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/test/test_checkouts.py#L43-L48) reads `conventions.md`. Seven focused tests passed in a temporary checkout of this historical head.

**Structural diagram pending.** GitNexus did not return a current change surface or symbol relationships for this checkout. The overview contract requires graph-derived areas and edges; a diagram inferred from these file links would not meet it.

## Behaviour

The source prescribes a common-context read gate and conditional configuration reads. These descriptions are document evidence, not measured execution traces or completed board/report workflows.

### Shared Context Before Mode Selection

- **Entry gate.**
  `SKILL.md` requires Rules and Conventions before mode selection. Rules supplies bounded-reading and execution conditions; Conventions supplies the shared working vocabulary.

### Board Configuration

- **Proposal board creation.**
  [Create Proposals Board](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L35-L46) prescribes finding the configured template, using its returned number for copying, and linking the result to the repository. This run created no board.
- **Theme board creation.**
  [Create Theme Board](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L48-L60) requires proposal provenance when applicable and uses the configured theme template and field description. This run did not execute these commands.

### Record Location and Report Window

- **Record location.**
  Configuration states that planning records live under `artifacts/planning/` on `engineering`; the folder-format consumer links that location.
- **Omitted report start.**
  The report prerequisite reaches Standup configuration, whose default opens a week before today. An explicit start selects its own window. This run generated no standup.

**Functional diagrams pending.** No `process_symbols` entries, `step_index` values or graph freshness block were returned. Sequence diagrams cannot be presented as measured flows.

## What Changed

### Instruction Ownership

- **Common homes.**
  Rules and Conventions are required common documents, and Configuration is the linked home for deployed values. See the PR's [Changes](https://github.com/m2ux/workflow-server/pull/1642) for the change listing.

### Consuming Contracts

- **Configuration routes.**
  Board operations, record placement and omitted standup starts reach the corresponding configuration sections.
- **Vocabulary authority.**
  The checkout test derives its vocabulary from the shared Conventions document.

## Reading Order

1. **[SKILL.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/SKILL.md#L9-L24)** — begin with the common-context gate before mode selection.
2. **[rules.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/rules.md#L1-L10)** — understand reading and execution obligations.
3. **[conventions.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/conventions.md#L1-L29)** — locate the command and checkout vocabulary.
4. **[configuration.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/configuration.md#L1-L33)** — inspect values before their consumers.
5. **[artifacts/board.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L5-L60)** — inspect conditional board reads and creation inputs.
6. **[artifacts/planning-record.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/planning-record.md#L139-L149)** — inspect the configured location's folder-format consumer.
7. **[artifacts/standup-report.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/standup-report.md#L5-L36)** — inspect the missing-start condition and explicit-start contract.
8. **[test/test_checkouts.py](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/test/test_checkouts.py#L43-L48)** — inspect the executable reader of the new vocabulary home.

## Risks and Watch Points

- **Graph evidence.**
  The required current surface, per-symbol context, ordered flow traces and diagrams remain unavailable. The temporary index attempt failed on a read-only global registry write.
- **Behavioural coverage.**
  The focused tests observe checkout vocabulary and declarations. They do not prove board creation, report generation, full workflow disclosure or reduced reading cost.
- **Historical snapshot.**
  Captured PR metadata and local git objects establish this reviewed change. No live PR refresh, remote freshness check or publication readback ran.

## References

- **R1.** [Pull request #1642](https://github.com/m2ux/workflow-server/pull/1642) — identity and captured delivery narrative; remote state was not refreshed.
- **R2.** [Head commit](https://github.com/m2ux/workflow-server/commit/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2) — the literal revision used for source links and the focused local test.
