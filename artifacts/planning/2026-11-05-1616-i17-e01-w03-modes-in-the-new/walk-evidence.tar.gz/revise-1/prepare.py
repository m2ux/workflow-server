from pathlib import Path
import hashlib
import shutil
import difflib
import json

source = Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new')
output = Path('/tmp/w03-walk-source/revise-1')
candidate = output / 'candidate'
shutil.copytree(source / 'skills', candidate / 'skills', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
relative = Path('skills/work-planner/scripts/progress.py')
original = (source / relative).read_text()
old = "help='the first day of the window, YYYY-MM-DD'"
new = "help='the local-date start of the reporting window, YYYY-MM-DD'"
assert original.count(old) == 1
(candidate / relative).write_text(original.replace(old, new))
(output / 'candidate.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), (candidate / relative).read_text().splitlines(True), fromfile='a/' + str(relative), tofile='b/' + str(relative))))
manifest = {str(p.relative_to(source / 'skills')): hashlib.sha256(p.read_bytes()).hexdigest() for p in (source / 'skills').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
(output / 'source-hashes-before.json').write_text(json.dumps(manifest, indent=2))
print((output / 'candidate.diff').read_text())
