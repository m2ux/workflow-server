from pathlib import Path
import ast
import hashlib
import json

source = Path('/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills')
out = Path('/tmp/w03-walk-source/revise-1')
candidate = out / 'candidate/skills'
baseline = json.loads((out / 'source-hashes-before.json').read_text())
current = {str(p.relative_to(source)): hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
assert current == baseline, 'source changed during exercise'
changed = [p for p, digest in baseline.items() if hashlib.sha256((candidate / p).read_bytes()).hexdigest() != digest]
assert changed == ['work-planner/scripts/progress.py'], changed
before = ast.parse((source / changed[0]).read_text())
after = ast.parse((candidate / changed[0]).read_text())
old = 'the first day of the window, YYYY-MM-DD'
new = 'the local-date start of the reporting window, YYYY-MM-DD'
found = [n for n in ast.walk(after) if isinstance(n, ast.Constant) and n.value == new]
assert len(found) == 1
found[0].value = old
assert ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False)
assert new in ' '.join((out / 'help.txt').read_text().replace('YYYY-MM-\n                        DD', 'YYYY-MM-DD').split())
print(f'Source content unchanged: {len(current)} files')
print('Candidate differs only in progress.py')
print('AST differs only in the specified help constant: runtime, argument names and defaults preserved')
print('CLI help renders the requested wording')
reads = [json.loads(line) for line in (out / 'reads/reads.jsonl').read_text().splitlines()]
print('Captured read metadata:')
for item in reads:
    print(json.dumps(item))
