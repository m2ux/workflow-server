# Bounded Revise Exercise

The reviewable candidate is `candidate/skills/work-planner/scripts/progress.py`; `candidate.diff` contains one help-string replacement. Its text is `the local-date start of the reporting window, YYYY-MM-DD`. Runtime logic, option names and defaults are preserved by normalized AST comparison. The authoritative source remains untouched.

## Reading Order and Receipt

1. Read the supplied exercise prompt completely with `cat` (454 output tokens).
2. Read the authoritative Work Planner `SKILL.md`, then `rules.md` and `conventions.md`, completely through the required neutral helper.
3. Selected Revise and read `modes/revise-mode.md` completely.
4. Read the whole shared and skill-specific guidelines as the mode requires. The combined tool response was truncated: shared guidelines were received completely, while part of the skill-specific Procedure/Prose text was omitted. Recovered both exact sections through helper heading reads before editing. This repeats 40 source lines; some overlap was already received, but the transcript does not identify the omitted character boundary precisely.
5. Searched guidelines headings and the target script's date/help wording (`source-search.txt`). Read the whole target script through the helper. Its existing docstring and datetime conversion establish local-midnight semantics.
6. Searched the standup consumer and existing tests (`consumer-search.txt`); read the whole `artifacts/standup-report.md` through the helper. Its window/command guidance corroborates the date format. The other report sections were unnecessary for this bounded help edit. This full read reached its hot-fix prerequisites without loading them first; that is a reading-order limitation. No standup operation was executed, and those unrelated prerequisites were not loaded afterward merely to inflate receipt.
7. Searched test names and fixture paths (`test-search.txt`). The display was intentionally bounded to 100 lines and then tool-truncated; unused test names were not recovered. The needed Window tests were recovered directly with a narrow `rg -A22` read (`window-tests.txt`). Read `test/fixtures.py` completely through the helper to confirm test script resolution. Its unrelated issue/branch fixture helpers were unnecessary context.

The complete emitted source texts and exact source-line ranges are retained in `reads/reads.jsonl` and its referenced files. Retained emission is distinct from actual model receipt: the guideline omission was recovered, while unused search results were not. Full-script receipt included implementation unrelated to the one help constant. No memories, other agents' findings or other walk outputs were inspected.

## Commands and Authority

- First attempted the neutral helper's `--help` without the mandated launcher; the tool hook blocked execution. Corrected to the requested absolute `md-composer/scripts/sbx` launcher. That restricted launch failed because bubblewrap could not create a namespace. The same launcher succeeded with tool escalation, and subsequent helper/script commands used that launcher. Neither failure returned source content.
- Helper invocations used `--log /tmp/w03-walk-source/revise-1/reads`, the authoritative source path and, for recovery, `--heading Procedure` or `--heading Prose`.
- Searches were `rg` commands against the named source files/directories, redirecting exact search output into this task's folder; output was displayed with bounded `cat`, `head` or narrow `rg`.
- `prepare.py` copies only `skills/` under this folder, excluding bytecode, changes exactly one string, writes a unified diff and records SHA-256 source hashes. It is retained for inspection.
- All check commands use `PYTHONDONTWRITEBYTECODE=1`. The prescribed full skill suite runs from the candidate's `skills/work-planner` with `python3 -m unittest discover -s test`. The tests resolve scripts in the candidate. Existing tests construct disposable local git repositories/commits as fixtures under temporary directories; no source checkout git operation or remote action was requested.
- Ran the prescribed `python3 skills/scripts/check_skill_files.py skills/work-planner` in both candidate and source, retaining both logs.
- Ran candidate `progress.py --help`, retaining `help.txt`.
- Ran `validate.py`, retaining `validation.log`: all 189 captured source skill files match their initial hashes, only candidate progress.py differs, and both ASTs match after normalizing the requested help constant. No git or remote commands were issued directly. No issue, comment, worktree, branch, commit, push, publication or merge was created in an authoritative repository.

## Validation and Limitations

- Candidate CLI help: exit 0; requested text renders, with argparse's normal line wrapping.
- Candidate/source content and AST assertions: exit 0.
- Shared checker: exit 1 on both source and candidate with the same finding: `work-planner/modes/revise-mode.md:128: section outside the set — Fields`; 58 files checked. This predates the candidate and was not repaired outside scope.
- Full skill suite: exit 0; 923 tests in 116.976 seconds, OK with one skip (`skill-tests.log`).
- No markdown, entry-point frontmatter or section bodies changed, so frontmatter and moved-section comparison checks are inapplicable. The checker still traversed the affected skill's markdown.
- Disclosure verification traces this bounded Revise request through its required entry, rules, conventions, whole mode and whole guidelines, then consumer, script and test guidance; prerequisites were reused at the same snapshot. No reading paths changed, so independent live-agent checks were not required. Broad unused context and the consumer prerequisite-order limitation are observations, not claimed successes.
- No external state, live delivery readiness, CI result or historical capture was asserted. A passing local suite alone cannot establish delivery.

## Delivery Requirements

This exercise authorizes a temporary candidate only. Actual delivery requires authorization to change the owning linked worktree, resolving or explicitly accepting the pre-existing checker finding under the repository's rules, then validation, commit and plain push on the appropriate owning branch. Applying the patch, creating or updating a pull request and any remote action remain proposed and unexecuted. The confirmed scope and wording required no additional interview.
