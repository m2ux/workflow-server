# Other source reads and executed commands

Source-document helper reads are recorded exactly in `reads/reads.jsonl`. All writes target the supplied output folder under `/tmp`.

```bash
cat /tmp/w03-walk-source/standup-2.md
cat /tmp/w04-neutral-read.py
wc -c /tmp/w03-walk-source/captured/items.json /tmp/w03-walk-source/captured/prs.jsonl /tmp/w03-walk-source/captured/links.json /tmp/w03-walk-source/captured/epic.json
```

The two executed renderer commands, from `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new`:

```bash
/home/mike1/projects/dev/md-composer/scripts/sbx python3 skills/work-planner/scripts/progress.py --items /tmp/w03-walk-source/captured/items.json --prs /tmp/w03-walk-source/captured/prs.jsonl --links /tmp/w03-walk-source/captured/links.json --since 2026-11-01 --initiative I17 > /tmp/w03-walk-source/standup-2/report-initial.txt 2> /tmp/w03-walk-source/standup-2/unresolved-initial.txt
/home/mike1/projects/dev/md-composer/scripts/sbx python3 skills/work-planner/scripts/progress.py --items /tmp/w03-walk-source/captured/items.json --prs /tmp/w03-walk-source/captured/prs.jsonl --links /tmp/w03-walk-source/captured/links.json --since 2026-11-01 --initiative I17 --summary /tmp/w03-walk-source/standup-2/summary.txt > /tmp/w03-walk-source/standup-2/report.txt 2> /tmp/w03-walk-source/standup-2/unresolved-renderer.txt
```

Bounded source-data inspections:

```bash
jq 'type, (if type == "array" then .[0] | keys else keys end)' /tmp/w03-walk-source/captured/items.json > /tmp/w03-walk-source/standup-2/items-shape.txt
jq '[.[] | select(.content.title | test("^\\[I17(:|\\])")) | {number:.content.number,title:.content.title,state:.content.state,closed_at:.content.closed_at,fields:.fields}]' /tmp/w03-walk-source/captured/items.json > /tmp/w03-walk-source/standup-2/i17-board-check.json
jq -s '[.[] | select(.title | test("^\\[I17(:|\\])")) | {number,title,merged_at,state,draft,base:.base.ref,head:.head.ref}]' /tmp/w03-walk-source/captured/prs.jsonl > /tmp/w03-walk-source/standup-2/i17-pr-check.json
jq -s '{read_events:length,emitted_characters:(map(.characters)|add),emitted_lines:(map(.lines)|add),distinct_sources:(map(.source)|unique|length)}' /tmp/w03-walk-source/standup-2/reads/reads.jsonl > /tmp/w03-walk-source/standup-2/read-totals.json
```

Read each generated output completely with `cat`, including initial/final renderer stdout and stderr, shape, board check, PR check, helper ledger and totals. A source-data inventory inline Python attempt was rejected before execution; `account.md` records it. No other source searches were run. No `gh`, `git`, remote tools, test suite or publication commands were executed.

Final output packaging used `awk` over `report.txt` and `unresolved.md` to add a fenced block and separate findings. The first command was rejected before execution for literal backtick characters; the successful equivalent used `printf` character code 96. `wc -c` checked output sizes. `awk` extracted the final fenced report into `cmp - report.txt`; exit 0 proves verbatim packaging.
