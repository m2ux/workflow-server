# Proposed Publication

- Record: `artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/` on `engineering`.
- Overview: `architecture-overview.md`.
- Existing-record search: local `origin/engineering` tree has no `-1642-` match. This is not a fresh remote or shared-worktree search; repeat and reuse any existing identity before publication.
- Register the overview in the record README's Artifacts table and PR #1642 under Links.
- Proposed URL, not published or verified: https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/architecture-overview.md
- Proposed References row, after the captured body's existing R1 and subject to fresh readback:

```markdown
- **R2.** [Architecture Overview](https://github.com/m2ux/workflow-server/tree/engineering/artifacts/planning/2026-11-05-1642-common-files-rules-conventions-and-configuration/architecture-overview.md) — the change's structure, its flows, and the order to read the diff.
```

No publication, commit, push, PR edit or remote readback occurred. Measured diagrams remain a prerequisite gap.
