# Architecture Overview — Common Files: Rules, Conventions and Configuration

> architecture-overview draft · [m2ux/workflow-server#1642](https://github.com/m2ux/workflow-server/pull/1642) · 2026-11-05

## Evidence Status

This local source-backed draft describes captured merged head `83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2` against captured base `dd44528b3fdea032c4128e1e0f638d038261498a`. It is not a completed Change Overview: measured structure and ordered functional traces remain incomplete. Publication is outside this exercise's authority.

The historical capture records this task PR merged into `i17/e01/workspace`, with merge commit `238b652aaa52057f66c86c9651c379296a7ba5b2`. It does not establish current remote state or epic integration into `workspace`.

## Summary

Work Planner's entry point requires common Rules and Conventions before mode selection. Configuration owns deployed board values, planning-record placement and the default standup window, reached through consuming sections. The checkout-vocabulary test reads its names from Conventions.

## Structure

The change concerns the skill's instruction corpus and one Python test module. These relationships come from the exact-head diff and explicit source links; they are not graph measurements.

- **Entry point.**
  [SKILL.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/SKILL.md#L18-L22) links proposals configuration and requires Rules and Conventions before mode selection.
- **Common operating context.**
  [rules.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/rules.md#L1-L10) states reading boundaries, decisions, layer direction and execution rules. [conventions.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/conventions.md#L1-L29) defines session, repository, checkout, body-file and script conventions, with labelled examples.
- **Deployment values.**
  [configuration.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/configuration.md#L1-L33) holds template titles, board fields, theme examples, engineering record placement and the reporting default.
- **Conditional consumers.**
  [board.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L5-L10) loads configuration for proposals selection/creation or theme creation. [planning-record.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/planning-record.md#L5-L9) loads planning placement. [standup-report.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/standup-report.md#L5-L11) loads its default when the start is omitted.
- **Corpus validation.**
  [vocabulary()](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/test/test_checkouts.py#L43-L56) extracts checkout names from Conventions. These names supply checks of command declarations, procedure declarations and cross-checkout calls.

### Structural Diagram Evidence

A compliant component diagram remains blocked. The isolated exact-head GitNexus index is current and recognizes the changed Work Planner section, but its context returns empty incoming/outgoing relationships and no processes. That representative empty context cannot establish the explicit instruction links above as measured diagram edges. Context for every changed symbol remains incomplete.

## Behaviour

These are source-stated conditions, not measured runtime traces.

- **Mode selection.**
  The entry point requires Rules and Conventions before selecting a mode.
- **Board operations.**
  Proposals-board selection or creation reads proposals configuration; theme-board creation reads theme configuration. Consumer operations refer to the configured template titles and fields.
- **Planning records.**
  Configuration places records under `artifacts/planning/` on `engineering`; Add Planning Record supplies the dated reference-and-slug folder beneath it.
- **Standup windows.**
  An omitted start uses the configured week-before-today default. An explicit start selects its supplied window.
- **Checkout checks.**
  The vocabulary reader opens `conventions.md`, locates Checkouts and extracts its nested names. Seven tests in `test_checkouts.py` pass in the isolated exact-head copy.

### Functional Diagram Evidence

No sequence diagram is asserted. Change detection reports zero affected processes; the analyzer also warns about omitted entry points, callees and walks. No ordered `process_symbols` records were returned for the reading conditions, so source order alone cannot satisfy the measured-flow requirement.

## What Changed

- **Common context.**
  Separate documents own the rules and conventions required before mode selection.
- **Configuration consumers.**
  Consumers reach deployed values through their applicable linked sections.
- **Authoring and validation.**
  Guidelines describe the common-document entry contract, and checkout tests consume vocabulary from its documented home.

The [PR body](https://github.com/m2ux/workflow-server/pull/1642) carries the detailed Changes section. The inspected diff contains 10 paths, 108 additions and 70 deletions; no production server module or command body is changed.

## Reading Order

1. **[SKILL.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/SKILL.md#L18-L24)** — entry contract and mode selection.
2. **[rules.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/rules.md#L1-L10)** — required operative constraints.
3. **[conventions.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/conventions.md#L1-L29)** — checkout names and execution conventions.
4. **[configuration.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/configuration.md#L1-L33)** — deployed values and example identities.
5. **[board.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/board.md#L5-L60)** — conditional board reads and consuming operations.
6. **[planning-record.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/planning-record.md#L139-L159)** — configured placement and naming.
7. **[standup-report.md](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/artifacts/standup-report.md#L5-L36)** — omitted-start condition.
8. **[test_checkouts.py](https://github.com/m2ux/workflow-server/blob/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2/skills/work-planner/test/test_checkouts.py#L43-L56)** — executable vocabulary consumer.

## Risks and Watch Points

- **Disclosure remains partial.**
  This exercise follows Understand, not board creation or standup execution. Whole-artifact prerequisites return extensive merge/publication material unused here. Nested artifact prerequisites were not exhaustively loaded; this run does not claim complete procedural conformance.
- **Graph coverage is incomplete.**
  Fresh indexing succeeds with an isolated registry and reports omitted flows. The CLI prints 15 of 39 changed symbols even with `--limit 100`; full per-symbol contexts and functional measurements remain incomplete. No JSON staleness blocks appear in the returned CLI surface or context.
- **Historical validation is separate.**
  The captured body reports broader passing suites and bounded walks. Their linked documents were not opened or verified here. Only the seven checkout tests were executed.
- **Publication needs a separate authorized run.**
  This draft has no published record or PR edit. Publication requires fresh metadata, a fresh existing-record search and complete graph evidence or resolution of the document-measurement contract.

## References

- **R1.** [Pull request #1642](https://github.com/m2ux/workflow-server/pull/1642) — selected task change, with state taken from the historical capture.
- **R2.** [Head commit](https://github.com/m2ux/workflow-server/commit/83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2) — immutable source inspected locally.
