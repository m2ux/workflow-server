import json
from pathlib import Path

out = Path('/tmp/w03-walk-source/standup-1')
root = out.parent / 'captured'
prs = [json.loads(line) for line in (root / 'prs.jsonl').read_text().splitlines() if line.strip()]
links = json.loads((root / 'links.json').read_text())
pr_keys = {('/'.join(pr['html_url'].split('/')[3:5]), pr['number']) for pr in prs}
link_keys = {(row['repo'], row['number']) for row in links}
assert pr_keys == link_keys, (pr_keys - link_keys, link_keys - pr_keys)
assert len(links) == len(link_keys), 'duplicate link entries'
assert all(isinstance(row['closingIssuesReferences'], list) for row in links)
report = (out / 'report.txt').read_text()
summary = (out / 'summary.txt').read_text().strip()
assert summary in report
assert (out / 'findings.txt').read_text() == ''
assert '*In progress*\n• Nothing' in report
assert '*Next*\n▶️ *I17:E01 Skill Style*, next W03' in report
assert 'I16' not in report
assert '1641' not in report
result = ('Historical captured state; saved delivery-refresh checkpoint supplied.\n\n'
          '```text\n' + report + '```\n\nUnresolved evidence\n\n'
          + (out / 'unresolved-evidence.md').read_text())
(out / 'result.md').write_text(result)
checks = {
 'PR_and_link_key_sets_match': True,
 'PR_and_link_unique_key_count': len(pr_keys),
 'link_arrays_present_for_all_entries': True,
 'composer_stderr_empty': True,
 'initiative_filter_preserved': True,
 'board_Ready_status_preserved': True,
 'result_fence_equals_report_verbatim': result.split('```text\n',1)[1].split('```',1)[0] == report,
}
assert checks['result_fence_equals_report_verbatim']
(out / 'final-checks.json').write_text(json.dumps(checks, indent=2))
print(json.dumps(checks, indent=2))
manifest = [json.loads(line) for line in (out / 'reads/reads.jsonl').read_text().splitlines()]
command_lines = ['# Actual source/helper commands', '',
 'Prompt: cat /tmp/w03-walk-source/standup-1.md', '',
 'Initial SKILL helper attempt used the same command as below without namespace escalation; bwrap denied execution.', '',
 'Successful helper commands below are in helper-completion order; batch presentation/truncation is explained in account.md.', '']
for row in manifest:
 command_lines.append('/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads ' + row['source'])
command_lines.extend(['', 'Other reads/checks are described in account.md; inspect-captures.py and finish.py retain exact parser code.',
 '/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w03-walk-source/standup-1/inspect-captures.py',
 '/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w03-walk-source/standup-1/finish.py'])
(out / 'commands.md').write_text('\n'.join(command_lines) + '\n')
with (out / 'account.md').open('a') as handle:
 handle.write('\nFinal bounded validation: finish.py exited 0. All 359 unique PR identities exactly match the 359 unique issue-link entries; each holds a closingIssuesReferences array. This validates supplied snapshot coverage structurally, not live pagination. The final fenced report matches report.txt byte for byte, retains the Ready/Next placement, excludes I16 and does not portray open #1641 as completed. See final-checks.json.\n')
