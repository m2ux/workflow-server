import json
from pathlib import Path

root = Path('/tmp/w03-walk-source')
out = root / 'standup-1'
items = json.loads((root / 'captured/items.json').read_text())
prs = [json.loads(line) for line in (root / 'captured/prs.jsonl').read_text().splitlines() if line.strip()]
links = json.loads((root / 'captured/links.json').read_text())
selected = [pr for pr in prs if pr.get('title', '').startswith('[I17')]
rows = [{k: pr.get(k) for k in ('number','title','html_url','state','merged_at','created_at','updated_at')} for pr in selected]
(out / 'selected-prs.json').write_text(json.dumps(rows, indent=2))
selected_items = [i for i in items if i.get('content',{}).get('title','').startswith('[I17')]
epic = json.loads((root / 'captured/epic.json').read_text())
board_epic = next(i['content'] for i in selected_items if i['content']['number'] == epic['number'])
result = {
 'board_item_count': len(items),
 'I17_item_count': len(selected_items),
 'pull_request_record_count': len(prs),
 'I17_pull_request_count': len(selected),
 'link_snapshot_type': type(links).__name__,
 'link_snapshot_entries': len(links),
 'link_snapshot_sample': links[:1] if isinstance(links,list) else list(links.items())[:1],
 'held_epic_number': epic['number'],
 'held_epic_body_matches_board_body': epic['body'] == board_epic['body'],
 'board_epic_updated_at': board_epic.get('updated_at'),
 'held_epic_updated_at': epic.get('updated_at'),
 'held_epic_rows_with_planning_holds': [line for line in epic['body'].splitlines() if line.startswith('| [W') and '/tree/engineering/' in line],
 'board_epic_rows_at_same_positions': [line for line in board_epic['body'].splitlines() if line.startswith('| W03') or line.startswith('| W04') or line.startswith('| W05')],
}
if isinstance(links,list):
 result['I17_link_entries'] = [x for x in links if x.get('number') in {pr['number'] for pr in selected}]
(out / 'capture-checks.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
