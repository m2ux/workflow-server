# Actual source/helper commands

Prompt: cat /tmp/w03-walk-source/standup-1.md

Initial SKILL helper attempt used the same command as below without namespace escalation; bwrap denied execution.

Successful helper commands below are in helper-completion order; batch presentation/truncation is explained in account.md.

/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/SKILL.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/conventions.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/modes/standup-mode.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/rules.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/board.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/modes/sync-mode.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/pull-request.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/standup-report.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/issue.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/epic-issue-body.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/issue-body.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/modes/sync-mode.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/pull-request.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/standup-report.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/issue.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/epic-issue-body.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/hotfix.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w03-modes-in-the-new/skills/work-planner/artifacts/hotfix-body.md
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /tmp/w03-walk-source/captured/items.json
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /tmp/w03-walk-source/standup-1/selected-items.json
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /tmp/w03-walk-source/standup-1/selected-epic.json
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w03-walk-source/standup-1/reads /tmp/w03-walk-source/standup-1/selected-prs.json

Other reads/checks are described in account.md; inspect-captures.py and finish.py retain exact parser code.
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w03-walk-source/standup-1/inspect-captures.py
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w03-walk-source/standup-1/finish.py
