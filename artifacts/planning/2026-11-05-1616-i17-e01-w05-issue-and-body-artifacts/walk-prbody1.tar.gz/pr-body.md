## Overview

This pull request delivers AC1 by naming the affected candidate and missing board field when its status cannot be read, so the queue report explains why that candidate cannot start.

## Changes

The queue report identifies missing status evidence to make blocked candidates actionable.

### Queue Diagnostics

- **Identify unreadable status evidence.**
  The report names the affected candidate and the missing board status field.

## Test Plan

| Test | Description | Coverage | Pass |
| --- | --- | --- | --- |
| T1 | Queue fixture | AC1 | |

## Open Questions

- **Verify the published T1 result.** The supplied synthetic record reports a passing local queue-fixture run at revision `1111111111111111111111111111111111111111`. Contents of its [purported result section](https://github.com/m2ux/workflow-server/blob/engineering/artifacts/planning/example/validation.md#queue-fixture) are unavailable; accessibility, section content and revision correspondence remain unverified. T1's Pass cell stays pending until that evidence is verified.
