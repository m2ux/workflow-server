#!/usr/bin/env bash
set -o pipefail
label=$1
shift
printf '%q ' "$@" > "/tmp/w05-walk-v4-epic2/${label}.command"
printf '\n' >> "/tmp/w05-walk-v4-epic2/${label}.command"
"$@" 2>&1 | tee "/tmp/w05-walk-v4-epic2/${label}.out"
result=${PIPESTATUS[0]}
printf '%s\n' "$result" > "/tmp/w05-walk-v4-epic2/${label}.status"
exit "$result"
