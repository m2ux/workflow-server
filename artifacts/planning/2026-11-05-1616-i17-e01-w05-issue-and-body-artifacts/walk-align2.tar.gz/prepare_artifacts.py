import difflib
import json
from pathlib import Path

root = Path('/tmp/w05-walk-v4-align2')
fixture = Path('/tmp/i17-e01-w05/disclosure-v4/inputs/standalone-fixture.json')
issue = json.loads(fixture.read_text())
original = issue['body']
corrected = (root / 'corrected-body.md').read_text()

def sections(body):
    result = {}
    for block in body.split('## ')[1:]:
        title, text = block.split('\n', 1)
        result[title] = text
    return result

before = sections(original)
after = sections(corrected)
assert before == after, 'section text differs'
assert list(after) == ['Overview', 'Problem', 'Proposal', 'Acceptance Criteria']
assert issue['title'] == 'Queue Diagnostics: Explain Missing Status Evidence'
assert issue['labels'] == ['bug']
assert '- [ ] **AC1.** A candidate with unreadable status has a report naming that missing evidence, as the queue fixture verifies.\n' in corrected

(root / 'original-body.md').write_text(original)
(root / 'body.diff').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True), corrected.splitlines(keepends=True), fromfile='original-body.md', tofile='corrected-body.md')))
(root / 'issue-update-payload.json').write_text(json.dumps({'body': corrected}, indent=2) + '\n')
snapshot = dict(issue, body=corrected)
(root / 'corrected-issue.json').write_text(json.dumps(snapshot, indent=2) + '\n')
(root / 'proposed-request.json').write_text(json.dumps({
    'method': 'PATCH',
    'endpoint': 'repos/m2ux/workflow-server/issues/99001',
    'payload_file': str(root / 'issue-update-payload.json'),
    'body_file': str(root / 'corrected-body.md'),
    'publication_status': 'not published; supplied fixture only',
    'selected_changes': ['body'],
    'retained_metadata': {'title': issue['title'], 'labels': issue['labels'], 'state': issue['state']},
}, indent=2) + '\n')
(root / 'repositories.json').write_text('[]\n')
print('PASS: section text is identical; section order is Overview, Problem, Proposal, Acceptance Criteria.')
print('PASS: title, bug label, open state, and unchecked AC1 are preserved.')
print('Wrote original-body.md, body.diff, issue-update-payload.json, corrected-issue.json, proposed-request.json, repositories.json.')
