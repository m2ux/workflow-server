## Overview

Queue selection needs enough evidence to explain why a candidate cannot start.

## Proposal

- **Identify incomplete status evidence.**
  The queue report names the candidate and the missing board field.

## Problem

- **The report omits the missing field.**
  A supplied report fixture contains one blocked candidate with no reason.

## Acceptance Criteria

- [ ] **AC1.** A candidate with unreadable status has a report naming that missing evidence, as the queue fixture verifies.
