# Captured Walk Inputs

epic-1616.json and initiative-1597.json are fresh read-only issue captures, verified by their issue numbers and [I17:E01]/[I17] title prefixes. pr-1641.json, pr-1642.json, pr-1643.json and pr-1644.json capture the integration request and delivered task requests. files-1642.json, files-1643.json and files-1644.json capture their changed paths. These records establish only their captured state. No complete Development-link snapshot or independent criterion verification report is supplied.

standalone-fixture.json is a local synthetic review fixture. Its issue number and URL identify no asserted live issue, and it authorizes no tracker access. Its label is supplied metadata for local review.
