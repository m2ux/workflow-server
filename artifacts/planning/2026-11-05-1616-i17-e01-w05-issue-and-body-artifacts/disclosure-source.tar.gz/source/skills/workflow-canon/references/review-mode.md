# Review Mode

Reviews the combined result of the requested integration and produces a report of findings, coverage and readiness.

## Prerequisites

Before the first command spec, read the [command conventions](command-conventions.md#common).

## Procedure

1. **Establish the subject.**
   - Read applicable project instructions and take the repository, integration PRs or branches, intended targets and merge order from the request and repository metadata.
   - Identify the long-lived branches and what each owns from [Branches and Sources](coverage.md#branches-and-sources) and the project's documentation, manifests and CI. Resolve the shared [planning record](planning.md) before saving evidence.
   - [Fetch Pull Request](#fetch-pull-request) and [Fetch Requirements](#fetch-requirements) where applicable. Resolve only missing decisions with the user, one question at a time.
2. **Capture the revisions.**
   - [Fetch Branches](#fetch-branches), then [Compare Revisions](#compare-revisions) for each head and target. Record the merge base, full SHAs, constituent PRs and delivered requirements.
   - [Create Review Worktree](#create-review-worktree) for each distinct reviewed tree. [Prepare Integration Result](#prepare-integration-result) where the head does not already contain its current target.
   - When engine or corpus behavior is involved, resolve [Engine and Corpus Pairing](coverage.md#engine-and-corpus-pairing).
   - Record the final combination and any intermediate combination the proposed merge or deployment order exposes. Keep separate branch products in their own trees.
3. **Read the design.**
   - Use [Read Captured File](#read-captured-file) for whole-document links and [Read Captured Section](#read-captured-section) for heading links. Start with the documentation index, then the architecture, affected component contracts, schemas, configuration and test guidance at the captured revisions.
   - When engine or corpus behavior is involved, use [Design Reading](coverage.md#design-reading) to select the authoritative architecture and component documents.
   - Trace each affected requirement from its authoritative source through declaration, loading, execution, delivered content and observable output. Follow unchanged consumers of changed shared components.
   - Record disagreements between design, schema and implementation as review evidence.
4. **Plan coverage.**
   - Fill the coverage table in the [report template](../templates/integration-review.md) before broad validation. Use [Coverage](#coverage), [Coverage Planning](coverage.md#coverage-planning) and [Branch Coverage](#branch-coverage) to select observations from its contracts and implementation.
   - Associate each check with its exact revision combination, relevant failure scenario and requirement. Include missing checks as evidence gaps.
5. **Examine and exercise the result.**
   - Inspect the combined diff, shared consumers and the proposed integration result against the documented design.
   - [Run Project Check](command-conventions.md#run-project-check) for each selected observation, inspect its output and preserve evidence in the review record. Read CI definitions for the branches and artifacts each job actually uses.
   - Reproduce uncertain findings in disposable fixtures. Where attribution is unclear, compare target and candidate under equivalent conditions and explain any pairing differences.
6. **Check the integration boundaries.**
   - Compare producers and consumers across branches: schema and tool callers, generated and served surfaces, packaging, paths, configuration and host instructions. Inspect CI selection for wrong trees, stale revisions and incomplete coverage scope, and identify assumptions from one constituent PR that another invalidates.
   - Assess the proposed deployment order against session and runtime behavior. Distinguish an existing defect from a regression and from an unavailable measurement.
   - Check whether the PR bodies describe the complete current result and identify the constituent PRs accurately.
7. **Refresh evidence.**
   - [Fetch Check Evidence](#fetch-check-evidence) for each reviewed PR and its relevant CI runs. Inspect recorded checkout revisions as well as the reported check SHA.
   - [Refresh Revisions](#refresh-revisions) before concluding. A moved head, target or paired dependency sends the affected conclusions back through examination and validation.
8. **Report.**
   Write the [integration review](../templates/integration-review.md) in the shared [planning record](planning.md), using [Verdicts](#verdicts) and [Findings](#findings). End with the smallest concrete actions that close the findings or evidence gaps.

## Reference

### Coverage

- **Requirements.**
  Each applicable requirement has an observable successful path, relevant boundary or negative behavior, the integration boundary exercised and the observation's limits.
- **Design.**
  Assess the integration against the project's principles, including responsibility boundaries, authoritative homes and dependency policy. A proposed correction follows those same principles.
- **Kinds of evidence.**
  Syntax checks, schema checks, snapshots, simulated walks and real execution establish different facts. Match the check to the claim; file or string checks establish only facts about that file or string.
- **Agent behavior.**
  A walk supplying stand-in values cannot establish that an agent performs a technique correctly or an external tool returns the claimed result. Inspect the instructions the receiving role gets and identify the execution evidence those claims need.
- **Validation behavior.**
  For changed validation, use an existing defect fixture or disposable reproduction to show that the invalid case is detected.
- **Scope.**
  Broaden coverage to the affected dependency closure. A narrow check is sufficient only when the closure excludes the other consumers; explain every not-applicable decision.
- **Results.**
  Record executed, inspected and inferred evidence separately. A skipped test, unavailable dependency, cancelled run or pending check leaves its requirement unobserved.

### Branch Coverage

Select the section for every affected product and consumer before reading its check specifications:

| Product | Coverage |
| --- | --- |
| Engine | [Main Coverage](coverage.md#main-coverage) |
| Definitions | [Workflows Coverage](coverage.md#workflows-coverage) |
| Packaging | [Docker Coverage](coverage.md#docker-coverage) |
| Workspace tooling | [Workspace Coverage](coverage.md#workspace-coverage) |

### Findings

Group findings by area of concern and order them by severity. Each finding states its trigger, expected behavior and source, observed behavior or reproduction, consequence, owning branch, suggested correction and confidence. Cite code and definitions with commit-pinned links where available. Distinguish a confirmed defect from a suspected one or an evidence gap; classify severity by consequence using the project's scale.

### Verdicts

| Verdict | Meaning |
| --- | --- |
| Ready on the reviewed revisions | Required evidence holds for the stated combination and no finding prevents integration |
| Changes required | A confirmed defect prevents integration; further evidence may also be missing |
| Insufficient evidence | Readiness cannot be established and no confirmed blocking defect determines the verdict |

## Rules

- **Review authority.**
  This mode reads, validates and writes a local report. Reviewed branches, tests, baselines and exception ledgers stay as captured; fixes, commits, pushes, publication, merges and GitHub review posts are outside this mode.
- **Isolation.**
  Builds, test output and disposable reproductions belong in review worktrees or scratch storage. Shared checkouts and live services retain their state.
- **Exact subject.**
  Evidence names the revisions it measured. Separate branch products are paired for testing, not merged into one unrelated history.
- **Integration evidence.**
  Constituent PR approvals and passing checks do not establish that their combined result works. Record a conflicting integration result and [Abort Review Merge](#abort-review-merge) without inventing a resolution.
- **Missing authority or environment.**
  Record the required observation when it needs an unavailable environment or an action outside existing authorization, and continue independent review work.

## Commands

### Fetch Pull Request

Save a PR, its changed files and its commits through REST.

```bash
gh api repos/{owner}/{repo}/pulls/950 > <record>/pr-950.json
gh api --paginate repos/{owner}/{repo}/pulls/950/files > <record>/pr-950-files.json
gh api --paginate repos/{owner}/{repo}/pulls/950/commits > <record>/pr-950-commits.json
```

### Fetch Requirements

Save an issue whose requirements the integration claims to deliver.

```bash
gh api repos/{owner}/{repo}/issues/950 > <record>/issue-950.json
```

### Fetch Branches

Refresh each named remote branch for revision capture.

```bash
git fetch <remote> <branch>
git rev-parse <remote>/<branch>
```

### Compare Revisions

Inspect the incoming change and the relationship to its current target.

- Use full captured SHAs after resolving branch names.
- A three-dot diff describes the incoming change; the proposed integration result supplies the combined behavior.

```bash
git merge-base <target-sha> <head-sha>
git diff --stat <target-sha>...<head-sha>
git diff <target-sha>...<head-sha>
git log --oneline <target-sha>..<head-sha>
```

### Create Review Worktree

Create a detached tree at a captured revision without moving an existing checkout.

```bash
git worktree add --detach <review-worktree> <sha>
```

### Prepare Integration Result

Combine a head with its current target inside a disposable review worktree.

- Start the worktree at the target SHA, using [Create Review Worktree](#create-review-worktree).
- A clean merge's tree SHA identifies the candidate alongside both parent SHAs. A conflict is evidence; preserve its details and abort without resolving it.
- Use a separate worktree per proposed result. Independently versioned products retain their own histories.

```bash
git -C <review-worktree> merge --no-commit --no-ff <head-sha>
git -C <review-worktree> write-tree
```

### Abort Review Merge

Return a disposable candidate to its captured target after recording a merge conflict.

```bash
git -C <review-worktree> merge --abort
```

### Read Captured File

Read a complete document, manifest or CI definition from a captured branch revision.

```bash
git show <sha>:<repo-relative-path>
```

### Read Captured Section

Read an anchored section from a captured branch revision.

- Locate the heading in the outline, then substitute the start and end lines required by the [linked-section rule](../SKILL.md#rules). Markdown code fences do not create document headings.

```bash
git show <sha>:<repo-relative-path> | rg -n '^#{1,6} '
git show <sha>:<repo-relative-path> | sed -n '<start-line>,<end-line>p'
```

### Fetch Check Evidence

Read checks and commit statuses, then the relevant Actions run and jobs.

- Run and job metadata identify the reported SHA; logs and artifacts establish separately checked-out dependency SHAs.
- Use the latest relevant attempts and retain their URLs. A success on another pairing leaves the candidate unmeasured.

```bash
gh api --paginate repos/{owner}/{repo}/commits/<sha>/check-runs
gh api repos/{owner}/{repo}/commits/<sha>/status
gh api repos/{owner}/{repo}/actions/runs/<run-id>
gh api --paginate repos/{owner}/{repo}/actions/runs/<run-id>/jobs
```

### Refresh Revisions

Compare current remote heads and PR metadata with the captured review subject.

```bash
git ls-remote <remote> refs/heads/<head> refs/heads/<target> refs/heads/<paired-branch>
gh api repos/{owner}/{repo}/pulls/950
```
