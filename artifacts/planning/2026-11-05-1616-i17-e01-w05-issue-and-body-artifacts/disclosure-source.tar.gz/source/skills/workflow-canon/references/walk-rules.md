# Walk Rules

These govern every walk of the canon's units, in each mode. The criterion applied on a hit is the entry's.

## Order

- **Entry-major.**
  One unit across the surface, paths recorded, then the next. A file-major walk drops later instances of an entry that already fired.
- **Compound headings.**
  - On a `## Rules` or I/O heading, apply each binding entry to each constraint on its own, before testing the heading whole.
  - The entry's Do not flag covers that constraint. A sound first sentence leaves the sibling clause still to test.

## Evidence

- **The construct.**
  A finding quotes or names the construct the entry's Detect keys on. Where that construct is the harness tool surface or a bootstrap resource, read that surface.
- **Identifiers.**
  Take an identifier at full length from its authority: [Resolve Ref](canon-context.md#resolve-ref), the registry, the resolved path.
- **Search hits.**
  - A search hit is a site. Read the construct around it, and cite that construct.
  - An empty search leaves open a construct the pattern did not name.
- **Probes.**
  Read a probe's field, label, id, and anchor back from the schema, the registry, or the catalog before reading the result.
- **Consumers.**
  A claim about what consumes a construct is settled at that consumer: the guard, the loader, or the call sites.
- **Forms.**
  Where an entry keys on a form, sweep the reference workflows before recording. Convention conformance decides a form the siblings carry.
- **Hand-checks.**
  - An empty hand-check is `blocked` until it has reported a case already in the corpus.
  - Take a set the entry names from that entry's wording.

## Candidates and Fixes

- **Falling candidates.**
  A candidate that falls identifies a correction to the entry's Do not flag or the guard's exemption surface. Apply that correction within authorized remediation; a review-only audit records it for Author.
- **Unread paths.**
  `unread` paths are outside the remediation scope.
  - An audit walks them under [Rules](audit-mode.md#rules).
- **Consumers of a Fix.**  Follow the entry's Fix through to the consumer it names.
- **Ledgers, fixtures and snapshots.**
  Edit the lines a ledger, fixture, or snapshot needs. The diff's size is the check.
