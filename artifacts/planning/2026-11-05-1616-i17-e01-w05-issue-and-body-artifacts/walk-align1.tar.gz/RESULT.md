# Standalone issue review

Reviewed only the complete supplied synthetic issue record, m2ux/workflow-server#99001. No live issue with this number was consulted. No network, tracker write, board change, source edit, worktree, commit, push, merge or agent spawn occurred.

## Body and metadata

- Mechanical finding: the original body puts Proposal (original-body.md:5) before Problem (original-body.md:10). The standalone template requires Overview, Problem, Proposal, Acceptance Criteria. corrected-body.md reorders those complete sections.
- Each section's contents, including the Problem, Proposal and AC1 wording, are byte-for-byte preserved. wording-preservation.json records the successful assertions. The local corrected snapshot retains title, labels, identity and state; AC1 stays unchecked.
- The title has a two-word name and four-word title-case subtitle, separated by a colon, with no planning prefix. The existing bug label fits the stated defect, and there is no type:* label. No metadata correction is proposed.
- The counted evidence is present: “A supplied report fixture contains one blocked candidate with no reason.” (original-body.md:13). Problem and Proposal use the required bold lead/body layout.
- Open Questions and References have no supplied content, so their omission is permitted. A standalone body needs no Work Breakdown.

## Criteria and content decisions

- AC1 states one observable end state: a report names missing status evidence, observed by the named queue fixture (original-body.md:17). It addresses the stated friction and uses the required criterion label and unchecked checkbox. The record establishes no subjective or contradictory wording requiring a content decision. No content decision is pending from this format/metadata review.
- The actual queue fixture, its path/command, implementation and execution evidence were not supplied. This review assesses the criterion's wording; it does not verify the outcome, execution-level feasibility or the fixture's coverage. Identifying an executable fixture is an evidence follow-up, not an authorized wording change. No acceptance tick is proposed.

## Proposed update

- Exact request metadata: proposed-request.json. Method PATCH, endpoint /repos/m2ux/workflow-server/issues/99001, interpreted solely as the supplied synthetic identity.
- Exact JSON body: issue-update-payload.json. It contains only the body field and references no live tracker state. It proposes no title, label or state write.
- Complete local correction: corrected-body.md. Reviewable difference: body.diff. Full local issue-shaped snapshot: corrected-issue.json.
- Publication is outside this run's authority. The payload was not sent. No live endpoint should be inferred to be a disposable fixture.

## Commands and limitations

- command-history.json gives the actual shell commands and outcomes in invocation order, grouping concurrent read batches. Individual checker outputs are in repositories-command.json, prepare-command.json, format-rerun-command.json and reference-visibility-command.json.
- The first wrapper attempt was rejected before execution because it used shell variable expansion. The literal retry failed before Python started because bwrap could not create a user namespace. The identical checker invoked with escalated execution still ran through the required sbx helper, with PYTHONPYCACHEPREFIX under this scratch directory, and returned exit 0: one section-order fix, no metadata or content finding.
- The corrected-snapshot rerun returned exit 0: 0 fixed, 0 to apply, 0 to decide. cmp confirmed the rerun body equals the proposed correction. The preparation script's preservation assertions passed.
- Reference extraction returned only the destination repository, m2ux/workflow-server; there are no References entries. No repository-visibility capture was supplied and network access is forbidden. repositories-unavailable.json is an intentionally empty array of fetched objects, not evidence of public visibility. The visibility checker correctly returned exit 1: destination repository visibility unavailable. Full alignment cannot be claimed while that evidence remains unavailable.
- Before any authorized publication in another context, refresh the intended issue identity/body and repository evidence, then read back the saved issue and rerun checks. Those operations were not attempted here.

## Actual reading account

- Actual tool calls returned the task, SKILL.md, Rules and Conventions, then the selected Align mode. The first full artifact batch returned Standalone Body, Task Body, Issue Body, Proposal Body, Review Finding and Goal Trace. Subsequent batches and sequential calls returned the other explicit Align prerequisites. Later reads loaded the artifact prerequisite closure before the final review. Invocation order and concurrency are preserved in command-history.json; this was not a topologically ordered prerequisite traversal, and no procedure from the unrelated prerequisite artifacts was executed.
- All 18 explicit Align prerequisite documents were returned in full. Their referenced artifact prerequisite closure was also returned: Lane, Delivery Plan, Planning Record, Work Item, Plan Change, Agent Review, Hot-fix, Hot-fix Body, Board, Board Delivery, Placement, Repository Labels and Board Queue. Planning Records configuration was read as a linked section; the command returned its next-heading delimiter but no following section content. Conditional board-creation prerequisites were inapplicable.
- One aggregate tool result truncated Epic Issue Body even though tee saved the complete file. A subsequent dedicated cat returned all 566 lines from that receipt; the truncated retrieval was recovered. No other tool output reported truncation. No required document retrieval remains incomplete.
- read-receipts.json inventories the saved receipt bytes, line counts and hashes. These files are captured bytes, not by themselves proof that the model received the text. command-history.json distinguishes full contents returned by tool calls, prerequisite-prefix reads, count/index-only reads, saved-only copies and the truncated/recovered retrieval. The task and SKILL.md saved-only copies duplicate content actually returned earlier. read-format-index.txt is selected script lines, not a full-script read.

Stopped before publication with the requested correction and exact payload prepared.
