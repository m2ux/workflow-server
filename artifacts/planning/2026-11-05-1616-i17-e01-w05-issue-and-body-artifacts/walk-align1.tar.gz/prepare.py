import difflib
import hashlib
import json
import re
from pathlib import Path

root = Path('/tmp/w05-walk-v4-align1')
source = Path('/tmp/i17-e01-w05/disclosure-v4/inputs/standalone-fixture.json')
issue = json.loads(source.read_text())
original = issue['body']
corrected = (root / 'corrected-body.md').read_text()

def sections(text):
    return dict(re.findall(r'(?ms)^## ([^\n]+)\n(.*?)(?=^## |\Z)', text))

before = sections(original)
after = sections(corrected)
assert before == after, 'Section contents differ'
assert list(after) == ['Overview', 'Problem', 'Proposal', 'Acceptance Criteria']
assert issue['title'] == 'Queue Diagnostics: Explain Missing Status Evidence'
assert issue['labels'] == ['bug']
assert '- [ ] **AC1.**' in corrected
(root / 'original-body.md').write_text(original)
snapshot = dict(issue, body=corrected)
(root / 'corrected-issue.json').write_text(json.dumps(snapshot, indent=2) + '\n')
(root / 'issue-update-payload.json').write_text(json.dumps({'body': corrected}, indent=2) + '\n')
(root / 'proposed-request.json').write_text(json.dumps({
    'method': 'PATCH',
    'endpoint': '/repos/m2ux/workflow-server/issues/99001',
    'payload_file': str(root / 'issue-update-payload.json'),
    'status': 'proposed only; synthetic fixture; not sent',
}, indent=2) + '\n')
(root / 'body.diff').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), corrected.splitlines(keepends=True),
    fromfile='supplied-body.md', tofile='corrected-body.md')))
(root / 'repositories-unavailable.json').write_text('[]\n')
(root / 'wording-preservation.json').write_text(json.dumps({
    'passed': True,
    'assertions': ['All section contents are byte-for-byte equal',
                   'Section order matches standalone template',
                   'Title and labels retained in local issue snapshot',
                   'AC1 remains unchecked',
                   'Proposed API payload contains only body'],
    'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'corrected_body_sha256': hashlib.sha256(corrected.encode()).hexdigest(),
}, indent=2) + '\n')
reads = []
for path in sorted(root.glob('read-*')):
    data = path.read_bytes()
    reads.append({'receipt': str(path), 'bytes': len(data),
                  'lines': len(data.splitlines()), 'sha256': hashlib.sha256(data).hexdigest()})
(root / 'read-receipts.json').write_text(json.dumps(reads, indent=2) + '\n')
print('Prepared body, body-only update payload, request envelope, diff, snapshots and read receipts.')
print('Wording-preservation assertions: PASS')
