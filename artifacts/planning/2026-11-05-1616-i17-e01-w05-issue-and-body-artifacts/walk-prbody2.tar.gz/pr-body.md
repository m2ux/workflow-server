## Overview

Queue reports identify the affected candidate and the missing board Status field when status is unreadable, giving reviewers the evidence behind a blocked selection.

## Changes

Queue diagnostics explain the incomplete status evidence that prevents a candidate from starting.

### Queue Diagnostics

- **Name the affected candidate.**
  An unreadable-status report identifies the candidate whose board evidence is incomplete.
- **Identify the missing field.**
  The report names the missing board Status field as the reason the candidate cannot start.

## Test Plan

| Test | Description | Coverage | Pass |
| --- | --- | --- | --- |
| T1 | Queue fixture: unreadable status names the candidate and missing field. | AC1 | |

## Open Questions

- T1 is supplied as a passing local run at synthetic revision `1111111111111111111111111111111111111111`. Its [purported published result](https://github.com/m2ux/workflow-server/blob/engineering/artifacts/planning/example/validation.md#queue-fixture) has no supplied page contents. Confirm reader access, the section, tested revision and observations before recording a passing result.
