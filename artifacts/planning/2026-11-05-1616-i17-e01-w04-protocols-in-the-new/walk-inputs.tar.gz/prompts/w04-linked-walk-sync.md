Use Work Planner from `/tmp/w04-linked-walk-source/skills/work-planner/SKILL.md` for this bounded sync rehearsal. The source identity is `/tmp/w04-linked-walk-source/IDENTITY.txt`; read source instructions from that captured tree.

Request: Sync the supplied epic against its captured task merge and integration pull request. Determine what can be recorded, whether any issue is eligible to close, and what would be required for the epic's review and integration. Return the ordered procedure and the first missing evidence for each requested result.

Captured inputs:
- Repository m2ux/workflow-server, epic1616 in `/tmp/w04-linked-walk-source/captured/epic.json`.
- Merged task pull request1642 in `/tmp/w04-linked-walk-source/captured/merged-pr.json`.
- Draft integration1641 in `/tmp/w04-linked-walk-source/captured/integration-pr.json`.
- Project checkout `/home/mike1/projects/dev/workflow-server`, epic-base checkout `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/workspace`, branch i17/e01/workspace targeting workspace, engineering checkout `/home/mike1/projects/dev/workflow-server/.engineering`.
- Board users/m2ux/projectsV2/17, Status422017304, epic item291152098. Repository auto-close is confirmed disabled.
- No complete live Development-link snapshot, fresh criterion-verification record or independent agent-review evidence is supplied.

Authority: This is read-only. Do not post, save, link, merge, close, change a board, dispatch another agent, modify source or write repository artifacts. Local temporary scratch under `/tmp` is permitted. Inspect captured inputs and source instructions. Describe operations requiring external writes and stop before executing them. Do not treat a captured record as fresh live closure/merge evidence.

Report the bounded result, evidence gaps and actual files/sections read. Keep a plain read log in temporary scratch if useful, with read ranges and truncation/recovery when they occur. Use the available read tools normally; there is no preferred retrieval strategy.
