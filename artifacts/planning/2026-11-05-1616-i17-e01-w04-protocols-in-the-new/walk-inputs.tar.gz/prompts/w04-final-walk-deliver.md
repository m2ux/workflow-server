Use Work Planner from `/tmp/w04-final-walk-source/skills/work-planner/SKILL.md` for this bounded delivery rehearsal. The source identity is `/tmp/w04-final-walk-source/IDENTITY.txt`; read source instructions from that captured tree.

Request: A task pull request has merged. Determine how its completed unit is recorded and how the retained preparation is checked before delivery can resume. Use the captured records below, explain the next operations in order and their required inputs, and identify the first unavailable evidence or permission boundary. Do not infer that the epic is complete.

Captured inputs:
- Repository m2ux/workflow-server, project checkout `/home/mike1/projects/dev/workflow-server` and engineering checkout `/home/mike1/projects/dev/workflow-server/.engineering`.
- Board users/m2ux/projectsV2/17, Status422017304, epic item291152098; captured epic `/tmp/w04-final-walk-source/captured/epic.json`.
- Confirmed merged task pull request1642, captured `/tmp/w04-final-walk-source/captured/merged-pr.json`; draft integration1641, captured `/tmp/w04-final-walk-source/captured/integration-pr.json`.
- The repository's auto-close setting is confirmed disabled. No task issue exists for W02 or W04.
- Retained preparation: epic1616/W04, record `artifacts/planning/2026-11-05-1616-i17-e01-w04-protocols-in-the-new`, branch i17/e01/w04-protocols-in-the-new, base i17/e01/workspace, unit checkout `/home/mike1/projects/dev/workflow-server/.worktrees/i17/e01/w04-protocols-in-the-new`. The captured epic body records its reservation. The worker procedure and fresh board/readiness snapshot are not supplied.

Authority: This is read-only. Do not post, save, link, merge, close, change a board, dispatch another agent, modify source or write repository artifacts. Local temporary scratch under `/tmp` is permitted. You may inspect captured inputs and source instructions. Describe operations requiring external writes and stop before executing them. Do not treat a captured record as fresh live closure/merge evidence.

Report the bounded result, evidence gaps and actual files/sections read. Keep a plain read log in temporary scratch if useful, with read ranges and truncation/recovery when they occur. Use the available read tools normally; there is no preferred retrieval strategy.
