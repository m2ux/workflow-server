# Bounded reviewer outline — m2ux/workflow-server#1642

This is a metadata-grounded outline and procedure account, not a measured or published architecture overview. The read-only rehearsal stops before repository preparation, indexing and publication.

## Captured identity and scope

- PR: https://github.com/m2ux/workflow-server/pull/1642
- Title: `[I17:E01] Common Files: Rules, Conventions and Configuration`.
- Captured state: closed, merged at `2026-11-05T09:23:37Z`.
- Captured head: `83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2`, branch `i17/e01/w02-rules-conventions-and-configuration`.
- Captured base: `i17/e01/workspace`, SHA `dd44528b3fdea032c4128e1e0f638d038261498a`.
- Captured merge commit: `238b652aaa52057f66c86c9651c379296a7ba5b2`.
- Instruction snapshot identity: base `238b652aaa52057f66c86c9651c379296a7ba5b2`; manifest SHA256 `fd0ad01dcc101d42d6eab4c32192f4140805d52c06db9db06834bd7be09e400c`.
- Metadata reports 10 changed files, 108 additions and 70 deletions. These counts do not supply changed paths, a reviewed diff, graph evidence or current freshness.

The instruction snapshot's base is the captured merge commit, not the captured PR head. Neither identity establishes a current live review checkout or index.

## Outline a reviewer could develop

### Summary

The captured PR body says Work Planner selects modes after loading separate Rules and Conventions documents, while deployment configuration has linked homes. It describes conditional routes for proposal selection, board creation and omitted reporting starts. These are attributed body claims; this rehearsal does not independently validate the diff, preservation or test results.

### Structure

- **Entry point:** the captured `skills/work-planner/SKILL.md` requires Rules and Conventions before mode selection and lists modes and dependencies.
- **Common context:** `rules.md` defines linked reads, decisions, layers and execution; `conventions.md` defines session, repository, checkout, body, script and board conventions.
- **Configuration:** the captured Planning Records section locates records at `artifacts/planning/` on `engineering`. Other configuration contents were not read here.
- **Consumers:** the PR body names guideline and checkout-vocabulary-test consumers. Their precise changed paths and implementation are not supplied by the metadata.

A final component diagram needs measured areas and edges. Directory groupings alone cannot supply them.

### Behaviour

Candidate subjects are common-context loading and the conditional configuration routes described in the PR body. A final sequence diagram for each measured flow needs ordered `process_symbols` with `step_index`, files and lines. This account supplies no inferred call order or functional diagram.

### What Changed

Use the body claims as questions to verify at the reviewed head: operative rules and conventions load before selection; deployed values have linked homes; each conditional consumer reaches the applicable section. Link the PR's Changes section rather than duplicate its complete listing.

### Reading Order

Candidate order, pending changed-path and diff verification: `SKILL.md`, `rules.md`, `conventions.md`, relevant `configuration.md` sections, then the actual consuming references and tests. The final reading order must select relevant changed files, start at the entry point and move outward. Each entry needs a head-pinned permalink and line anchors; no line anchors are established here.

### Risks and Watch Points

- Confirm preservation of operative conditions, command bodies and model declarations against the actual diff.
- Verify conditional reads, not just the existence of linked homes.
- Keep the body-disclosed limitations visible: inherited prerequisite fanout, snapshot-only freshness, graph-tool gaps and broader board-setup reads. The linked validation record was not read, so its results remain attributed claims.

## Exact required procedure and recovery

The selected route is Understand → Change Overview. Reading a procedure does not authorize executing its writes.

1. **Read current PR state in the project checkout.** Before the first `gh` call, follow the session credential convention. Save the complete `gh api repos/m2ux/workflow-server/pulls/1642` response in temporary scratch; retain identity, title, base and verified head. The captured JSON is not a substitute for this freshness evidence. Request changed paths with paginated `gh api repos/m2ux/workflow-server/pulls/1642/files --jq '.[].filename'` when the protocol reaches its matching-head branch.
2. **Prepare matching review evidence.** In `/home/mike1/projects/dev/workflow-server`, the authorized full procedure would run `git fetch origin pull/1642/head`, resolve `FETCH_HEAD^{commit}` and compare it with the verified head. A mismatch returns a changed-head finding before worktree creation. Read current PR state again and retry with its new verified head.
3. **Select the detached review worktree.** The normal path is the project's `.worktrees/pr/1642`. An existing worktree is reusable only if `HEAD` matches the verified head and `git status --porcelain --branch` proves detached HEAD and no tracked or untracked changes. Preserve any other worktree and select an unused path suffixed with the verified commit. For an unused path, the full procedure uses `git worktree add --detach <path> <verified-head>` and confirms its HEAD. Fetching and worktree creation are not executed here.
4. **Measure only the matching review checkout.** Run every graph command there: `gitnexus status`; if unindexed or behind, `gitnexus analyze`, then confirm freshness; `gitnexus detect-changes --scope compare --base-ref '<verified-base-branch>'`; `gitnexus context '<symbol-identity>'` for every changed symbol; `gitnexus query --query '<flow-identity>' --limit 1` for every reported flow. Do not substitute the default branch or branch-wide history for the PR's supplied base.
5. **Recover stale evidence.** Inspect every graph response's JSON `staleness` block. Discard measurements from a behind index, reindex and repeat affected measurements. Change Overview repeats Measure Repository Change after the index update. On a changed revision, reread PR state and rebuild worktree evidence. Return unresolved freshness blockers before writing an overview.
6. **Locate and populate one record, only after freshness is resolved.** Search for an existing overview record for PR 1642 before choosing a new identity. Reuse its folder identity and preserve its other content. Otherwise use `artifacts/planning/<opening-date>-1642-<title-slug>/` on the existing engineering worktree, not another engineering checkout. Populate README and `architecture-overview.md` from their templates.
7. **Populate from measurements.** Include Summary (at most three sentences), Structure, Behaviour, What Changed and Reading Order; delete empty optional sections. Target about 200 lines including diagrams. Carry structural and functional diagrams: measured component areas and dependencies, or a class diagram for an appropriate one-area type change; one sequence per measured flow. Further diagrams depend on the actual change. Use 5–10 elements per concept, labelled directional edges, consistent names and fills, changed elements distinct and untouched context grey. Pin every code link to the verified PR head with line anchors.
8. **Register, publish, link and read back.** Register the overview as its Artifacts row and the PR under README Links. Publish Planning Record through the existing engineering worktree: locate it; stage/commit the procedure's pending worktree content, fetch engineering, rebase and plain push; report conflicts and confirm this record's files reached `origin/engineering`. Only after its URL resolves, apply Link Architecture Overview to the current complete PR body. Preserve any existing overview row and other body content, including the captured Delivery record reference. Publish the returned complete body with `gh api --method PATCH repos/m2ux/workflow-server/pulls/1642 -F body=@<body-file>` and reread PR state. Return PR, record folder, published overview, diagrams and its References row.

## What prevents a complete published overview

- No current PR/head verification, detached review checkout, changed-path list, inspected diff, fresh index, symbol contexts or ordered graph traces is supplied or produced.
- No existing overview record was located or inspected. Absence was not established; a new record identity must not be assumed.
- No head-pinned code links or measured diagrams can be populated from the captured metadata alone.
- Authority forbids git mutation (including fetching), checkout/index creation, repository artifacts, engineering publication and PR-body writes. All such operations above are descriptions only.
- Source-prerequisite traversal is partial and its read order has deviations, documented in `account.md`. This is not a claim of full Work Planner execution or full prerequisite compliance.

Only temporary scratch was written. No PR, board, issue, checkout, index or repository artifact was changed.
