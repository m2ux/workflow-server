import json
from pathlib import Path
import shlex

root = Path('/tmp/w04-linked-deliver-walk1')
rows = [json.loads(line) for line in (root / 'reads/reads.jsonl').read_text().splitlines()]
base = '/tmp/w04-linked-walk-source/'
launcher = '/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py'
text = '''# Reading account

## Identity and boundary

The immutable source identifies base `238b652aaa52057f66c86c9651c379296a7ba5b2` and snapshot manifest SHA256 `fd0ad01dcc101d42d6eab4c32192f4140805d52c06db9db06834bd7be09e400c`. The task prompt is `/tmp/w04-linked-walk-deliver.md`. Only this source tree and supplied captured inputs were used for conclusions. No memory, sibling walk, other agent findings or live repository/service state was consulted.

Scratch result: `result.md`. Other commands/reads and initial launcher failures: `other-reads.txt`. Source retrieval metadata and stored emissions: `reads/reads.jsonl` plus its named `read-*.txt` files. All successful source-document retrievals ran through the required helper and absolute md-composer `scripts/sbx`, with escalation needed because unprivileged bubblewrap namespace creation failed. Escalation succeeded; no automatic approval rejection remained unresolved.

No protocol was executed. No source, repository, git, remote, board or dispatch state was changed. Scratch files under this directory are the only writes. This is an explanatory rehearsal with partial prerequisite disclosure, not a complete workflow run.

## Receipt and truncation

- The first four-source batch submitted Deliver, epic, merged PR and integration PR concurrently. The helper's persisted completion/emission order was integration PR, merged PR, epic, Deliver (entries 5–8 below); source-read start order is not observable. All other source calls were sequential.
- That batch exceeded the outer functions.exec output budget: original output was reported as 18,207 tokens, with a truncation marker covering 8,207 tokens in the middle. The Deliver text and integration PR text were visibly received; raw epic/merged-PR receipt was incomplete. Stored full emissions are not counted as full model receipt.
- Entries 9 and 10 recover all epic/merged-PR fields used in this result through the same helper, piped through jq. The helper again stored each whole one-line JSON emission; the model received only the selected jq fields. Unselected user/repository/API metadata was not recovered or used.
- No other tool output reported truncation. Required selected sections were received with their complete subsections, stopping before the next equal/higher heading. No stored read-*.txt content was reopened.

## Prerequisite coverage and unused reads

Rules and Conventions were read before mode selection. Deliver and the selected protocols were read as documents to explain the route; none was invoked. Pull Request, Delivery Branches, Planning Record and Pull Request Body prerequisite blocks were read before their selected operation/field sections, and their listed prerequisite documents were loaded as shown below. Board Delivery was read only for its prerequisite block; its operation was not retrieved. Delivery Plan's Work Units section was read after its prerequisite block, but Lane and Hot-fix Body were not subsequently loaded. The full Deliver/Task Merge/Unit Dispatch prerequisite closure was not loaded; this is a disclosed limit, not a claim that all skill reading requirements were satisfied for execution.

The Deliver implementation/debt/arising-issues paths, hot-fix operations, task-issue closure detail, most issue/issue-body operations and most epic planning commands were retrieved but not needed for this W02/W04 decision. These broad whole-file reads were prerequisite/context overhead. Configuration was read whole although only Planning Records was needed. Issue Closure was used only to distinguish a nonexistent task issue and the later conditional epic gate. The two whole JSON rereads were recovery; other selected windows do not repeat their prerequisite blocks. There is no performance comparison, timing claim or complete-workflow claim.

## Actual emission order and ranges

The following table copies this run's helper log order. Paths are relative to the immutable source root. A null heading means the whole file was emitted. For entries 5–8, read the receipt qualifications above. For entries 9–10, the table describes the stored emission; jq receipt is narrower.

| # | Source | Heading | Lines |
| --- | --- | --- | --- |
'''
for i, row in enumerate(rows, 1):
    path = row['source'].removeprefix(base)
    heading = row['heading'] or '(whole file)'
    text += f"| {i} | `{path}` | {heading} | {row['start_line']}–{row['end_line']} |\n"
text += '\n## Source commands\n\nAll commands used cwd `/home/mike1/projects/dev/md-composer`; successful source reads used `require_escalated`. Commands are listed in helper emission order, with the concurrent exception described above.\n\n```bash\n'
for i, row in enumerate(rows, 1):
    cmd = launcher + ' --log /tmp/w04-linked-deliver-walk1/reads'
    if row['heading']:
        cmd += ' --heading ' + shlex.quote(row['heading'])
    cmd += ' ' + shlex.quote(row['source'])
    if i == 9:
        cmd += " | jq '{number,title,state,body}'"
    if i == 10:
        cmd += " | jq '{number,title,state,body,merged,merged_at,merge_commit_sha,head:{ref:.head.ref,sha:.head.sha},base:{ref:.base.ref,sha:.base.sha}}'"
    text += f'# {i}\n{cmd}\n'
text += '''```

## Correctness and remaining limits

- W02 already has its captured PR link, Done tick and AC2 tick; recording must preserve that state and establish current evidence, rather than invent a missing task issue or assert that a write is necessary.
- Integration #1641 is already a draft and already cites #1642. Its current body and actual merges must be compared before any update; no handoff or epic closure follows merely from W02's merge.
- W04 is a singleton row with W02 dependency and AC4 coverage. Captured reservation is neither current admission nor observed execution. The supplied worker procedure, run-owned complete preparation, live hold, remote publication and harness readiness remain unverified.
- Create Task Worktree exposes a creation command with `-b`; the read source does not establish successful reuse of an existing prepared branch/worktree. No such reuse was tested or claimed.
- The first unavailable recording evidence and first conditional external write are identified at the start of result.md. All later operations there are descriptions, not actions taken. No completeness, live readiness or performance result is claimed.
'''
(root / 'account.md').write_text(text)
print(f'Wrote account.md with {len(rows)} source emission entries; stored emitted characters: {sum(r["characters"] for r in rows)} (not a received-context count).')
