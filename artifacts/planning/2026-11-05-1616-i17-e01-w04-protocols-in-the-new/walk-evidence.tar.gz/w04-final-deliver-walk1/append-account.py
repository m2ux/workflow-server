import json
from pathlib import Path

root = Path('/tmp/w04-final-deliver-walk1')
reads = [json.loads(line) for line in (root / 'reads/reads.jsonl').read_text().splitlines()]
with (root / 'account.md').open('a') as output:
    output.write('| Order | Source | Heading | Lines | Emitted receipt |\n| --- | --- | --- | --- | --- |\n')
    for index, receipt in enumerate(reads, 1):
        path = Path(receipt['source']).relative_to('/tmp/w04-final-walk-source')
        output.write(f"| {index} | {path} | {receipt['heading'] or 'whole'} | {receipt['start_line']}-{receipt['end_line']} | {Path(receipt['returned_file']).name} |\n")
with (root / 'other-reads.txt').open('a') as output:
    output.write('9. Report generation: heredoc rejected pre-execution for literal backticks; inline account Python rejected pre-execution for missing sbx. Recovery writes result/account with apply_patch and runs local append-account.py through sbx.\n')
    output.write('10. append-account.py reads reads/reads.jsonl to append exact chronological source/heading/range receipt table to account.md; no additional source or other walk read.\n')
print(f'Appended {len(reads)} successful capture receipts, not a count of fully received documents.')
