import json
from pathlib import Path

root = Path('/tmp/w04-linked-sync-walk2')
records = [json.loads(line) for line in (root / 'reads/reads.jsonl').read_text().splitlines()]
rows = ['\n| Source | Selected section | Lines | Emitted characters |', '| --- | --- | --- | --- |']
for record in records:
    path = Path(record['source']).relative_to('/tmp/w04-linked-walk-source')
    section = record['heading'] or 'Whole'
    rows.append(f"| `{path}` | {section} | {record['start_line']}–{record['end_line']} | {record['characters']} |")
rows.append(f"\nSuccessful source emissions: {len(records)}; characters saved: {sum(record['characters'] for record in records)}. These are emission counts, not token counts or a measure of actual receipt.\n")
with (root / 'account.md').open('a') as output:
    output.write('\n'.join(rows))
print(f'Appended {len(records)} source-read receipts to account.md')
