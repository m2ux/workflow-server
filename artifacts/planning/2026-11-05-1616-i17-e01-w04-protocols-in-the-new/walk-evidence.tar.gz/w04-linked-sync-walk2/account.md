# Read and correctness account

## Scope and authority

- Prompt: `/tmp/w04-linked-walk-sync.md`; result: `result.md` in this directory.
- Source documents and three supplied JSON inputs came only from `/tmp/w04-linked-walk-source`. No memory, other agent output, live checkout, git or remote evidence was consulted.
- Successful source reads ran through the requested neutral reader and `md-composer/scripts/sbx`, logging under this directory. Only temporary scratch was written. No procedure that mutates source, git, tracker, board, planning branch, or PR was executed.
- The snapshot identity was read; the manifest itself was not independently verified. This is a bounded procedure rehearsal, not execution of Sync, Issue Closure, Change Overview or Epic Integration.

## Correctness and gaps

- The conclusion separates captured merge evidence, existing ticks/Done, new criterion verification, review readiness and completed integration. #1641 is treated as an integration PR and never matched to a task.
- #1640 is linked but absent. No complete Development-link relation exists in the inputs; empty/absent links were never invented. PR-side recording snapshots and issue-side fresh closure snapshots are distinct requirements.
- The actual W02 delivery is already present in the epic capture; no new row, task issue or body/link write is inferred. The supplied confirmed-disabled auto-close setting is accepted for the session.
- No issue is established eligible to close. #1616 visibly lacks six delivered rows/criteria and its integration is unmerged. An actual task issue was not supplied. Fresh criterion records, complete expected bases and merges, current agent review, graph measurements, board state/options/assignee, target rules/checks/reviews and write authority remain missing where the result names them.
- Review Record defines current head/base evidence, findings and publication; it does not itself add an independence rule. The prompt's absent independent review is not replaced with a self-declared review or an invented stricter source requirement.
- The ordered result describes the required write boundaries but does not execute them. The named live checkout paths are supplied identities only. No future command is reported as run.

## Truncation and receipt

- Source emissions were saved before stdout returned. `reads.jsonl` proves those emissions and their ranges; it does not prove the model received every byte.
- Initial six-document batch emitted Rules, Conventions, Sync and three JSON inputs. Aggregate tool output was truncated (reported 18,894 original tokens). Rules/Conventions were received; Sync's tail and relevant JSON fields required recovery. Sync lines 145–193 were recovered from the saved emission. Selected JSON fields, including all three bodies and relevant state/head/base data, were recovered by parsing saved emissions into a bounded display. A further jq recovery supplied #1642's exact merge commit. Unneeded API metadata was not recovered, and full raw JSON receipt is not claimed.
- A later long prerequisite batch saved outputs in functions storage and reader logs, but aggregate output truncated/hid the epic-body tail and eight further documents. The nine affected outputs were re-emitted individually or as small complete pairs through functions load. Full text was then received for epic-issue-body, initiative-issue-body, board, work-item, Understand, board-delivery, issue-closure, review-pull-request and epic-integration. Successful source commands were not repeated for that recovery.
- All other displayed document emissions were received without reported truncation. The exact retained source emissions remain in `reads/`. This account does not infer receipt from save success alone.

## Retrieval choices and limitations

- Common Rules and Conventions were read before mode selection. Sync explicitly names whole-file prerequisites, so the run loaded those and followed their unconditional prerequisite graph. This reached lane/dependency, delivery-plan, hot-fix, placement and label contracts that did not materially change this epic's bounded conclusion. They are inherited prerequisite fanout, not evidence that those workflows ran.
- Understand was read as a Sync prerequisite document. Its own Change Overview prerequisite was loaded because Epic Integration separately requires that protocol; Understand itself was not run. Proposals/theme-board configuration was not loaded because no board selection/creation path applied. Planning Records was read as an exact heading section only.
- Whole-document prerequisites were discovered by reading their containing documents; nested prerequisites were completed afterward, before any artifact operation. Thus this is not proof of strict prerequisite-before-dependent-section receipt order. No operation ran with incomplete prerequisites.
- The all-file filename inventory was broader than necessary to locate the task's source documents. The six-document and long-prerequisite output batches were unnecessarily broad and caused recoverable output loss. Smaller bounded displays would have avoided that recovery.
- Existing same-revision document prerequisites were reused rather than reread. Recovery re-emitted saved text and repeated no successful neutral source retrieval. Initial IDENTITY/SKILL attempts failed before reading; their successful retries are logged separately in other-reads.txt.
- No timing benchmark, comparative read-cost result, complete-workflow disclosure, live-freshness claim or performance conclusion follows from this rehearsal.

## Actual reads and commands

The table below is generated from successful neutral-reader receipts, in their append order. All paths are relative to `/tmp/w04-linked-walk-source`; full paths and emitted-file names are retained in `reads/reads.jsonl`. Whole means the reader selected the complete document. Commands and non-source recovery reads are recorded in `other-reads.txt`.

| Source | Selected section | Lines | Emitted characters |
| --- | --- | --- | --- |
| `IDENTITY.txt` | Whole | 1–2 | 142 |
| `skills/work-planner/SKILL.md` | Whole | 1–81 | 4466 |
| `skills/work-planner/rules.md` | Whole | 1–10 | 1515 |
| `captured/epic.json` | Whole | 1–1 | 12631 |
| `skills/work-planner/modes/sync-mode.md` | Whole | 1–193 | 16976 |
| `captured/merged-pr.json` | Whole | 1–1 | 19758 |
| `captured/integration-pr.json` | Whole | 1–1 | 17860 |
| `skills/work-planner/conventions.md` | Whole | 1–29 | 2531 |
| `skills/work-planner/artifacts/issue.md` | Whole | 1–531 | 22268 |
| `skills/work-planner/artifacts/issue-body.md` | Whole | 1–265 | 12740 |
| `skills/work-planner/artifacts/acceptance-criteria.md` | Whole | 1–86 | 5804 |
| `skills/work-planner/artifacts/task-body.md` | Whole | 1–92 | 3182 |
| `skills/work-planner/artifacts/pull-request.md` | Whole | 1–700 | 33393 |
| `skills/work-planner/artifacts/delivery-evidence.md` | Whole | 1–46 | 3132 |
| `skills/work-planner/artifacts/epic.md` | Whole | 1–116 | 9914 |
| `skills/work-planner/artifacts/epic-issue-body.md` | Whole | 1–369 | 25922 |
| `skills/work-planner/artifacts/initiative-issue-body.md` | Whole | 1–250 | 13168 |
| `skills/work-planner/artifacts/board.md` | Whole | 1–339 | 12361 |
| `skills/work-planner/artifacts/work-item.md` | Whole | 1–74 | 3122 |
| `skills/work-planner/modes/understand-mode.md` | Whole | 1–33 | 1306 |
| `skills/work-planner/artifacts/board-delivery.md` | Whole | 1–141 | 10642 |
| `skills/work-planner/protocols/issue-closure.md` | Whole | 1–71 | 2981 |
| `skills/work-planner/protocols/review-pull-request.md` | Whole | 1–58 | 3277 |
| `skills/work-planner/protocols/epic-integration.md` | Whole | 1–63 | 5456 |
| `skills/work-planner/artifacts/plan-change.md` | Whole | 1–66 | 3101 |
| `skills/work-planner/references/requirement-characteristics.md` | Whole | 1–59 | 2848 |
| `skills/work-planner/artifacts/delivery-branches.md` | Whole | 1–436 | 19020 |
| `skills/work-planner/artifacts/agent-review.md` | Whole | 1–45 | 3685 |
| `skills/work-planner/protocols/change-overview.md` | Whole | 1–66 | 3592 |
| `skills/work-planner/artifacts/pull-request-body.md` | Whole | 1–153 | 8544 |
| `skills/work-planner/artifacts/planning-record.md` | Whole | 1–159 | 5943 |
| `skills/work-planner/artifacts/architecture-overview.md` | Whole | 1–165 | 5955 |
| `skills/work-planner/artifacts/repository-graph.md` | Whole | 1–128 | 3684 |
| `skills/work-planner/artifacts/lane.md` | Whole | 1–109 | 4135 |
| `skills/work-planner/artifacts/dependency-graph.md` | Whole | 1–178 | 13637 |
| `skills/work-planner/artifacts/delivery-plan.md` | Whole | 1–90 | 8530 |
| `skills/work-planner/artifacts/board-queue.md` | Whole | 1–163 | 13171 |
| `skills/work-planner/artifacts/initiative.md` | Whole | 1–38 | 2497 |
| `skills/work-planner/artifacts/hotfix-body.md` | Whole | 1–61 | 2370 |
| `skills/work-planner/artifacts/hotfix.md` | Whole | 1–132 | 7791 |
| `skills/work-planner/artifacts/repository-labels.md` | Whole | 1–44 | 1189 |
| `skills/work-planner/artifacts/standalone-body.md` | Whole | 1–71 | 2002 |
| `skills/work-planner/artifacts/placement.md` | Whole | 1–160 | 9750 |
| `skills/work-planner/configuration.md` | Planning Records | 27–30 | 101 |

Successful source emissions: 44; characters saved: 366092. These are emission counts, not token counts or a measure of actual receipt.
