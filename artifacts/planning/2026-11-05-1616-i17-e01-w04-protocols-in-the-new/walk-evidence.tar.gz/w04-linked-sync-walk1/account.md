# Rehearsal account

## Scope and actual route

I used the captured Work Planner skill for a bounded read-only Sync rehearsal of epic #1616, merged task #1642 and integration #1641. The identity file reports source base `238b652aaa52057f66c86c9651c379296a7ba5b2` and manifest SHA256 `fd0ad01dcc101d42d6eab4c32192f4140805d52c06db9db06834bd7be09e400c`. I did not independently hash the source manifest or compare it to a checkout.

All successful source-document reads used this command form, with the actual path substituted and the one selected heading shown in the inventory:

```text
/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w04-linked-sync-walk1/reads <source-path> [--heading <exact-title>]
```

The commands were invoked as `scripts/sbx` from `/home/mike1/projects/dev/md-composer`, resolving to that absolute sandbox path. Two initial calls, for IDENTITY.txt and SKILL.md, failed before source receipt with the bubblewrap non-privileged-namespace error. Both were retried with `sandbox_permissions=require_escalated`; those and all subsequent helper invocations passed. No automatic approval review rejected an action. Escalation did not change the read-only task scope: helper writes stayed in this scratch directory.

I read Rules and Conventions before selecting Sync. Sync's entire explicit prerequisite list was read, including Understand as a document; reading it did not run Understand. I then read additional artifact/protocol prerequisites needed to describe review, integration and closure. I did not execute any protocol or artifact operation, inspect a diff, run a criterion instrument, create a worktree, fetch branches or call the tracker. Source inspection here establishes the required procedure; it does not establish any real workflow's success.

The whole-document prerequisite fanout included unrelated operations. I did not finish the entire transitive prerequisite graph of every unused operation: Initiative, Hot-fix Body, Placement, Repository Labels, Board Queue, Repository Graph and Architecture Overview remain unloaded. No operation depending on them was executed. For an authorized run that reaches those operations, load their prerequisites first. Some newly discovered prerequisites were loaded after their parent document (for example Requirement Characteristics after Issue Body, and Planning Records configuration after Planning Record), before any operation could execute; this is actual retrieval order, not a claim of strict dependency-first reading. Rules' explicit linked-section behavior was used for Planning Records only; no mode named as a prerequisite was recursively run.

## Receipt, truncation and recovery

- The helper saves an exact emission and a JSON-lines ledger entry before printing. Its saved file is evidence of what was emitted, not proof that the whole text reached the model.
- One functions.exec grouped Sync plus all three captured JSON inputs. Their nested tool caps were 14000, 7000, 5000 and 5000 tokens, but the outer default output cap yielded a warning: original aggregate 17715 tokens, with 7715 tokens omitted. Sync was visible in full and the integration JSON was visible in full; the middle epic/task JSON records were cut. I do not claim full initial receipt of those two records despite their complete saved emissions.
- Required epic and task-PR fields, including their complete bodies, were recovered with the jq projections listed in other-reads.txt. Those projections returned untruncated. The remaining omitted account/repository metadata in the full JSON was unnecessary for this task and was not recovered. Integration was projected again for concise assessment; this was a repeated read of its saved emission, not a new source fetch.
- Every later source read was printed in its own functions.exec response, with tool caps larger than its reported output. No other truncation warning occurred. All required source procedure text used in the result was received. I did not estimate input-token savings, elapsed-time improvement or full-workflow efficiency from saved bytes or returned-token counts.

## Correctness, evidence and authority

The result distinguishes already-recorded captured W02/AC2/Done from a new saved result, row delivery from task-issue closure, and epic readiness from epic completion. It does not classify #1641 as a task delivery, infer integration from its non-null merge_commit_sha, infer Development links from body references, treat missing links as empty, or treat a task-merge Test Plan claim as fresh independent criterion verification. The supplied auto-close-disabled confirmation is reused without elevating it into merge or closure authority.

No issue is proven eligible to close. W03–W08 and AC3–AC8 are visibly incomplete, and integration is explicitly unmerged. Task issues, PR #1640 metadata, complete current Development links, revision-bound criterion verification, readable expected-base declarations, published integration review/overview, current target rules/checks/reviews and live board item state are missing. The first gap for each requested result is stated in result.md. The procedure stops before external writes, branch update/push, publication, dispatch, ready/board changes, merge and closure.

Only temporary scratch under `/tmp/w04-linked-sync-walk1` was written. No source, repository, git, remote, issue, PR, board, planning record or memory was changed. No peer or memory material was inspected. The parent received progress messages about my own run; I did not inspect peer messages or findings.

## Unused and repeated retrieval

- The top-level entry's unrelated modes were received because SKILL.md was read whole. Sync's explicit prerequisites were loaded whole once, then reused at the same immutable revision.
- Large artifacts such as Issue and Pull Request contain commands and operations this bounded request never executes. Lane, Dependency Graph, Delivery Plan and Hot-fix were read as transitive context; much of their detail was unused. This is retrieval overhead, not evidence that this run exercised those systems.
- No complete source document was reread successfully. The failed initial sandbox invocations did not produce helper ledger entries. Captured epic/task saved emissions were projected once for recovery; integration's saved emission was projected once for concise reassessment. The helper ledger itself was read to locate those emissions.
- Planning Records was the single heading-only content read. Configuration's heading index was read afterward to confirm it has no prerequisite section; Theme Boards, Proposals Board, Themes and Standup configuration bodies were not loaded.
- other-reads.txt records non-helper reads. The table below is generated from the helper ledger in actual emission order; it describes emitted source ranges, with the JSON receipt qualification above.

## Actual source read order

| Order | Source relative to captured root | Section | Emitted lines | Saved characters |
| --- | --- | --- | --- | --- |
| 1 | IDENTITY.txt | Whole document | 1-2 | 142 |
| 2 | skills/work-planner/SKILL.md | Whole document | 1-81 | 4466 |
| 3 | skills/work-planner/rules.md | Whole document | 1-10 | 1515 |
| 4 | skills/work-planner/conventions.md | Whole document | 1-29 | 2531 |
| 5 | skills/work-planner/modes/sync-mode.md | Whole document | 1-193 | 16976 |
| 6 | captured/epic.json | Whole document | 1-1 | 12631 |
| 7 | captured/merged-pr.json | Whole document | 1-1 | 19758 |
| 8 | captured/integration-pr.json | Whole document | 1-1 | 17860 |
| 9 | skills/work-planner/artifacts/issue.md | Whole document | 1-531 | 22268 |
| 10 | skills/work-planner/artifacts/issue-body.md | Whole document | 1-265 | 12740 |
| 11 | skills/work-planner/references/requirement-characteristics.md | Whole document | 1-59 | 2848 |
| 12 | skills/work-planner/artifacts/acceptance-criteria.md | Whole document | 1-86 | 5804 |
| 13 | skills/work-planner/artifacts/task-body.md | Whole document | 1-92 | 3182 |
| 14 | skills/work-planner/artifacts/pull-request.md | Whole document | 1-700 | 33393 |
| 15 | skills/work-planner/artifacts/delivery-evidence.md | Whole document | 1-46 | 3132 |
| 16 | skills/work-planner/artifacts/epic.md | Whole document | 1-116 | 9914 |
| 17 | skills/work-planner/artifacts/epic-issue-body.md | Whole document | 1-369 | 25922 |
| 18 | skills/work-planner/artifacts/initiative-issue-body.md | Whole document | 1-250 | 13168 |
| 19 | skills/work-planner/artifacts/board.md | Whole document | 1-339 | 12361 |
| 20 | skills/work-planner/artifacts/work-item.md | Whole document | 1-74 | 3122 |
| 21 | skills/work-planner/modes/understand-mode.md | Whole document | 1-33 | 1306 |
| 22 | skills/work-planner/artifacts/board-delivery.md | Whole document | 1-141 | 10642 |
| 23 | skills/work-planner/protocols/issue-closure.md | Whole document | 1-71 | 2981 |
| 24 | skills/work-planner/protocols/review-pull-request.md | Whole document | 1-58 | 3277 |
| 25 | skills/work-planner/protocols/epic-integration.md | Whole document | 1-63 | 5456 |
| 26 | skills/work-planner/artifacts/plan-change.md | Whole document | 1-66 | 3101 |
| 27 | skills/work-planner/artifacts/agent-review.md | Whole document | 1-45 | 3685 |
| 28 | skills/work-planner/artifacts/delivery-branches.md | Whole document | 1-436 | 19020 |
| 29 | skills/work-planner/artifacts/pull-request-body.md | Whole document | 1-153 | 8544 |
| 30 | skills/work-planner/artifacts/planning-record.md | Whole document | 1-159 | 5943 |
| 31 | skills/work-planner/protocols/change-overview.md | Whole document | 1-66 | 3592 |
| 32 | skills/work-planner/artifacts/lane.md | Whole document | 1-109 | 4135 |
| 33 | skills/work-planner/artifacts/dependency-graph.md | Whole document | 1-178 | 13637 |
| 34 | skills/work-planner/artifacts/delivery-plan.md | Whole document | 1-90 | 8530 |
| 35 | skills/work-planner/artifacts/hotfix.md | Whole document | 1-132 | 7791 |
| 36 | skills/work-planner/configuration.md | Planning Records | 27-30 | 101 |

Ledger totals: 36 successful helper emissions; 325474 saved characters. These are emission counts, not actual model-input token counts or performance measurements.

Two final inventory-generation commands were blocked before execution: the composition hook rejected literal Markdown backticks in a Python output string, then the interpreter hook rejected an unsandboxed inline interpreter. The sandboxed version without backticks succeeded. These were hook rejections, not automatic permission-review rejections.
