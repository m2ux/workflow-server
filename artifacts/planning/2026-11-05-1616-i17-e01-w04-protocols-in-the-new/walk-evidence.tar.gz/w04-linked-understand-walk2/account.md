# Understand rehearsal account

## Result and limits

- Produced `outline.md`, a captured-metadata reviewer outline with exact evidence/recovery/publication procedure, and this account under authorized `/tmp` scratch.
- Source identity: base `238b652aaa52057f66c86c9651c379296a7ba5b2`; recorded manifest SHA256 `fd0ad01dcc101d42d6eab4c32192f4140805d52c06db9db06834bd7be09e400c`. Manifest not independently verified.
- Applied the captured Work Planner Understand route: entry point → rules/conventions → Understand → Change Overview → artifact requirements. No mode/protocol operations were executed against a repository or tracker.
- No source/git/remote mutation, checkout/index creation, external write, dispatch or publication occurred. Only this rehearsal's scratch/logger files were written.
- No claim of measured architecture, a completed published overview, full-workflow execution, token savings or performance follows from these reads.

## Actual source-document reads

All paths below are relative to `/tmp/w04-linked-walk-source/`. `whole` means the full logger-selected source range was emitted; receipt qualifications follow the table. The exact command form was:

`/home/mike1/projects/dev/md-composer/scripts/sbx python3 /tmp/w04-neutral-read.py --log /tmp/w04-linked-understand-walk2/reads [--heading 'Planning Records'] <absolute-source-path>`

Every successful source read used `sandbox_permissions=require_escalated` after the initial namespace failure. `reads/reads.jsonl` records each source/range, output file, lines and characters. Invocation order below groups concurrent returns in request order; the JSONL records completion order.

| Read | Source | Selected range | Receipt/use |
| --- | --- | --- | --- |
| 1 | IDENTITY.txt | whole, 1–2 | Complete identity |
| 2 | skills/work-planner/SKILL.md | whole, 1–81 | Complete entry point |
| 3 | captured/merged-pr.json | whole, 1–1 | Complete captured PR JSON |
| 4 | skills/work-planner/rules.md | whole, 1–10 | Complete shared rules |
| 5 | skills/work-planner/conventions.md | whole, 1–29 | Complete shared conventions |
| 6 | skills/work-planner/modes/understand-mode.md | whole, 1–33 | Complete selected mode |
| 7 | skills/work-planner/protocols/change-overview.md | whole, 1–66 | Complete procedure |
| 8 | skills/work-planner/artifacts/pull-request.md | whole emitted, 1–700 | Aggregate receipt truncated; recovered in read 11 |
| 9 | skills/work-planner/artifacts/delivery-branches.md | whole emitted, 1–436 | Aggregate truncation made complete receipt uncertain; recovered in read 12 |
| 10 | skills/work-planner/artifacts/repository-graph.md | whole, 1–128 | Complete graph contract visible in aggregate receipt |
| 11 | skills/work-planner/artifacts/pull-request.md | whole, 1–700 | Complete recovery received individually |
| 12 | skills/work-planner/artifacts/delivery-branches.md | whole, 1–436 | Complete recovery received individually |
| 13 | skills/work-planner/artifacts/planning-record.md | whole, 1–159 | Complete record/publication requirements |
| 14 | skills/work-planner/artifacts/architecture-overview.md | whole, 1–165 | Complete output/evidence contract |
| 15 | skills/work-planner/artifacts/pull-request-body.md | whole, 1–153 | Complete linking/body requirements |
| 16 | skills/work-planner/artifacts/issue.md | whole, 1–531 | Complete inherited prerequisite; most operations unused |
| 17 | skills/work-planner/artifacts/agent-review.md | whole, 1–45 | Complete inherited prerequisite; operations unused |
| 18 | skills/work-planner/artifacts/hotfix.md | whole, 1–132 | Complete inherited prerequisite; operations unused |
| 19 | skills/work-planner/artifacts/work-item.md | whole, 1–74 | Complete inherited prerequisite; operations unused |
| 20 | skills/work-planner/configuration.md | Planning Records, 27–30 | Complete linked section and boundary |
| 21 | skills/work-planner/artifacts/issue-body.md | whole, 1–265 | Complete inherited prerequisite; most operations unused |

## Truncation and recovery

- The first batch of Pull Request, Delivery Branches and Repository Graph produced a functions.exec aggregate warning: original 14,482 tokens, output truncated. Logger output files contained complete selected emissions, while the assistant's visible result included an omission within the Pull Request/Delivery Branches serialized text.
- Those stored emissions were not counted as complete actual receipt. Both large documents were reread individually with explicit outer output budgets (12,000 and 10,000 tokens), returning complete 8,349-token and 4,755-token document outputs without a truncation warning.
- Repository Graph's complete 921-token text was visible in the first result and was reused without a second read. Later batches fit their explicit outer budgets; no additional truncation warning appeared.
- Repeated retrieval consists of the two whole-document recovery reads. They repeat some already-visible content as well as recovering the uncertain/missing text. No read was repeated merely to establish a performance claim.

## Correctness and authority gaps

- The source snapshot's base/PR merge commit is distinct from the captured PR head. Neither a snapshot base nor a captured head establishes the current PR head or indexed review revision.
- Aggregate changed-file counts cannot establish changed paths, symbols, component edges or flow order. Captured body claims about preservation and tests were labelled as claims, not independently verified results.
- The procedure requires fresh metadata, exact-head detached review evidence, a base-relative graph change surface, symbol contexts, ordered flow traces, response-by-response staleness checks and pinned line links. None was fabricated from document headings or directory structure.
- Changed FETCH_HEAD requires a new metadata read before checkout creation. A dirty/mismatching existing review checkout is retained and an unused commit-suffixed path selected. A behind index invalidates measurements, requiring reindex and affected measurement repeats; changed revision rebuilds PR/worktree evidence. Unresolved freshness stops overview writing.
- Publication requires writes to the engineering record, a shared-index commit/push and an existing PR-body patch with readback. These operations were described, not attempted. No existing-record absence was inferred from its not being supplied.

## Bounded prerequisite disclosure

- The direct six Change Overview artifact documents were received in full. Several pull in unrelated operation families through whole-document prerequisites; those reads were not treated as authorization to execute them.
- This rehearsal stopped expanding after receiving Issue, Agent Review, Hot-fix, Work Item and Issue Body. It did not read the full remaining Hot-fix prerequisite documents: Hot-fix Body, Board, Board Delivery, Placement and Repository Labels. Their headings alone were searched to characterize the boundary.
- Issue Body also requires `references/requirement-characteristics.md`, whose headings alone were searched. Prerequisites of the unread documents were not fully discovered. Accordingly this is not complete transitive prerequisite disclosure and is not execution-ready certification of the entire workflow.
- Configuration's heading search shows no Prerequisites section; only the applicable Planning Records section was read as content. Other configuration windows were not required by the selected direct overview route.
- Broad unused retrieval came from whole-document requirements: merge, delivery-link, issue closure, hot-fix, board-delivery references, review-readiness and task-work-item instructions do not establish this overview's architecture evidence. Complete common prerequisites already received at the same snapshot were reused.

`other-reads.txt` records the prompt, helper discovery, failures, directory listings, heading search and own-log read. The source read log is evidence of selected/stored emissions; this account separately records actual receipt and recovery.
