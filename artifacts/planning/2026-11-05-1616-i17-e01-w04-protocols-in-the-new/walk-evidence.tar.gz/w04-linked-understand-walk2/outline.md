# PR #1642: bounded reviewer outline

This is a captured-metadata explanation and a procedure outline, not a measured or published architecture overview.

## Captured identity

- PR: https://github.com/m2ux/workflow-server/pull/1642
- Title: `[I17:E01] Common Files: Rules, Conventions and Configuration`.
- Captured state: closed and merged on 2026-11-05 at 09:23:37Z.
- Captured head: `83ac545a0c9f37cf545fd17ce945c27dd6a0ddd2`, branch `i17/e01/w02-rules-conventions-and-configuration`.
- Captured base: `dd44528b3fdea032c4128e1e0f638d038261498a`, branch `i17/e01/workspace`.
- Captured merge commit and source snapshot base: `238b652aaa52057f66c86c9651c379296a7ba5b2`.
- Metadata reports one commit, ten changed files, 108 additions and 70 deletions. Those are captured aggregate fields, not an independently obtained change surface.
- Snapshot identity reports manifest SHA256 `fd0ad01dcc101d42d6eab4c32192f4140805d52c06db9db06834bd7be09e400c`; this rehearsal did not recompute it.

## Explanation supported by the capture

- **Common context.** The PR body says Work Planner loads separate rules and conventions before mode selection. The captured entry point contains that requirement; it lists modes and dependencies separately.
- **Deployment values.** The body says configuration centralizes board titles and fields, planning placement and the reporting default, with project identities labelled examples. The retrieved Planning Records section specifies `artifacts/planning/` on `engineering`.
- **Reader routes.** The body describes conditional configuration reads for proposal selection, board creation and omitted reporting starts; it also names guideline and checkout-vocabulary-test consumers. Their actual diff and runtime effect were not inspected here.
- **Validation claims.** The captured body links five passing test-plan rows, including preservation checks, Work Planner/shared checker suites and repeated reading routes. These are claims and links in captured metadata, not test results independently verified in this rehearsal. The body itself describes partial full-workflow disclosure.

## Proposed overview sections

1. **Summary:** the entry point selects a mode after shared context; deployed values have a documented home.
2. **Structure:** entry point, common rules, conventions and applicable configuration consumers. Populate actual component boundaries and labelled edges only after measuring the requested head; directory layout alone cannot establish them.
3. **Behaviour:** shared-context loading and the conditional configuration routes reported by the body. Require measured ordered flows before drawing sequence diagrams; a hand-traced read order is not a graph trace.
4. **What Changed:** group verified behaviour by common context, deployment values and reader contracts, linking the PR's Changes rather than duplicating its listing.
5. **Reading Order:** tentative starting point is `skills/work-planner/SKILL.md`, followed by its linked rules/conventions and relevant configuration consumers. Finalize from the actual diff and measured relationships. Every selected file needs a head-pinned permalink with line anchors; no such review links are asserted here.
6. **Risks and Watch Points:** preservation of operative conditions and command bodies; conditional-route reachability; stale graph/head evidence; the validation body's explicitly partial disclosure.

The complete artifact requires a structural diagram and a sequence diagram for every measured flow, five to ten elements per diagram, consistent names/fills, labelled interactions and grey untouched context. Include before/after structure if measured evidence warrants it. This bounded outline supplies no invented measured diagram.

## Exact procedure to obtain the missing evidence

These are instructions for a later authorized run, not executed commands.

1. Run Understand in the project checkout `/home/mike1/projects/dev/workflow-server`, selecting the supplied PR URL. Read the remaining prerequisite documents described in account.md before executing their operations. Before the first `gh` call, unset `GH_TOKEN` and `GITHUB_TOKEN`, or confirm neither is set where shell state does not persist.
2. Apply Read Pull Request State / Save Pull Request Snapshot: `gh api 'repos/m2ux/workflow-server/pulls/1642' > '<snapshot.json>'`. Obtain current identity, title, base and literal verified head; captured metadata cannot substitute for this.
3. Apply Create Pull Request Worktree in the project checkout: `git fetch origin 'pull/1642/head'`, then `git -C '<project>' rev-parse 'FETCH_HEAD^{commit}'`. A mismatch with the verified head returns a changed-head finding before creating a checkout. Re-read PR state and retry with its new head.
4. Select `/home/mike1/projects/dev/workflow-server/.worktrees/pr/1642`. If present, inspect `HEAD^{commit}` and `git status --porcelain --branch`; reuse only a clean detached checkout at the verified head, including no untracked files. Preserve a mismatching/dirty checkout and choose an unused path suffixed with the verified commit. For an unused path, `git worktree add --detach '<review-path>' '<verified-head>'`, then confirm HEAD.
5. Only after matching the head, apply Read Pull Request State for changed paths: `gh api --paginate 'repos/m2ux/workflow-server/pulls/1642/files' --jq '.[].filename' > '<changed-paths.txt>'` alongside its metadata snapshot.
6. Apply Measure Repository Change entirely in that review checkout: `gitnexus status`; if unindexed or behind, `gitnexus analyze` and confirm freshness. Then `gitnexus detect-changes --scope compare --base-ref '<verified-base-branch>'`; run `gitnexus context '<changed-symbol>'` for every changed symbol and `gitnexus query --query '<reported-flow>' --limit 1` for every reported flow. Require worktree/indexed-commit identity and `process_symbols` with step indices, files and lines.
7. Inspect every response's `staleness` block. Discard behind-index measurements, reindex and repeat affected measurements; Change Overview calls Measure Repository Change again after its index update. If revision changes, re-read PR state and rebuild worktree evidence. Return any unresolved freshness blocker before writing the overview.

## Recording and publication, requiring broader authority

- Locate an existing overview record for PR 1642 first; none was supplied or searched for here. Reuse its folder identity if found, replacing only the overview and preserving other record content. Otherwise choose `<yyyy-mm-dd>-1642-<title-slug>/` under the engineering checkout's configured `artifacts/planning/`; do not assume a new record is needed.
- Populate Planning Record and Architecture Overview with measured structure/flows, verified head, anchored code permalinks and output path. The README has its creation header, two-paragraph executive summary, the overview as its one Artifacts row and PR under Links.
- Publish Planning Record from the existing engineering worktree `/home/mike1/projects/dev/workflow-server/.engineering`. Its prescribed command stages the whole shared worktree, commits pending changes using an external message file, fetches/rebases `origin/engineering`, then uses `git push`. Confirm this record's own files reached the remote; report a rebase conflict rather than rewriting the branch.
- Only after publication resolves, Link Architecture Overview in the current PR body's References at the template position. Preserve an existing overview row and the rest of the body. The captured body already has R1 Delivery record; select a suitable nonconflicting reference rather than replacing it. Publish Pull Request patches the whole body through a file (`-F body=@file`) and re-reads saved state.
- Return PR URL, reused/new record folder, published overview, diagrams and the actual References row. This rehearsal has none of those publication results.

## What prevents completion

- **Evidence:** no live PR-state verification, prepared review checkout, changed-path list, diff, head-pinned code anchors, graph index freshness, measured symbol relationships/flows or existing-overview lookup was supplied or obtained.
- **Authority:** fetching changes git state; checkout creation, indexing, repository record writes, commits/pushes and PR-body publication exceed the read-only scope. They were described and not run. The captured merge state does not authorize these actions.
- **Instruction disclosure:** the inherited whole-document prerequisite fanout was bounded, with exact unread dependencies listed in account.md. The direct mode/protocol and six direct artifact prerequisites were received, including recovery of a truncated aggregate response; this does not establish a fully executed workflow.
